    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.movz       s7, #15
    s.sub        s10, s8, s9
    s.rdspecial  s8, pid.x
    s.movz       s9, #0
    s.add        s11, s3, s2
    s.ld.sw      s12, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.rdspecial  s5, pid.y
    s.xor        s13, s11, s14
    s.movz       s11, #16
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s17, s11, s13
    s.add        s13, s12, s7
    s.sub        s7, s16, s17
    s.cmp.lt     s16, s13, s9
    s.xor        s9, s11, s7
    s.sub        s17, s4, s16
    s.ld.d       s4, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.xor        s16, s13, s17
    s.xor        s13, s17, s7
    s.sub        s18, s16, s17
    s.xor        s16, s6, s10
    s.lshri      s17, s18, #4
    s.sub        s19, s9, s7
    s.muli       s7, s17, #16
    s.xor        s9, s17, s13
    s.sub        s17, s9, s13
    s.ld.d       s9, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.sub        s13, s18, s7
    s.sub        s7, s16, s10
    s.ld.d       s7, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.lshri      s13, s15, #7
    s.ld.d       s16, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.muli       s18, s13, #128
    s.ld.d       s19, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s20, s14, s10
    s.sub        s10, s15, s18
    s.xor        s10, s13, s20
    s.ld.sw      s13, [s1, #56]                  // K: i32 at arg_base+56
    s.sub        s14, s10, s20
    s.ld.sw      s10, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.mul        s15, s8, s14
    s.ld.sw      s8, [s1, #72]                   // stride_bn: i32 at arg_base+72
    s.add        s18, s15, s5
    s.ld.sw      s5, [s1, #80]                   // stride_cm: i32 at arg_base+80
    s.movz       s15, #8
    s.ld.sw      s20, [s1, #88]                  // stride_bs_n: i32 at arg_base+88
    s.mul        s1, s14, s15
    s.movz       s14, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s1, s14
    s.cmp.lt     s14, s18, s21
    s.sub        s21, s22, s24
    s.sub        s22, s23, s14
    s.xor        s14, s1, s21
    s.xor        s23, s18, s22
    s.sub        s24, s14, s21
    s.movz       s14, #0
    s.movz       s25, #1
    s.sub        s26, s23, s22
    s.movz       s23, #0
    s.addi       s27, s14, #0
    s.cmp.eq     s14, s24, s25
    s.addi       s25, s23, #0
    s.mov        s27, s26
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s23, #31
    s.mov        s27, s14
    s.addi       s14, s23, #0
sdiv_2:
    s.lshr       s23, s26, s14
    s.shli       s28, s25, #1
    s.andi       s29, s23, #1
    s.movz       s23, #0
    s.or         s30, s28, s29
    s.movz       s28, #1
    s.cmp.geu    s29, s30, s24
    s.shl        s31, s28, s14
    s.sub        s28, s23, s29
    s.subi       s23, s14, #1
    s.and        s29, s24, s28
    s.and        s32, s31, s28
    s.sub        s28, s30, s29
    s.or         s29, s27, s32
    s.mov        s25, s28
    s.mov        s27, s29
    s.mov        s14, s23
    s.movz       s23, #0
    s.cmp.ge     s28, s14, s23
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s14, s22, s21
    s.movz       s21, #0
    s.xor        s22, s27, s14
    s.movz       s23, #0
    s.movz       s24, #0
    s.cmp.lt     s25, s1, s21
    s.sub        s21, s22, s14
    s.movz       s14, #0
    s.cmp.lt     s22, s18, s23
    s.sub        s23, s24, s25
    s.mul        s24, s21, s15
    s.sub        s21, s14, s22
    s.xor        s14, s1, s23
    s.xor        s1, s18, s21
    s.sub        s18, s14, s23
    s.movz       s14, #0
    s.movz       s22, #1
    s.sub        s23, s17, s24
    s.sub        s17, s1, s21
    s.movz       s1, #0
    s.addi       s25, s14, #0
    s.cmp.eq     s14, s18, s22
    s.min.s      s22, s23, s15
    s.addi       s15, s1, #0
    s.mov        s25, s17
    br.nz        s14, sdiv_done_3
    s.movz       s1, #0
    s.movz       s14, #31
    s.mov        s25, s1
    s.addi       s1, s14, #0
sdiv_4:
    s.lshr       s14, s17, s1
    s.shli       s23, s15, #1
    s.andi       s26, s14, #1
    s.movz       s14, #0
    s.or         s27, s23, s26
    s.movz       s23, #1
    s.cmp.geu    s26, s27, s18
    s.shl        s28, s23, s1
    s.sub        s23, s14, s26
    s.subi       s14, s1, #1
    s.and        s26, s18, s23
    s.and        s29, s28, s23
    s.sub        s23, s27, s26
    s.or         s26, s25, s29
    s.mov        s15, s23
    s.mov        s25, s26
    s.mov        s1, s14
    s.movz       s14, #0
    s.cmp.ge     s23, s1, s14
    br.nz        s23, sdiv_4
sdiv_done_3:
    s.xor        s1, s15, s21
    s.movz       s14, #0
    s.sub        s15, s1, s21
    s.movz       s1, #0
    s.movz       s17, #0
    s.cmp.lt     s18, s22, s14
    s.movz       s14, #0
    s.cmp.lt     s21, s15, s1
    s.sub        s1, s17, s18
    s.sub        s17, s14, s21
    s.xor        s14, s22, s1
    s.xor        s18, s15, s17
    s.sub        s21, s14, s1
    s.movz       s1, #0
    s.movz       s14, #1
    s.sub        s23, s18, s17
    s.movz       s18, #0
    s.addi       s25, s1, #0
    s.cmp.eq     s1, s21, s14
    s.addi       s14, s18, #0
    s.mov        s25, s23
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s18, #31
    s.mov        s25, s1
    s.addi       s1, s18, #0
sdiv_6:
    s.lshr       s18, s23, s1
    s.shli       s26, s14, #1
    s.andi       s27, s18, #1
    s.movz       s18, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s21
    s.shl        s29, s26, s1
    s.sub        s26, s18, s27
    s.subi       s18, s1, #1
    s.and        s27, s21, s26
    s.and        s30, s29, s26
    s.sub        s26, s28, s27
    s.or         s27, s25, s30
    s.mov        s14, s26
    s.mov        s25, s27
    s.mov        s1, s18
    s.movz       s18, #0
    s.cmp.ge     s26, s1, s18
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s18, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s22, s1
    s.movz       s1, #0
    s.cmp.lt     s25, s15, s18
    s.sub        s18, s21, s23
    s.sub        s21, s1, s25
    s.xor        s1, s22, s18
    s.xor        s22, s14, s17
    s.xor        s14, s15, s21
    s.sub        s15, s1, s18
    s.movz       s1, #0
    s.movz       s23, #1
    s.sub        s25, s22, s17
    s.sub        s17, s14, s21
    s.movz       s14, #0
    s.addi       s22, s1, #0
    s.cmp.eq     s1, s15, s23
    s.add        s23, s24, s25
    s.addi       s24, s14, #0
    s.mov        s22, s17
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s14, #31
    s.mov        s22, s1
    s.addi       s1, s14, #0
sdiv_8:
    s.lshr       s14, s17, s1
    s.shli       s25, s24, #1
    s.andi       s26, s14, #1
    s.movz       s14, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s15
    s.shl        s28, s25, s1
    s.sub        s25, s14, s26
    s.subi       s14, s1, #1
    s.and        s26, s15, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s22, s29
    s.mov        s24, s25
    s.mov        s22, s26
    s.mov        s1, s14
    s.movz       s14, #0
    s.cmp.ge     s25, s1, s14
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.mul        s1, s23, s11
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.movi       v2, #0
    s.xor        s14, s21, s18
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s15, s22, s14
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s17, s15, s14
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s14, #31
idiv_9:
    v.splat      v5, s14
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s15, s14, #1
    v.and        v5, v8, v3
    s.movz       s18, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s14, s15
    s.cmp.ge     s15, s14, s18
    br.nz        s15, idiv_9
    s.mul        s14, s17, s6
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s14
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v4
    v.add        v2, v1, v3
    v.add        v1, v5, v7
    v.add        v3, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s14
    v.splat      v11, s14
    v.splat      v12, s14
    v.splat      v13, s14
    v.splat      v14, s14
    v.splat      v15, s14
    v.splat      v16, s14
    @p2 v.sel        v17, v6, v4
    v.movi       v4, #0
    v.add        v6, v10, v2
    v.add        v2, v11, v1
    v.sub        v1, v4, v18
    v.sub        v10, v4, v0
    v.cmp.lt     p1, v18, v4
    v.cmp.lt     p2, v0, v4
    v.add        v11, v12, v3
    v.add        v3, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v1, v18
    @p2 v.sel        v1, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s15, #31
idiv_10:
    v.splat      v18, s15
    v.shl        v22, v10, v20
    v.cmp.lt     p2, v10, v4
    v.lshr       v23, v21, v18
    v.shl        v24, v20, v18
    s.subi       s17, s15, #1
    v.and        v18, v23, v20
    s.movz       s18, #0
    v.or         v23, v22, v18
    v.cmp.geu    p3, v23, v1
    p.or         p4, p2, p3
    v.sub        v18, v23, v1
    @p4 v.sel        v22, v24, v4
    @p4 v.sel        v24, v18, v23
    v.or         v18, v0, v22
    v.mov        v10, v24
    v.mov        v0, v18
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_10
    v.movi       v0, #0
    v.sub        v1, v4, v10
    v.movi       v4, #1
    v.sub        v18, v0, v6
    v.sub        v20, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v21, v1, v10
    @p2 v.sel        v1, v18, v6
    @p3 v.sel        v6, v20, v9
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v18, s15
    v.shl        v20, v10, v4
    v.cmp.lt     p1, v10, v0
    v.lshr       v22, v1, v18
    v.shl        v23, v4, v18
    s.subi       s17, s15, #1
    v.and        v18, v22, v4
    s.movz       s18, #0
    v.or         v22, v20, v18
    v.cmp.geu    p3, v22, v6
    p.or         p4, p1, p3
    v.sub        v18, v22, v6
    @p4 v.sel        v20, v23, v0
    @p4 v.sel        v23, v18, v22
    v.or         v18, v9, v20
    v.mov        v10, v23
    v.mov        v9, v18
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_11
    v.movi       v1, #0
    v.sub        v4, v0, v10
    v.movi       v0, #1
    v.sub        v6, v1, v2
    v.sub        v9, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v18, v4, v10
    @p1 v.sel        v4, v6, v2
    @p3 v.sel        v2, v9, v12
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s15, #31
idiv_12:
    v.splat      v10, s15
    v.shl        v12, v9, v0
    v.cmp.lt     p2, v9, v1
    v.lshr       v20, v4, v10
    v.shl        v22, v0, v10
    s.subi       s17, s15, #1
    v.and        v10, v20, v0
    s.movz       s18, #0
    v.or         v20, v12, v10
    v.cmp.geu    p3, v20, v2
    p.or         p4, p2, p3
    v.sub        v10, v20, v2
    @p4 v.sel        v12, v22, v1
    @p4 v.sel        v22, v10, v20
    v.or         v10, v6, v12
    v.mov        v9, v22
    v.mov        v6, v10
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v9
    v.movi       v1, #1
    v.sub        v4, v0, v11
    v.sub        v6, v0, v13
    v.cmp.lt     p2, v11, v0
    v.cmp.lt     p3, v13, v0
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v4, v11
    @p3 v.sel        v4, v6, v13
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s15, #31
idiv_13:
    v.splat      v11, s15
    v.shl        v12, v9, v1
    v.cmp.lt     p1, v9, v0
    v.lshr       v13, v2, v11
    v.shl        v20, v1, v11
    s.subi       s17, s15, #1
    v.and        v11, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v11
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v11, v13, v4
    @p4 v.sel        v12, v20, v0
    @p4 v.sel        v20, v11, v13
    v.or         v11, v6, v12
    v.mov        v9, v20
    v.mov        v6, v11
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v4, v1, v3
    v.sub        v6, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v11, v2, v9
    @p1 v.sel        v2, v4, v3
    @p3 v.sel        v3, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s15, #31
idiv_14:
    v.splat      v9, s15
    v.shl        v12, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v13, v2, v9
    v.shl        v14, v0, v9
    s.subi       s17, s15, #1
    v.and        v9, v13, v0
    s.movz       s18, #0
    v.or         v13, v12, v9
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v9, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v9, v13
    v.or         v9, v4, v12
    v.mov        v6, v14
    v.mov        v4, v9
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v15
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v15, v0
    @p1 v.sel        v9, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v15
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_15:
    v.splat      v6, s15
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v6
    v.shl        v14, v1, v6
    s.subi       s17, s15, #1
    v.and        v6, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v6
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v6, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v6, v13
    v.or         v6, v4, v12
    v.mov        v5, v14
    v.mov        v4, v6
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v16, v1
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v7
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_16:
    v.splat      v7, s15
    v.shl        v12, v5, v0
    v.cmp.lt     p2, v5, v1
    v.lshr       v13, v2, v7
    v.shl        v14, v0, v7
    s.subi       s17, s15, #1
    v.and        v7, v13, v0
    s.movz       s18, #0
    v.or         v13, v12, v7
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v7, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v7, v13
    v.or         v7, v4, v12
    v.mov        v5, v14
    v.mov        v4, v7
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v19
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v19, v0
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v19
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_17:
    v.splat      v8, s15
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v8
    v.shl        v14, v1, v8
    s.subi       s17, s15, #1
    v.and        v8, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v8
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v8, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v8, v13
    v.or         v8, v4, v12
    v.mov        v5, v14
    v.mov        v4, v8
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_17
    v.sub        v1, v0, v5
    v.movi       v0, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v5
    v.movi       v1, #0
    v.movi       v4, #0
    v.sub        v5, v0, v21
    v.sub        v8, v2, v18
    v.sub        v12, v1, v10
    v.cmp.lt     p1, v21, v0
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v10, v1
    @p1 v.sel        v13, v5, v21
    v.movi       v5, #7
    @p2 v.sel        v14, v8, v18
    v.movi       v8, #7
    @p3 v.sel        v15, v12, v10
    v.movi       v12, #7
    v.lshr       v16, v13, v5
    v.lshr       v5, v14, v8
    v.lshr       v8, v15, v12
    v.movi       v12, #128
    v.sub        v13, v0, v16
    v.movi       v14, #128
    v.sub        v15, v2, v5
    v.movi       v19, #128
    v.sub        v20, v1, v8
    v.movi       v22, #128
    v.sub        v23, v0, v12
    @p1 v.sel        v24, v13, v16
    v.sub        v13, v2, v14
    @p2 v.sel        v16, v15, v5
    v.sub        v5, v1, v19
    @p3 v.sel        v15, v20, v8
    v.cmp.lt     p1, v12, v0
    v.cmp.lt     p2, v14, v2
    v.cmp.lt     p3, v19, v1
    s.movz       s15, #32
    s.movz       s17, #48
    s.movz       s18, #64
    v.sub        v0, v4, v11
    s.movz       s21, #80
    s.movz       s22, #96
    v.sub        v1, v4, v22
    s.movz       s23, #112
    v.movi       v2, #7
    v.movi       v8, #1
    v.movi       v8, #0
    v.movi       v20, #128
    @p1 v.sel        v25, v23, v12
    v.sub        v12, v8, v9
    v.cmp.lt     p1, v11, v4
    @p1 v.sel        v23, v0, v11
    v.movi       v0, #7
    v.sub        v25, v8, v20
    v.lshr       v26, v23, v2
    v.movi       v2, #1
    v.movi       v2, #0
    v.sub        v23, v4, v26
    v.movi       v27, #128
    @p2 v.sel        v28, v13, v14
    v.sub        v13, v2, v6
    v.cmp.lt     p2, v9, v8
    @p2 v.sel        v14, v12, v9
    v.movi       v12, #7
    @p1 v.sel        v28, v23, v26
    v.cmp.lt     p1, v6, v2
    @p1 v.sel        v23, v13, v6
    v.lshr       v13, v14, v0
    v.sub        v0, v2, v27
    v.lshr       v14, v23, v12
    v.sub        v12, v8, v13
    v.movi       v23, #1
    v.movi       v23, #0
    v.sub        v26, v2, v14
    @p2 v.sel        v29, v12, v13
    v.cmp.lt     p2, v7, v23
    v.movi       v12, #128
    @p1 v.sel        v13, v26, v14
    v.cmp.lt     p1, v22, v4
    @p3 v.sel        v4, v5, v19
    v.sub        v4, v23, v7
    v.movi       v5, #7
    v.sub        v14, v23, v12
    @p2 v.sel        v19, v4, v7
    v.cmp.lt     p3, v20, v8
    v.movi       v4, #1
    v.movi       v4, #0
    v.lshr       v8, v19, v5
    v.movi       v5, #128
    @p1 v.sel        v19, v1, v22
    v.sub        v1, v4, v3
    v.cmp.lt     p1, v3, v4
    v.movi       v19, #7
    @p1 v.sel        v22, v1, v3
    v.sub        v1, v23, v8
    v.movi       v26, #1
    v.lshr       v26, v22, v19
    @p2 v.sel        v19, v1, v8
    v.sub        v1, v4, v5
    v.sub        v8, v4, v26
    v.cmp.lt     p2, v27, v2
    v.splat      v2, s20
    @p1 v.sel        v22, v8, v26
    v.splat      v8, s20
    v.cmp.lt     p1, v12, v23
    v.splat      v23, s20
    @p3 v.sel        v26, v25, v20
    v.splat      v20, s20
    v.splat      v25, s20
    v.cmp.lt     p3, v5, v4
    v.splat      v4, s20
    v.movi       v26, #1
    @p2 v.sel        v26, v0, v27
    s.add        s24, s13, s2
    s.movz       s2, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s2
    s.movz       s2, #0
    s.sub        s27, s25, s26
    s.movz       s25, #0
    v.splat      v0, s20
    v.splat      v26, s20
    v.movi       v27, #1
    s.xor        s20, s24, s27
    s.cmp.lt     s24, s6, s2
    s.sub        s2, s20, s27
    s.sub        s20, s25, s24
    @p1 v.sel        v27, v14, v12
    s.lshri      s24, s2, #7
    s.xor        s25, s27, s20
    s.muli       s26, s24, #128
    s.xor        s27, s6, s20
    s.xor        s28, s24, s25
    s.movz       s24, #0
    v.movi       v12, #1
    s.movz       s29, #0
    s.movz       s30, #0
    @p3 v.sel        v12, v1, v5
    v.mul        v1, v24, v2
    v.mul        v2, v16, v8
    v.mul        v5, v15, v23
    v.mul        v8, v28, v20
    v.mul        v12, v29, v25
    v.mul        v14, v13, v4
    v.mul        v4, v19, v0
    v.mul        v0, v22, v26
    s.ld.w       s31, [s16, #0]                  // one element, not a vector
    s.sub        s16, s27, s20
    s.sub        s16, s2, s26
    s.sub        s2, s28, s25
    s.movz       s16, #1
    s.addi       s20, s24, #0
    s.addi       s25, s29, #0
    s.addi       s26, s30, #0
    s.addi       s27, s19, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s19, s20, s2
    br.nz        s19, endfor_27
    s.mul        s19, s20, s6
    s.sub        s28, s13, s19
    v.splat      v13, s31
    v.splat      v15, s8
    v.mul        v16, v21, v15
    v.splat      v15, s8
    v.mul        v19, v18, v15
    v.splat      v15, s8
    v.mul        v20, v10, v15
    v.splat      v15, s8
    v.mul        v22, v11, v15
    v.splat      v15, s8
    v.mul        v23, v9, v15
    v.splat      v15, s8
    v.mul        v24, v6, v15
    v.splat      v15, s8
    v.mul        v25, v7, v15
    v.splat      v15, s8
    v.mul        v26, v3, v15
    v.ld.gather.w v15, [s27, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v27, [s27, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v28, [s27, v5]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s27, v8]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s27, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s27, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s27, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s27, v0]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s24, s28
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v34                             // arange(0, VLEN)
    s.movz       s29, #16
    v.splat      v35, s29
    v.mul        v36, v34, v35
    v.iota       v34                             // arange(0, VLEN)
    v.movi       v35, #7
    v.and        v37, v34, v35
    v.movi       v34, #2
    v.shl        v35, v37, v34
    v.iota       v34                             // arange(0, VLEN)
    v.movi       v37, #3
    v.lshr       v38, v34, v37
    v.movi       v34, #0
    v.cmp.eq     p1, v38, v34
    v.iota       v34                             // arange(0, VLEN)
    v.movi       v37, #3
    v.lshr       v38, v34, v37
    v.movi       v34, #1
    v.cmp.eq     p2, v38, v34
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.rdspecial  s29, arg_base
    s.ld.d       s30, [s29, #96]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s29, s30, #0                    // 512 bytes of repack scratch
    s.muli       s32, s10, #2
    s.muli       s33, s25, #2
    v.splat      v34, s32
    v.mul        v37, v17, v34
    v.extract    s32, v37, #0
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.iota       v34                             // arange(0, VLEN)
    s.movz       s34, #0
    s.add        s35, s34, s28                   // the tile origin
    v.splat      v38, s35
    v.cmp.lt     p3, v34, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v39, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    .li       s32, #1065353216
    v.splat      v40, s32                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v41, v13, v38, v40
    vf.fms       v42, v38, v41, v38
    vf.neg       v41, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v41, v41
    @p4 v.sel        v42, v41, v38
    vf.mul       v38, v39, v42                   // a/y: faithful quotient
    vf.fms       v41, v38, v13, v39
    vf.fms       v39, v41, v42, v38
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v41, v41
    @p4 v.sel        v39, v41, v38
    vf.cvt.f32.e4m3 v38, v39
    v.movi       v41, #24
    v.lshr       v42, v39, v41
    v.movi       v39, #128
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #0
    v.st.scatter.b [s32, v36], v42
    v.extract    s32, v37, #1
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #1
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #2
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #2
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #3
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #3
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #4
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #4
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #5
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #5
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #6
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #6
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #7
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #7
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #8
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #8
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #9
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #9
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #10
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #10
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #11
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #11
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #12
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #12
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #13
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #13
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #14
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #14
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #15
    s.add        s34, s32, s33
    s.add        s32, s4, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #15
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #0
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    s.movz       s32, #0
    s.add        s35, s32, s11                   // the tile origin
    v.splat      v38, s35
    v.add        v42, v34, v38
    s.movz       s32, #0
    s.add        s35, s32, s28                   // the tile origin
    v.splat      v38, s35
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #256
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #1
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #257
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #2
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #258
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #3
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #259
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #4
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #260
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #5
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #261
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #6
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #262
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #7
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #263
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #8
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #264
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #9
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #265
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #10
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #266
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #11
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #267
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #12
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #268
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #13
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #269
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #14
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #270
    v.st.scatter.b [s32, v36], v43
    v.extract    s32, v37, #15
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s4, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s29, #271
    v.st.scatter.b [s32, v36], v43
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v38, [s29, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #64
    v.ld.w       v38, [s32, #0]
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #128
    v.ld.w       v38, [s32, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #192
    v.ld.w       v38, [s32, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #256
    v.ld.w       v38, [s32, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #320
    v.ld.w       v38, [s32, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #384
    v.ld.w       v38, [s32, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s29, #448
    v.ld.w       v38, [s32, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s19, #0
    v.splat      v38, s29
    v.sub        v42, v38, v35
    v.movi       v38, #0
    v.cmp.gt     p3, v42, v38
    v.movi       v38, #0
    v.max.s      v43, v42, v38
    v.movi       v38, #4
    v.min.s      v42, v43, v38
    v.movi       v38, #1
    v.movi       v43, #3
    v.shl        v44, v42, v43
    v.shl        v43, v38, v44
    v.movi       v38, #1
    v.sub        v44, v43, v38
    v.movi       v38, #4
    v.cmp.ge     p4, v42, v38
    v.movi       v38, #-1
    @p4 v.sel        v42, v38, v44
    s.add        s29, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s32, v16, #0
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #1
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #2
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #3
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #4
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #5
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #6
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #7
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #8
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #9
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #10
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #11
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #12
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #13
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #14
    s.add        s34, s29, s32
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s34, #0]
    v.extract    s32, v16, #15
    s.add        s34, s29, s32
    s.addi       s29, s34, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s29, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s29
    mb.wait      s29
    s.add        s32, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s34, v19, #0
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #1
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #2
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #3
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #4
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #5
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #6
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #7
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #8
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #9
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #10
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #11
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #12
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #13
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v19, #14
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s35, #0]
    v.extract    s34, v19, #15
    s.add        s35, s32, s34
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s32, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    s.add        s34, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s35, v20, #0
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #1
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #2
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #3
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #4
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #5
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #6
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #7
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #8
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #9
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #10
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #11
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #12
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #13
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v20, #14
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s36, #0]
    v.extract    s35, v20, #15
    s.add        s36, s34, s35
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s34, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s34
    mb.wait      s34
    s.add        s35, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s36, v22, #0
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #1
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #2
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #3
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #4
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #5
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #6
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #7
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #8
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #9
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #10
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #11
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #12
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #13
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v22, #14
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s37, #0]
    v.extract    s36, v22, #15
    s.add        s37, s35, s36
    s.addi       s35, s37, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s35, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s35
    mb.wait      s35
    s.add        s36, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s37, v23, #0
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #1
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #2
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #3
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #4
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #5
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #6
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #7
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #8
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #9
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #10
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #11
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #12
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #13
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v23, #14
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s38, #0]
    v.extract    s37, v23, #15
    s.add        s38, s36, s37
    s.addi       s36, s38, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s36, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s36
    mb.wait      s36
    s.add        s37, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s38, v24, #0
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #1
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #2
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #3
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #4
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #5
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #6
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #7
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #8
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #9
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #10
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #11
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #12
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #13
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v24, #14
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s39, #0]
    v.extract    s38, v24, #15
    s.add        s39, s37, s38
    s.addi       s37, s39, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s37, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s37
    mb.wait      s37
    s.add        s38, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v25, #0
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #1
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #2
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #3
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #4
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #5
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #6
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #7
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #8
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #9
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #10
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #11
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #12
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #13
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v25, #14
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s40, #0]
    v.extract    s39, v25, #15
    s.add        s40, s38, s39
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s38, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s38
    mb.wait      s38
    s.add        s39, s9, s26
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s40, v26, #0
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #1
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #2
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #3
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #4
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #5
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #6
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #7
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #8
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #9
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #10
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #11
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #12
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #13
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v26, #14
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s41, #0]
    v.extract    s40, v26, #15
    s.add        s41, s39, s40
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s39, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s39
    mb.wait      s39
    s.addi       s40, s30, #512                  // 512 bytes of repack scratch
    v.extract    s41, v37, #0
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    s.movz       s41, #0
    s.add        s43, s41, s15                   // the tile origin
    v.splat      v38, s43
    v.add        v42, v34, v38
    s.movz       s41, #0
    s.add        s43, s41, s28                   // the tile origin
    v.splat      v38, s43
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #0
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #1
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #1
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #2
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #2
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #3
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #3
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #4
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #4
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #5
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #5
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #6
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #6
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #7
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #7
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #8
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #8
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #9
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #9
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #10
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #10
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #11
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #11
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #12
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #12
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #13
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #13
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #14
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #14
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #15
    s.add        s42, s41, s33
    s.addi       s41, s42, #64
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #15
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #0
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    s.movz       s41, #0
    s.add        s43, s41, s17                   // the tile origin
    v.splat      v38, s43
    v.add        v42, v34, v38
    s.movz       s41, #0
    s.add        s43, s41, s28                   // the tile origin
    v.splat      v38, s43
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #256
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #1
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #257
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #2
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #258
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #3
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #259
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #4
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #260
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #5
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #261
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #6
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #262
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #7
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #263
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #8
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #264
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #9
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #265
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #10
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #266
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #11
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #267
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #12
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #268
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #13
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #269
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #14
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #270
    v.st.scatter.b [s41, v36], v43
    v.extract    s41, v37, #15
    s.add        s42, s41, s33
    s.addi       s41, s42, #96
    s.add        s42, s4, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s42, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s40, #271
    v.st.scatter.b [s41, v36], v43
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v38, [s40, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #64
    v.ld.w       v38, [s41, #0]
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #128
    v.ld.w       v38, [s41, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #192
    v.ld.w       v38, [s41, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #256
    v.ld.w       v38, [s41, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #320
    v.ld.w       v38, [s41, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #384
    v.ld.w       v38, [s41, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s40, #448
    v.ld.w       v38, [s41, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s19, #-32
    v.splat      v38, s40
    v.sub        v42, v38, v35
    v.movi       v38, #0
    v.cmp.gt     p3, v42, v38
    v.movi       v38, #0
    v.max.s      v43, v42, v38
    v.movi       v38, #4
    v.min.s      v42, v43, v38
    v.movi       v38, #1
    v.movi       v43, #3
    v.shl        v44, v42, v43
    v.shl        v43, v38, v44
    v.movi       v38, #1
    v.sub        v44, v43, v38
    v.movi       v38, #4
    v.cmp.ge     p4, v42, v38
    v.movi       v38, #-1
    @p4 v.sel        v42, v38, v44
    s.addi       s40, s26, #32
    s.add        s41, s9, s40
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s40, v16, #0
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #1
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #2
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #3
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #4
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #5
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #6
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #7
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #8
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #9
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #10
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #11
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #12
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #13
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v16, #14
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s42, #0]
    v.extract    s40, v16, #15
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s40, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s40
    mb.wait      s40
    s.addi       s41, s26, #32
    s.add        s42, s9, s41
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s41, v19, #0
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #1
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #2
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #3
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #4
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #5
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #6
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #7
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #8
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #9
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #10
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #11
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #12
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #13
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v19, #14
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s43, #0]
    v.extract    s41, v19, #15
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s41, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s41
    mb.wait      s41
    s.addi       s42, s26, #32
    s.add        s43, s9, s42
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s42, v20, #0
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #1
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #2
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #3
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #4
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #5
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #6
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #7
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #8
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #9
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #10
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #11
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #12
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #13
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v20, #14
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s44, #0]
    v.extract    s42, v20, #15
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s42, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s42
    mb.wait      s42
    s.addi       s43, s26, #32
    s.add        s44, s9, s43
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s43, v22, #0
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #1
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #2
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #3
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #4
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #5
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #6
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #7
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #8
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #9
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #10
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #11
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #12
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #13
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v22, #14
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s45, #0]
    v.extract    s43, v22, #15
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s43, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s43
    mb.wait      s43
    s.addi       s44, s26, #32
    s.add        s45, s9, s44
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s44, v23, #0
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #1
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #2
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #3
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #4
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #5
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #6
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #7
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #8
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #9
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #10
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #11
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #12
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #13
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v23, #14
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s46, #0]
    v.extract    s44, v23, #15
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s44, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s44
    mb.wait      s44
    s.addi       s45, s26, #32
    s.add        s46, s9, s45
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s45, v24, #0
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #1
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #2
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #3
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #4
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #5
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #6
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #7
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #8
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #9
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #10
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #11
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #12
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #13
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v24, #14
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s47, #0]
    v.extract    s45, v24, #15
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s45, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s45
    mb.wait      s45
    s.addi       s46, s26, #32
    s.add        s47, s9, s46
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s46, v25, #0
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #1
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #2
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #3
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #4
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #5
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #6
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #7
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #8
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #9
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #10
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #11
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #12
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #13
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v25, #14
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s48, #0]
    v.extract    s46, v25, #15
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s46, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s46
    mb.wait      s46
    s.addi       s47, s26, #32
    s.add        s48, s9, s47
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s47, v26, #0
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #1
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #2
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #3
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #4
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #5
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #6
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #7
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #8
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #9
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #10
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #11
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #12
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #13
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v26, #14
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s49, #0]
    v.extract    s47, v26, #15
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s47, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s47
    mb.wait      s47
    s.addi       s48, s30, #1024                 // 512 bytes of repack scratch
    v.extract    s49, v37, #0
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    s.movz       s49, #0
    s.add        s51, s49, s18                   // the tile origin
    v.splat      v38, s51
    v.add        v42, v34, v38
    s.movz       s49, #0
    s.add        s51, s49, s28                   // the tile origin
    v.splat      v38, s51
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #0
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #1
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #1
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #2
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #2
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #3
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #3
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #4
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #4
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #5
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #5
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #6
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #6
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #7
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #7
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #8
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #8
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #9
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #9
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #10
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #10
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #11
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #11
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #12
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #12
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #13
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #13
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #14
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #14
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #15
    s.add        s50, s49, s33
    s.addi       s49, s50, #128
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #15
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #0
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    s.movz       s49, #0
    s.add        s51, s49, s21                   // the tile origin
    v.splat      v38, s51
    v.add        v42, v34, v38
    s.movz       s49, #0
    s.add        s51, s49, s28                   // the tile origin
    v.splat      v38, s51
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #256
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #1
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #257
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #2
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #258
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #3
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #259
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #4
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #260
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #5
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #261
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #6
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #262
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #7
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #263
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #8
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #264
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #9
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #265
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #10
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #266
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #11
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #267
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #12
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #268
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #13
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #269
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #14
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #270
    v.st.scatter.b [s49, v36], v43
    v.extract    s49, v37, #15
    s.add        s50, s49, s33
    s.addi       s49, s50, #160
    s.add        s50, s4, s49
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s50, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s48, #271
    v.st.scatter.b [s49, v36], v43
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v38, [s48, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #64
    v.ld.w       v38, [s49, #0]
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #128
    v.ld.w       v38, [s49, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #192
    v.ld.w       v38, [s49, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #256
    v.ld.w       v38, [s49, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #320
    v.ld.w       v38, [s49, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #384
    v.ld.w       v38, [s49, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s48, #448
    v.ld.w       v38, [s49, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s19, #-64
    v.splat      v38, s48
    v.sub        v42, v38, v35
    v.movi       v38, #0
    v.cmp.gt     p3, v42, v38
    v.movi       v38, #0
    v.max.s      v43, v42, v38
    v.movi       v38, #4
    v.min.s      v42, v43, v38
    v.movi       v38, #1
    v.movi       v43, #3
    v.shl        v44, v42, v43
    v.shl        v43, v38, v44
    v.movi       v38, #1
    v.sub        v44, v43, v38
    v.movi       v38, #4
    v.cmp.ge     p4, v42, v38
    v.movi       v38, #-1
    @p4 v.sel        v42, v38, v44
    s.addi       s48, s26, #64
    s.add        s49, s9, s48
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s48, v16, #0
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #1
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #2
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #3
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #4
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #5
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #6
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #7
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #8
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #9
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #10
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #11
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #12
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #13
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v16, #14
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s50, #0]
    v.extract    s48, v16, #15
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s48, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s48
    mb.wait      s48
    s.addi       s49, s26, #64
    s.add        s50, s9, s49
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s49, v19, #0
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #1
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #2
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #3
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #4
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #5
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #6
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #7
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #8
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #9
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #10
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #11
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #12
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #13
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v19, #14
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s51, #0]
    v.extract    s49, v19, #15
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s49, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s49
    mb.wait      s49
    s.addi       s50, s26, #64
    s.add        s51, s9, s50
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s50, v20, #0
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #1
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #2
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #3
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #4
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #5
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #6
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #7
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #8
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #9
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #10
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #11
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #12
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #13
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v20, #14
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s52, #0]
    v.extract    s50, v20, #15
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s50, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s50
    mb.wait      s50
    s.addi       s51, s26, #64
    s.add        s52, s9, s51
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s51, v22, #0
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #1
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #2
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #3
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #4
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #5
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #6
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #7
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #8
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #9
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #10
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #11
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #12
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #13
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v22, #14
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s53, #0]
    v.extract    s51, v22, #15
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s51, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s51
    mb.wait      s51
    s.addi       s52, s26, #64
    s.add        s53, s9, s52
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s52, v23, #0
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #1
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #2
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #3
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #4
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #5
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #6
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #7
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #8
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #9
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #10
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #11
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #12
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #13
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v23, #14
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s54, #0]
    v.extract    s52, v23, #15
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s52, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s52
    mb.wait      s52
    s.addi       s53, s26, #64
    s.add        s54, s9, s53
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s53, v24, #0
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #1
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #2
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #3
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #4
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #5
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #6
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #7
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #8
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #9
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #10
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #11
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #12
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #13
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v24, #14
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s55, #0]
    v.extract    s53, v24, #15
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s53, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s53
    mb.wait      s53
    s.addi       s54, s26, #64
    s.add        s55, s9, s54
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s54, v25, #0
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #1
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #2
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #3
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #4
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #5
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #6
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #7
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #8
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #9
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #10
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #11
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #12
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #13
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v25, #14
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s56, #0]
    v.extract    s54, v25, #15
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s54, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s54
    mb.wait      s54
    s.addi       s55, s26, #64
    s.add        s56, s9, s55
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s55, v26, #0
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #1
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #2
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #3
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #4
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #5
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #6
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #7
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #8
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #9
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #10
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #11
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #12
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #13
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v26, #14
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s57, #0]
    v.extract    s55, v26, #15
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v43, [s55, #0]
    v.or         v44, v38, v43
    v.and        v38, v44, v42
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s55
    mb.wait      s55
    s.addi       s56, s30, #1536                 // 512 bytes of repack scratch
    v.extract    s57, v37, #0
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    s.movz       s57, #0
    s.add        s59, s57, s22                   // the tile origin
    v.splat      v38, s59
    v.add        v42, v34, v38
    s.movz       s57, #0
    s.add        s59, s57, s28                   // the tile origin
    v.splat      v38, s59
    v.cmp.lt     p3, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #0
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #1
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #1
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #2
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #2
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #3
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #3
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #4
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #4
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #5
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #5
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #6
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #6
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #7
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #7
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #8
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #8
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #9
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #9
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #10
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #10
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #11
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #11
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #12
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #12
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #13
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #13
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #14
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #14
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #15
    s.add        s58, s57, s33
    s.addi       s57, s58, #192
    s.add        s58, s4, s57
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v38, [s58, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v13, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v13, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s56, #15
    v.st.scatter.b [s57, v36], v43
    v.extract    s57, v37, #0
    s.add        s58, s57, s33
    s.addi       s57, s58, #224
    s.add        s58, s4, s57
    s.movz       s57, #0
    s.add        s59, s57, s23                   // the tile origin
    v.splat      v38, s59
    v.add        v42, v34, v38
    s.movz       s57, #0
    s.add        s59, s57, s28                   // the tile origin
    v.splat      v34, s59
    v.cmp.lt     p3, v42, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s58, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #256
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #1
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #257
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #2
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #258
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #3
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #259
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #4
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #260
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #5
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #261
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #6
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #262
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #7
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #263
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #8
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #264
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #9
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #265
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #10
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #266
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #11
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #267
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #12
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #268
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #13
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #269
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #14
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s57, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s57, #0]
    vf.cvt.bf16.f32 v38, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v13, v34, v40
    vf.fms       v43, v34, v42, v34
    vf.neg       v42, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v43, v42, v34
    vf.mul       v34, v38, v43                   // a/y: faithful quotient
    vf.fms       v42, v34, v13, v38
    vf.fms       v38, v42, v43, v34
    vf.neg       v42, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v42, v42
    @p4 v.sel        v38, v42, v34
    vf.cvt.f32.e4m3 v34, v38
    v.lshr       v42, v38, v41
    v.and        v38, v42, v39
    v.or         v42, v34, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #270
    v.st.scatter.b [s28, v36], v42
    v.extract    s28, v37, #15
    s.add        s57, s28, s33
    s.addi       s28, s57, #224
    s.add        s33, s4, s28
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s33, #0]
    vf.cvt.bf16.f32 v37, v34
    v.rcp.approx v34, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v38, v13, v34, v40
    vf.fms       v40, v34, v38, v34
    vf.neg       v38, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v38, v38
    @p3 v.sel        v40, v38, v34
    vf.mul       v34, v37, v40                   // a/y: faithful quotient
    vf.fms       v38, v34, v13, v37
    vf.fms       v13, v38, v40, v34
    vf.neg       v37, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v13, v37, v34
    vf.cvt.f32.e4m3 v34, v13
    v.lshr       v37, v13, v41
    v.and        v13, v37, v39
    v.or         v37, v34, v13                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s28, s56, #271
    v.st.scatter.b [s28, v36], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v13, [s56, #0]
    v.mov        v48, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #64
    v.ld.w       v13, [s28, #0]
    v.mov        v49, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #128
    v.ld.w       v13, [s28, #0]
    v.mov        v50, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #192
    v.ld.w       v13, [s28, #0]
    v.mov        v51, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #256
    v.ld.w       v13, [s28, #0]
    v.mov        v52, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #320
    v.ld.w       v13, [s28, #0]
    v.mov        v53, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #384
    v.ld.w       v13, [s28, #0]
    v.mov        v54, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s56, #448
    v.ld.w       v13, [s28, #0]
    v.mov        v55, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s19, #-96
    v.splat      v13, s28
    v.sub        v34, v13, v35
    v.movi       v13, #0
    v.cmp.gt     p3, v34, v13
    v.movi       v13, #0
    v.max.s      v35, v34, v13
    v.movi       v13, #4
    v.min.s      v34, v35, v13
    v.movi       v13, #1
    v.movi       v35, #3
    v.shl        v37, v34, v35
    v.shl        v35, v13, v37
    v.movi       v13, #1
    v.sub        v37, v35, v13
    v.movi       v13, #4
    v.cmp.ge     p4, v34, v13
    v.movi       v13, #-1
    @p4 v.sel        v34, v13, v37
    s.addi       s19, s26, #96
    s.add        s28, s9, s19
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s19, v16, #0
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #1
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #2
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #3
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #4
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #5
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #6
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #7
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #8
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #9
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #10
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #11
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #12
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #13
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s19, #0]
    v.or         v37, v13, v35
    v.and        v13, v37, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v16, #14
    s.add        s33, s28, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    v.extract    s19, v16, #15
    s.add        s33, s28, s19
    s.addi       s19, s33, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s19, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s19
    mb.wait      s19
    s.addi       s28, s26, #96
    s.add        s33, s9, s28
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s28, v19, #0
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #1
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #2
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #3
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #4
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #5
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #6
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #7
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #8
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #9
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #10
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #11
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #12
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #13
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v35, v13, v16
    v.and        v13, v35, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v19, #14
    s.add        s56, s33, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    v.extract    s28, v19, #15
    s.add        s56, s33, s28
    s.addi       s28, s56, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s28, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s28
    mb.wait      s28
    s.addi       s33, s26, #96
    s.add        s56, s9, s33
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s33, v20, #0
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #1
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #2
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #3
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #4
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #5
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #6
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #7
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #8
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #9
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #10
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #11
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #12
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #13
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v20, #14
    s.add        s57, s56, s33
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    v.extract    s33, v20, #15
    s.add        s57, s56, s33
    s.addi       s33, s57, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s33, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s33
    mb.wait      s33
    s.addi       s56, s26, #96
    s.add        s57, s9, s56
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s56, v22, #0
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #1
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #2
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #3
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #4
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #5
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #6
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #7
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #8
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #9
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #10
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #11
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #12
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #13
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #14
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    v.extract    s56, v22, #15
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s56
    mb.wait      s56
    s.addi       s57, s26, #96
    s.add        s58, s9, s57
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s57, v23, #0
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #1
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #2
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #3
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #4
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #5
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #6
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #7
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #8
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #9
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #10
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #11
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #12
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #13
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #14
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    v.extract    s57, v23, #15
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s57, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s57
    mb.wait      s57
    s.addi       s58, s26, #96
    s.add        s59, s9, s58
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s58, v24, #0
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #1
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #2
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #3
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #4
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #5
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #6
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #7
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #8
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #9
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #10
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #11
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #12
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #13
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #14
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    v.extract    s58, v24, #15
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s58, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s58
    mb.wait      s58
    s.addi       s59, s26, #96
    s.add        s60, s9, s59
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s59, v25, #0
    s.add        s19, s60, s59
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s19, #0]
    v.extract    s19, v25, #1
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #2
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #3
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #4
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #5
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #6
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #7
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #8
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #9
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #10
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #11
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #12
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #13
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s19, v25, #14
    s.add        s28, s60, s19
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    v.extract    s19, v25, #15
    s.add        s28, s60, s19
    s.addi       s19, s28, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s19, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s19, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s19
    mb.wait      s19
    s.addi       s28, s26, #96
    s.add        s29, s9, s28
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s28, v26, #0
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #1
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #2
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #3
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #4
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #5
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #6
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #7
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #8
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #9
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #10
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #11
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #12
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #13
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v26, #14
    s.add        s32, s29, s28
    p.and        p4, p1, p3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    v.extract    s28, v26, #15
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    p.and        p1, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v16, [s28, #0]
    v.or         v19, v13, v16
    v.and        v13, v19, v34
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s28, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s28
    mb.wait      s28
    s.addi       s29, s30, #2048
    s.movz       s32, #0
    a.vread      v13, a8, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a8, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a8, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #3072
    s.movz       s32, #0
    a.vread      v13, a9, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a9, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a9, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #4096
    s.movz       s32, #0
    a.vread      v13, a10, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a10, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a10, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #5120
    s.movz       s32, #0
    a.vread      v13, a11, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a11, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a11, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #6144
    s.movz       s32, #0
    a.vread      v13, a12, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a12, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a12, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #7168
    s.movz       s32, #0
    a.vread      v13, a13, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a13, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a13, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #8192
    s.movz       s32, #0
    a.vread      v13, a14, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a14, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a14, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #9216
    s.movz       s32, #0
    a.vread      v13, a15, s32
    v.st.scatter.w [s29, v36], v13
    s.addi       s32, s29, #4
    s.movz       s33, #1
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #8
    s.movz       s33, #2
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #12
    s.movz       s33, #3
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #16
    s.movz       s33, #4
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #20
    s.movz       s33, #5
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #24
    s.movz       s33, #6
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #28
    s.movz       s33, #7
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #32
    s.movz       s33, #8
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #36
    s.movz       s33, #9
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #40
    s.movz       s33, #10
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #44
    s.movz       s33, #11
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #48
    s.movz       s33, #12
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #52
    s.movz       s33, #13
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #56
    s.movz       s33, #14
    a.vread      v13, a15, s33
    v.st.scatter.w [s32, v36], v13
    s.addi       s32, s29, #60
    s.movz       s29, #15
    a.vread      v13, a15, s29
    v.st.scatter.w [s32, v36], v13
    fence.acq_rel.device
    s.addi       s29, s30, #10240
    s.movz       s32, #0
    a.vread      v13, a0, s32
    s.addi       s32, s30, #2048
    v.ld.w       v16, [s32, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s29, #0], v16
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2112
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2176
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2240
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2304
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2368
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2432
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2496
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2560
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2624
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2688
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2752
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2816
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2880
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a0, s33
    s.addi       s33, s30, #2944
    v.ld.w       v16, [s33, #0]
    vf.mul       v19, v16, v15
    vf.add       v16, v13, v19
    v.st.w       [s32, #0], v16
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a0, s29
    s.addi       s29, s30, #3008
    v.ld.w       v16, [s29, #0]
    vf.mul       v19, v16, v15
    vf.add       v15, v13, v19
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #11264
    s.movz       s32, #0
    a.vread      v13, a1, s32
    s.addi       s32, s30, #3072
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3136
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3200
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3264
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3328
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3392
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3456
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3520
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3584
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3648
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3712
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3776
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3840
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3904
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a1, s33
    s.addi       s33, s30, #3968
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a1, s29
    s.addi       s29, s30, #4032
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v27
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #12288
    s.movz       s32, #0
    a.vread      v13, a2, s32
    s.addi       s32, s30, #4096
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4160
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4224
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4288
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4352
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4416
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4480
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4544
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4608
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4672
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4736
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4800
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4864
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4928
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a2, s33
    s.addi       s33, s30, #4992
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a2, s29
    s.addi       s29, s30, #5056
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v28
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #13312
    s.movz       s32, #0
    a.vread      v13, a3, s32
    s.addi       s32, s30, #5120
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5184
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5248
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5312
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5376
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5440
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5504
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5568
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5632
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5696
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5760
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5824
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5888
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a3, s33
    s.addi       s33, s30, #5952
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a3, s33
    s.addi       s33, s30, #6016
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a3, s29
    s.addi       s29, s30, #6080
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v29
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #14336
    s.movz       s32, #0
    a.vread      v13, a4, s32
    s.addi       s32, s30, #6144
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6208
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6272
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6336
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6400
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6464
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6528
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6592
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6656
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6720
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6784
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6848
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6912
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a4, s33
    s.addi       s33, s30, #6976
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a4, s33
    s.addi       s33, s30, #7040
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a4, s29
    s.addi       s29, s30, #7104
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #15360
    s.movz       s32, #0
    a.vread      v13, a5, s32
    s.addi       s32, s30, #7168
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7232
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7296
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7360
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7424
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7488
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7552
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7616
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7680
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7744
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7808
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7872
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a5, s33
    s.addi       s33, s30, #7936
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a5, s33
    s.addi       s33, s30, #8000
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a5, s33
    s.addi       s33, s30, #8064
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a5, s29
    s.addi       s29, s30, #8128
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v31
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #16384
    s.movz       s32, #0
    a.vread      v13, a6, s32
    s.addi       s32, s30, #8192
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8256
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8320
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8384
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8448
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8512
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8576
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8640
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8704
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8768
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8832
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8896
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a6, s33
    s.addi       s33, s30, #8960
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a6, s33
    s.addi       s33, s30, #9024
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a6, s33
    s.addi       s33, s30, #9088
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a6, s29
    s.addi       s29, s30, #9152
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v32
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s30, #17408
    s.movz       s32, #0
    a.vread      v13, a7, s32
    s.addi       s32, s30, #9216
    v.ld.w       v15, [s32, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s29, #0], v15
    s.addi       s32, s29, #64
    s.movz       s33, #1
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9280
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #128
    s.movz       s33, #2
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9344
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #192
    s.movz       s33, #3
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9408
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #256
    s.movz       s33, #4
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9472
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #320
    s.movz       s33, #5
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9536
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #384
    s.movz       s33, #6
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9600
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #448
    s.movz       s33, #7
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9664
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #512
    s.movz       s33, #8
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9728
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #576
    s.movz       s33, #9
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9792
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #640
    s.movz       s33, #10
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9856
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #704
    s.movz       s33, #11
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9920
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #768
    s.movz       s33, #12
    a.vread      v13, a7, s33
    s.addi       s33, s30, #9984
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #832
    s.movz       s33, #13
    a.vread      v13, a7, s33
    s.addi       s33, s30, #10048
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #896
    s.movz       s33, #14
    a.vread      v13, a7, s33
    s.addi       s33, s30, #10112
    v.ld.w       v15, [s33, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    s.addi       s32, s29, #960
    s.movz       s29, #15
    a.vread      v13, a7, s29
    s.addi       s29, s30, #10176
    v.ld.w       v15, [s29, #0]
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s29, s25, #128
    s.addi       s32, s29, #0
    s.addi       s29, s26, #128
    s.addi       s33, s29, #0
    s.addi       s29, s27, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    s.addi       s34, s29, #0
    s.addi       s29, s27, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s29, s27, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    s.mov        s25, s32
    s.mov        s26, s33
    s.mov        s27, s34
    s.movz       s29, #0
    s.addi       s32, s30, #10240
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #10304
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #10368
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #10432
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #10496
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #10560
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #10624
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #10688
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #10752
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #10816
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #10880
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #10944
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #11008
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #11072
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #11136
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #11200
    v.ld.w       v13, [s32, #0]
    a.vwrite     a0, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #11264
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #11328
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #11392
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #11456
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #11520
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #11584
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #11648
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #11712
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #11776
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #11840
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #11904
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #11968
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #12032
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #12096
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #12160
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #12224
    v.ld.w       v13, [s32, #0]
    a.vwrite     a1, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #12288
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #12352
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #12416
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #12480
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #12544
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #12608
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #12672
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #12736
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #12800
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #12864
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #12928
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #12992
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #13056
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #13120
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #13184
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #13248
    v.ld.w       v13, [s32, #0]
    a.vwrite     a2, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #13312
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #13376
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #13440
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #13504
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #13568
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #13632
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #13696
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #13760
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #13824
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #13888
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #13952
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #14016
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #14080
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #14144
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #14208
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #14272
    v.ld.w       v13, [s32, #0]
    a.vwrite     a3, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #14336
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #14400
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #14464
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #14528
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #14592
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #14656
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #14720
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #14784
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #14848
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #14912
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #14976
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #15040
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #15104
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #15168
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #15232
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #15296
    v.ld.w       v13, [s32, #0]
    a.vwrite     a4, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #15360
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #15424
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #15488
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #15552
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #15616
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #15680
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #15744
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #15808
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #15872
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #15936
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #16000
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #16064
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #16128
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #16192
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #16256
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #16320
    v.ld.w       v13, [s32, #0]
    a.vwrite     a5, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #16384
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #16448
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #16512
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #16576
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #16640
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #16704
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #16768
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #16832
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #16896
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #16960
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #17024
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #17088
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #17152
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #17216
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #17280
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #17344
    v.ld.w       v13, [s32, #0]
    a.vwrite     a6, s29, v13
    s.movz       s29, #0
    s.addi       s32, s30, #17408
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #1
    s.addi       s32, s30, #17472
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #2
    s.addi       s32, s30, #17536
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #3
    s.addi       s32, s30, #17600
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #4
    s.addi       s32, s30, #17664
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #5
    s.addi       s32, s30, #17728
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #6
    s.addi       s32, s30, #17792
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #7
    s.addi       s32, s30, #17856
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #8
    s.addi       s32, s30, #17920
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #9
    s.addi       s32, s30, #17984
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #10
    s.addi       s32, s30, #18048
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #11
    s.addi       s32, s30, #18112
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #12
    s.addi       s32, s30, #18176
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #13
    s.addi       s32, s30, #18240
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #14
    s.addi       s32, s30, #18304
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.movz       s29, #15
    s.addi       s32, s30, #18368
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s29, v13
    s.add        s29, s20, s16
    s.mov        s20, s29
    s.movz       s29, #1
    br.nz        s29, for_26
endfor_27:
    s.movz       s2, #0
    s.mul        s4, s1, s5
    v.splat      v0, s31
    a.vread      v1, a0, s2
    s.movz       s2, #0
    s.movz       s6, #0
    s.add        s8, s2, s14                     // the tile origin
    vf.mul       v2, v1, v0
    s.movz       s2, #0
    s.movz       s9, #0
    s.muli       s10, s4, #2
    s.muli       s4, s14, #2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s8
    s.add        s8, s6, s1                      // the tile origin
    s.add        s1, s2, s12                     // the tile origin
    s.add        s2, s9, s3                      // the tile origin
    v.splat      v4, s8
    v.splat      v5, s1
    v.add        v6, v1, v3
    v.splat      v3, s2
    vf.cvt.f32.bf16 v7, v2
    s.add        s1, s10, s4
    s.muli       s2, s5, #2
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v6, v3
    s.add        s5, s7, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s5, #0], v7
    a.vread      v2, a0, s1
    s.muli       s1, s2, #1
    s.addi       s5, s8, #1
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.addi       s5, s14, #16
    s.add        s6, s1, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s6, s4
    p.and        p3, p1, p2
    s.add        s6, s7, s1
    s.movz       s1, #2
    @p3 v.st.h       [s6, #0], v2
    s.addi       s6, s14, #32
    a.vread      v2, a0, s1
    s.addi       s1, s14, #48
    s.addi       s9, s14, #64
    vf.mul       v3, v2, v0
    s.addi       s11, s14, #80
    s.muli       s12, s2, #2
    s.addi       s13, s14, #96
    s.addi       s15, s14, #112
    s.addi       s14, s8, #2
    vf.cvt.f32.bf16 v2, v3
    s.add        s16, s12, s10
    v.splat      v3, s14
    s.add        s12, s16, s4
    s.movz       s14, #3
    v.cmp.lt     p1, v3, v5
    s.add        s16, s7, s12
    p.and        p3, p1, p2
    s.muli       s12, s2, #3
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s14
    s.addi       s14, s8, #3
    s.movz       s16, #4
    vf.mul       v3, v2, v0
    s.add        s17, s12, s10
    v.splat      v2, s14
    s.add        s12, s17, s4
    s.muli       s14, s2, #4
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s17, s7, s12
    p.and        p3, p1, p2
    s.addi       s12, s8, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v2, a0, s16
    s.add        s16, s14, s10
    v.splat      v3, s12
    vf.mul       v4, v2, v0
    s.add        s12, s16, s4
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s12, #5
    s.muli       s16, s2, #5
    s.addi       s17, s8, #5
    s.movz       s18, #6
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s12
    s.add        s12, s16, s10
    v.splat      v3, s17
    vf.mul       v4, v2, v0
    s.add        s14, s12, s4
    v.cmp.lt     p1, v3, v5
    s.add        s12, s7, s14
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.muli       s14, s2, #6
    s.addi       s16, s8, #6
    s.movz       s17, #7
    v.splat      v3, s16
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a0, s18
    s.add        s12, s14, s10
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s14, s12, s4
    p.and        p3, p1, p2
    s.add        s12, s7, s14
    s.muli       s14, s2, #7
    vf.cvt.f32.bf16 v2, v3
    s.addi       s16, s8, #7
    s.movz       s18, #8
    v.splat      v3, s16
    s.add        s16, s14, s10
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a0, s17
    s.add        s12, s16, s4
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    s.muli       s12, s2, #8
    s.addi       s16, s8, #8
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s16
    s.movz       s16, #9
    s.add        s17, s12, s10
    v.cmp.lt     p1, v3, v5
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s18
    s.add        s12, s17, s4
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s14, s7, s12
    s.muli       s12, s2, #9
    s.addi       s17, s8, #9
    s.movz       s18, #10
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s17
    s.add        s17, s12, s10
    s.muli       s12, s2, #10
    s.add        s20, s17, s4
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s16
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s20
    vf.mul       v3, v2, v0
    p.and        p3, p1, p2
    s.addi       s16, s8, #10
    s.add        s17, s12, s10
    v.splat      v2, s16
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s17, s4
    v.cmp.lt     p1, v2, v5
    s.add        s16, s7, s12
    p.and        p4, p1, p2
    @p3 v.st.h       [s14, #0], v4
    a.vread      v2, a0, s18
    s.movz       s12, #11
    s.muli       s14, s2, #11
    vf.mul       v3, v2, v0
    s.addi       s17, s8, #11
    s.movz       s18, #12
    v.splat      v2, s17
    s.add        s17, s14, s10
    vf.cvt.f32.bf16 v4, v3
    s.add        s14, s17, s4
    v.cmp.lt     p1, v2, v5
    s.add        s17, s7, s14
    p.and        p3, p1, p2
    @p4 v.st.h       [s16, #0], v4
    a.vread      v2, a0, s12
    s.muli       s12, s2, #12
    s.addi       s14, s8, #12
    vf.mul       v3, v2, v0
    v.splat      v2, s14
    s.movz       s14, #13
    s.add        s16, s12, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s12, s16, s4
    p.and        p4, p1, p2
    s.add        s16, s7, s12
    s.muli       s12, s2, #13
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s18
    s.addi       s17, s8, #13
    s.movz       s18, #14
    vf.mul       v3, v2, v0
    s.add        s20, s12, s10
    v.splat      v2, s17
    s.add        s12, s20, s4
    s.muli       s17, s2, #14
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s20, s7, s12
    p.and        p3, p1, p2
    s.addi       s12, s8, #14
    @p4 v.st.h       [s16, #0], v4
    a.vread      v2, a0, s14
    s.add        s14, s17, s10
    v.splat      v3, s12
    vf.mul       v4, v2, v0
    s.add        s12, s14, s4
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s12, #15
    s.muli       s16, s2, #15
    s.addi       s17, s8, #15
    s.movz       s21, #0
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s18
    s.add        s18, s16, s10
    v.splat      v3, s17
    vf.mul       v4, v2, v0
    s.add        s16, s18, s4
    v.cmp.lt     p1, v3, v5
    s.add        s4, s7, s16
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s16, #0
    s.movz       s17, #0
    s.add        s18, s16, s5                    // the tile origin
    s.muli       s16, s5, #2
    @p4 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s12
    v.splat      v3, s18
    s.add        s5, s17, s3                     // the tile origin
    vf.mul       v4, v2, v0
    v.splat      v2, s8
    v.add        v6, v1, v3
    v.splat      v3, s5
    s.add        s5, s10, s16
    vf.cvt.f32.bf16 v7, v4
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p2, v6, v3
    s.add        s12, s7, s5
    p.and        p4, p1, p2
    @p3 v.st.h       [s4, #0], v7
    a.vread      v2, a1, s21
    s.movz       s4, #1
    s.muli       s5, s2, #1
    vf.mul       v3, v2, v0
    s.addi       s14, s8, #1
    s.movz       s17, #2
    v.splat      v2, s14
    s.add        s14, s5, s10
    vf.cvt.f32.bf16 v4, v3
    s.add        s5, s14, s16
    v.cmp.lt     p1, v2, v5
    s.add        s14, s7, s5
    p.and        p3, p1, p2
    @p4 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s4
    s.muli       s4, s2, #2
    s.addi       s5, s8, #2
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.movz       s5, #3
    s.add        s12, s4, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s4, s12, s16
    p.and        p4, p1, p2
    s.add        s12, s7, s4
    s.muli       s4, s2, #3
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a1, s17
    s.addi       s14, s8, #3
    s.movz       s17, #4
    vf.mul       v3, v2, v0
    s.add        s18, s4, s10
    v.splat      v2, s14
    s.add        s4, s18, s16
    s.muli       s14, s2, #4
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s18, s7, s4
    p.and        p3, p1, p2
    s.addi       s4, s8, #4
    @p4 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s5
    s.add        s5, s14, s10
    v.splat      v3, s4
    vf.mul       v4, v2, v0
    s.add        s4, s5, s16
    v.cmp.lt     p1, v3, v5
    s.add        s5, s7, s4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s4, #5
    s.muli       s12, s2, #5
    s.addi       s14, s8, #5
    s.movz       s20, #6
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s17
    s.add        s17, s12, s10
    v.splat      v3, s14
    vf.mul       v4, v2, v0
    s.add        s12, s17, s16
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.muli       s12, s2, #6
    s.addi       s17, s8, #6
    s.movz       s18, #7
    v.splat      v3, s17
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a1, s4
    s.add        s4, s12, s10
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s5, s4, s16
    p.and        p4, p1, p2
    s.add        s4, s7, s5
    s.muli       s5, s2, #7
    vf.cvt.f32.bf16 v2, v3
    s.addi       s12, s8, #7
    s.movz       s17, #8
    v.splat      v3, s12
    s.add        s12, s5, s10
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a1, s20
    s.add        s5, s12, s16
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s12, s7, s5
    p.and        p3, p1, p2
    s.muli       s5, s2, #8
    s.addi       s14, s8, #8
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s14
    s.movz       s14, #9
    s.add        s20, s5, s10
    s.muli       s5, s2, #9
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a1, s18
    s.add        s4, s20, s16
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s18, s7, s4
    p.and        p4, p1, p2
    s.addi       s4, s8, #9
    s.add        s20, s5, s10
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s4
    s.add        s4, s20, s16
    s.movz       s5, #10
    s.add        s20, s7, s4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a1, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.muli       s4, s2, #10
    s.addi       s12, s8, #10
    s.movz       s17, #11
    v.splat      v2, s12
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s4, s10
    s.muli       s4, s2, #11
    s.add        s21, s12, s16
    s.addi       s12, s8, #11
    @p4 v.st.h       [s18, #0], v4
    a.vread      v3, a1, s14
    v.cmp.lt     p1, v2, v5
    s.add        s14, s7, s21
    vf.mul       v2, v3, v0
    p.and        p4, p1, p2
    s.add        s18, s4, s10
    v.splat      v3, s12
    s.add        s4, s18, s16
    vf.cvt.f32.bf16 v4, v2
    s.add        s12, s7, s4
    s.movz       s4, #12
    s.muli       s18, s2, #12
    s.addi       s21, s8, #12
    @p3 v.st.h       [s20, #0], v4
    a.vread      v2, a1, s5
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s5, s18, s10
    v.splat      v2, s21
    s.add        s18, s5, s16
    s.movz       s5, #13
    vf.cvt.f32.bf16 v4, v3
    s.add        s20, s7, s18
    s.muli       s18, s2, #13
    s.addi       s21, s8, #13
    s.movz       s22, #14
    @p4 v.st.h       [s14, #0], v4
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s14, s18, s10
    v.splat      v3, s21
    s.add        s17, s14, s16
    s.muli       s14, s2, #14
    vf.cvt.f32.bf16 v4, v2
    s.add        s18, s7, s17
    s.addi       s17, s8, #14
    s.movz       s21, #15
    s.add        s23, s14, s10
    @p3 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    v.splat      v2, s17
    s.add        s4, s23, s16
    s.muli       s12, s2, #15
    s.add        s14, s7, s4
    vf.cvt.f32.bf16 v4, v3
    s.addi       s4, s8, #15
    s.movz       s17, #0
    s.add        s23, s12, s10
    v.splat      v3, s4
    @p4 v.st.h       [s20, #0], v4
    a.vread      v4, a1, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s23, s16
    s.movz       s5, #0
    s.add        s12, s7, s4
    s.add        s4, s5, s6                      // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s5, #0
    s.muli       s16, s6, #2
    v.splat      v2, s4
    s.add        s4, s5, s3                      // the tile origin
    @p3 v.st.h       [s18, #0], v4
    a.vread      v4, a1, s22
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.splat      v4, s8
    v.add        v6, v1, v2
    v.splat      v2, s4
    s.add        s4, s10, s16
    vf.cvt.f32.bf16 v7, v3
    v.cmp.lt     p1, v4, v5
    s.add        s5, s7, s4
    s.movz       s4, #1
    s.muli       s6, s2, #1
    @p4 v.st.h       [s14, #0], v7
    a.vread      v3, a1, s21
    v.cmp.lt     p2, v6, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.addi       s14, s8, #1
    s.add        s18, s6, s10
    v.splat      v3, s14
    s.add        s6, s18, s16
    vf.cvt.f32.bf16 v4, v2
    s.add        s14, s7, s6
    s.movz       s6, #2
    s.muli       s18, s2, #2
    s.addi       s20, s8, #2
    @p3 v.st.h       [s12, #0], v4
    a.vread      v2, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s12, s18, s10
    v.splat      v2, s20
    s.add        s17, s12, s16
    s.movz       s12, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s18, s7, s17
    s.muli       s17, s2, #3
    s.addi       s20, s8, #3
    s.movz       s21, #4
    @p4 v.st.h       [s5, #0], v4
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s4, s17, s10
    v.splat      v3, s20
    s.add        s5, s4, s16
    s.muli       s4, s2, #4
    vf.cvt.f32.bf16 v4, v2
    s.add        s17, s7, s5
    s.addi       s5, s8, #4
    s.movz       s20, #5
    s.add        s22, s4, s10
    @p3 v.st.h       [s14, #0], v4
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.add        s4, s22, s16
    s.muli       s5, s2, #5
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v3
    s.addi       s4, s8, #5
    s.movz       s14, #6
    s.add        s22, s5, s10
    v.splat      v3, s4
    @p4 v.st.h       [s18, #0], v4
    a.vread      v4, a2, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s22, s16
    s.muli       s5, s2, #6
    s.add        s12, s7, s4
    s.addi       s4, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s4
    s.add        s4, s5, s10
    s.movz       s5, #7
    s.add        s18, s4, s16
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a2, s21
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s18
    s.muli       s17, s2, #7
    s.addi       s18, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s18
    s.add        s18, s17, s10
    s.movz       s17, #8
    s.add        s21, s18, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s20
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s21
    s.muli       s18, s2, #8
    s.addi       s20, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s18, s10
    s.movz       s18, #9
    s.add        s21, s20, s16
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s12, s7, s21
    s.muli       s14, s2, #9
    s.addi       s20, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s14, s10
    s.movz       s14, #10
    s.add        s21, s20, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s21
    s.muli       s5, s2, #10
    s.addi       s20, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s5, s10
    s.movz       s5, #11
    s.add        s21, s20, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s21
    s.muli       s17, s2, #11
    s.addi       s20, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s17, s10
    s.movz       s17, #12
    s.add        s21, s20, s16
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s12, s7, s21
    s.muli       s18, s2, #12
    s.addi       s20, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s18, s10
    s.movz       s18, #13
    s.add        s21, s20, s16
    @p3 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s21
    s.muli       s14, s2, #13
    s.addi       s20, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s14, s10
    s.movz       s14, #14
    s.add        s21, s20, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s21
    s.muli       s6, s2, #14
    s.addi       s20, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s6, s10
    s.movz       s6, #15
    s.add        s21, s20, s16
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s12, s7, s21
    s.muli       s17, s2, #15
    s.addi       s20, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s17, s10
    s.movz       s17, #0
    s.add        s21, s20, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s21
    s.movz       s16, #0
    s.muli       s18, s1, #2
    s.add        s20, s16, s1                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s1, #0
    v.splat      v2, s20
    s.add        s16, s1, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s16
    s.add        s1, s10, s18
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s5, s7, s1
    s.movz       s1, #1
    s.muli       s14, s2, #1
    s.addi       s16, s8, #1
    @p4 v.st.h       [s12, #0], v6
    a.vread      v3, a2, s6
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s6, s14, s10
    v.splat      v3, s16
    s.add        s12, s6, s18
    s.movz       s6, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s14, s7, s12
    s.muli       s12, s2, #2
    s.addi       s16, s8, #2
    s.movz       s20, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a3, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s12, s10
    v.splat      v2, s16
    s.add        s12, s4, s18
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s16, s7, s12
    s.addi       s12, s8, #3
    s.movz       s17, #4
    s.add        s21, s4, s10
    @p4 v.st.h       [s5, #0], v4
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s12
    s.add        s1, s21, s18
    s.muli       s4, s2, #4
    s.add        s5, s7, s1
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #4
    s.movz       s12, #5
    s.add        s21, s4, s10
    v.splat      v2, s1
    @p3 v.st.h       [s14, #0], v4
    a.vread      v4, a3, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s21, s18
    s.muli       s4, s2, #5
    s.add        s6, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s14, s1, s18
    @p4 v.st.h       [s16, #0], v4
    a.vread      v4, a3, s20
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s14
    s.muli       s14, s2, #6
    s.addi       s16, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s14, s10
    s.movz       s14, #7
    s.add        s20, s16, s18
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s20
    s.muli       s16, s2, #7
    s.addi       s17, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #8
    s.add        s20, s17, s18
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s20
    s.muli       s12, s2, #8
    s.addi       s17, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s12, s10
    s.movz       s12, #9
    s.add        s20, s17, s18
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s20
    s.muli       s4, s2, #9
    s.addi       s17, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s4, s10
    s.movz       s4, #10
    s.add        s20, s17, s18
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s14
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s20
    s.muli       s14, s2, #10
    s.addi       s17, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s14, s10
    s.movz       s14, #11
    s.add        s20, s17, s18
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s20
    s.muli       s16, s2, #11
    s.addi       s17, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #12
    s.add        s20, s17, s18
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s20
    s.muli       s12, s2, #12
    s.addi       s17, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s12, s10
    s.movz       s12, #13
    s.add        s20, s17, s18
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s20
    s.muli       s5, s2, #13
    s.addi       s17, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s5, s10
    s.movz       s5, #14
    s.add        s20, s17, s18
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s14
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s20
    s.muli       s14, s2, #14
    s.addi       s17, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s14, s10
    s.movz       s14, #15
    s.add        s20, s17, s18
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s20
    s.muli       s16, s2, #15
    s.addi       s17, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #0
    s.add        s20, s17, s18
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s20
    s.movz       s12, #0
    s.muli       s17, s9, #2
    s.add        s18, s12, s9                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s18
    s.add        s12, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s5
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s12
    s.add        s5, s10, s17
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s12, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a3, s14
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s12
    s.add        s9, s1, s17
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s12, s7, s9
    s.muli       s9, s2, #2
    s.addi       s14, s8, #2
    s.movz       s18, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a4, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s14
    s.add        s9, s4, s17
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s14, s7, s9
    s.addi       s9, s8, #3
    s.movz       s16, #4
    s.add        s20, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s20, s17
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s20, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a4, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s20, s17
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s12, s1, s17
    @p4 v.st.h       [s14, #0], v4
    a.vread      v4, a4, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s12
    s.muli       s12, s2, #6
    s.addi       s14, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s12, s10
    s.movz       s12, #7
    s.add        s18, s14, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s18
    s.muli       s14, s2, #7
    s.addi       s16, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #8
    s.add        s18, s16, s17
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s18
    s.muli       s9, s2, #8
    s.addi       s16, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s9, s10
    s.movz       s9, #9
    s.add        s18, s16, s17
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s18
    s.muli       s4, s2, #9
    s.addi       s16, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s4, s10
    s.movz       s4, #10
    s.add        s18, s16, s17
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s18
    s.muli       s12, s2, #10
    s.addi       s16, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s12, s10
    s.movz       s12, #11
    s.add        s18, s16, s17
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s18
    s.muli       s14, s2, #11
    s.addi       s16, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #12
    s.add        s18, s16, s17
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s18
    s.muli       s9, s2, #12
    s.addi       s16, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s9, s10
    s.movz       s9, #13
    s.add        s18, s16, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s18
    s.muli       s6, s2, #13
    s.addi       s16, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s6, s10
    s.movz       s6, #14
    s.add        s18, s16, s17
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s18
    s.muli       s12, s2, #14
    s.addi       s16, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s12, s10
    s.movz       s12, #15
    s.add        s18, s16, s17
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s18
    s.muli       s14, s2, #15
    s.addi       s16, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #0
    s.add        s18, s16, s17
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s18
    s.movz       s9, #0
    s.muli       s16, s11, #2
    s.add        s17, s9, s11                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s17
    s.add        s11, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s11
    s.add        s5, s10, s16
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s11, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a4, s12
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s11
    s.add        s9, s1, s16
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s11, s7, s9
    s.muli       s9, s2, #2
    s.addi       s12, s8, #2
    s.movz       s17, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a5, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s12
    s.add        s9, s4, s16
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s7, s9
    s.addi       s9, s8, #3
    s.movz       s14, #4
    s.add        s18, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s18, s16
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s18, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s11, #0], v4
    a.vread      v4, a5, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s18, s16
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s11, s1, s16
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a5, s17
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s11
    s.muli       s11, s2, #6
    s.addi       s12, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #7
    s.add        s17, s12, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s17
    s.muli       s12, s2, #7
    s.addi       s14, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #8
    s.add        s17, s14, s16
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s17
    s.muli       s9, s2, #8
    s.addi       s14, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s9, s10
    s.movz       s9, #9
    s.add        s17, s14, s16
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s17
    s.muli       s4, s2, #9
    s.addi       s14, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s4, s10
    s.movz       s4, #10
    s.add        s17, s14, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s17
    s.muli       s11, s2, #10
    s.addi       s14, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s11, s10
    s.movz       s11, #11
    s.add        s17, s14, s16
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s17
    s.muli       s12, s2, #11
    s.addi       s14, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #12
    s.add        s17, s14, s16
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s17
    s.muli       s9, s2, #12
    s.addi       s14, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s9, s10
    s.movz       s9, #13
    s.add        s17, s14, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s17
    s.muli       s6, s2, #13
    s.addi       s14, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s6, s10
    s.movz       s6, #14
    s.add        s17, s14, s16
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s17
    s.muli       s11, s2, #14
    s.addi       s14, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s11, s10
    s.movz       s11, #15
    s.add        s17, s14, s16
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s17
    s.muli       s12, s2, #15
    s.addi       s14, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #0
    s.add        s17, s14, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s17
    s.movz       s9, #0
    s.muli       s14, s13, #2
    s.add        s16, s9, s13                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s16
    s.add        s13, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s13
    s.add        s5, s10, s14
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s13, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a5, s11
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s13
    s.add        s9, s1, s14
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s11, s7, s9
    s.muli       s9, s2, #2
    s.addi       s13, s8, #2
    s.movz       s16, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s13
    s.add        s9, s4, s14
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s7, s9
    s.addi       s9, s8, #3
    s.movz       s13, #4
    s.add        s17, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a6, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s17, s14
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s17, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s11, #0], v4
    a.vread      v4, a6, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s17, s14
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s11, s1, s14
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a6, s16
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s11
    s.muli       s11, s2, #6
    s.addi       s12, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #7
    s.add        s16, s12, s14
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s13
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s16
    s.muli       s12, s2, #7
    s.addi       s13, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #8
    s.add        s16, s13, s14
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s16
    s.muli       s9, s2, #8
    s.addi       s13, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s9, s10
    s.movz       s9, #9
    s.add        s16, s13, s14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s16
    s.muli       s4, s2, #9
    s.addi       s13, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s4, s10
    s.movz       s4, #10
    s.add        s16, s13, s14
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s16
    s.muli       s11, s2, #10
    s.addi       s13, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s11, s10
    s.movz       s11, #11
    s.add        s16, s13, s14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s16
    s.muli       s12, s2, #11
    s.addi       s13, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #12
    s.add        s16, s13, s14
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s16
    s.muli       s9, s2, #12
    s.addi       s13, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s9, s10
    s.movz       s9, #13
    s.add        s16, s13, s14
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s16
    s.muli       s6, s2, #13
    s.addi       s13, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s6, s10
    s.movz       s6, #14
    s.add        s16, s13, s14
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s16
    s.muli       s11, s2, #14
    s.addi       s13, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s11, s10
    s.movz       s11, #15
    s.add        s16, s13, s14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s16
    s.muli       s12, s2, #15
    s.addi       s13, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #0
    s.add        s16, s13, s14
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s16
    s.movz       s9, #0
    s.muli       s13, s15, #2
    s.add        s14, s9, s15                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s14
    s.add        s14, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v1, s14
    s.add        s3, s10, s13
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s5, s7, s3
    s.movz       s3, #1
    s.muli       s6, s2, #1
    s.addi       s9, s8, #1
    @p4 v.st.h       [s1, #0], v2
    a.vread      v2, a6, s11
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    vf.mul       v1, v2, v0
    s.add        s1, s6, s10
    v.splat      v2, s9
    s.add        s6, s1, s13
    s.movz       s1, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s9, s7, s6
    s.muli       s6, s2, #2
    s.addi       s11, s8, #2
    s.movz       s14, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s12
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v1, v0
    s.add        s4, s6, s10
    v.splat      v1, s11
    s.add        s6, s4, s13
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v3, v2
    s.add        s11, s7, s6
    s.addi       s6, s8, #3
    s.movz       s12, #4
    s.add        s15, s4, s10
    @p4 v.st.h       [s5, #0], v3
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v2, v0
    v.splat      v2, s6
    s.add        s3, s15, s13
    s.muli       s4, s2, #4
    s.add        s5, s7, s3
    vf.cvt.f32.bf16 v3, v1
    s.addi       s3, s8, #4
    s.movz       s6, #5
    s.add        s15, s4, s10
    v.splat      v1, s3
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s15, s13
    s.muli       s3, s2, #5
    s.add        s4, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s1
    s.add        s1, s3, s10
    s.movz       s3, #6
    s.add        s9, s1, s13
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a7, s14
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s1, s7, s9
    s.muli       s9, s2, #6
    s.addi       s11, s8, #6
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s11
    s.add        s11, s9, s10
    s.movz       s9, #7
    s.add        s14, s11, s13
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s12
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s5, s7, s14
    s.muli       s11, s2, #7
    s.addi       s12, s8, #7
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #8
    s.add        s14, s12, s13
    @p4 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s4, s7, s14
    s.muli       s6, s2, #8
    s.addi       s12, s8, #8
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s6, s10
    s.movz       s6, #9
    s.add        s14, s12, s13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s3
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s7, s14
    s.muli       s3, s2, #9
    s.addi       s12, s8, #9
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s3, s10
    s.movz       s3, #10
    s.add        s14, s12, s13
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s9
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s5, s7, s14
    s.muli       s9, s2, #10
    s.addi       s12, s8, #10
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s9, s10
    s.movz       s9, #11
    s.add        s14, s12, s13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s11
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s4, s7, s14
    s.muli       s11, s2, #11
    s.addi       s12, s8, #11
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #12
    s.add        s14, s12, s13
    @p4 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s1, s7, s14
    s.muli       s6, s2, #12
    s.addi       s12, s8, #12
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s6, s10
    s.movz       s6, #13
    s.add        s14, s12, s13
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s3
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s3, s7, s14
    s.muli       s5, s2, #13
    s.addi       s12, s8, #13
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s5, s10
    s.movz       s5, #14
    s.add        s14, s12, s13
    @p4 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s9
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s4, s7, s14
    s.muli       s9, s2, #14
    s.addi       s12, s8, #14
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s9, s10
    s.movz       s9, #15
    s.add        s14, s12, s13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s11
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s7, s14
    s.muli       s11, s2, #15
    s.addi       s2, s8, #15
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s2
    s.add        s2, s11, s10
    s.add        s8, s2, s13
    @p4 v.st.h       [s3, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s2, s7, s8
    vf.cvt.f32.bf16 v3, v1
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v1, v0
    vf.cvt.f32.bf16 v1, v2
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s9
    vf.mul       v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    @p3 v.st.h       [s2, #0], v0
    exit
    exit
