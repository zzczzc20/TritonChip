import sys,re,json
from pathlib import Path
root=Path('/tmp/r40_registered_ranges24');sys.path.insert(0,str(root/'tools/r1'));import r1lib as R
source=(root/'rtl/nuca/tnca_tmu.v').read_text();out=Path('/tmp/r40_registered_ranges24_mutations');out.mkdir()
assignment=re.search(r'te\[rg_slot\]\s*<=\s*(.*?);',source,re.S)
stale=source[:assignment.start(1)]+assignment[1].replace('st_base[w_src]','tb[rg_slot]').replace('st_size[w_src]','ts[rg_slot]')+source[assignment.end(1):]
variants={
 'source_alias':(source.replace('wire [SRC_W-1:0] w_src  = w_srcf;', 'wire [SRC_W-1:0] w_src = w_srcf[1:0];'),'registration missing or duplicated'),
 'stale_endpoint':(stale,'endpoint epoch mismatch'),
 'port_alias':(source.replace('s_ar[SELECT_W-1:0]','s_ar[1:0]'),'TMU range bench timeout'),
 'drop_overflow':(source.replace('localparam DROP_W = $clog2(N_SLICE+1);','localparam DROP_W = 3;'),'drop count overflowed')}
report={'results':[],'mutations':{},'gate_status':'not-measured'}
for name,(body,expected) in variants.items():
 assert body!=source,name
 path=out/(name+'.v');path.write_text(body)
 image=out/(name+'.vvp')
 compiled=R.run_step(['iverilog','-g2012','-I',str(root/'rtl/common'),'-s','tb_tmu_registered_ranges','-Ptb_tmu_registered_ranges.PORTS=8','-o',str(image),str(root/'tb/nuca/tb_tmu_registered_ranges.v'),str(path)],kind='build',case_dir=str(out),name=name+'_build',cap_override=30)
 report['results'].append(dict(compiled))
 assert compiled['status']==R.PASS,compiled
 result=R.run_step(['vvp',str(image)],kind='rtl',case_dir=str(out),name=name,cap_override=30)
 report['results'].append(dict(result));text=R.read_text(result['stdout'])+R.read_text(result['stderr'])
 report['mutations'][name]=result['status']==R.FAIL and expected in text
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,report['mutations'][name],flush=True)
assert all(report['mutations'].values()),report
