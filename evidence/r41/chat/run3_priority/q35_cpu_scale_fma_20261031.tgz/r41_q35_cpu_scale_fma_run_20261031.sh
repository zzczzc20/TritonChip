#!/usr/bin/env bash
set -eu
variant="$1"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HOME="$HOME/flux-hf" HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR="$HOME/r41-p3/snapview"
export R41_CPU_SCALE=ieee R41_CPU_FMA=0
case "$variant" in recip) export R41_CPU_SCALE=recip;; fma) export R41_CPU_FMA=1;; recip_fma) export R41_CPU_SCALE=recip R41_CPU_FMA=1;; *) exit 1;; esac
export PYTHONPATH="$HOME/r41_q35_multiturn_diag_20261031/tools/models:$HOME/r41_q35_multiturn_diag_20261031:$HOME/r41_q35_multiturn_diag_20261031/python:$HOME/r41_q35_multiturn_diag_20261031/compiler/python:$HOME/r41_q35_multiturn_diag_20261031/tools/asm"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_q35_cpu_scale_fma_20261031.py" --mode cpu --old-chat "$HOME/r41_q35_multiturn_diag_20261031/tools/models/chat.py" --tree "$HOME/r41_q35_multiturn_diag_20261031" --out "$HOME/r41_q35_cpu_${variant}_20261031_diag"
