    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4095
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v1, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #8
    v.cmp.lt     p2, v4, v1
    v.and        v8, v7, v3
    @p2 v.sel        v3, v6, v4
    v.movi       v4, #12
    v.sub        v6, v2, v8
    v.movi       v7, #0
    v.lshr       v9, v3, v4
    @p1 v.sel        v3, v6, v8
    s.rdspecial  s2, arg_base
    v.sub        v4, v1, v9
    v.sub        v6, v0, v3
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p3, v3, v7
    @p1 v.sel        v8, v6, v3
    @p2 v.sel        v6, v4, v9
    v.movi       v4, #256
    v.lshr       v9, v8, v5
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v5, #3840
    v.sub        v8, v0, v9
    v.mul        v10, v6, v4
    v.cmp.lt     p2, v4, v0
    @p1 v.sel        v11, v8, v9
    v.movi       v8, #4096
    v.sub        v9, v0, v4
    v.mul        v0, v11, v5
    v.cmp.lt     p1, v8, v2
    v.sub        v5, v2, v8
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.add        v2, v10, v0
    v.sub        v0, v7, v3
    @p1 v.sel        v10, v5, v8
    v.sub        v5, v1, v8
    v.cmp.lt     p1, v8, v1
    @p2 v.sel        v1, v9, v4
    v.cmp.lt     p2, v4, v7
    @p1 v.sel        v1, v5, v8
    s.ld.d       s5, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p3 v.sel        v1, v0, v3
    v.movi       v0, #255
    v.movi       v3, #512
    v.movi       v5, #8192
    v.and        v8, v1, v0
    v.mul        v0, v11, v3
    v.mul        v1, v6, v5
    v.sub        v3, v7, v8
    v.add        v5, v0, v4
    .li       s2, #1069066811
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v6, v3, v8
    v.add        v3, v5, v1
    .li       s2, #1060205080
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v8, v3, v6
    .li       s2, #1065353216
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v9, v2, v6
    v.ld.gather.h v2, [s3, v8]                   // index is in elements (ISA sec 9.1)
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.sub        v6, v7, v4
    s.add        s1, s5, s2                      // &out_ptr0[...]
    @p2 v.sel        v7, v6, v4
    vf.cvt.bf16.f32 v4, v2
    v.ld.gather.w v2, [s4, v9]                   // index is in elements (ISA sec 9.1)
    vf.neg       v6, v4
    vf.mul       v4, v6, v0
    v.exp2.approx v7, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v0, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v8, v1
    vf.fma       v1, v7, v0, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v7
    vf.add       v1, v0, v5
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v1, v0, v3
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v5, v3                      // a/y: faithful quotient
    vf.fms       v4, v0, v1, v5
    vf.fms       v1, v4, v3, v0
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v0
    vf.mul       v0, v2, v1
    vf.cvt.f32.bf16 v1, v0
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
