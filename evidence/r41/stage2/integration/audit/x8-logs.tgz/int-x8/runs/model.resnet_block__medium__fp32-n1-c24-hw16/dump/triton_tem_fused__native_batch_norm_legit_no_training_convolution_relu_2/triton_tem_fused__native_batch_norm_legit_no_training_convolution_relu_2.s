    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, role_id
    s.mul        s5, s3, s1
    s.movz       s3, #4160
    v.splat      v1, s2
    s.rdspecial  s2, arg_base
    v.add        v2, v1, v0
    s.mul        s6, s4, s3
    v.movi       v1, #0
    s.ld.d       s3, [s2, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.cmp.lt     p1, v2, v1
    s.movz       s2, #0
    s.add        s4, s3, s6                      // this context's own scratch
    v.movi       v3, #16
    s.addi       s3, s4, #0
    s.rdspecial  s6, arg_base
    v.sub        v4, v1, v2
    s.addi       s7, s3, #64
    s.addi       s8, s3, #128
    s.addi       s9, s3, #192
    s.addi       s10, s3, #256
    s.addi       s11, s3, #320
    s.addi       s12, s3, #384
    s.addi       s13, s3, #448
    s.addi       s14, s3, #512
    s.addi       s15, s3, #576
    s.addi       s16, s3, #640
    s.addi       s17, s3, #704
    s.addi       s18, s3, #768
    s.addi       s19, s3, #832
    s.addi       s20, s3, #896
    s.addi       s21, s3, #960
    s.addi       s22, s4, #1024
    v.cmp.lt     p2, v3, v1
    s.ld.d       s23, [s6, #0]                   // arg_X: device_ptr64 at arg_base+0
    @p1 v.sel        v5, v4, v2
    s.movz       s24, #6144
    s.ld.d       s25, [s6, #8]                   // arg_W: device_ptr64 at arg_base+8
    v.sub        v4, v1, v3
    s.movz       s26, #216
    s.ld.d       s26, [s6, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s27, #18
    s.movz       s28, #1
    s.ld.d       s29, [s6, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v6, #15
    v.movi       v7, #1
    s.ld.d       s30, [s6, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    v.and        v7, v5, v6
    @p2 v.sel        v5, v4, v3
    s.ld.d       s31, [s6, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    v.sub        v4, v1, v7
    s.ld.d       s32, [s6, #48]                  // out_ptr1: device_ptr64 at arg_base+48
    v.movi       v1, #0
    v.movi       v5, #4
    v.sub        v6, v1, v2
    v.cmp.lt     p2, v2, v1
    @p2 v.sel        v8, v6, v2
    v.movi       v2, #0
    v.lshr       v6, v8, v5
    v.movi       v5, #4
    v.sub        v8, v1, v6
    v.movi       v9, #0
    @p2 v.sel        v10, v8, v6
    v.movi       v6, #6144
    v.sub        v8, v2, v10
    v.cmp.lt     p2, v10, v2
    @p2 v.sel        v11, v8, v10
    v.sub        v8, v9, v10
    v.lshr       v12, v11, v5
    v.splat      v5, s5
    v.sub        v11, v2, v12
    v.cmp.lt     p3, v10, v9
    @p2 v.sel        v13, v11, v12
    @p3 v.sel        v11, v8, v10
    v.mul        v8, v13, v6
    v.movi       v6, #15
    v.add        v10, v5, v0
    v.extract    s6, v8, #0
    v.extract    s33, v8, #1
    v.and        v5, v11, v6
    v.splat      v6, s2
    v.splat      v11, s6
    v.cmp.lt     p2, v3, v1
    v.sub        v12, v1, v3
    v.add        v1, v6, v11
    @p1 v.sel        v11, v4, v7
    v.splat      v4, s33
    v.cmp.lt     p1, v3, v9
    v.add        v7, v6, v4
    v.movi       v4, #1
    v.extract    s6, v8, #2
    v.extract    s33, v8, #3
    @p2 v.sel        v4, v12, v3
    v.extract    s34, v8, #4
    v.splat      v4, s6
    v.cmp.lt     p2, v3, v2
    v.sub        v12, v2, v3
    v.add        v2, v6, v4
    v.movi       v4, #1
    v.extract    s6, v8, #5
    v.extract    s35, v8, #6
    v.movi       v4, #1
    @p2 v.sel        v4, v12, v3
    v.splat      v4, s33
    v.st.w       [s3, #0], v1
    v.splat      v1, s34
    v.add        v12, v6, v4
    v.add        v4, v6, v1
    v.st.w       [s7, #0], v7
    v.splat      v1, s6
    v.add        v7, v6, v1
    v.st.w       [s8, #0], v2
    v.sub        v1, v9, v3
    v.sub        v2, v9, v5
    @p1 v.sel        v9, v1, v3
    v.extract    s3, v8, #7
    v.splat      v1, s35
    @p3 v.sel        v9, v2, v5
    v.extract    s6, v8, #8
    v.extract    s7, v8, #9
    v.extract    s8, v8, #10
    v.extract    s33, v8, #11
    v.extract    s34, v8, #12
    v.extract    s35, v8, #13
    v.extract    s36, v8, #14
    v.splat      v2, s3
    v.extract    s3, v8, #15
    v.splat      v5, s6
    v.add        v8, v6, v1
    v.add        v1, v6, v2
    v.add        v2, v6, v5
    v.st.w       [s9, #0], v12
    v.movi       v5, #216
    v.mul        v12, v10, v5
    v.st.w       [s10, #0], v4
    v.splat      v4, s7
    v.add        v5, v6, v4
    v.st.w       [s11, #0], v7
    v.splat      v4, s8
    s.addi       s6, s2, #0
    v.add        v7, v6, v4
    v.st.w       [s12, #0], v8
    v.splat      v4, s33
    v.add        v8, v6, v4
    v.st.w       [s13, #0], v1
    v.splat      v1, s34
    v.add        v4, v6, v1
    v.st.w       [s14, #0], v2
    v.splat      v1, s35
    v.add        v2, v6, v1
    v.st.w       [s15, #0], v5
    v.splat      v1, s36
    v.add        v5, v6, v1
    v.st.w       [s16, #0], v7
    v.splat      v1, s3
    v.add        v7, v6, v1
    v.splat      v1, s2
    v.add        v6, v1, v12
    v.st.w       [s17, #0], v8
    v.st.w       [s18, #0], v4
    v.st.w       [s19, #0], v2
    v.st.w       [s20, #0], v5
    v.st.w       [s21, #0], v7
    fence.acq_rel.device
    v.st.w       [s22, #0], v6
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s3, s6, s27
    br.nz        s3, endfor_2
    s.movz       s3, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s6, s3
    s.movz       s3, #2
    s.sub        s9, s7, s8
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s10, s3, s7
    s.xor        s7, s6, s9
    s.sub        s11, s8, s10
    s.sub        s8, s7, s9
    s.xor        s7, s9, s11
    s.lshri      s9, s8, #1
    s.movz       s10, #0
    s.xor        s12, s9, s7
    s.movz       s13, #0
    s.sub        s14, s12, s7
    s.movz       s7, #0
    s.cmp.lt     s12, s14, s10
    s.movz       s10, #0
    s.sub        s15, s13, s12
    .li       s12, #1431655766
    s.xor        s13, s14, s15
    s.cmp.lt     s16, s6, s7
    s.sub        s7, s13, s15
    s.sub        s13, s10, s16
    s.mul        s10, s7, s12
    s.xor        s12, s6, s13
    s.movz       s16, #3
    s.sub        s17, s12, s13
    s.movz       s12, #0
    s.lshri      s18, s10, #32
    s.cmp.lt     s10, s16, s12
    s.muli       s12, s9, #2
    s.sub        s9, s8, s12
    s.lshri      s8, s17, #1
    s.movz       s9, #0
    s.muli       s12, s8, #2
    s.sub        s8, s9, s10
    s.movz       s9, #0
    s.cmp.lt     s10, s3, s9
    s.sub        s9, s17, s12
    s.movz       s12, #0
    s.xor        s17, s9, s13
    s.sub        s9, s12, s10
    s.sub        s10, s7, s18
    s.sub        s12, s17, s13
    s.lshri      s13, s10, #1
    s.mul        s10, s12, s1
    s.add        s12, s18, s13
    s.xor        s13, s3, s9
    s.lshri      s17, s12, #1
    s.xor        s12, s15, s8
    s.muli       s15, s17, #3
    s.xor        s18, s3, s11
    s.sub        s3, s13, s9
    s.movz       s3, #0
    s.movz       s9, #0
    s.cmp.lt     s13, s14, s3
    s.xor        s3, s17, s12
    s.sub        s17, s9, s13
    .li       s9, #1431655766
    s.xor        s13, s14, s17
    s.sub        s14, s3, s12
    s.sub        s3, s13, s17
    s.movz       s12, #0
    s.mul        s13, s3, s9
    s.cmp.lt     s9, s16, s12
    s.sub        s12, s18, s11
    s.sub        s11, s14, s28
    v.movi       v1, #384
    s.lshri      s12, s13, #32
    v.splat      v2, s11
    s.sub        s11, s3, s12
    v.add        v4, v2, v9
    s.lshri      s13, s11, #1
    v.mul        v2, v4, v1
    s.add        s11, s12, s13
    v.splat      v1, s10
    s.lshri      s12, s11, #1
    v.add        v5, v0, v1
    s.muli       s11, s12, #3
    s.movz       s12, #0
    s.xor        s13, s16, s8
    s.sub        s18, s12, s9
    s.movz       s9, #24
    s.sub        s12, s3, s11
    s.xor        s3, s16, s18
    s.xor        s11, s12, s17
    s.sub        s12, s13, s8
    s.sub        s8, s11, s17
    s.addi       s11, s4, #0
    s.sub        s12, s8, s28
    v.movi       v1, #24
    v.splat      v6, s12
    v.ld.w       v7, [s11, #0]
    v.add        v8, v6, v11
    v.extract    s11, v2, #0
    v.mul        v6, v8, v1
    v.splat      v12, s11
    v.extract    s11, v6, #0
    v.splat      v14, s11
    s.addi       s11, s4, #1088
    s.sub        s12, s7, s15
    s.movz       s7, #0
    v.iota       v15                             // arange(0, VLEN)
    s.add        s12, s7, s10                    // the tile origin
    v.add        v16, v12, v14
    v.splat      v12, s12
    s.addi       s7, s4, #64
    v.add        v14, v15, v12
    v.extract    s12, v2, #1
    v.add        v12, v16, v14
    v.extract    s13, v6, #1
    v.add        v16, v7, v12
    v.splat      v7, s12
    v.st.w       [s11, #0], v16
    s.addi       s12, s11, #64
    s.sub        s15, s3, s18
    v.splat      v12, s13
    s.addi       s3, s4, #128
    v.add        v16, v7, v12
    v.extract    s13, v2, #2
    v.add        v7, v16, v14
    v.extract    s15, v6, #2
    v.splat      v12, s13
    v.ld.w       v16, [s7, #0]
    v.splat      v17, s15
    s.addi       s7, s11, #128
    v.add        v18, v12, v17
    s.addi       s13, s4, #192
    v.add        v12, v18, v14
    v.extract    s15, v2, #3
    s.addi       s16, s11, #192
    s.movz       s17, #384
    v.extract    s17, v6, #3
    v.add        v17, v16, v7
    v.splat      v7, s15
    v.st.w       [s12, #0], v17
    v.splat      v16, s17
    s.addi       s12, s4, #256
    v.add        v17, v7, v16
    v.extract    s15, v2, #4
    v.add        v7, v17, v14
    v.extract    s17, v6, #4
    v.splat      v16, s15
    v.splat      v17, s17
    s.addi       s15, s11, #256
    v.ld.w       v18, [s3, #0]
    v.add        v19, v16, v17
    s.addi       s3, s4, #320
    v.add        v16, v19, v14
    v.extract    s17, v2, #5
    v.splat      v17, s17
    v.extract    s17, v6, #5
    v.splat      v19, s17
    s.addi       s17, s11, #320
    v.add        v20, v17, v19
    v.add        v17, v18, v12
    v.add        v12, v20, v14
    v.st.w       [s7, #0], v17
    s.addi       s7, s4, #384
    v.ld.w       v17, [s13, #0]
    v.extract    s13, v2, #6
    v.splat      v18, s13
    v.extract    s13, v6, #6
    v.splat      v19, s13
    s.addi       s13, s11, #384
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v17, v7
    v.st.w       [s16, #0], v19
    s.addi       s16, s4, #448
    v.ld.w       v7, [s12, #0]
    v.extract    s12, v2, #7
    v.splat      v17, s12
    v.extract    s12, v6, #7
    v.splat      v19, s12
    s.addi       s12, s11, #448
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v7, v16
    v.st.w       [s15, #0], v19
    s.addi       s15, s4, #512
    v.ld.w       v7, [s3, #0]
    v.extract    s3, v2, #8
    v.splat      v16, s3
    v.extract    s3, v6, #8
    v.splat      v19, s3
    s.addi       s3, s11, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v7, v12
    v.st.w       [s17, #0], v19
    s.addi       s17, s4, #576
    v.ld.w       v7, [s7, #0]
    v.extract    s7, v2, #9
    v.splat      v12, s7
    v.extract    s7, v6, #9
    v.splat      v19, s7
    s.addi       s7, s11, #576
    v.add        v20, v12, v19
    v.add        v12, v20, v14
    v.add        v19, v7, v18
    v.st.w       [s13, #0], v19
    s.addi       s13, s4, #640
    v.ld.w       v7, [s16, #0]
    v.extract    s16, v2, #10
    v.splat      v18, s16
    v.extract    s16, v6, #10
    v.splat      v19, s16
    s.addi       s16, s11, #640
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v7, v17
    v.st.w       [s12, #0], v19
    s.addi       s12, s4, #704
    v.ld.w       v7, [s15, #0]
    v.extract    s15, v2, #11
    v.splat      v17, s15
    v.extract    s15, v6, #11
    v.splat      v19, s15
    s.addi       s15, s11, #704
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v7, v16
    v.st.w       [s3, #0], v19
    s.addi       s3, s4, #768
    v.ld.w       v7, [s17, #0]
    v.extract    s17, v2, #12
    v.splat      v16, s17
    v.extract    s17, v6, #12
    v.splat      v19, s17
    s.addi       s17, s11, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v7, v12
    v.st.w       [s7, #0], v19
    s.addi       s7, s4, #832
    v.ld.w       v7, [s13, #0]
    v.extract    s13, v2, #13
    v.splat      v12, s13
    v.extract    s13, v6, #13
    v.splat      v19, s13
    s.addi       s13, s11, #832
    v.add        v20, v12, v19
    v.add        v12, v20, v14
    v.add        v19, v7, v18
    v.st.w       [s16, #0], v19
    s.addi       s16, s4, #896
    v.ld.w       v7, [s12, #0]
    v.extract    s12, v2, #14
    v.splat      v18, s12
    v.extract    s12, v6, #14
    v.splat      v19, s12
    s.addi       s12, s11, #896
    v.add        v20, v18, v19
    v.movi       v18, #1
    v.add        v19, v20, v14
    s.addi       s18, s11, #960
    v.add        v20, v7, v17
    v.cmp.lt     p1, v13, v18
    v.st.w       [s15, #0], v20
    s.addi       s11, s4, #960
    v.movi       v7, #1
    v.movi       v17, #0
    @p1 v.sel        v18, v7, v17
    v.ld.w       v7, [s3, #0]
    v.extract    s3, v2, #15
    v.movi       v2, #0
    v.splat      v17, s3
    v.extract    s3, v6, #15
    v.splat      v6, s3
    v.movi       v20, #1
    v.cmp.ge     p1, v4, v2
    v.add        v21, v17, v6
    v.movi       v6, #0
    v.add        v17, v7, v16
    @p1 v.sel        v7, v20, v6
    v.st.w       [s17, #0], v17
    v.movi       v6, #1
    v.movi       v16, #0
    v.cmp.lt     p1, v4, v3
    v.add        v4, v21, v14
    @p1 v.sel        v14, v6, v16
    v.movi       v6, #1
    v.cmp.ge     p1, v8, v2
    v.ld.w       v2, [s7, #0]
    v.movi       v16, #0
    v.movi       v17, #1
    @p1 v.sel        v20, v6, v16
    v.movi       v6, #0
    v.cmp.lt     p1, v8, v3
    @p1 v.sel        v8, v17, v6
    v.cmp.lt     p1, v5, v1
    v.add        v1, v2, v12
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.st.w       [s13, #0], v1
    v.extract    s7, v18, #0
    s.addi       s13, s4, #1088
    v.ld.w       v1, [s16, #0]
    v.extract    s15, v7, #0
    v.splat      v2, s7
    v.movi       v5, #0
    v.splat      v6, s15
    v.movi       v12, #0
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v6, v12
    v.add        v2, v1, v19
    p.and        p4, p2, p3
    v.st.w       [s12, #0], v2
    v.extract    s7, v14, #0
    v.splat      v1, s7
    v.movi       v2, #0
    v.ld.w       v5, [s11, #0]
    v.extract    s7, v20, #0
    v.cmp.ne     p2, v1, v2
    v.splat      v1, s7
    v.movi       v2, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v1, v2
    p.and        p4, p3, p2
    v.add        v1, v5, v4
    v.extract    s7, v8, #0
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    v.splat      v1, s7
    v.movi       v2, #0
    v.extract    s7, v18, #1
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    v.extract    s11, v7, #1
    p.and        p2, p3, p1
    v.splat      v1, s7
    v.ld.w       v2, [s13, #0]
    v.movi       v4, #0
    v.splat      v5, s11
    v.movi       v6, #0
    s.addi       s7, s4, #1152
    v.extract    s11, v14, #1
    v.cmp.ne     p3, v1, v4
    v.cmp.ne     p4, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s23, v2]              // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s11, v20, #1
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s11
    v.movi       v2, #0
    p.and        p4, p2, p3
    v.extract    s11, v8, #1
    v.cmp.ne     p2, v1, v2
    v.splat      v1, s11
    a.vwrite     a1, s3, v5
    v.ld.w       v2, [s7, #0]
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v1, v4
    p.and        p4, p3, p2
    v.extract    s3, v18, #2
    p.and        p2, p4, p1
    v.extract    s7, v7, #2
    v.splat      v1, s3
    v.movi       v4, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s7
    v.movi       v6, #0
    s.movz       s3, #1
    s.addi       s7, s4, #1216
    v.extract    s11, v14, #2
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v2, v6
    v.splat      v1, s11
    v.movi       v2, #0
    a.vwrite     a1, s3, v5
    v.ld.w       v4, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #2
    v.cmp.ne     p2, v1, v2
    v.splat      v1, s3
    v.movi       v2, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #2
    v.cmp.ne     p2, v1, v2
    v.splat      v1, s3
    v.movi       v2, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    v.extract    s3, v18, #3
    p.and        p2, p3, p1
    v.extract    s7, v7, #3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #2
    s.addi       s7, s4, #1280
    v.extract    s11, v14, #3
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #3
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #3
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #4
    p.and        p2, p3, p1
    v.extract    s7, v7, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #3
    s.addi       s7, s4, #1344
    v.extract    s11, v14, #4
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #5
    p.and        p2, p3, p1
    v.extract    s7, v7, #5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #4
    s.addi       s7, s4, #1408
    v.extract    s11, v14, #5
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #5
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #5
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #6
    p.and        p2, p3, p1
    v.extract    s7, v7, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #5
    s.addi       s7, s4, #1472
    v.extract    s11, v14, #6
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #7
    p.and        p2, p3, p1
    v.extract    s7, v7, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #6
    s.addi       s7, s4, #1536
    v.extract    s11, v14, #7
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #7
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #7
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #8
    p.and        p2, p3, p1
    v.extract    s7, v7, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #7
    s.addi       s7, s4, #1600
    v.extract    s11, v14, #8
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #9
    p.and        p2, p3, p1
    v.extract    s7, v7, #9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #8
    s.addi       s7, s4, #1664
    v.extract    s11, v14, #9
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #9
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #9
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #10
    p.and        p2, p3, p1
    v.extract    s7, v7, #10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #9
    s.addi       s7, s4, #1728
    v.extract    s11, v14, #10
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #11
    p.and        p2, p3, p1
    v.extract    s7, v7, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #10
    s.addi       s7, s4, #1792
    v.extract    s11, v14, #11
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #11
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #11
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #12
    p.and        p2, p3, p1
    v.extract    s7, v7, #12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #11
    s.addi       s7, s4, #1856
    v.extract    s11, v14, #12
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #13
    p.and        p2, p3, p1
    v.extract    s7, v7, #13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #12
    s.addi       s7, s4, #1920
    v.extract    s11, v14, #13
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #13
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #13
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #14
    p.and        p2, p3, p1
    v.extract    s7, v7, #14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #13
    s.addi       s7, s4, #1984
    v.extract    s11, v14, #14
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v1, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v2
    v.ld.w       v2, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s3, v18, #15
    p.and        p2, p3, p1
    v.extract    s7, v7, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    s.movz       s3, #14
    s.addi       s7, s4, #2048
    v.extract    s11, v14, #15
    v.cmp.ne     p2, v2, v4
    v.cmp.ne     p3, v5, v6
    v.splat      v2, s11
    v.movi       v4, #0
    a.vwrite     a1, s3, v1
    v.ld.w       v1, [s7, #0]
    p.and        p4, p2, p3
    v.extract    s3, v20, #15
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s3, v8, #15
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    s.movz       s3, #72
    p.and        p2, p3, p1
    s.movz       s7, #15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s4, #1024
    s.mul        s12, s14, s3
    s.movz       s3, #0
    s.mul        s13, s8, s9
    s.add        s8, s3, s10                     // the tile origin
    s.addi       s3, s4, #2112
    s.add        s14, s8, s12                    // the tile origin
    s.addi       s8, s4, #1024
    s.add        s12, s14, s13                   // the tile origin
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s11, #0]
    v.splat      v2, s12
    s.addi       s7, s12, #1
    s.addi       s11, s3, #64
    v.splat      v4, s7
    s.addi       s7, s4, #1024
    s.addi       s13, s12, #2
    s.addi       s14, s3, #128
    v.splat      v5, s13
    s.addi       s13, s4, #1024
    v.add        v6, v1, v2
    s.addi       s15, s12, #3
    v.st.w       [s3, #0], v6
    v.splat      v1, s15
    s.addi       s15, s3, #192
    s.addi       s16, s4, #1024
    s.addi       s17, s12, #4
    s.addi       s18, s3, #256
    v.splat      v2, s17
    s.addi       s17, s4, #1024
    v.ld.w       v6, [s8, #0]
    s.addi       s8, s12, #5
    v.splat      v7, s8
    s.addi       s8, s3, #320
    v.add        v8, v6, v4
    v.st.w       [s11, #0], v8
    s.addi       s11, s4, #1024
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s12, #6
    v.splat      v6, s7
    s.addi       s7, s3, #384
    v.add        v8, v4, v5
    v.st.w       [s14, #0], v8
    s.addi       s14, s4, #1024
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s12, #7
    v.splat      v5, s13
    s.addi       s13, s3, #448
    v.add        v8, v4, v1
    v.st.w       [s15, #0], v8
    s.addi       s15, s4, #1024
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s12, #8
    v.splat      v4, s16
    s.addi       s16, s3, #512
    v.add        v8, v1, v2
    v.st.w       [s18, #0], v8
    s.addi       s18, s4, #1024
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s12, #9
    v.splat      v2, s17
    s.addi       s17, s3, #576
    v.add        v8, v1, v7
    v.st.w       [s8, #0], v8
    s.addi       s8, s4, #1024
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s12, #10
    v.splat      v7, s11
    s.addi       s11, s3, #640
    v.add        v8, v1, v6
    v.st.w       [s7, #0], v8
    s.addi       s7, s4, #1024
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #11
    v.splat      v6, s14
    s.addi       s14, s3, #704
    v.add        v8, v1, v5
    v.st.w       [s13, #0], v8
    s.addi       s13, s4, #1024
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #12
    v.splat      v5, s15
    s.addi       s15, s3, #768
    v.add        v8, v1, v4
    v.st.w       [s16, #0], v8
    s.addi       s16, s4, #1024
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s12, #13
    v.splat      v4, s18
    s.addi       s18, s3, #832
    v.add        v8, v1, v2
    v.st.w       [s17, #0], v8
    s.addi       s17, s4, #1024
    v.splat      v1, s9
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s12, #14
    s.addi       s19, s12, #15
    v.splat      v8, s8
    s.addi       s8, s3, #896
    v.splat      v12, s19
    s.addi       s12, s4, #1024
    s.addi       s19, s3, #960
    v.add        v14, v2, v7
    v.st.w       [s11, #0], v14
    s.addi       s3, s4, #2112
    v.splat      v2, s9
    s.movz       s9, #0
    s.add        s11, s9, s5                     // the tile origin
    v.splat      v7, s11
    s.movz       s9, #0
    v.add        v14, v15, v7
    v.ld.w       v7, [s7, #0]
    s.add        s7, s9, s10                     // the tile origin
    v.cmp.lt     p1, v14, v2
    v.splat      v2, s7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.cmp.lt     p2, v2, v1
    p.and        p3, p2, p1
    v.add        v2, v7, v6
    s.movz       s10, #1
    v.st.w       [s14, #0], v2
    s.addi       s11, s4, #2176
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s7, #1
    v.splat      v6, s13
    v.cmp.lt     p2, v6, v1
    p.and        p4, p2, p1
    v.add        v6, v2, v5
    v.st.w       [s15, #0], v6
    s.addi       s13, s4, #2240
    s.movz       s14, #2
    v.ld.w       v2, [s16, #0]
    s.addi       s15, s7, #2
    v.splat      v5, s15
    v.add        v6, v2, v4
    v.cmp.lt     p2, v5, v1
    v.st.w       [s18, #0], v6
    p.and        p5, p2, p1
    v.ld.w       v2, [s17, #0]
    s.addi       s15, s4, #2304
    s.movz       s16, #3
    v.add        v4, v2, v8
    s.addi       s17, s7, #3
    v.st.w       [s8, #0], v4
    v.splat      v2, s17
    v.ld.w       v4, [s12, #0]
    s.movz       s8, #4
    v.add        v5, v4, v12
    s.addi       s12, s4, #2368
    v.st.w       [s19, #0], v5
    fence.acq_rel.device
    s.addi       s17, s7, #4
    v.splat      v4, s17
    v.ld.w       v5, [s3, #0]
    s.addi       s3, s4, #2432
    s.addi       s17, s7, #5
    s.movz       s18, #5
    v.splat      v6, s17
    s.movz       s17, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s25, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p2, p1
    a.vwrite     a2, s9, v7
    v.ld.w       v2, [s11, #0]
    s.addi       s9, s4, #2496
    s.addi       s11, s7, #6
    v.splat      v5, s11
    s.movz       s11, #7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    a.vwrite     a2, s10, v7
    v.ld.w       v2, [s13, #0]
    s.addi       s10, s4, #2560
    s.addi       s13, s7, #7
    v.splat      v4, s13
    s.movz       s13, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p5, p2, p1
    a.vwrite     a2, s14, v7
    v.ld.w       v2, [s15, #0]
    s.addi       s14, s4, #2624
    s.addi       s15, s7, #8
    v.splat      v6, s15
    s.movz       s15, #9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    a.vwrite     a2, s16, v7
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s4, #2688
    s.addi       s16, s7, #9
    v.splat      v5, s16
    s.movz       s16, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    a.vwrite     a2, s8, v7
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s4, #2752
    s.addi       s8, s7, #10
    v.splat      v4, s8
    s.movz       s8, #11
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p5, p2, p1
    a.vwrite     a2, s18, v7
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s4, #2816
    s.addi       s18, s7, #11
    v.splat      v6, s18
    s.movz       s18, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    a.vwrite     a2, s17, v7
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s4, #2880
    s.addi       s17, s7, #12
    v.splat      v5, s17
    s.movz       s17, #13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    a.vwrite     a2, s11, v7
    v.ld.w       v2, [s14, #0]
    s.addi       s11, s4, #2944
    s.addi       s14, s7, #13
    v.splat      v4, s14
    s.movz       s14, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p5, p2, p1
    a.vwrite     a2, s13, v7
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s4, #3008
    s.addi       s13, s7, #14
    v.splat      v6, s13
    s.movz       s13, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    a.vwrite     a2, s15, v7
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s4, #3072
    s.addi       s15, s7, #15
    v.movi       v5, #0
    v.splat      v7, s15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    a.vwrite     a2, s16, v8
    v.ld.w       v2, [s9, #0]
    s.movz       s9, #0
    s.movz       s15, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p5, p2, p1
    a.vwrite     a2, s8, v4
    v.ld.w       v2, [s10, #0]
    s.movz       s8, #1
    s.movz       s10, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s25, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v1
    p.and        p3, p2, p1
    a.vwrite     a2, s18, v4
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #3
    s.movz       s16, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s25, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s12, #5
    s.movz       s17, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s25, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s25, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s14, #8
    a.vwrite     a2, s13, v2
    a.vread      v1, a1, s9
    a.vread      v2, a2, s15
    v.extract    s9, v1, #0
    v.splat      v4, s9
    v.extract    s9, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s9
    a.vread      v4, a2, s8
    v.extract    s8, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s8
    a.vread      v4, a2, s10
    v.extract    s8, v1, #3
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s8
    a.vread      v4, a2, s11
    v.extract    s8, v1, #4
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s8
    a.vread      v4, a2, s16
    v.extract    s8, v1, #5
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s8
    a.vread      v4, a2, s12
    v.extract    s8, v1, #6
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s8
    a.vread      v4, a2, s17
    v.extract    s8, v1, #7
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s8
    a.vread      v4, a2, s3
    v.extract    s3, v1, #8
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s14
    s.movz       s3, #9
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s3
    s.movz       s3, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s3
    s.movz       s3, #1
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s3
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #1
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #2
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #2
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #3
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #4
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #6
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #8
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #9
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #9
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #10
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #11
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #12
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #13
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #14
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v6, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #15
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s7
    a.vread      v2, a2, s8
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s9
    v.extract    s3, v1, #2
    vf.fma       v5, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s10
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s3
    s.movz       s3, #15
    vf.fma       v6, v2, v4, v5
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v5, v2, v4, v6
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v2, v4, v5
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v5, v2, v4, v6
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v2, v4, v5
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v5, v2, v4, v6
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v2, v4, v5
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #0
    vf.fma       v4, v1, v2, v6
    s.movz       s8, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    s.movz       s10, #1
    a.vwrite     a3, s3, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s8
    s.movz       s3, #1
    vf.add       v4, v1, v2
    s.movz       s7, #1
    s.movz       s8, #2
    s.movz       s11, #2
    a.vwrite     a4, s9, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s3
    s.movz       s3, #2
    vf.add       v4, v1, v2
    s.movz       s9, #3
    s.movz       s10, #3
    s.movz       s12, #3
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s11
    s.movz       s7, #4
    vf.add       v4, v1, v2
    s.movz       s8, #4
    s.movz       s11, #4
    s.movz       s13, #5
    a.vwrite     a4, s3, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s10
    s.movz       s3, #5
    vf.add       v4, v1, v2
    s.movz       s9, #5
    s.movz       s10, #6
    s.movz       s14, #6
    a.vwrite     a4, s12, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s8
    s.movz       s7, #6
    vf.add       v4, v1, v2
    s.movz       s8, #7
    s.movz       s12, #7
    s.movz       s15, #7
    a.vwrite     a4, s11, v4
    a.vread      v1, a0, s13
    a.vread      v2, a3, s3
    s.movz       s3, #8
    vf.add       v4, v1, v2
    s.movz       s11, #8
    s.movz       s13, #8
    s.movz       s16, #9
    a.vwrite     a4, s9, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s14
    s.movz       s9, #9
    vf.add       v4, v1, v2
    s.movz       s10, #9
    s.movz       s14, #10
    s.movz       s17, #10
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s12
    s.movz       s7, #10
    vf.add       v4, v1, v2
    s.movz       s8, #11
    s.movz       s12, #11
    s.movz       s18, #11
    a.vwrite     a4, s15, v4
    a.vread      v1, a0, s3
    a.vread      v2, a3, s11
    s.movz       s3, #12
    vf.add       v4, v1, v2
    s.movz       s11, #12
    s.movz       s15, #12
    s.movz       s19, #13
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s16
    a.vread      v2, a3, s9
    s.movz       s9, #13
    vf.add       v4, v1, v2
    s.movz       s13, #13
    s.movz       s16, #14
    a.vwrite     a4, s10, v4
    a.vread      v1, a0, s14
    a.vread      v2, a3, s17
    s.movz       s10, #14
    vf.add       v4, v1, v2
    s.movz       s14, #14
    s.movz       s17, #15
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s12
    s.movz       s7, #15
    vf.add       v4, v1, v2
    s.movz       s8, #15
    s.movz       s12, #0
    a.vwrite     a4, s18, v4
    a.vread      v1, a0, s3
    a.vread      v2, a3, s11
    s.movz       s3, #0
    vf.add       v4, v1, v2
    s.movz       s11, #1
    s.movz       s18, #1
    a.vwrite     a4, s15, v4
    a.vread      v1, a0, s19
    a.vread      v2, a3, s9
    s.movz       s9, #2
    vf.add       v4, v1, v2
    s.movz       s15, #2
    s.movz       s19, #3
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s16
    a.vread      v2, a3, s10
    s.movz       s10, #3
    vf.add       v4, v1, v2
    s.movz       s13, #4
    s.movz       s16, #4
    a.vwrite     a4, s14, v4
    a.vread      v1, a0, s17
    a.vread      v2, a3, s7
    s.movz       s7, #5
    vf.add       v4, v1, v2
    s.movz       s14, #5
    s.movz       s17, #6
    a.vwrite     a4, s8, v4
    a.vread      v1, a4, s12
    s.movz       s8, #6
    a.vwrite     a0, s3, v1
    a.vread      v1, a4, s11
    s.movz       s3, #7
    a.vwrite     a0, s18, v1
    a.vread      v1, a4, s9
    s.movz       s9, #7
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s19
    s.movz       s11, #8
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s13
    s.movz       s10, #8
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s7
    s.movz       s7, #9
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s17
    s.movz       s12, #9
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s3
    s.movz       s3, #10
    a.vwrite     a0, s9, v1
    a.vread      v1, a4, s11
    s.movz       s8, #10
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s7
    s.movz       s7, #11
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s3
    s.movz       s3, #11
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s7
    s.movz       s7, #12
    a.vwrite     a0, s3, v1
    s.movz       s3, #12
    a.vread      v1, a4, s7
    s.movz       s7, #13
    a.vwrite     a0, s3, v1
    s.movz       s3, #13
    a.vread      v1, a4, s7
    s.movz       s7, #14
    a.vwrite     a0, s3, v1
    s.movz       s3, #14
    a.vread      v1, a4, s7
    s.movz       s7, #15
    a.vwrite     a0, s3, v1
    s.movz       s3, #15
    a.vread      v1, a4, s7
    s.add        s7, s6, s28
    s.movz       s8, #1
    a.vwrite     a0, s3, v1
    s.mov        s6, s7
    br.nz        s8, for_1
endfor_2:
    s.muli       s3, s5, #256                    // a runtime tile origin, x256
    s.movz       s6, #0
    s.movz       s7, #256
    v.extract    s8, v9, #0
    v.splat      v0, s8
    v.splat      v1, s1
    s.add        s1, s6, s3                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s7
    v.extract    s3, v11, #0
    v.splat      v5, s3
    v.mul        v6, v0, v1
    v.mul        v0, v2, v4
    v.splat      v2, s1
    v.add        v4, v5, v6
    v.add        v5, v0, v2
    v.movi       v0, #1
    v.add        v2, v4, v5
    v.movi       v4, #1
    v.movi       v6, #0
    v.movi       v7, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v13, v0
    v.extract    s1, v13, #0
    v.splat      v0, s1
    v.splat      v12, s24
    v.cmp.lt     p2, v9, v3
    @p1 v.sel        v14, v4, v6
    v.mul        v4, v0, v12
    @p2 v.sel        v0, v7, v8
    v.add        v6, v2, v4
    v.movi       v2, #0
    v.movi       v4, #1
    v.movi       v7, #0
    s.movz       s1, #0
    v.cmp.lt     p1, v11, v3
    v.cmp.lt     p2, v6, v2
    @p1 v.sel        v3, v4, v7
    v.sub        v4, v2, v6
    s.add        s3, s1, s5                      // the tile origin
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s3
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    v.add        v15, v7, v8
    v.movi       v7, #24
    @p2 v.sel        v8, v4, v6
    s.addi       s3, s4, #3136
    v.splat      v4, s2
    v.cmp.lt     p1, v10, v7
    s.add        s2, s29, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    .li       s1, #925353388
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s5, #4                      // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s7, s5, #4                      // a runtime tile origin, x4
    v.movi       v7, #0
    s.movz       s5, #256
    s.add        s8, s26, s1                     // the tile origin
    v.movi       v10, #255
    s.add        s1, s30, s6                     // the tile origin
    v.and        v16, v8, v10
    s.movz       s6, #24
    v.sub        v8, v2, v16
    v.splat      v10, s6
    @p2 v.sel        v17, v8, v16
    s.add        s6, s31, s7                     // the tile origin
    v.extract    s7, v9, #1
    v.splat      v8, s7
    v.extract    s7, v11, #1
    v.splat      v16, s7
    v.mul        v18, v8, v1
    v.extract    s7, v13, #1
    v.add        v8, v16, v18
    v.splat      v16, s7
    v.add        v18, v8, v5
    v.mul        v8, v16, v12
    v.movi       v16, #0
    v.add        v19, v18, v8
    v.movi       v8, #255
    v.sub        v18, v16, v19
    v.cmp.lt     p2, v19, v16
    @p2 v.sel        v20, v18, v19
    v.mul        v18, v17, v10
    v.and        v17, v20, v8
    v.add        v8, v15, v18
    v.sub        v18, v16, v17
    v.add        v19, v4, v8
    @p2 v.sel        v8, v18, v17
    s.addi       s7, s3, #64
    v.mul        v17, v8, v10
    s.addi       s9, s3, #128
    v.add        v8, v15, v17
    v.st.w       [s3, #0], v19
    v.add        v17, v4, v8
    v.splat      v8, s5
    v.extract    s5, v11, #2
    v.splat      v18, s5
    v.sub        v19, v2, v8
    v.sub        v20, v16, v8
    v.cmp.lt     p2, v8, v2
    v.cmp.lt     p3, v8, v16
    v.movi       v2, #1
    v.extract    s5, v9, #2
    v.splat      v2, s5
    v.extract    s5, v13, #2
    v.mul        v16, v2, v1
    v.st.w       [s7, #0], v17
    v.add        v2, v18, v16
    @p2 v.sel        v16, v19, v8
    v.extract    s7, v9, #3
    v.splat      v16, s7
    v.extract    s7, v11, #3
    v.splat      v17, s7
    v.splat      v18, s5
    v.add        v19, v2, v5
    v.mul        v2, v18, v12
    v.movi       v18, #0
    v.add        v21, v19, v2
    v.movi       v2, #255
    v.sub        v19, v18, v21
    v.cmp.lt     p2, v21, v18
    @p2 v.sel        v22, v19, v21
    s.addi       s5, s3, #192
    v.and        v19, v22, v2
    v.sub        v2, v18, v8
    v.sub        v21, v18, v19
    v.cmp.lt     p4, v8, v18
    @p2 v.sel        v18, v21, v19
    v.movi       v19, #1
    v.mul        v19, v16, v1
    v.extract    s7, v13, #3
    v.add        v16, v17, v19
    v.splat      v17, s7
    v.add        v19, v16, v5
    v.mul        v16, v17, v12
    v.mul        v17, v18, v10
    @p3 v.sel        v18, v20, v8
    v.extract    s7, v9, #4
    v.splat      v18, s7
    v.extract    s7, v11, #4
    v.splat      v20, s7
    v.add        v21, v19, v16
    v.movi       v16, #0
    v.movi       v19, #255
    v.cmp.lt     p2, v21, v16
    v.add        v22, v15, v17
    s.addi       s7, s3, #256
    v.add        v17, v4, v22
    v.cmp.lt     p3, v8, v16
    v.st.w       [s9, #0], v17
    v.sub        v17, v16, v21
    v.movi       v22, #1
    v.mul        v22, v18, v1
    v.extract    s9, v13, #4
    v.add        v18, v20, v22
    v.splat      v20, s9
    v.add        v22, v18, v5
    v.mul        v18, v20, v12
    @p2 v.sel        v20, v17, v21
    v.sub        v17, v16, v8
    v.and        v21, v20, v19
    @p4 v.sel        v19, v2, v8
    v.extract    s9, v9, #5
    v.splat      v2, s9
    v.extract    s9, v11, #5
    v.splat      v19, s9
    v.add        v20, v22, v18
    v.movi       v18, #0
    v.sub        v22, v16, v21
    v.cmp.lt     p4, v20, v18
    @p2 v.sel        v16, v22, v21
    v.sub        v21, v18, v20
    v.mul        v22, v16, v10
    @p4 v.sel        v16, v21, v20
    v.movi       v20, #255
    v.add        v21, v15, v22
    v.and        v22, v16, v20
    v.add        v16, v4, v21
    v.sub        v20, v18, v22
    s.addi       s9, s3, #320
    @p4 v.sel        v21, v20, v22
    v.st.w       [s5, #0], v16
    v.mul        v16, v21, v10
    v.sub        v20, v18, v8
    v.add        v21, v15, v16
    v.cmp.lt     p2, v8, v18
    v.add        v16, v4, v21
    v.movi       v18, #1
    v.mul        v18, v2, v1
    v.extract    s5, v13, #5
    v.add        v2, v19, v18
    v.splat      v18, s5
    v.add        v19, v2, v5
    v.mul        v2, v18, v12
    v.st.w       [s7, #0], v16
    @p3 v.sel        v16, v17, v8
    v.extract    s5, v9, #6
    v.splat      v16, s5
    v.extract    s5, v11, #6
    v.splat      v17, s5
    v.add        v18, v19, v2
    v.movi       v2, #0
    v.movi       v19, #255
    v.sub        v21, v2, v18
    v.cmp.lt     p3, v18, v2
    @p3 v.sel        v22, v21, v18
    s.addi       s5, s3, #384
    v.and        v18, v22, v19
    v.sub        v19, v2, v8
    v.sub        v21, v2, v18
    v.cmp.lt     p4, v8, v2
    @p3 v.sel        v2, v21, v18
    v.movi       v18, #1
    v.mul        v18, v16, v1
    v.extract    s7, v13, #6
    v.add        v16, v17, v18
    v.splat      v17, s7
    v.add        v18, v16, v5
    v.mul        v16, v17, v12
    v.mul        v17, v2, v10
    @p2 v.sel        v2, v20, v8
    v.extract    s7, v9, #7
    v.splat      v2, s7
    v.extract    s7, v11, #7
    v.splat      v20, s7
    v.add        v21, v18, v16
    v.movi       v16, #0
    v.movi       v18, #255
    v.cmp.lt     p2, v21, v16
    v.add        v22, v15, v17
    s.addi       s7, s3, #448
    v.add        v17, v4, v22
    v.cmp.lt     p3, v8, v16
    v.st.w       [s9, #0], v17
    v.sub        v17, v16, v21
    v.movi       v22, #1
    v.mul        v22, v2, v1
    v.extract    s9, v13, #7
    v.add        v2, v20, v22
    v.splat      v20, s9
    v.add        v22, v2, v5
    v.mul        v2, v20, v12
    @p2 v.sel        v20, v17, v21
    v.sub        v17, v16, v8
    v.and        v21, v20, v18
    @p4 v.sel        v18, v19, v8
    v.extract    s9, v9, #8
    v.splat      v18, s9
    v.extract    s9, v11, #8
    v.splat      v19, s9
    v.add        v20, v22, v2
    v.movi       v2, #0
    v.sub        v22, v16, v21
    v.cmp.lt     p4, v20, v2
    @p2 v.sel        v16, v22, v21
    v.sub        v21, v2, v20
    v.mul        v22, v16, v10
    @p4 v.sel        v16, v21, v20
    v.movi       v20, #255
    v.add        v21, v15, v22
    v.and        v22, v16, v20
    v.add        v16, v4, v21
    v.sub        v20, v2, v22
    s.addi       s9, s3, #512
    @p4 v.sel        v21, v20, v22
    v.st.w       [s5, #0], v16
    v.mul        v16, v21, v10
    v.sub        v20, v2, v8
    v.add        v21, v15, v16
    v.cmp.lt     p2, v8, v2
    v.add        v2, v4, v21
    v.movi       v16, #1
    v.mul        v16, v18, v1
    v.extract    s5, v13, #8
    v.add        v18, v19, v16
    v.splat      v16, s5
    v.add        v19, v18, v5
    v.mul        v18, v16, v12
    v.st.w       [s7, #0], v2
    @p3 v.sel        v2, v17, v8
    v.extract    s5, v9, #9
    v.splat      v2, s5
    v.extract    s5, v11, #9
    v.splat      v16, s5
    v.add        v17, v19, v18
    v.movi       v18, #0
    v.movi       v19, #255
    v.sub        v21, v18, v17
    v.cmp.lt     p3, v17, v18
    @p3 v.sel        v22, v21, v17
    s.addi       s5, s3, #576
    v.and        v17, v22, v19
    v.sub        v19, v18, v8
    v.sub        v21, v18, v17
    v.cmp.lt     p4, v8, v18
    @p3 v.sel        v18, v21, v17
    v.movi       v17, #1
    v.mul        v17, v2, v1
    v.extract    s7, v13, #9
    v.add        v2, v16, v17
    v.splat      v16, s7
    v.add        v17, v2, v5
    v.mul        v2, v16, v12
    v.mul        v16, v18, v10
    @p2 v.sel        v18, v20, v8
    v.extract    s7, v9, #10
    v.splat      v18, s7
    v.extract    s7, v11, #10
    v.splat      v20, s7
    v.add        v21, v17, v2
    v.movi       v2, #0
    v.movi       v17, #255
    v.cmp.lt     p2, v21, v2
    v.add        v22, v15, v16
    s.addi       s7, s3, #640
    v.add        v16, v4, v22
    v.cmp.lt     p3, v8, v2
    v.st.w       [s9, #0], v16
    v.sub        v16, v2, v21
    v.movi       v22, #1
    v.mul        v22, v18, v1
    v.extract    s9, v13, #10
    v.add        v18, v20, v22
    v.splat      v20, s9
    v.add        v22, v18, v5
    v.mul        v18, v20, v12
    @p2 v.sel        v20, v16, v21
    v.sub        v16, v2, v8
    v.and        v21, v20, v17
    @p4 v.sel        v17, v19, v8
    v.extract    s9, v9, #11
    v.splat      v17, s9
    v.extract    s9, v11, #11
    v.splat      v19, s9
    v.add        v20, v22, v18
    v.movi       v18, #0
    v.sub        v22, v2, v21
    v.cmp.lt     p4, v20, v18
    @p2 v.sel        v2, v22, v21
    v.sub        v21, v18, v20
    v.mul        v22, v2, v10
    @p4 v.sel        v2, v21, v20
    v.movi       v20, #255
    v.add        v21, v15, v22
    v.and        v22, v2, v20
    v.add        v2, v4, v21
    v.sub        v20, v18, v22
    s.addi       s9, s3, #704
    @p4 v.sel        v21, v20, v22
    v.st.w       [s5, #0], v2
    v.mul        v2, v21, v10
    v.sub        v20, v18, v8
    v.add        v21, v15, v2
    v.cmp.lt     p2, v8, v18
    v.add        v2, v4, v21
    v.movi       v18, #1
    v.mul        v18, v17, v1
    v.extract    s5, v13, #11
    v.add        v17, v19, v18
    v.splat      v18, s5
    v.add        v19, v17, v5
    v.mul        v17, v18, v12
    v.st.w       [s7, #0], v2
    @p3 v.sel        v2, v16, v8
    v.extract    s5, v9, #12
    v.splat      v2, s5
    v.extract    s5, v11, #12
    v.splat      v16, s5
    v.add        v18, v19, v17
    v.movi       v17, #0
    v.movi       v19, #255
    v.sub        v21, v17, v18
    v.cmp.lt     p3, v18, v17
    @p3 v.sel        v22, v21, v18
    s.addi       s5, s3, #768
    v.and        v18, v22, v19
    v.sub        v19, v17, v8
    v.sub        v21, v17, v18
    v.cmp.lt     p4, v8, v17
    @p3 v.sel        v17, v21, v18
    v.movi       v18, #1
    v.mul        v18, v2, v1
    v.extract    s7, v13, #12
    v.add        v2, v16, v18
    v.splat      v16, s7
    v.add        v18, v2, v5
    v.mul        v2, v16, v12
    v.mul        v16, v17, v10
    @p2 v.sel        v17, v20, v8
    v.extract    s7, v9, #13
    v.splat      v17, s7
    v.extract    s7, v11, #13
    v.splat      v20, s7
    v.add        v21, v18, v2
    v.movi       v2, #0
    v.movi       v18, #255
    v.cmp.lt     p2, v21, v2
    v.add        v22, v15, v16
    s.addi       s7, s3, #832
    v.add        v16, v4, v22
    v.cmp.lt     p3, v8, v2
    v.st.w       [s9, #0], v16
    v.sub        v16, v2, v21
    v.movi       v22, #1
    v.mul        v22, v17, v1
    v.extract    s9, v13, #13
    v.add        v17, v20, v22
    v.splat      v20, s9
    v.add        v22, v17, v5
    v.mul        v17, v20, v12
    @p2 v.sel        v20, v16, v21
    v.sub        v16, v2, v8
    v.and        v21, v20, v18
    @p4 v.sel        v18, v19, v8
    v.extract    s9, v9, #14
    v.splat      v18, s9
    v.extract    s9, v11, #14
    v.splat      v19, s9
    v.add        v20, v22, v17
    v.movi       v17, #0
    v.sub        v22, v2, v21
    v.cmp.lt     p4, v20, v17
    @p2 v.sel        v2, v22, v21
    v.sub        v21, v17, v20
    v.mul        v22, v2, v10
    @p4 v.sel        v2, v21, v20
    v.movi       v20, #255
    v.add        v21, v15, v22
    v.and        v22, v2, v20
    v.add        v2, v4, v21
    v.sub        v20, v17, v22
    s.addi       s9, s3, #896
    @p4 v.sel        v21, v20, v22
    v.st.w       [s5, #0], v2
    v.mul        v2, v21, v10
    v.sub        v20, v17, v8
    v.add        v21, v15, v2
    v.cmp.lt     p2, v8, v17
    v.add        v2, v4, v21
    v.movi       v17, #1
    v.mul        v17, v18, v1
    v.extract    s5, v13, #14
    v.add        v18, v19, v17
    v.splat      v17, s5
    v.add        v19, v18, v5
    v.mul        v18, v17, v12
    v.st.w       [s7, #0], v2
    @p3 v.sel        v2, v16, v8
    v.extract    s5, v9, #15
    v.splat      v2, s5
    v.extract    s5, v11, #15
    v.splat      v9, s5
    v.add        v11, v19, v18
    v.movi       v16, #0
    v.movi       v17, #255
    v.sub        v18, v16, v11
    v.cmp.lt     p3, v11, v16
    @p3 v.sel        v19, v18, v11
    s.addi       s5, s3, #960
    v.and        v11, v19, v17
    v.sub        v17, v16, v8
    v.sub        v18, v16, v11
    v.cmp.lt     p4, v8, v16
    @p3 v.sel        v16, v18, v11
    v.movi       v11, #1
    v.mul        v11, v2, v1
    v.extract    s3, v13, #15
    v.add        v1, v9, v11
    v.splat      v2, s3
    v.add        v9, v1, v5
    v.mul        v1, v2, v12
    v.mul        v2, v16, v10
    @p2 v.sel        v5, v20, v8
    v.add        v5, v9, v1
    v.movi       v1, #0
    v.movi       v9, #255
    v.sub        v11, v1, v5
    v.cmp.lt     p2, v5, v1
    @p2 v.sel        v12, v11, v5
    v.add        v5, v15, v2
    v.and        v2, v12, v9
    v.add        v9, v4, v5
    v.sub        v5, v1, v2
    s.movz       s3, #0
    @p2 v.sel        v11, v5, v2
    v.st.w       [s9, #0], v9
    v.mul        v2, v11, v10
    v.extract    s7, v14, #0
    v.add        v5, v15, v2
    v.splat      v2, s7
    v.add        v9, v4, v5
    v.sub        v4, v1, v8
    v.cmp.lt     p2, v8, v1
    v.movi       v1, #1
    v.extract    s7, v0, #0
    v.st.w       [s5, #0], v9
    fence.acq_rel.device
    a.vread      v1, a0, s3
    v.movi       v5, #0
    v.splat      v9, s7
    v.movi       v10, #0
    v.cmp.ne     p3, v2, v5
    @p4 v.sel        v2, v17, v8
    v.extract    s3, v14, #0
    v.extract    s5, v0, #0
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v11, s5
    v.movi       v12, #0
    v.extract    s3, v3, #0
    v.cmp.ne     p4, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    v.extract    s3, v3, #0
    v.splat      v13, s3
    v.movi       v15, #0
    v.movi       v16, #1
    @p2 v.sel        v16, v4, v8
    v.cmp.ne     p2, v11, v12
    p.and        p5, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p4, p1
    p.and        p4, p3, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v13, v15
    p.and        p3, p4, p2
    v.extract    s3, v14, #0
    p.and        p2, p3, p1
    v.extract    s5, v0, #0
    v.splat      v4, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.movi       v9, #0
    vf.add       v10, v2, v6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s8, #0]
    v.extract    s3, v3, #0
    .li       s5, #1077936128
    v.splat      v11, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rsqrt.approx v12, v10                      // ISA 8.8: <= 2**-22 relative
    .li       s5, #3204448256
    v.splat      v13, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v4, v5
    v.cmp.ne     p3, v8, v9
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #0
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    vf.sub       v8, v1, v2
    v.extract    s3, v0, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.extract    s3, v3, #0
    v.cmp.ne     p2, v4, v5
    v.cmp.ne     p4, v1, v2
    v.splat      v1, s3
    v.movi       v2, #0
    p.and        p5, p3, p1
    p.and        p3, p2, p4
    v.cmp.ne     p2, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v1, [s1, #0]
    p.and        p4, p3, p2
    s.addi       s3, s4, #3136
    vf.mul       v2, v12, v12
    vf.mul       v4, v12, v13
    p.and        p2, p4, p1
    v.extract    s5, v14, #0
    vf.fms       v5, v10, v2, v11
    v.extract    s7, v0, #0
    v.splat      v2, s5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s6, #0]
    vf.mul       v10, v4, v5                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v15, #0
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v16, v10, v12
    v.extract    s5, v3, #0
    vf.mul       v10, v8, v16
    v.cmp.ne     p2, v2, v4
    v.ld.w       v2, [s3, #0]
    v.cmp.ne     p3, v5, v15
    vf.mul       v4, v10, v1
    v.extract    s3, v14, #1
    v.extract    s7, v0, #1
    v.splat      v1, s3
    v.movi       v5, #0
    v.splat      v8, s7
    v.movi       v10, #0
    vf.add       v12, v4, v9
    v.extract    s3, v3, #1
    v.splat      v4, s5
    v.movi       v9, #0
    v.cmp.ne     p4, v1, v5
    p.and        p5, p2, p3
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v9
    vf.max.prop  v1, v12, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #1
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v2], v1
    a.vread      v1, a0, s3
    v.extract    s3, v14, #1
    v.extract    s5, v0, #1
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #1
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #1
    p.and        p2, p3, p1
    v.extract    s5, v0, #1
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #1
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #1
    v.extract    s5, v0, #1
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #1
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3200
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #1
    v.extract    s7, v0, #1
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #1
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #2
    v.extract    s7, v0, #2
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #2
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #2
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #2
    v.extract    s5, v0, #2
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #2
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #2
    p.and        p2, p3, p1
    v.extract    s5, v0, #2
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #2
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #2
    v.extract    s5, v0, #2
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #2
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3264
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #2
    v.extract    s7, v0, #2
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #2
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #3
    v.extract    s7, v0, #3
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #3
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #3
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #3
    v.extract    s5, v0, #3
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #3
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #3
    p.and        p2, p3, p1
    v.extract    s5, v0, #3
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #3
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #3
    v.extract    s5, v0, #3
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #3
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3328
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #3
    v.extract    s7, v0, #3
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #3
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #4
    v.extract    s7, v0, #4
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #4
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #4
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #4
    v.extract    s5, v0, #4
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #4
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #4
    p.and        p2, p3, p1
    v.extract    s5, v0, #4
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #4
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #4
    v.extract    s5, v0, #4
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #4
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3392
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #4
    v.extract    s7, v0, #4
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #4
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #5
    v.extract    s7, v0, #5
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #5
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #5
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #5
    v.extract    s5, v0, #5
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #5
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #5
    p.and        p2, p3, p1
    v.extract    s5, v0, #5
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #5
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #5
    v.extract    s5, v0, #5
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #5
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3456
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #5
    v.extract    s7, v0, #5
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #5
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #6
    v.extract    s7, v0, #6
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #6
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #6
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #6
    v.extract    s5, v0, #6
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #6
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #6
    p.and        p2, p3, p1
    v.extract    s5, v0, #6
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #6
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #6
    v.extract    s5, v0, #6
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #6
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3520
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #6
    v.extract    s7, v0, #6
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #6
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #7
    v.extract    s7, v0, #7
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #7
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #7
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #7
    v.extract    s5, v0, #7
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #7
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #7
    p.and        p2, p3, p1
    v.extract    s5, v0, #7
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #7
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #7
    v.extract    s5, v0, #7
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #7
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3584
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #7
    v.extract    s7, v0, #7
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #7
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #8
    v.extract    s7, v0, #8
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #8
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #8
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #8
    v.extract    s5, v0, #8
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #8
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #8
    p.and        p2, p3, p1
    v.extract    s5, v0, #8
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #8
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #8
    v.extract    s5, v0, #8
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #8
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3648
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #8
    v.extract    s7, v0, #8
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #8
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #9
    v.extract    s7, v0, #9
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #9
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #9
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #9
    v.extract    s5, v0, #9
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #9
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #9
    p.and        p2, p3, p1
    v.extract    s5, v0, #9
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #9
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #9
    v.extract    s5, v0, #9
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #9
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3712
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #9
    v.extract    s7, v0, #9
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #9
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #10
    v.extract    s7, v0, #10
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #10
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #10
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #10
    v.extract    s5, v0, #10
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #10
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #10
    p.and        p2, p3, p1
    v.extract    s5, v0, #10
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #10
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #10
    v.extract    s5, v0, #10
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #10
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3776
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #10
    v.extract    s7, v0, #10
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #10
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #11
    v.extract    s7, v0, #11
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #11
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #11
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #11
    v.extract    s5, v0, #11
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #11
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #11
    p.and        p2, p3, p1
    v.extract    s5, v0, #11
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #11
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #11
    v.extract    s5, v0, #11
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #11
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3840
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #11
    v.extract    s7, v0, #11
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #11
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #12
    v.extract    s7, v0, #12
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #12
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #12
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #12
    v.extract    s5, v0, #12
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #12
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #12
    p.and        p2, p3, p1
    v.extract    s5, v0, #12
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #12
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #12
    v.extract    s5, v0, #12
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #12
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3904
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #12
    v.extract    s7, v0, #12
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #12
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #13
    v.extract    s7, v0, #13
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #13
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #13
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #13
    v.extract    s5, v0, #13
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #13
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #13
    p.and        p2, p3, p1
    v.extract    s5, v0, #13
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #13
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #13
    v.extract    s5, v0, #13
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #13
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #3968
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #13
    v.extract    s7, v0, #13
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #13
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #14
    v.extract    s7, v0, #14
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #14
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #14
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #14
    v.extract    s5, v0, #14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #14
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s3, v14, #14
    p.and        p2, p3, p1
    v.extract    s5, v0, #14
    vf.add       v4, v2, v6
    v.splat      v2, s3
    v.movi       v5, #0
    v.splat      v8, s5
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s8, #0]
    v.extract    s3, v3, #14
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v8, v10
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s3, v14, #14
    v.extract    s5, v0, #14
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s3
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v12
    v.splat      v1, s5
    v.movi       v5, #0
    v.extract    s3, v3, #14
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s3
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v9, v9
    vf.mul       v8, v9, v13
    p.and        p3, p5, p2
    s.addi       s3, s4, #4032
    vf.fms       v10, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s5, v14, #14
    v.extract    s7, v0, #14
    vf.mul       v4, v8, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    v.splat      v8, s5
    v.movi       v10, #0
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v12, v4, v9
    v.splat      v4, s7
    vf.mul       v9, v2, v12
    v.movi       v2, #0
    v.extract    s5, v3, #14
    v.cmp.ne     p2, v8, v10
    vf.mul       v8, v9, v1
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v14, #15
    v.extract    s7, v0, #15
    v.splat      v9, s3
    v.movi       v10, #0
    v.splat      v12, s7
    v.movi       v15, #0
    vf.add       v16, v8, v5
    v.extract    s3, v3, #15
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s5
    v.movi       v4, #0
    v.cmp.ne     p4, v9, v10
    p.and        p5, p2, p3
    v.cmp.ne     p2, v12, v15
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v4
    vf.max.prop  v2, v16, v7
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v4, v5
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s3, #15
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v1], v2
    a.vread      v1, a0, s3
    v.extract    s3, v14, #15
    v.extract    s5, v0, #15
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s5
    v.movi       v8, #0
    v.extract    s3, v3, #15
    v.cmp.ne     p2, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p3, v5, v8
    v.splat      v4, s3
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s2, v14, #15
    p.and        p2, p3, p1
    v.extract    s3, v0, #15
    vf.add       v4, v2, v6
    v.splat      v2, s2
    v.movi       v5, #0
    v.splat      v6, s3
    v.rsqrt.approx v8, v4                        // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s8, #0]
    v.extract    s2, v3, #15
    v.cmp.ne     p2, v2, v5
    v.cmp.ne     p3, v6, v9
    v.splat      v2, s2
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s2, v14, #15
    v.extract    s3, v0, #15
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s2
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v5
    p.and        p4, p3, p1
    vf.sub       v2, v1, v10
    v.splat      v1, s3
    v.movi       v5, #0
    v.extract    s2, v3, #15
    v.cmp.ne     p3, v1, v5
    v.splat      v1, s2
    v.movi       v5, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    vf.mul       v5, v8, v8
    vf.mul       v6, v8, v13
    p.and        p3, p5, p2
    s.addi       s1, s4, #4096
    vf.fms       v9, v4, v5, v11
    p.and        p2, p3, p1
    v.extract    s2, v14, #15
    v.extract    s3, v0, #15
    vf.mul       v0, v6, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s6, #0]
    v.splat      v5, s2
    v.movi       v6, #0
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v9, v0, v8
    v.splat      v0, s3
    vf.mul       v8, v2, v9
    v.movi       v2, #0
    v.extract    s2, v3, #15
    v.cmp.ne     p2, v5, v6
    vf.mul       v3, v8, v1
    v.ld.w       v1, [s1, #0]
    v.cmp.ne     p3, v0, v2
    v.splat      v0, s2
    vf.add       v2, v3, v4
    v.movi       v3, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v0, v3
    vf.max.prop  v0, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s32, v1], v0
__rctx_next:
    exit
