"""Control: test_depthwise with every [R,1] source treated as replicated (no lane-0 copy)."""
import sys, unittest
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(ROOT), str(ROOT/'python'), str(ROOT/'compiler/python'), str(ROOT/'tools/asm'),
                str(ROOT/'tools/performance_harness'), str(ROOT/'tools/performance_harness/systemc')]
from tnca_cc.frontend import TTIRImporter
TTIRImporter._rows_replicated = lambda self, value: True
import test_depthwise
result = unittest.main(module=test_depthwise, argv=['control', '-v', 'DepthwiseTests.test_standard_convolution_geometries'],
                       exit=False).result
print('CONTROL', 'failures', len(result.failures), 'errors', len(result.errors))
