    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s1, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s11, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
__rctx_program:
    v.splat      v0, s2
    v.movi       v1, #0
    v.movi       v2, #6
    v.movi       v3, #64
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v5, #5
    @p1 v.sel        v6, v4, v0
    v.movi       v4, #0
    v.sub        v7, v1, v3
    v.lshr       v8, v6, v2
    v.sub        v2, v4, v5
    v.cmp.lt     p2, v3, v1
    v.sub        v6, v1, v8
    v.cmp.lt     p3, v5, v4
    v.iota       v1                              // arange(0, VLEN)
    @p1 v.sel        v9, v6, v8
    v.movi       v6, #1
    @p2 v.sel        v6, v7, v3
    v.sub        v6, v4, v9
    v.cmp.lt     p1, v9, v4
    v.movi       v7, #1
    @p1 v.sel        v8, v6, v9
    @p3 v.sel        v6, v2, v5
    v.movi       v2, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v5, v7
    v.cmp.lt     p2, v5, v4
    v.lshr       v11, v8, v9
    v.shl        v12, v7, v9
    s.subi       s12, s1, #1
    v.and        v9, v11, v7
    s.movz       s13, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v6
    p.or         p4, p2, p3
    v.sub        v9, v11, v6
    @p4 v.sel        v10, v12, v4
    @p4 v.sel        v12, v9, v11
    v.or         v9, v2, v10
    v.mov        v5, v12
    v.mov        v2, v9
    s.mov        s1, s12
    s.cmp.ge     s12, s1, s13
    br.nz        s12, idiv_1
    v.movi       v2, #320
    v.movi       v6, #0
    v.sub        v7, v4, v5
    v.movi       v4, #1
    v.sub        v8, v6, v0
    v.sub        v9, v6, v2
    v.cmp.lt     p2, v0, v6
    v.cmp.lt     p3, v2, v6
    @p1 v.sel        v10, v7, v5
    @p2 v.sel        v5, v8, v0
    @p3 v.sel        v7, v9, v2
    v.movi       v2, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v9, s1
    v.shl        v11, v8, v4
    v.cmp.lt     p1, v8, v6
    v.lshr       v12, v5, v9
    v.shl        v13, v4, v9
    s.subi       s12, s1, #1
    v.and        v9, v12, v4
    s.movz       s13, #0
    v.or         v12, v11, v9
    v.cmp.geu    p4, v12, v7
    p.or         p5, p1, p4
    v.sub        v9, v12, v7
    @p5 v.sel        v11, v13, v6
    @p5 v.sel        v13, v9, v12
    v.or         v9, v2, v11
    v.mov        v8, v13
    v.mov        v2, v9
    s.mov        s1, s12
    s.cmp.ge     s12, s1, s13
    br.nz        s12, idiv_2
    v.movi       v4, #0
    v.movi       v5, #63
    v.sub        v7, v6, v2
    v.sub        v6, v4, v0
    v.cmp.lt     p1, v0, v4
    v.sub        v8, v4, v3
    @p1 v.sel        v9, v6, v0
    v.movi       v0, #0
    v.movi       v6, #0
    v.and        v11, v9, v5
    p.xor        p4, p2, p3
    s.movz       s1, #0
    v.sub        v5, v4, v11
    v.cmp.lt     p2, v3, v4
    @p4 v.sel        v4, v7, v2
    v.movi       v2, #1
    @p2 v.sel        v2, v8, v3
    @p1 v.sel        v2, v5, v11
    s.movz       s12, #116
    s.movz       s13, #16
    s.addi       s14, s1, #0
    v.mov        v6, v0
for_3:
    s.cmp.ge     s1, s14, s12
    br.nz        s1, endfor_4
    v.movi       v5, #116
    v.movi       v7, #576
    s.ld.d       s1, [s8, #0]                    // one element, not a vector
    v.mul        v8, v10, v5
    v.splat      v5, s14
    v.mul        v9, v4, v7
    v.extract    s15, v8, #0
    v.add        v7, v5, v1
    v.splat      v5, s15
    v.extract    s15, v9, #0
    v.movi       v8, #116
    v.add        v9, v7, v5
    v.movi       v5, #576
    v.splat      v11, s15
    v.movi       v12, #1
    v.extract    s15, v4, #0
    v.cmp.lt     p1, v7, v8
    v.cmp.lt     p2, v9, v5
    v.splat      v5, s15
    v.add        v8, v9, v11
    v.shl        v11, v9, v12
    v.movi       v9, #0
    v.movi       v12, #0
    p.and        p3, p1, p2
    s.addi       s15, s7, #4
    s.lshri      s16, s1, #32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v13, [s3, v5]             // index is in elements (ISA sec 9.1)
    s.lshri      s17, s1, #32
    s.lshri      s18, s1, #32
    s.lshri      s19, s1, #32
    s.lshri      s20, s1, #32
    .li       s21, #1065353216
    v.splat      v14, s21                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #0
    v.movi       v16, #1
    v.movi       v17, #0
    v.movi       v18, #0
    s.movz       s21, #576
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v19, [s5, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p4, v13, v15
    @p4 v.sel        v8, v16, v17
    v.cmp.eq     p4, v8, v18
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s6, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s7, v11]              // index is in elements (ISA sec 9.1)
    v.rcp.approx v13, v8                         // ISA 8.8: <= 2**-22 relative
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v15, [s15, v11]            // index is in elements (ISA sec 9.1)
    v.insert     v9, s1, #0
    v.insert     v12, s16, #0
    s.lshri      s15, s1, #32
    v.insert     v9, s1, #1
    v.insert     v12, s17, #1
    s.lshri      s16, s1, #32
    v.insert     v9, s1, #2
    v.insert     v12, s18, #2
    s.lshri      s17, s1, #32
    v.insert     v9, s1, #3
    v.insert     v12, s19, #3
    s.lshri      s18, s1, #32
    v.insert     v9, s1, #4
    v.insert     v12, s20, #4
    s.lshri      s19, s1, #32
    v.insert     v9, s1, #5
    v.insert     v12, s15, #5
    s.lshri      s15, s1, #32
    v.insert     v9, s1, #6
    v.insert     v12, s16, #6
    vf.fms       v11, v8, v13, v14
    v.insert     v9, s1, #7
    v.insert     v12, s17, #7
    v.insert     v9, s1, #8
    v.insert     v12, s18, #8
    vf.fms       v8, v13, v11, v13
    v.insert     v9, s1, #9
    v.insert     v12, s19, #9
    s.lshri      s16, s1, #32
    v.insert     v9, s1, #10
    v.insert     v12, s15, #10
    vf.neg       v11, v8                         // Newton step: r0*(2 - x*r0)
    v.insert     v9, s1, #11
    v.insert     v12, s16, #11
    vf.cmp.o     p5, v11, v11
    v.insert     v9, s1, #12
    @p5 v.sel        v8, v11, v13
    s.lshri      s15, s1, #32
    vf.mul       v11, v19, v8                    // a/y as a refined reciprocal (ISA has no divide)
    v.insert     v12, s15, #12
    @p4 v.sel        v8, v0, v11
    s.lshri      s15, s1, #32
    v.insert     v9, s1, #13
    v.insert     v12, s15, #13
    s.lshri      s15, s1, #32
    v.insert     v9, s1, #14
    v.insert     v12, s15, #14
    s.lshri      s15, s1, #32
    v.insert     v9, s1, #15
    v.insert     v12, s15, #15
    v.movi       v11, #1
    v.movi       v13, #0
    v.extract    s1, v12, #0
    v.extract    s15, v9, #0
    s.shli       s16, s1, #32
    @p2 v.sel        v14, v11, v13
    v.extract    s1, v12, #1
    s.or         s17, s15, s16
    s.movz       s15, #0
    v.extract    s16, v9, #1
    s.shli       s18, s1, #32
    v.extract    s1, v14, #0
    s.sub        s19, s17, s15
    v.extract    s17, v12, #2
    s.or         s20, s16, s18
    s.movz       s16, #0
    s.mul        s18, s1, s19
    v.extract    s1, v9, #2
    s.shli       s19, s17, #32
    v.extract    s17, v14, #1
    s.sub        s21, s20, s16
    s.or         s20, s1, s19
    v.extract    s1, v12, #3
    s.mul        s19, s17, s21
    s.movz       s17, #0
    s.shli       s21, s1, #32
    s.sub        s1, s20, s17
    s.add        s20, s15, s18
    v.extract    s15, v9, #3
    v.movi       v11, #0
    s.or         s18, s15, s21
    v.extract    s15, v14, #2
    v.movi       v13, #0
    s.mul        s21, s15, s1
    v.extract    s1, v12, #4
    s.add        s15, s16, s19
    s.movz       s16, #0
    s.shli       s19, s1, #32
    s.sub        s1, s18, s16
    v.insert     v11, s20, #0
    s.lshri      s18, s20, #32
    s.add        s20, s17, s21
    v.extract    s17, v9, #4
    v.insert     v13, s18, #0
    v.extract    s18, v14, #3
    s.or         s21, s17, s19
    v.extract    s17, v12, #5
    s.mul        s19, s18, s1
    s.movz       s1, #0
    s.shli       s18, s17, #32
    s.sub        s17, s21, s1
    v.insert     v11, s15, #1
    s.lshri      s21, s15, #32
    s.add        s15, s16, s19
    v.extract    s16, v9, #5
    v.insert     v13, s21, #1
    v.extract    s19, v14, #4
    s.or         s21, s16, s18
    v.extract    s16, v12, #6
    s.mul        s18, s19, s17
    s.movz       s17, #0
    s.shli       s19, s16, #32
    s.sub        s16, s21, s17
    v.insert     v11, s20, #2
    s.lshri      s21, s20, #32
    s.add        s20, s1, s18
    v.extract    s1, v9, #6
    v.insert     v13, s21, #2
    v.extract    s18, v14, #5
    s.or         s21, s1, s19
    v.extract    s1, v12, #7
    s.mul        s19, s18, s16
    s.movz       s16, #0
    s.shli       s18, s1, #32
    s.sub        s1, s21, s16
    v.insert     v11, s15, #3
    s.lshri      s21, s15, #32
    s.add        s15, s17, s19
    v.extract    s17, v9, #7
    v.insert     v13, s21, #3
    v.extract    s19, v14, #6
    s.or         s21, s17, s18
    v.extract    s17, v12, #8
    s.mul        s18, s19, s1
    s.movz       s1, #0
    s.shli       s19, s17, #32
    s.sub        s17, s21, s1
    v.insert     v11, s20, #4
    s.lshri      s21, s20, #32
    s.add        s20, s16, s18
    v.extract    s16, v9, #8
    v.insert     v13, s21, #4
    v.extract    s18, v14, #7
    s.or         s21, s16, s19
    v.extract    s16, v12, #9
    s.mul        s19, s18, s17
    s.movz       s17, #0
    s.shli       s18, s16, #32
    s.sub        s16, s21, s17
    v.insert     v11, s15, #5
    s.lshri      s21, s15, #32
    s.add        s15, s1, s19
    v.extract    s1, v9, #9
    v.insert     v13, s21, #5
    v.extract    s19, v14, #8
    s.or         s21, s1, s18
    v.extract    s1, v12, #10
    s.mul        s18, s19, s16
    s.movz       s16, #0
    s.shli       s19, s1, #32
    s.sub        s1, s21, s16
    v.insert     v11, s20, #6
    s.lshri      s21, s20, #32
    s.add        s20, s17, s18
    v.extract    s17, v9, #10
    v.insert     v13, s21, #6
    v.extract    s18, v14, #9
    s.or         s21, s17, s19
    v.extract    s17, v12, #11
    s.mul        s19, s18, s1
    s.movz       s1, #0
    s.shli       s18, s17, #32
    s.sub        s17, s21, s1
    v.insert     v11, s15, #7
    s.lshri      s21, s15, #32
    s.add        s15, s16, s19
    v.extract    s16, v9, #11
    v.insert     v13, s21, #7
    v.extract    s19, v14, #10
    s.or         s21, s16, s18
    v.extract    s16, v12, #12
    s.mul        s18, s19, s17
    s.movz       s17, #0
    s.shli       s19, s16, #32
    s.sub        s16, s21, s17
    v.insert     v11, s20, #8
    s.lshri      s21, s20, #32
    s.add        s20, s1, s18
    v.extract    s1, v9, #12
    v.insert     v13, s21, #8
    v.extract    s18, v14, #11
    s.or         s21, s1, s19
    v.extract    s1, v12, #13
    s.mul        s19, s18, s16
    s.movz       s16, #0
    s.shli       s18, s1, #32
    s.sub        s1, s21, s16
    v.insert     v11, s15, #9
    s.lshri      s21, s15, #32
    s.add        s15, s17, s19
    v.extract    s17, v9, #13
    v.insert     v13, s21, #9
    v.extract    s19, v14, #12
    s.or         s21, s17, s18
    v.extract    s17, v12, #14
    s.mul        s18, s19, s1
    s.movz       s1, #0
    s.shli       s19, s17, #32
    s.sub        s17, s21, s1
    v.insert     v11, s20, #10
    s.lshri      s21, s20, #32
    s.add        s20, s16, s18
    v.extract    s16, v9, #14
    v.insert     v13, s21, #10
    v.extract    s18, v14, #13
    s.or         s21, s16, s19
    v.extract    s16, v12, #15
    s.mul        s19, s18, s17
    s.movz       s17, #0
    s.shli       s18, s16, #32
    s.sub        s16, s21, s17
    v.insert     v11, s15, #11
    s.lshri      s21, s15, #32
    s.add        s15, s1, s19
    v.extract    s1, v9, #15
    v.insert     v13, s21, #11
    v.extract    s19, v14, #14
    s.or         s21, s1, s18
    s.movz       s1, #0
    s.mul        s18, s19, s16
    s.lshri      s16, s20, #32
    s.sub        s19, s21, s1
    v.insert     v11, s20, #12
    v.extract    s20, v14, #15
    v.insert     v13, s16, #12
    s.mul        s16, s20, s19
    s.lshri      s19, s15, #32
    s.add        s20, s17, s18
    v.insert     v11, s15, #13
    v.insert     v13, s19, #13
    s.lshri      s15, s20, #32
    s.add        s17, s1, s16
    v.insert     v11, s20, #14
    v.insert     v13, s15, #14
    s.lshri      s1, s17, #32
    v.insert     v11, s17, #15
    v.insert     v13, s1, #15
    v.extract    s1, v15, #0
    v.extract    s15, v5, #0
    v.extract    s16, v13, #0
    s.shli       s17, s1, #32
    v.extract    s1, v11, #0
    s.shli       s18, s16, #32
    v.extract    s16, v15, #1
    v.extract    s19, v13, #1
    s.or         s20, s15, s17
    s.or         s15, s1, s18
    v.movi       v9, #0
    v.extract    s1, v5, #1
    s.shli       s17, s16, #32
    v.extract    s16, v11, #1
    s.shli       s18, s19, #32
    s.cmp.eq     s19, s20, s15
    v.extract    s15, v15, #2
    v.extract    s20, v13, #2
    s.or         s21, s1, s17
    s.or         s1, s16, s18
    v.insert     v9, s19, #0
    v.extract    s16, v5, #2
    s.shli       s17, s15, #32
    v.extract    s15, v11, #2
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s1
    v.extract    s1, v15, #3
    v.extract    s20, v13, #3
    s.or         s21, s16, s17
    s.or         s16, s15, s18
    v.insert     v9, s19, #1
    v.extract    s15, v5, #3
    s.shli       s17, s1, #32
    v.extract    s1, v11, #3
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s16
    v.extract    s16, v15, #4
    v.extract    s20, v13, #4
    s.or         s21, s15, s17
    s.or         s15, s1, s18
    v.insert     v9, s19, #2
    v.extract    s1, v5, #4
    s.shli       s17, s16, #32
    v.extract    s16, v11, #4
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s15
    v.extract    s15, v15, #5
    v.extract    s20, v13, #5
    s.or         s21, s1, s17
    s.or         s1, s16, s18
    v.insert     v9, s19, #3
    v.extract    s16, v5, #5
    s.shli       s17, s15, #32
    v.extract    s15, v11, #5
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s1
    v.extract    s1, v15, #6
    v.extract    s20, v13, #6
    s.or         s21, s16, s17
    s.or         s16, s15, s18
    v.insert     v9, s19, #4
    v.extract    s15, v5, #6
    s.shli       s17, s1, #32
    v.extract    s1, v11, #6
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s16
    v.extract    s16, v15, #7
    v.extract    s20, v13, #7
    s.or         s21, s15, s17
    s.or         s15, s1, s18
    v.insert     v9, s19, #5
    v.extract    s1, v5, #7
    s.shli       s17, s16, #32
    v.extract    s16, v11, #7
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s15
    v.extract    s15, v15, #8
    v.extract    s20, v13, #8
    s.or         s21, s1, s17
    s.or         s1, s16, s18
    v.insert     v9, s19, #6
    v.extract    s16, v5, #8
    s.shli       s17, s15, #32
    v.extract    s15, v11, #8
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s1
    v.extract    s1, v15, #9
    v.extract    s20, v13, #9
    s.or         s21, s16, s17
    s.or         s16, s15, s18
    v.insert     v9, s19, #7
    v.extract    s15, v5, #9
    s.shli       s17, s1, #32
    v.extract    s1, v11, #9
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s16
    v.extract    s16, v15, #10
    v.extract    s20, v13, #10
    s.or         s21, s15, s17
    s.or         s15, s1, s18
    v.insert     v9, s19, #8
    v.extract    s1, v5, #10
    s.shli       s17, s16, #32
    v.extract    s16, v11, #10
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s15
    v.extract    s15, v15, #11
    v.extract    s20, v13, #11
    s.or         s21, s1, s17
    s.or         s1, s16, s18
    v.insert     v9, s19, #9
    v.extract    s16, v5, #11
    s.shli       s17, s15, #32
    v.extract    s15, v11, #11
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s1
    v.extract    s1, v15, #12
    v.extract    s20, v13, #12
    s.or         s21, s16, s17
    s.or         s16, s15, s18
    v.insert     v9, s19, #10
    v.movi       v12, #0
    v.extract    s15, v5, #12
    s.shli       s17, s1, #32
    v.cmp.lt     p4, v4, v12
    v.extract    s1, v11, #12
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s16
    v.extract    s16, v15, #13
    v.extract    s20, v13, #13
    s.or         s21, s15, s17
    s.or         s15, s1, s18
    v.insert     v9, s19, #11
    v.sub        v14, v12, v4
    v.movi       v16, #2
    v.extract    s1, v5, #13
    @p4 v.sel        v17, v14, v4
    s.shli       s17, s16, #32
    v.extract    s16, v11, #13
    v.lshr       v14, v17, v16
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s15
    v.sub        v16, v12, v14
    v.extract    s15, v15, #14
    v.extract    s20, v13, #14
    @p4 v.sel        v17, v16, v14
    s.or         s21, s1, s17
    s.or         s1, s16, s18
    v.mul        v14, v17, v3
    v.insert     v9, s19, #12
    .li       s16, #294912
    v.splat      v16, s16                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v18, #64
    v.extract    s16, v5, #14
    v.add        v19, v2, v16
    s.shli       s17, s15, #32
    v.extract    s15, v11, #14
    s.shli       s18, s20, #32
    s.cmp.eq     s19, s21, s1
    v.mul        v16, v7, v18
    v.extract    s1, v15, #15
    v.extract    s20, v13, #15
    v.add        v7, v2, v14
    s.or         s21, s16, s17
    s.or         s16, s15, s18
    v.insert     v9, s19, #13
    v.movi       v13, #7424
    v.extract    s15, v19, #0
    v.extract    s17, v5, #15
    v.mul        v5, v10, v13
    v.splat      v13, s15
    s.shli       s15, s1, #32
    v.extract    s1, v5, #0
    v.add        v5, v13, v16
    v.splat      v13, s1
    v.extract    s1, v11, #15
    s.shli       s18, s20, #32
    v.add        v11, v5, v13
    s.cmp.eq     s19, s21, s16
    v.extract    s16, v7, #0
    s.or         s20, s17, s15
    s.or         s15, s1, s18
    v.insert     v9, s19, #14
    s.movz       s1, #36864
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v7, s16
    s.cmp.eq     s1, s20, s15
    v.mul        v13, v17, v5
    v.insert     v9, s1, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v7]               // index is in elements (ISA sec 9.1)
    v.extract    s1, v13, #0
    v.movi       v7, #0
    v.splat      v13, s1
    v.movi       v14, #4
    v.cmp.ne     p4, v9, v7
    v.add        v7, v11, v13
    v.movi       v9, #0
    v.sub        v11, v12, v14
    v.cmp.lt     p5, v14, v12
    v.movi       v12, #1
    s.add        s1, s14, s13
    s.movz       s15, #1
    @p5 v.sel        v12, v11, v14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v11, [s10, v7]             // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v7, v5
    s.movz       s16, #64
    .li       s16, #294912
    s.movz       s16, #7424
    s.movz       s16, #36864
    vf.cvt.f16.f32 v5, v11
    @p4 v.sel        v11, v7, v5
    vf.mul       v5, v8, v11
    @p2 v.sel        v7, v5, v0
    vf.add       v5, v6, v7
    @p1 v.sel        v7, v5, v6
    v.mov        v9, v7
    v.mov        v6, v9
    s.mov        s14, s1
    br.nz        s15, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s12, s2, #2                     // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s11, s12                    // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s12, s1, s4
    s.mov        s2, s1
    br.nz        s12, __rctx_program
    exit
