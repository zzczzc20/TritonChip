# Focused read-only postmortem. No synthesis, placement, route or loading.
set_param general.maxThreads 2
set checkpoint [lindex $argv 0]
set out [file normalize [lindex $argv 1]]
set driver_file [lindex $argv 2]
if {[file exists $out]} {error "fresh output required"}
file mkdir $out
open_checkpoint $checkpoint
set cells [get_cells -hierarchical -quiet -filter {NAME =~ "*g_stage*" && (REF_NAME =~ "FD*" || REF_NAME =~ "RAM*")}]
set grouped [dict create]
foreach cell $cells name [get_property NAME $cells] {
    if {![regexp {^(.*?/g_stage\[[0-9]+\])([./])} $name whole stage]} {continue}
    set kind other_state
    if {[regexp {(mem_reg|rd_reg)} $name]} {set kind payload}
    if {[regexp {rv_reg} $name]} {set kind valid}
    if {[regexp {cnt_reg} $name]} {set kind occupancy_ready}
    if {[regexp {(rptr_reg|wptr_reg)} $name]} {set kind pointer}
    dict lappend grouped "$stage:$kind" $cell
}
set f [open $out/pipeline_state_locations.tsv {WRONLY CREAT EXCL}]
puts $f "scope\tstate_cells\tactual_slrs\tsample_locs"
dict for {scope members} $grouped {
    set locations [get_property LOC $members]
    set slrs [lsort -unique [get_property NAME [get_slrs -quiet -of_objects $members]]]
    puts $f [join [list $scope [llength $members] $slrs [lrange $locations 0 7]] "\t"]
    flush $f
}
close $f
set source [open $driver_file r]
set drivers [split [string trim [read $source]] \n]
close $source
if {[llength $drivers] > 20} {error "fanin probe budget exceeded"}
set f [open $out/shared_logic_cones.tsv {WRONLY CREAT EXCL}]
puts $f "driver\tprimitive\tactual_slrs\tstartpoint_cells\tsequential_endpoints"
foreach name $drivers {
    set cell [get_cells -quiet $name]
    if {[llength $cell]!=1} {error "driver absent or ambiguous: $name"}
    set pins [get_pins -quiet -of_objects $cell -filter {DIRECTION == OUT}]
    set starts [all_fanin -flat -startpoints_only -to $pins]
    set ends [all_fanout -flat -endpoints_only -from $pins]
    set start_cells [get_cells -quiet -of_objects $starts]
    set end_cells [get_cells -quiet -of_objects $ends]
    puts $f [join [list $name [get_property REF_NAME $cell] [get_property NAME [get_slrs -quiet -of_objects $cell]] [lsort -unique [get_property NAME $start_cells]] [lsort -unique [get_property NAME $end_cells]]] "\t"]
    flush $f
}
close $f
set f [open $out/status.txt {WRONLY CREAT EXCL}]
puts $f "scope diagnostic_only; checkpoint $checkpoint"
puts $f "pipeline_groups [dict size $grouped]; sampled_shared_logic_drivers [llength $drivers]"
puts $f "reports_complete 1"
close $f
puts "R40_FOCUSED_P1_DIAGNOSIS_DONE"
exit
