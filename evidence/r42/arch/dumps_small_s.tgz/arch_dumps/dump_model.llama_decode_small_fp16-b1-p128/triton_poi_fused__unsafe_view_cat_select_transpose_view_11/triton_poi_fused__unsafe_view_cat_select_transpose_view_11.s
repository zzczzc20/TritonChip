    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #64
    v.movi       v1, #5
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    @p1 v.sel        v7, v5, v4
    s.shli       s6, s1, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v4, v3
    s.add        s1, s3, s6                      // &in_ptr0[...]
    v.cmp.lt     p3, v4, v0
    @p2 v.sel        v0, v6, v4
    v.movi       v4, #31
    v.lshr       v5, v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s1, #0]
    v.and        v6, v0, v4
    v.sub        v0, v2, v5
    v.movi       v4, #4128
    v.sub        v7, v3, v6
    @p1 v.sel        v8, v0, v5
    v.movi       v0, #32
    @p2 v.sel        v5, v7, v6
    v.mul        v6, v8, v4
    v.sub        v4, v3, v0
    v.sub        v7, v2, v0
    v.add        v8, v5, v6
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v2, v4, v0
    @p2 v.sel        v2, v7, v0
    @p3 v.st.scatter.h [s5, v8], v1
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
