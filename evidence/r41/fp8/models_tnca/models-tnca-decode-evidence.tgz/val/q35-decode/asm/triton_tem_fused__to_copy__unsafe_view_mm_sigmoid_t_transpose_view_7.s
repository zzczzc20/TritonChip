    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #5120
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #2
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    s.movz       s7, #1
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #1
    s.cmp.lt     s16, s4, s6
    s.sub        s6, s3, s16
    s.xor        s3, s4, s6
    s.sub        s16, s3, s6
    s.lshri      s3, s16, #1
    s.muli       s17, s3, #2
    s.sub        s18, s16, s17
    s.xor        s16, s6, s8
    s.xor        s6, s3, s16
    s.sub        s3, s6, s16
    s.sub        s6, s7, s3
    s.min.s      s8, s6, s7
    s.cmp.lt     s6, s4, s10
    s.sub        s10, s9, s6
    s.cmp.lt     s6, s8, s12
    s.sub        s9, s11, s6
    s.xor        s6, s4, s10
    s.sub        s11, s6, s10
    s.xor        s6, s8, s9
    s.sub        s12, s6, s9
    s.addi       s6, s13, #0
    s.addi       s9, s14, #0
    s.cmp.eq     s13, s12, s15
    s.mov        s6, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s6, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s9, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s6, s19
    s.mov        s9, s15
    s.mov        s6, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s6, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s6
    s.movz       s6, #0
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.cmp.lt     s12, s8, s6
    s.lshri      s6, s14, #1
    s.movz       s15, #0
    s.muli       s16, s6, #2
    s.sub        s6, s4, s12
    s.movz       s4, #0
    s.cmp.lt     s12, s1, s15
    s.xor        s15, s8, s6
    s.sub        s8, s14, s16
    s.movz       s14, #0
    s.xor        s16, s8, s13
    s.xor        s8, s9, s10
    s.sub        s9, s16, s13
    s.sub        s13, s14, s12
    s.cmp.lt     s12, s9, s11
    s.sub        s11, s15, s6
    s.sub        s14, s4, s12
    s.movz       s4, #0
    s.xor        s12, s9, s14
    s.movz       s9, #1
    s.sub        s15, s8, s10
    s.xor        s8, s1, s13
    s.sub        s1, s12, s14
    s.movz       s10, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s11, s9
    s.add        s9, s3, s15
    s.sub        s3, s8, s13
    s.addi       s3, s10, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s8, #31
    s.mov        s12, s4
    s.addi       s4, s8, #0
sdiv_4:
    s.lshr       s8, s1, s4
    s.shli       s10, s3, #1
    s.andi       s13, s8, #1
    s.movz       s8, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s11
    s.shl        s16, s10, s4
    s.sub        s10, s8, s13
    s.subi       s8, s4, #1
    s.and        s13, s11, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s12, s17
    s.mov        s3, s10
    s.mov        s12, s13
    s.mov        s4, s8
    s.movz       s8, #0
    s.cmp.ge     s10, s4, s8
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s6
    s.movz       s3, #16
    s.xor        s4, s12, s1
    s.movz       s6, #0
    s.sub        s8, s4, s1
    v.splat      v0, s9
    s.mul        s1, s8, s3
    v.splat      v1, s6
    v.splat      v2, s8
    v.splat      v3, s6
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s4, s1, #31
    v.splat      v5, s1
    v.splat      v6, s4
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.movz       s8, #160
    s.addi       s10, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s6, s10, s8
    br.nz        s6, endfor_6
    s.mul        s6, s10, s3
    s.rdspecial  s11, role_id
    s.movz       s12, #1024
    s.rdspecial  s13, arg_base
    s.mul        s14, s11, s12
    s.muli       s11, s6, #2                     // a runtime tile origin, x2
    s.movz       s12, #16
    s.movz       s15, #0
    s.add        s15, s2, s11                    // the tile origin
    v.ld.h       v0, [s15, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #16
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s16, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s6                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s16, s11
    mb.wait      s11
    s.ld.d       s6, [s13, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s13, #32
    s.movz       s16, #2
    s.add        s17, s6, s14                    // this context's own scratch
    .li       s6, #68719476752
    s.addi       s14, s17, #256                  // 512 bytes of repack scratch
    s.addi       s18, s17, #768                  // TensorMap 1: a repacked tile
    s.addi       s17, s14, #32                   // row 1
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s14, #0], v0
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #64                   // row 2
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #96                   // row 3
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #128                  // row 4
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #160                  // row 5
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #192                  // row 6
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #224                  // row 7
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #256                  // row 8
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #288                  // row 9
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #320                  // row 10
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #352                  // row 11
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #384                  // row 12
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #416                  // row 13
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #448                  // row 14
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #480                  // row 15
    v.st.h       [s17, #0], v0
    .li       s17, #1108101562368
    s.st.d       [s18, #0], s14
    s.movz       s14, #0
    s.st.d       [s18, #8], s12
    s.add        s12, s10, s7
    s.st.d       [s18, #16], s15
    s.movz       s15, #1
    s.st.d       [s18, #48], s13
    s.st.d       [s18, #56], s16
    s.st.d       [s18, #88], s6
    s.st.d       [s18, #104], s17
    fence.release.device
    td.load      d1, [s18]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s6, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s16, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s16, s6
    mb.wait      s6
    mb.arm       s13, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s13
    mb.wait      s13
    s.mov        s10, s12
    br.nz        s15, for_5
endfor_6:
    s.mul        s2, s9, s3
    v.splat      v0, s2
    v.add        v1, v0, v4
    .li       s3, #1065353216
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s3, s1, #4                      // a runtime tile origin, x4
    s.add        s4, s5, s3                      // the tile origin
    s.muli       s3, s2, #128                    // a runtime tile origin, x128
    s.add        s5, s4, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    a.vread      v2, a0, s3
    vf.cvt.f32.bf16 v3, v2
    vf.cvt.bf16.f32 v2, v3
    vf.neg       v3, v2
    .li       s3, #1069066811
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v3, v2
    vf.fms       v5, v3, v2, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    .li       s3, #1060205080
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v5, v4
    vf.fma       v5, v3, v6, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v6, v5, v3
    vf.add       v3, v6, v0
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v7, v3, v5, v6
    vf.fms       v8, v5, v7, v5
    vf.neg       v7, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v8, v7, v5
    vf.mul       v5, v1, v8                      // a/y: faithful quotient
    vf.fms       v7, v5, v3, v1
    vf.fms       v3, v7, v8, v5
    vf.neg       v7, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v3, v7, v5
    s.movz       s3, #0
    s.add        s4, s3, s2                      // the tile origin
    v.splat      v5, s4
    v.splat      v7, s7
    v.cmp.lt     p1, v5, v7
    s.movz       s2, #0
    s.add        s3, s2, s1                      // the tile origin
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s3
    v.add        v9, v5, v8
    s.movz       s1, #32
    v.splat      v5, s1
    v.cmp.lt     p2, v9, v5
    p.and        p3, p1, p2
    @p3 v.st.w       [s5, #0], v3
    s.movz       s1, #1
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #128                    // row 1
    s.addi       s2, s4, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #2
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #256                    // row 2
    s.addi       s2, s4, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #3
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #384                    // row 3
    s.addi       s2, s4, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #4
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #512                    // row 4
    s.addi       s2, s4, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #5
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #640                    // row 5
    s.addi       s2, s4, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #6
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #768                    // row 6
    s.addi       s2, s4, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #7
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #896                    // row 7
    s.addi       s2, s4, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #8
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1024                   // row 8
    s.addi       s2, s4, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #9
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1152                   // row 9
    s.addi       s2, s4, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #10
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1280                   // row 10
    s.addi       s2, s4, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #11
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1408                   // row 11
    s.addi       s2, s4, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #12
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1536                   // row 12
    s.addi       s2, s4, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #13
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1664                   // row 13
    s.addi       s2, s4, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #14
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v9, v3, v8, v3
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v9, v8, v3
    vf.mul       v3, v1, v9                      // a/y: faithful quotient
    vf.fms       v8, v3, v5, v1
    vf.fms       v5, v8, v9, v3
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    s.addi       s1, s5, #1792                   // row 14
    s.addi       s2, s4, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v5
    s.movz       s1, #15
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v2, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v4, v2, v3, v2                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v2
    vf.add       v2, v3, v0
    v.rcp.approx v0, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v2, v0, v6
    vf.fms       v4, v0, v3, v0
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v0
    vf.mul       v0, v1, v4                      // a/y: faithful quotient
    vf.fms       v3, v0, v2, v1
    vf.fms       v1, v3, v4, v0
    vf.neg       v2, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    s.addi       s1, s5, #1920                   // row 15
    s.addi       s2, s4, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v7
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
__rctx_next:
    exit
