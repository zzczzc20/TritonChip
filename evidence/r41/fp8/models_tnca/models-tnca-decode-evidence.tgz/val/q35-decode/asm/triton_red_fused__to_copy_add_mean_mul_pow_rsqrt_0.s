    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s4, #2560
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.movz       s6, #16
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s9, [s1, #24]                   // out_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s10, [s1, #32]                  // out_ptr3: device_ptr64 at arg_base+32
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s4
    br.nz        s1, endfor_2
    v.splat      v0, s7
    s.shli       s1, s7, #1                      // element offset -> bytes (x2)
    v.add        v3, v0, v2
    v.movi       v0, #2560
    s.add        s11, s3, s1                     // &in_ptr0[...]
    v.cmp.lt     p1, v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s11, #0]
    v.movi       v3, #0
    s.add        s1, s7, s6
    s.movz       s11, #1
    vf.cvt.bf16.f32 v4, v0
    vf.mul       v0, v4, v4
    vf.add       v4, v1, v0
    @p1 v.sel        v0, v4, v1
    v.mov        v3, v0
    v.mov        v1, v3
    s.mov        s7, s1
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s4
    br.nz        s2, endfor_4
    .li       s2, #1159725056
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #897988541
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1077936128
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v8, s1
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.add        v9, v8, v2
    v.movi       v8, #2560
    s.add        s7, s3, s2                      // &in_ptr0[...]
    s.add        s11, s5, s2                     // &in_ptr1[...]
    v.cmp.lt     p1, v9, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s7, #0]
    .li       s7, #1065353216
    v.splat      v9, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s7, s8, s2                      // &out_ptr1[...]
    s.add        s12, s9, s2                     // &out_ptr2[...]
    s.add        s13, s10, s2                    // &out_ptr3[...]
    s.add        s2, s1, s6
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s11, #0]
    vf.cvt.bf16.f32 v11, v8
    s.movz       s11, #1
    vf.cvt.bf16.f32 v8, v10
    vf.fms       v10, v0, v4, v1
    vf.add       v1, v8, v9
    vf.fms       v8, v4, v10, v4
    vf.neg       v9, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v8, v9, v4
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v9, v4, v0, v3
    vf.fms       v0, v9, v8, v4
    vf.neg       v8, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v0, v8, v4
    vf.add       v4, v0, v5
    v.rsqrt.approx v0, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v0, v0
    vf.mul       v8, v0, v7
    vf.fms       v7, v4, v5, v6
    vf.mul       v4, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v5, v4, v0
    v.extract    s14, v5, #0
    v.splat      v0, s14
    vf.mul       v4, v11, v0
    vf.mul       v0, v4, v1
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s7, #0], v1
    @p1 v.st.h       [s12, #0], v1
    @p1 v.st.h       [s13, #0], v1
    s.mov        s1, s2
    br.nz        s11, for_3
endfor_4:
    exit
    exit
