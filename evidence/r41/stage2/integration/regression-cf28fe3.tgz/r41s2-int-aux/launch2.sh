#!/bin/bash
L="bash $HOME/r41s2-int-aux/lane.sh"; P=$HOME/tc_env/torchenv/bin/python; A=$HOME/r41s2-int-aux; B=$HOME/r41s2-int-base
setsid nohup $L r41s2-int-f H "make r40-pipeline-checks PYTHON=$P TRITON_PYTHON=$P TORCH_PYTHON=$P" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-base I "make r40-pipeline-checks PYTHON=$P TRITON_PYTHON=$P TORCH_PYTHON=$P" </dev/null >/dev/null 2>&1 &
sleep 2; tail -n1 $HOME/r41s2-int-logs/[GHI].lane
