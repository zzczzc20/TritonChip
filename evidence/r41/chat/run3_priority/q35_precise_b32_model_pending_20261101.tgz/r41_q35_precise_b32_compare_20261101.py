#!/usr/bin/env python3
import json,os,select,sys
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home();kind=sys.argv[1];pid=int(sys.argv[2])
try:
 fd=os.pidfd_open(pid);p=select.poll();p.register(fd,select.POLLIN);p.poll();os.close(fd)
except ProcessLookupError:pass
if kind=='two':
 cpu=h/'r41_q35_first_headless_v2_cpu_20261031_diag';base=h/'r41_q35_first_headless_v2_tlm_20261031_diag';cand=h/'r41_q35_first_headless_precise_b32_tlm_20261031_diag';f='states.safetensors';out=h/'r41_q35_first_headless_precise_b32_compare_20261101.json'
elif kind=='full':
 cpu=h/'r41_q35_multiturn_cpu_diag';base=h/'r41_q35_multiturn_tlm_whole_20261031_diag';cand=h/'r41_q35_full_precise_b32_20261101_diag';f='logits.safetensors';out=h/'r41_q35_full_precise_b32_compare_20261101.json'
else:raise ValueError(kind)
cj=json.loads((cpu/'result.json').read_text());bj=json.loads((base/'result.json').read_text());dj=json.loads((cand/'result.json').read_text())
for k in ('input_ids','model','revision','legacy_chat_sha256' if kind=='full' else 'chat_sha256'):
 if cj[k]!=dj[k] or bj[k]!=dj[k]:raise ValueError('identity differs '+k)
c=load_file(str(cpu/f));b=load_file(str(base/f));d=load_file(str(cand/f));keys=['whole'] if kind=='full' else sorted(c)
rows={}
for k in keys:
 if c[k].shape!=b[k].shape or c[k].shape!=d[k].shape:raise ValueError('shape differs '+k)
 x=c[k].float();y=b[k].float();z=d[k].float();rows[k]={'elements':x.numel(),'baseline_mismatches':int((c[k].view(torch.int16)!=b[k].view(torch.int16)).sum()),'candidate_mismatches':int((c[k].view(torch.int16)!=d[k].view(torch.int16)).sum()),'baseline_rel_l2':float((x-y).norm()/x.norm().clamp_min(1e-30)),'candidate_rel_l2':float((x-z).norm()/x.norm().clamp_min(1e-30)),'candidate_max_abs':float((x-z).abs().max())}
 if kind=='full':rows[k].update(cpu_argmax=int(x.argmax()),baseline_argmax=int(y.argmax()),candidate_argmax=int(z.argmax()),candidate_top5=dj['paths']['whole']['logits'])
out.write_text(json.dumps({'scope':'nondefault precision casts + max block 32, CPU vs DP TLM; not board','rows':rows},indent=2)+'\n');print(json.dumps(rows),flush=True)
