"""Pin the already-recorded Hub revision while running the unmodified suite."""
import runpy
import sys
import kernels
original = kernels.get_kernel
def pinned(repo, *args, **kwargs):
    if repo == 'kernels-community/finegrained-fp8' and kwargs.get('version') == 4:
        kwargs.pop('version')
        kwargs['revision'] = '0e5764aa5c27d0f005117a92645156481540950a'
    return original(repo, *args, **kwargs)
kernels.get_kernel = pinned
sys.argv[0] = 'tools/performance_harness/fp8_kernels_cases.py'
runpy.run_path(sys.argv[0], run_name='__main__')
