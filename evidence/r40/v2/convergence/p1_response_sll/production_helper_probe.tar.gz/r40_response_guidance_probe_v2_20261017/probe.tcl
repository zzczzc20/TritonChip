if {[llength $argv]!=2} {error "expected EXISTING_DCP FRESH_REPORT"}
set dcp [lindex $argv 0]
set report [lindex $argv 1]
if {[file exists $report]} {error "fresh output required"}
set_param general.maxThreads 2
open_checkpoint $dcp
proc r40_index {name index} {return [format {%s\[%d\]} $name $index]}
proc r40_guide_response_crossing {link_suffix} {
    global r40_leaf_cells r40_leaf_names
    set sender [r40_index g_stage 1]
    set receiver [r40_index g_stage 0]
    set pairs 0
    set skipped 0
    set sender_pattern "$link_suffix/$sender.rd_reg*"
    set receiver_pattern "$link_suffix/$receiver.rd_reg*"
    foreach cell $r40_leaf_cells name $r40_leaf_names {
        if {(![string match "*/$sender_pattern" $name] &&
             ![string match $sender_pattern $name]) ||
            ![string match FD* [get_property REF_NAME $cell]]} {continue}
        set q [get_pins -quiet -of_objects $cell -filter {REF_PIN_NAME == Q}]
        set nets [get_nets -segments -quiet -of_objects $q]
        set loads [get_pins -leaf -quiet -of_objects $nets -filter {DIRECTION == IN}]
        # Guide only the direct, single-load payload FF pair screened on U280.
        # Valid/ready and locally consumed payloads retain ordinary placement.
        if {[llength $loads] != 1 || [get_property REF_PIN_NAME $loads] ne "D"} {
            incr skipped
            continue
        }
        set destination [get_cells -quiet -of_objects $loads]
        if {![string match FD* [get_property REF_NAME $destination]] ||
            (![string match "*/$receiver_pattern" [get_property NAME $destination]] &&
             ![string match $receiver_pattern [get_property NAME $destination]])} {
            incr skipped
            continue
        }
        # Preserve Vivado object handles; concat can stringify a collection
        # into an invalid object argument when the hierarchy contains brackets.
        set_property USER_SLL_REG TRUE $cell
        set_property USER_SLL_REG TRUE $destination
        incr pairs
    }
    if {$pairs == 0} {error "R40 placement: no eligible response FF pairs in $link_suffix"}
    puts "R40_RESPONSE_SLL_GUIDANCE link=$link_suffix pairs=$pairs skipped=$skipped"
    # This is placement guidance. Final LOC/BEL and setup/hold still need audit.
}

set r40_leaf_cells [get_cells -hierarchical -filter {IS_PRIMITIVE == 1}]
set r40_leaf_names [get_property NAME $r40_leaf_cells]
r40_guide_response_crossing link
set f [open $report {WRONLY CREAT EXCL}]
puts $f "cell\tprimitive\tuser_sll_reg"
set count 0
foreach cell $r40_leaf_cells name $r40_leaf_names {
 if {![string match {link/g_stage*.rd_reg*} $name]} {continue}
 set value [get_property USER_SLL_REG $cell]
 if {![string is true -strict $value]} {error "eligible FF missed: $name $value"}
 puts $f "$name\t[get_property REF_NAME $cell]\t$value"
 incr count
}
close $f
if {$count!=1034} {error "expected 1034 guided payload FFs, found $count"}
puts R40_PRODUCTION_GUIDANCE_proc r40_index {name index} {return [format {%s\[%d\]} $name $index]}
proc r40_guide_response_crossing {link_suffix} {
    global r40_leaf_cells r40_leaf_names
    set sender [r40_index g_stage 1]
    set receiver [r40_index g_stage 0]
    set pairs 0
    set skipped 0
    set sender_pattern "$link_suffix/$sender.rd_reg*"
    set receiver_pattern "$link_suffix/$receiver.rd_reg*"
    foreach cell $r40_leaf_cells name $r40_leaf_names {
        if {(![string match "*/$sender_pattern" $name] &&
             ![string match $sender_pattern $name]) ||
            ![string match FD* [get_property REF_NAME $cell]]} {continue}
        set q [get_pins -quiet -of_objects $cell -filter {REF_PIN_NAME == Q}]
        set nets [get_nets -segments -quiet -of_objects $q]
        set loads [get_pins -leaf -quiet -of_objects $nets -filter {DIRECTION == IN}]
        # Guide only the direct, single-load payload FF pair screened on U280.
        # Valid/ready and locally consumed payloads retain ordinary placement.
        if {[llength $loads] != 1 || [get_property REF_PIN_NAME $loads] ne "D"} {
            incr skipped
            continue
        }
        set destination [get_cells -quiet -of_objects $loads]
        if {![string match FD* [get_property REF_NAME $destination]] ||
            (![string match "*/$receiver_pattern" [get_property NAME $destination]] &&
             ![string match $receiver_pattern [get_property NAME $destination]])} {
            incr skipped
            continue
        }
        # Preserve Vivado object handles; concat can stringify a collection
        # into an invalid object argument when the hierarchy contains brackets.
        set_property USER_SLL_REG TRUE $cell
        set_property USER_SLL_REG TRUE $destination
        incr pairs
    }
    if {$pairs == 0} {error "R40 placement: no eligible response FF pairs in $link_suffix"}
    puts "R40_RESPONSE_SLL_GUIDANCE link=$link_suffix pairs=$pairs skipped=$skipped"
    # This is placement guidance. Final LOC/BEL and setup/hold still need audit.
}
_PROBE_DONE_1034
# In-memory guidance only. Never implement or write the source checkpoint.
exit
