
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 64},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16384, 'r0_': 4096}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4096
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 64], strides=[64, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 256)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((1) * ((1) <= ((255 + XBLOCK) // 256)) + ((255 + XBLOCK) // 256) * (((255 + XBLOCK) // 256) < (1))), ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 3, 1]), [R0_BLOCK])
        tmp7 = tl.load(in_ptr3 + (x0 + 256*r0_2 + 16384*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp14 = tl.load(in_ptr4 + (256 + 512*(x3 // 256) + ((x3 % 256))), None).to(tl.float32)
    tmp13 = tmp11.to(tl.float32)
    tmp15 = tl.sigmoid(tmp14)
    tmp16 = tmp13 * tmp15
    tl.store(out_ptr1 + (x3), tmp16, None)
