    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    .li       s1, #4286578688
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.cmp.ne     p1, v0, v1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #17
    s.movz       s6, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    p.mov        p2, p1
    s.ld.d       s8, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // out_ptr3: device_ptr64 at arg_base+24
    v.mov        v3, v2
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v1, s7
    v.movi       v4, #17
    v.movi       v5, #1
    v.add        v6, v1, v0
    s.add        s11, s7, s1
    v.movi       v1, #0
    s.shli       s12, s11, #2                    // element offset -> bytes (x4)
    v.cmp.lt     p1, v6, v4
    s.add        s11, s3, s12                    // &in_ptr0[...]
    v.movi       v4, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s11, #0]
    v.movi       v8, #1
    v.movi       v9, #0
    v.movi       v10, #1
    vf.cmp.eq    p3, v7, v2
    @p3 v.sel        v11, v5, v1
    v.movi       v1, #0
    v.movi       v5, #1
    v.cmp.eq     p3, v11, v4
    @p3 v.sel        v4, v8, v9
    @p3 v.sel        v8, v10, v1
    v.movi       v1, #0
    v.extract    s11, v4, #0
    v.movi       v4, #0
    v.movi       v9, #0
    s.lshri      s12, s11, #32
    v.extract    s13, v8, #1
    @p3 v.sel        v8, v5, v1
    v.movi       v1, #1
    v.movi       v5, #0
    v.insert     v4, s11, #0
    v.insert     v9, s12, #0
    s.lshri      s11, s13, #32
    v.extract    s12, v8, #2
    @p3 v.sel        v8, v1, v5
    v.movi       v1, #1
    v.movi       v5, #0
    v.insert     v4, s13, #1
    v.insert     v9, s11, #1
    s.lshri      s11, s12, #32
    v.extract    s13, v8, #3
    @p3 v.sel        v8, v1, v5
    v.insert     v4, s12, #2
    v.insert     v9, s11, #2
    s.lshri      s11, s13, #32
    v.extract    s12, v8, #4
    v.insert     v4, s13, #3
    v.insert     v9, s11, #3
    s.lshri      s11, s12, #32
    v.insert     v4, s12, #4
    v.splat      v1, s1
    v.insert     v9, s11, #4
    v.add        v5, v6, v1
    v.movi       v1, #1
    v.movi       v5, #0
    v.movi       v6, #1
    v.movi       v8, #0
    @p3 v.sel        v10, v1, v5
    v.movi       v1, #1
    @p3 v.sel        v5, v6, v8
    v.extract    s1, v10, #5
    v.movi       v6, #0
    s.lshri      s11, s1, #32
    v.extract    s12, v5, #6
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s1, #5
    v.insert     v9, s11, #5
    s.lshri      s1, s12, #32
    v.extract    s11, v5, #7
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s12, #6
    v.insert     v9, s1, #6
    s.lshri      s1, s11, #32
    v.extract    s12, v5, #8
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s11, #7
    v.insert     v9, s1, #7
    s.lshri      s1, s12, #32
    v.extract    s11, v5, #9
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s12, #8
    v.insert     v9, s1, #8
    s.lshri      s1, s11, #32
    v.extract    s12, v5, #10
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s11, #9
    v.insert     v9, s1, #9
    s.lshri      s1, s12, #32
    v.extract    s11, v5, #11
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s12, #10
    v.insert     v9, s1, #10
    s.lshri      s1, s11, #32
    v.extract    s12, v5, #12
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s11, #11
    v.insert     v9, s1, #11
    s.lshri      s1, s12, #32
    v.extract    s11, v5, #13
    @p3 v.sel        v5, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v4, s12, #12
    v.insert     v9, s1, #12
    s.lshri      s1, s11, #32
    v.extract    s12, v5, #14
    @p3 v.sel        v5, v1, v6
    v.insert     v4, s11, #13
    v.insert     v9, s1, #13
    s.lshri      s1, s12, #32
    v.extract    s11, v5, #15
    v.insert     v4, s12, #14
    v.insert     v9, s1, #14
    s.lshri      s1, s11, #32
    v.insert     v4, s11, #15
    v.insert     v9, s1, #15
    s.movz       s1, #0
    v.extract    s11, v4, #0
    v.extract    s12, v9, #0
    v.extract    s13, v9, #1
    s.shli       s14, s12, #32
    v.movi       v1, #0
    s.or         s12, s11, s14
    v.extract    s11, v4, #1
    s.shli       s14, s13, #32
    s.cmp.ne     s13, s12, s1
    v.extract    s1, v9, #2
    s.or         s12, s11, s14
    s.movz       s11, #0
    v.insert     v1, s13, #0
    v.extract    s13, v4, #2
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s12, s11
    v.extract    s11, v9, #3
    s.or         s12, s13, s14
    s.movz       s13, #0
    v.insert     v1, s1, #1
    v.extract    s1, v4, #3
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s12, s13
    v.extract    s12, v9, #4
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v1, s11, #2
    v.extract    s11, v4, #4
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s1
    v.extract    s1, v9, #5
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v1, s12, #3
    v.extract    s12, v4, #5
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s13, s11
    v.extract    s11, v9, #6
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v1, s1, #4
    v.extract    s1, v4, #6
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v9, #7
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v1, s11, #5
    v.extract    s11, v4, #7
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s1
    v.extract    s1, v9, #8
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v1, s12, #6
    v.extract    s12, v4, #8
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s13, s11
    v.extract    s11, v9, #9
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v1, s1, #7
    v.extract    s1, v4, #9
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v9, #10
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v1, s11, #8
    v.extract    s11, v4, #10
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s1
    v.extract    s1, v9, #11
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v1, s12, #9
    v.extract    s12, v4, #11
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s13, s11
    v.extract    s11, v9, #12
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v1, s1, #10
    v.extract    s1, v4, #12
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v9, #13
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v1, s11, #11
    v.extract    s11, v4, #13
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s1
    v.extract    s1, v9, #14
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v1, s12, #12
    v.extract    s12, v4, #14
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s13, s11
    v.extract    s11, v9, #15
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v1, s1, #13
    v.extract    s1, v4, #15
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    s.or         s12, s1, s14
    s.movz       s1, #0
    v.insert     v1, s11, #14
    s.cmp.ne     s11, s12, s1
    v.movi       v4, #0
    v.insert     v1, s11, #15
    vf.max.prop  v5, v3, v7
    p.not        p3, p1
    v.cmp.ne     p4, v1, v4
    p.or         p5, p2, p4
    p.and        p4, p3, p2
    p.and        p3, p1, p5
    @p1 v.sel        v1, v5, v3
    v.movi       v4, #0
    p.or         p1, p3, p4
    s.add        s1, s7, s6
    p.mov        p3, p1
    v.mov        v4, v1
    s.movz       s11, #1
    p.mov        p2, p3
    v.mov        v3, v4
    s.mov        s7, s1
    br.nz        s11, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v2, #0
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v3, v3
    @p1 v.sel        v6, v1, v2
    @p2 v.sel        v1, v4, v5
    v.movi       v2, #0
    v.reduce.or.b v4, v6
    vf.reduce.max.b v5, v3
    .li       s1, #2143289344
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s1, #1
    v.reduce.or  s7, v1
    v.cmp.ne     p1, v4, v2
    s.shli       s11, s4, #0                     // element offset -> bytes (x1)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s1
    v.splat      v4, s7
    @p1 v.sel        v6, v3, v5
    v.movi       v3, #0
    v.movi       v5, #0
    v.movi       v7, #0
    s.add        s1, s8, s11                     // &out_ptr0[...]
    v.cmp.lt     p1, v1, v2
    vf.add       v1, v6, v3
    @p1 v.st.b       [s1, #0], v4
    s.addi       s1, s2, #0
    v.mov        v7, v5
for_3:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_4
    s.mul        s2, s4, s5
    v.splat      v2, s1
    v.movi       v4, #17
    v.extract    s7, v1, #0
    v.add        v5, v2, v0
    s.add        s8, s1, s2
    v.splat      v2, s7
    s.shli       s7, s8, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v5, v4
    s.add        s8, s3, s7                      // &in_ptr0[...]
    .li       s11, #1069066811
    v.splat      v4, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s8, #0]
    .li       s8, #1060205080
    v.splat      v8, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0
    s.add        s8, s9, s7                      // &out_ptr2[...]
    v.splat      v10, s2
    s.add        s2, s1, s6
    s.movz       s7, #1
    v.add        v11, v5, v10
    vf.sub       v5, v6, v2
    vf.mul       v2, v5, v4
    v.exp2.approx v6, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v5, v4, v2                 // the exact rounding error of x*log2(e)
    vf.mul       v2, v10, v8
    vf.fma       v4, v6, v2, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v2, v4, v6
    vf.add       v4, v7, v2
    @p1 v.st.w       [s8, #0], v2
    @p1 v.sel        v2, v4, v7
    v.mov        v9, v2
    v.mov        v7, v9
    s.mov        s1, s2
    br.nz        s7, for_3
endfor_4:
    vf.reduce.add.b v0, v7
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v1, v0, v3
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s10, s2                     // &out_ptr3[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
