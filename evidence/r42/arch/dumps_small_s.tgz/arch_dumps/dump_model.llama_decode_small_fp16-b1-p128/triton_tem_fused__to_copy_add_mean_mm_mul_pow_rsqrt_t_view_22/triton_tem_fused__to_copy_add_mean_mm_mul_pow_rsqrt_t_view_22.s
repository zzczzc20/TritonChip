    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: one row broadcast down a tile (outer stride 0) (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #2
    s.st.d       [s5, #56], s2
    .li       s6, #68719476752
    s.st.d       [s5, #88], s6
    .li       s7, #8589934592
    s.st.d       [s5, #104], s7
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s8, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s9, #512
    s.mul        s10, s5, s9
    s.add        s5, s8, s10                     // this context's own scratch
    s.addi       s8, s5, #256                    // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s8, #0], s3
    s.st.d       [s8, #8], s1
    s.st.d       [s8, #16], s1
    s.movz       s1, #256
    s.st.d       [s8, #48], s1
    s.st.d       [s8, #56], s2
    s.st.d       [s8, #88], s6
    s.st.d       [s8, #104], s7
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #22
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s1, s2, s3
    .li       s3, #1952257862
    s.movz       s5, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
__rctx_program:
    s.cmp.lt     s8, s6, s2
    s.addi       s9, s2, #0
    s.sub        s10, s2, s8
    s.addi       s8, s2, #0
    s.xor        s11, s6, s10
    s.xor        s12, s10, s1
    s.sub        s13, s11, s10
    s.mul        s14, s13, s3
    s.mov        s9, s13
    s.lshri      s15, s14, #32
    s.sub        s14, s13, s15
    s.lshri      s16, s14, #1
    s.add        s14, s15, s16
    s.lshri      s15, s14, #4
    s.xor        s14, s15, s12
    s.sub        s15, s14, s12
    s.sub        s12, s5, s15
    s.min.s      s14, s12, s5
    s.cmp.lt     s12, s14, s2
    s.sub        s16, s2, s12
    s.xor        s12, s14, s16
    s.sub        s14, s12, s16
    s.cmp.eq     s12, s14, s5
    br.nz        s12, sdiv_done_1
    s.movz       s12, #0
    s.movz       s17, #31
    s.mov        s9, s12
    s.addi       s18, s17, #0
sdiv_2:
    s.lshr       s17, s13, s18
    s.shli       s19, s8, #1
    s.andi       s20, s17, #1
    s.shl        s17, s5, s18
    s.or         s21, s19, s20
    s.cmp.geu    s19, s21, s14
    s.sub        s20, s12, s19
    s.and        s19, s14, s20
    s.and        s22, s17, s20
    s.sub        s8, s21, s19
    s.or         s9, s9, s22
    s.subi       s18, s18, #1
    s.cmp.ge     s17, s18, s12
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.sub        s9, s11, s10
    s.xor        s11, s8, s10
    s.mul        s8, s9, s3
    s.movz       s12, #1
    s.sub        s13, s11, s10
    s.addi       s11, s2, #0
    s.cmp.eq     s17, s14, s12
    s.lshri      s18, s8, #32
    s.add        s8, s15, s13
    s.sub        s13, s9, s18
    s.addi       s15, s2, #0
    s.lshri      s19, s13, #1
    s.add        s13, s18, s19
    s.lshri      s18, s13, #4
    s.muli       s13, s18, #22
    s.sub        s18, s9, s13
    s.xor        s9, s18, s10
    s.sub        s13, s9, s10
    s.cmp.lt     s9, s13, s2
    s.sub        s10, s2, s9
    s.xor        s9, s13, s10
    s.sub        s13, s9, s10
    s.mov        s11, s13
    br.nz        s17, sdiv_done_3
    s.movz       s9, #0
    s.movz       s17, #31
    s.mov        s11, s9
    s.addi       s18, s17, #0
sdiv_4:
    s.lshr       s17, s13, s18
    s.shli       s19, s15, #1
    s.andi       s20, s17, #1
    s.shl        s17, s12, s18
    s.or         s21, s19, s20
    s.cmp.geu    s19, s21, s14
    s.sub        s20, s9, s19
    s.and        s19, s14, s20
    s.and        s22, s17, s20
    s.sub        s15, s21, s19
    s.or         s11, s11, s22
    s.subi       s18, s18, #1
    s.cmp.ge     s17, s18, s9
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.xor        s9, s10, s16
    s.movz       s10, #16
    s.xor        s12, s11, s9
    .li       s11, #1952257862
    s.sub        s13, s12, s9
    s.movz       s9, #0
    s.mul        s12, s13, s10
    s.movz       s13, #8
    s.addi       s14, s9, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.mul        s15, s12, s11
    s.lshri      s11, s15, #32
    s.sub        s15, s12, s11
    s.lshri      s16, s15, #1
    s.add        s15, s11, s16
    s.lshri      s11, s15, #8
    s.muli       s15, s11, #352
    s.sub        s11, s12, s15
for_5:
    s.cmp.ge     s15, s14, s13
    br.nz        s15, endfor_6
    s.mul        s15, s14, s10
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s16, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s17, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s17, s16
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s17, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s17, s16
    mb.wait      s16
gemm_pipe:
    mb.arm       s15, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s17, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s15
    s.add        s14, s14, s5
    s.cmp.ge     s17, s14, s13
    br.nz        s17, gemm_pipe_drain0
    s.mul        s17, s14, s10
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s19, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s19, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s19, s18
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s19, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s19, s18
    mb.wait      s18
    mb.wait      s15
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s17
    s.add        s14, s14, s5
    s.cmp.ge     s19, s14, s13
    br.nz        s19, gemm_pipe_drain1
    s.mul        s19, s14, s10
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s21, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s22, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s22, s20
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s22, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s22, s20
    mb.wait      s20
    mb.wait      s17
    br.nz        s21, gemm_pipe
gemm_pipe_drain0:
    s.movz       s11, #1
    mb.wait      s15
    br.nz        s11, endfor_6
gemm_pipe_drain1:
    mb.wait      s17
endfor_6:
    s.mul        s11, s8, s10
    s.add        s8, s9, s12                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v2, a0, s9
    s.add        s8, s9, s11                     // the tile origin
    s.movz       s9, #352
    s.muli       s10, s12, #2                    // a runtime tile origin, x2
    v.splat      v3, s8
    v.splat      v4, s5
    v.add        v5, v0, v1
    v.splat      v0, s9
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s9, s4, s10                     // the tile origin
    p.and        p3, p1, p2
    s.movz       s10, #1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v0, a0, s10
    s.addi       s10, s8, #1
    s.movz       s11, #2
    v.splat      v1, s10
    vf.cvt.f32.f16 v2, v0
    s.addi       s10, s8, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.splat      v0, s10
    s.movz       s10, #3
    s.addi       s12, s8, #3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    @p3 v.st.h       [s9, #0], v2
    a.vread      v0, a0, s11
    v.splat      v1, s12
    s.movz       s11, #4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s12, s8, #4
    s.movz       s13, #5
    v.splat      v0, s12
    s.addi       s12, s8, #5
    s.movz       s14, #6
    v.splat      v1, s12
    s.addi       s12, s8, #6
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v2
    v.splat      v2, s12
    s.movz       s10, #7
    s.addi       s12, s8, #7
    s.movz       s19, #8
    v.splat      v3, s12
    s.addi       s12, s8, #8
    v.splat      v5, s12
    s.movz       s12, #9
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s11, s8, #9
    v.splat      v0, s11
    s.movz       s11, #10
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s13
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s13, s8, #10
    v.splat      v1, s13
    s.movz       s13, #11
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s14
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s14, s8, #11
    v.splat      v2, s14
    s.movz       s14, #12
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a0, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s10, s8, #12
    v.splat      v3, s10
    s.movz       s10, #13
    @p3 v.st.h       [s9, #0], v5
    a.vread      v5, a0, s19
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v5
    s.addi       s19, s8, #13
    v.splat      v5, s19
    s.movz       s19, #14
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s12, s8, #14
    s.addi       s21, s8, #15
    v.splat      v0, s12
    s.movz       s8, #15
    v.splat      v6, s21
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s9, #0], v2
    a.vread      v1, a0, s13
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s9, #0], v2
    a.vread      v1, a0, s14
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s9, #0], v2
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s19
    v.cmp.lt     p1, v6, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s9, #0], v1
    a.vread      v0, a0, s8
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s9, #0], v1
__rctx_next:
    s.addi       s8, s6, #2                      // the next program of this context: + 2
    s.cmp.lt     s9, s8, s7
    s.mov        s6, s8
    br.nz        s9, __rctx_program
    exit
