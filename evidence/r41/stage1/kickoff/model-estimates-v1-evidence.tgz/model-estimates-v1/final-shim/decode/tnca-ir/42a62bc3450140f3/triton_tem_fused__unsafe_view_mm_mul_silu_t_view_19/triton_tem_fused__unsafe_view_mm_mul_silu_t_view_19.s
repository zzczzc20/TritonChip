    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #1024
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s7, #0], s3
    .li       s1, #2147483647
    s.st.d       [s7, #8], s1
    .li       s1, #2147483647
    s.st.d       [s7, #16], s1
    s.movz       s1, #4096
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476752
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #384
    s.movz       s3, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s1, s9
    s.sub        s9, s8, s10
    s.xor        s8, s1, s9
    s.sub        s10, s8, s9
    .li       s8, #1431655766
    s.movz       s10, #1
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #1
    s.cmp.lt     s18, s4, s7
    s.sub        s7, s3, s18
    s.xor        s3, s4, s7
    s.sub        s18, s3, s7
    s.mul        s3, s18, s8
    s.lshri      s8, s3, #32
    s.sub        s3, s18, s8
    s.lshri      s19, s3, #1
    s.add        s3, s8, s19
    s.lshri      s8, s3, #8
    s.muli       s3, s8, #384
    s.sub        s19, s18, s3
    s.xor        s3, s7, s9
    s.xor        s7, s8, s3
    s.sub        s8, s7, s3
    s.sub        s3, s10, s8
    s.min.s      s7, s3, s10
    s.cmp.lt     s3, s4, s12
    s.sub        s9, s11, s3
    s.cmp.lt     s3, s7, s14
    s.sub        s11, s13, s3
    s.xor        s3, s4, s9
    s.sub        s12, s3, s9
    s.xor        s3, s7, s11
    s.sub        s13, s3, s11
    s.addi       s3, s15, #0
    s.addi       s11, s16, #0
    s.cmp.eq     s14, s13, s17
    s.mov        s3, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s3, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s11, #1
    s.andi       s17, s15, #1
    s.movz       s15, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s13
    s.shl        s19, s16, s14
    s.sub        s16, s15, s17
    s.subi       s15, s14, #1
    s.and        s17, s13, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s3, s20
    s.mov        s11, s16
    s.mov        s3, s17
    s.mov        s14, s15
    s.movz       s15, #0
    s.cmp.ge     s16, s14, s15
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s4, s3
    .li       s3, #1431655766
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.mul        s16, s15, s3
    s.cmp.lt     s3, s7, s12
    s.movz       s12, #0
    s.sub        s17, s13, s3
    s.movz       s3, #0
    s.lshri      s13, s16, #32
    s.cmp.lt     s16, s1, s12
    s.xor        s12, s7, s17
    s.xor        s7, s11, s9
    s.sub        s11, s12, s17
    s.sub        s12, s7, s9
    s.sub        s7, s15, s13
    s.add        s9, s8, s12
    s.lshri      s8, s7, #1
    s.movz       s7, #0
    s.add        s12, s13, s8
    s.sub        s8, s7, s16
    s.lshri      s7, s12, #8
    s.movz       s12, #0
    s.muli       s13, s7, #384
    s.movz       s7, #1
    s.xor        s16, s1, s8
    s.addi       s1, s12, #0
    s.cmp.eq     s12, s11, s7
    s.sub        s7, s15, s13
    s.movz       s13, #0
    s.xor        s15, s7, s14
    s.sub        s7, s16, s8
    s.sub        s7, s15, s14
    s.addi       s8, s13, #0
    s.cmp.lt     s13, s7, s4
    s.sub        s4, s3, s13
    s.xor        s3, s7, s4
    s.sub        s7, s3, s4
    s.mov        s1, s7
    br.nz        s12, sdiv_done_3
    s.movz       s3, #0
    s.movz       s12, #31
    s.mov        s1, s3
    s.addi       s3, s12, #0
sdiv_4:
    s.lshr       s12, s7, s3
    s.shli       s13, s8, #1
    s.andi       s14, s12, #1
    s.movz       s12, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s3
    s.sub        s13, s12, s14
    s.subi       s12, s3, #1
    s.and        s14, s11, s13
    s.and        s18, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s1, s18
    s.mov        s8, s13
    s.mov        s1, s14
    s.mov        s3, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s3, s12
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.xor        s3, s4, s17
    s.movz       s4, #16
    s.xor        s7, s1, s3
    .li       s1, #1431655766
    s.sub        s8, s7, s3
    s.movz       s3, #0
    s.mul        s7, s8, s4
    v.splat      v0, s9
    v.splat      v1, s3
    v.splat      v2, s8
    v.splat      v3, s3
    s.mul        s8, s7, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s7
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    s.lshri      s1, s8, #32
    v.cmp.ge     p1, v2, v3
    s.sub        s8, s7, s1
    v.add        v0, v5, v4
    s.lshri      s11, s8, #1
    s.movz       s8, #128
    s.add        s12, s1, s11
    s.addi       s1, s3, #0
    s.lshri      s3, s12, #12
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.muli       s11, s3, #6144
    s.sub        s3, s7, s11
    v.splat      v0, s3
    v.add        v1, v0, v6
for_5:
    s.cmp.ge     s11, s1, s8
    br.nz        s11, endfor_6
    s.mul        s11, s1, s4
    s.muli       s12, s11, #2                    // a runtime tile origin, x2
    s.add        s13, s2, s12                    // the tile origin
    v.ld.h       v0, [s13, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s13, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s13, s12
    mb.wait      s12
    s.rdspecial  s11, arg_base
    s.ld.d       s13, [s11, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s11, role_id
    s.movz       s14, #1024
    s.mul        s15, s11, s14
    s.add        s11, s13, s15                   // this context's own scratch
    s.addi       s13, s11, #256                  // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s13, #0], v0
    s.addi       s14, s13, #32                   // row 1
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #64                   // row 2
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #96                   // row 3
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #128                  // row 4
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #160                  // row 5
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #192                  // row 6
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #224                  // row 7
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #256                  // row 8
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #288                  // row 9
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #320                  // row 10
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #352                  // row 11
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #384                  // row 12
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #416                  // row 13
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #448                  // row 14
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #480                  // row 15
    v.st.h       [s14, #0], v0
    s.addi       s14, s11, #768                  // TensorMap 1: a repacked tile
    s.movz       s11, #0
    s.st.d       [s14, #0], s13
    s.movz       s11, #16
    s.st.d       [s14, #8], s11
    s.movz       s11, #16
    s.st.d       [s14, #16], s11
    s.movz       s11, #32
    s.st.d       [s14, #48], s11
    s.movz       s11, #2
    s.st.d       [s14, #56], s11
    .li       s11, #68719476752
    s.st.d       [s14, #88], s11
    .li       s11, #1108101562368
    s.st.d       [s14, #104], s11
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s11, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s14, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s11, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s11
    mb.wait      s11
    s.add        s14, s1, s10
    s.mov        s1, s14
    s.movz       s14, #1
    br.nz        s14, for_5
endfor_6:
    s.mul        s1, s9, s4
    s.movz       s2, #0
    v.splat      v0, s10
    v.movi       v1, #1
    v.movi       v2, #0
    s.add        s3, s2, s1                      // the tile origin
    s.movz       s2, #0
    v.splat      v3, s3
    s.add        s4, s2, s7                      // the tile origin
    s.muli       s2, s7, #2                      // a runtime tile origin, x2
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v1, v2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s4
    v.extract    s4, v3, #0
    s.movz       s8, #6144
    s.muli       s9, s1, #12288                  // a runtime tile origin, x12288
    v.splat      v3, s4
    v.movi       v5, #0
    v.add        v6, v1, v2
    v.splat      v1, s8
    s.add        s4, s5, s2                      // the tile origin
    v.cmp.ne     p1, v3, v5
    v.cmp.lt     p2, v6, v1
    s.add        s2, s4, s9                      // the tile origin
    p.and        p3, p1, p2
    s.addi       s4, s3, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    v.splat      v2, s4
    v.movi       v3, #1
    v.movi       v5, #0
    v.cmp.lt     p1, v2, v0
    v.movi       v2, #0
    @p1 v.sel        v6, v3, v5
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.addi       s5, s2, #12288                  // row 1
    v.extract    s8, v6, #0
    s.movz       s9, #1
    v.splat      v3, s8
    s.movz       s8, #2
    v.splat      v5, s1
    vf.cvt.bf16.f32 v6, v1
    v.cmp.ne     p1, v3, v2
    p.and        p3, p1, p2
    s.addi       s10, s2, #24576                 // row 2
    v.add        v1, v5, v4
    a.vwrite     a1, s4, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    s.addi       s4, s3, #2
    v.movi       v2, #1
    v.splat      v3, s4
    v.movi       v4, #0
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v2, v4
    s.addi       s4, s3, #3
    v.movi       v2, #1
    v.extract    s5, v3, #0
    v.splat      v3, s4
    v.splat      v4, s5
    v.movi       v6, #0
    vf.cvt.bf16.f32 v7, v1
    v.cmp.ne     p1, v4, v5
    p.and        p3, p1, p2
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v1, v2, v6
    a.vwrite     a1, s9, v7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s10, #0]
    v.extract    s4, v1, #0
    v.movi       v1, #0
    v.splat      v3, s4
    s.movz       s4, #36864
    s.addi       s5, s3, #4
    v.cmp.ne     p1, v3, v1
    s.add        s9, s2, s4                      // row 3
    p.and        p3, p1, p2
    v.splat      v1, s5
    v.movi       v3, #1
    v.movi       v4, #0
    v.cmp.lt     p1, v1, v0
    v.movi       v1, #0
    vf.cvt.bf16.f32 v5, v2
    @p1 v.sel        v2, v3, v4
    s.movz       s4, #49152
    s.movz       s5, #3
    v.extract    s10, v2, #0
    a.vwrite     a1, s8, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s9, #0]
    v.splat      v3, s10
    s.add        s8, s2, s4                      // row 4
    s.addi       s4, s3, #5
    v.cmp.ne     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v1, s4
    v.movi       v3, #1
    v.movi       v4, #0
    v.cmp.lt     p1, v1, v0
    v.movi       v1, #0
    @p1 v.sel        v5, v3, v4
    s.movz       s4, #61440
    s.movz       s9, #4
    vf.cvt.bf16.f32 v3, v2
    v.extract    s10, v5, #0
    s.add        s14, s2, s4                     // row 5
    v.splat      v2, s10
    s.addi       s4, s3, #6
    a.vwrite     a1, s5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s8, #0]
    v.cmp.ne     p1, v2, v1
    p.and        p3, p1, p2
    v.splat      v1, s4
    v.movi       v2, #1
    v.movi       v4, #0
    v.cmp.lt     p1, v1, v0
    v.movi       v1, #0
    @p1 v.sel        v5, v2, v4
    .li       s4, #73728
    s.movz       s5, #5
    v.extract    s8, v5, #0
    s.add        s10, s2, s4                     // row 6
    v.splat      v2, s8
    vf.cvt.bf16.f32 v4, v3
    s.addi       s4, s3, #7
    v.cmp.ne     p1, v2, v1
    p.and        p4, p1, p2
    v.splat      v1, s4
    a.vwrite     a1, s9, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s14, #0]
    v.movi       v3, #1
    v.movi       v4, #0
    v.cmp.lt     p1, v1, v0
    v.movi       v1, #0
    @p1 v.sel        v5, v3, v4
    .li       s4, #86016
    s.movz       s8, #6
    v.extract    s9, v5, #0
    s.add        s14, s2, s4                     // row 7
    v.splat      v3, s9
    s.addi       s4, s3, #8
    v.movi       v4, #1
    v.cmp.ne     p1, v3, v1
    vf.cvt.bf16.f32 v1, v2
    p.and        p3, p1, p2
    v.splat      v2, s4
    v.movi       v3, #0
    v.movi       v5, #0
    a.vwrite     a1, s5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s10, #0]
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v2, v4, v3
    .li       s4, #98304
    s.movz       s5, #7
    v.extract    s9, v2, #0
    s.add        s10, s2, s4                     // row 8
    v.splat      v2, s9
    s.addi       s4, s3, #9
    v.movi       v3, #1
    v.cmp.ne     p1, v2, v5
    p.and        p4, p1, p2
    v.splat      v2, s4
    v.movi       v4, #0
    vf.cvt.bf16.f32 v5, v1
    v.movi       v1, #0
    .li       s4, #110592
    s.movz       s9, #8
    s.add        s15, s2, s4                     // row 9
    a.vwrite     a1, s8, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s14, #0]
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v2, v3, v4
    s.addi       s4, s3, #10
    v.movi       v3, #1
    v.extract    s8, v2, #0
    v.splat      v2, s4
    v.splat      v4, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    v.movi       v2, #0
    @p1 v.sel        v7, v3, v6
    v.cmp.ne     p1, v4, v1
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v1, v5
    v.extract    s4, v7, #0
    .li       s8, #122880
    v.splat      v3, s4
    s.movz       s4, #9
    a.vwrite     a1, s5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s10, #0]
    v.cmp.ne     p1, v3, v2
    s.add        s5, s2, s8                      // row 10
    p.and        p4, p1, p2
    s.addi       s8, s3, #11
    v.movi       v2, #1
    v.splat      v3, s8
    v.movi       v4, #0
    v.movi       v5, #0
    .li       s8, #135168
    s.movz       s10, #10
    s.add        s14, s2, s8                     // row 11
    s.movz       s8, #11
    vf.cvt.bf16.f32 v6, v1
    a.vwrite     a1, s9, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s15, #0]
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v2, v4
    s.addi       s9, s3, #12
    v.movi       v2, #1
    v.extract    s15, v3, #0
    v.splat      v3, s9
    v.splat      v4, s15
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    v.movi       v3, #0
    @p1 v.sel        v7, v2, v6
    v.cmp.ne     p1, v4, v5
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v2, v1
    v.extract    s9, v7, #0
    .li       s15, #147456
    v.splat      v1, s9
    s.add        s9, s2, s15                     // row 12
    a.vwrite     a1, s4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.ne     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s4, s3, #13
    v.movi       v1, #1
    v.splat      v3, s4
    v.movi       v4, #0
    v.movi       v5, #0
    .li       s4, #159744
    s.movz       s5, #12
    s.add        s15, s2, s4                     // row 13
    s.movz       s4, #13
    vf.cvt.bf16.f32 v6, v2
    a.vwrite     a1, s10, v6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s14, #0]
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v1, v4
    s.addi       s10, s3, #14
    v.movi       v1, #1
    v.extract    s14, v3, #0
    v.splat      v3, s10
    v.splat      v4, s14
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    v.movi       v3, #0
    @p1 v.sel        v7, v1, v6
    v.cmp.ne     p1, v4, v5
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v1, v2
    v.extract    s10, v7, #0
    .li       s14, #172032
    v.splat      v2, s10
    s.add        s10, s2, s14                    // row 14
    a.vwrite     a1, s8, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s9, #0]
    v.cmp.ne     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s8, s3, #15
    v.movi       v2, #1
    v.splat      v3, s8
    v.movi       v4, #0
    v.movi       v5, #0
    .li       s8, #184320
    s.movz       s9, #14
    s.add        s14, s2, s8                     // row 15
    s.movz       s2, #15
    vf.cvt.bf16.f32 v6, v1
    a.vwrite     a1, s5, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s15, #0]
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v2, v4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.movz       s8, #0
    v.extract    s15, v3, #0
    .li       s16, #1069066811
    v.splat      v2, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v3, s15
    .li       s15, #1065353216
    v.splat      v4, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s15, s7, #2                     // a runtime tile origin, x2
    v.cmp.ne     p1, v3, v5
    p.and        p3, p1, p2
    s.muli       s7, s1, #12288                  // a runtime tile origin, x12288
    vf.cvt.bf16.f32 v3, v1
    s.add        s1, s6, s15                     // the tile origin
    s.add        s6, s1, s7                      // the tile origin
    a.vwrite     a1, s4, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s10, #0]
    .li       s1, #1060205080
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s1, #0
    vf.cvt.bf16.f32 v6, v1
    a.vwrite     a1, s9, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s14, #0]
    v.splat      v6, s3
    v.movi       v7, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v6, v0
    v.movi       v6, #0
    @p1 v.sel        v9, v7, v8
    s.movz       s4, #1
    v.extract    s7, v9, #0
    v.splat      v7, s7
    vf.cvt.bf16.f32 v8, v1
    v.cmp.ne     p1, v7, v6
    p.and        p3, p1, p2
    a.vwrite     a1, s2, v8
    a.vread      v1, a1, s5
    a.vread      v6, a1, s8
    a.vread      v7, a0, s1
    s.movz       s1, #1
    vf.neg       v8, v6
    vf.cvt.f32.bf16 v6, v7
    vf.mul       v7, v8, v2
    vf.cvt.bf16.f32 v9, v6
    v.exp2.approx v6, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v8, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v7, v10, v3
    vf.fma       v8, v6, v7, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v6
    s.movz       s2, #1
    vf.add       v6, v7, v4
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v7, v5
    vf.fms       v6, v7, v8, v7
    s.addi       s5, s6, #12288                  // row 1
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    s.addi       s7, s3, #1
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v7
    v.splat      v7, s7
    vf.mul       v8, v1, v6                      // a/y as a refined reciprocal (ISA has no divide)
    v.movi       v1, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v0
    vf.mul       v7, v8, v9
    @p1 v.sel        v8, v1, v6
    v.movi       v1, #0
    v.extract    s7, v8, #0
    vf.cvt.f32.bf16 v6, v7
    v.splat      v7, s7
    s.movz       s7, #2
    s.movz       s8, #2
    v.cmp.ne     p1, v7, v1
    @p3 v.st.h       [s6, #0], v6
    a.vread      v1, a1, s4
    a.vread      v6, a1, s1
    a.vread      v7, a0, s2
    p.and        p3, p1, p2
    vf.neg       v8, v6
    vf.cvt.f32.bf16 v6, v7
    vf.mul       v7, v8, v2
    vf.cvt.bf16.f32 v9, v6
    v.exp2.approx v6, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v8, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v7, v10, v3
    vf.fma       v8, v6, v7, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v6
    s.movz       s1, #2
    vf.add       v6, v7, v4
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v7, v5
    vf.fms       v6, v7, v8, v7
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v7
    s.addi       s2, s3, #2
    s.addi       s4, s6, #24576                  // row 2
    vf.mul       v7, v1, v6                      // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v1, s2
    v.movi       v6, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v1, v0
    vf.mul       v1, v7, v9
    @p1 v.sel        v7, v6, v8
    v.extract    s2, v7, #0
    vf.cvt.f32.bf16 v6, v1
    v.splat      v1, s2
    v.movi       v7, #0
    s.movz       s2, #3
    s.movz       s9, #3
    @p3 v.st.h       [s5, #0], v6
    a.vread      v6, a1, s7
    a.vread      v8, a1, s8
    a.vread      v9, a0, s1
    v.cmp.ne     p1, v1, v7
    vf.neg       v1, v8
    vf.cvt.f32.bf16 v7, v9
    p.and        p3, p1, p2
    vf.mul       v8, v1, v2
    vf.cvt.bf16.f32 v9, v7
    v.exp2.approx v7, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v2, v8                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v10, v3
    vf.fma       v8, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v1, v8, v7
    s.movz       s1, #3
    vf.add       v7, v1, v4
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v7, v1, v5
    vf.fms       v7, v1, v8, v1
    vf.neg       v8, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v1
    s.movz       s5, #36864
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #3
    v.movi       v6, #1
    v.splat      v7, s7
    v.movi       v8, #0
    vf.mul       v10, v1, v9
    v.cmp.lt     p1, v7, v0
    @p1 v.sel        v1, v6, v8
    s.add        s7, s6, s5                      // row 3
    vf.cvt.f32.bf16 v6, v10
    v.extract    s5, v1, #0
    v.movi       v1, #0
    v.splat      v7, s5
    s.movz       s5, #4
    @p3 v.st.h       [s4, #0], v6
    a.vread      v6, a1, s2
    a.vread      v8, a1, s9
    a.vread      v9, a0, s1
    v.cmp.ne     p1, v7, v1
    vf.neg       v1, v8
    vf.cvt.f32.bf16 v7, v9
    p.and        p3, p1, p2
    s.movz       s1, #4
    vf.mul       v8, v1, v2
    vf.cvt.bf16.f32 v9, v7
    v.exp2.approx v7, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v2, v8                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v10, v3
    vf.fma       v8, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v1, v8, v7
    vf.add       v7, v1, v4
    s.movz       s2, #4
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v7, v1, v5
    vf.fms       v7, v1, v8, v1
    vf.neg       v8, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v1
    s.movz       s4, #49152
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #4
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 4
    vf.mul       v8, v1, v9
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v8
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #5
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #5
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #5
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    s.movz       s5, #61440
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #5
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s7, s6, s5                      // row 5
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s5, #6
    v.extract    s9, v8, #0
    @p3 v.st.h       [s8, #0], v7
    a.vread      v6, a1, s4
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #6
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #6
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s4, #73728
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #6
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 6
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #7
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #7
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s5, #86016
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #7
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s7, s6, s5                      // row 7
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s5, #8
    v.extract    s9, v8, #0
    @p3 v.st.h       [s8, #0], v7
    a.vread      v6, a1, s4
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #8
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #8
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s4, #98304
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #8
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 8
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #9
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #9
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #9
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s5, #110592
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #9
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s7, s6, s5                      // row 9
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s5, #10
    v.extract    s9, v8, #0
    @p3 v.st.h       [s8, #0], v7
    a.vread      v6, a1, s4
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #10
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #10
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s4, #122880
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #10
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 10
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #11
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #11
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #11
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s5, #135168
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #11
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s7, s6, s5                      // row 11
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s5, #12
    v.extract    s9, v8, #0
    @p3 v.st.h       [s8, #0], v7
    a.vread      v6, a1, s4
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #12
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #12
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s4, #147456
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #12
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 12
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #13
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #13
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #13
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s5, #159744
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #13
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s7, s6, s5                      // row 13
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s5, #14
    v.extract    s9, v8, #0
    @p3 v.st.h       [s8, #0], v7
    a.vread      v6, a1, s4
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #14
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #14
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s4, #172032
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s8, s3, #14
    v.movi       v6, #1
    v.splat      v7, s8
    s.add        s8, s6, s4                      // row 14
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v7, v9
    @p1 v.sel        v8, v6, v1
    v.movi       v1, #0
    s.movz       s4, #15
    v.extract    s9, v8, #0
    @p3 v.st.h       [s7, #0], v7
    a.vread      v6, a1, s5
    a.vread      v7, a1, s1
    a.vread      v8, a0, s2
    v.splat      v9, s9
    vf.neg       v10, v7
    vf.cvt.f32.bf16 v7, v8
    v.cmp.ne     p1, v9, v1
    p.and        p3, p1, p2
    s.movz       s1, #15
    vf.mul       v1, v10, v2
    vf.cvt.bf16.f32 v8, v7
    v.exp2.approx v7, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v2, v1                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v9, v3
    vf.fma       v9, v7, v1, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v7
    vf.add       v7, v1, v4
    s.movz       s2, #15
    v.rcp.approx v1, v7                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v7, v1, v5
    vf.fms       v7, v1, v9, v1
    vf.neg       v9, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v1
    .li       s5, #184320
    vf.mul       v1, v6, v7                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s7, s3, #15
    v.movi       v6, #1
    v.splat      v7, s7
    s.add        s3, s6, s5                      // row 15
    vf.mul       v9, v1, v8
    v.movi       v1, #0
    v.cmp.lt     p1, v7, v0
    vf.cvt.f32.bf16 v0, v9
    @p1 v.sel        v7, v6, v1
    v.movi       v1, #0
    v.extract    s5, v7, #0
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a1, s4
    a.vread      v6, a1, s1
    a.vread      v7, a0, s2
    v.splat      v8, s5
    vf.neg       v9, v6
    vf.cvt.f32.bf16 v6, v7
    v.cmp.ne     p1, v8, v1
    p.and        p3, p1, p2
    vf.mul       v1, v9, v2
    vf.cvt.bf16.f32 v7, v6
    v.exp2.approx v6, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v9, v2, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v8, v3
    vf.fma       v2, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v4
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v2, v1, v5
    vf.fms       v2, v1, v3, v1
    vf.neg       v3, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v1
    vf.mul       v1, v0, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v0, v1, v7
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s3, #0], v1
__rctx_next:
    exit
