    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s7, #0
    s.st.d       [s6, #0], s2
    s.movz       s7, #512
    s.st.d       [s6, #8], s7
    s.movz       s7, #1024
    s.st.d       [s6, #16], s7
    s.movz       s7, #2048
    s.st.d       [s6, #48], s7
    s.movz       s7, #2
    s.st.d       [s6, #56], s7
    .li       s7, #68719476737
    s.st.d       [s6, #88], s7
    .li       s7, #8589934592
    s.st.d       [s6, #104], s7
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s6, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    s.movz       s1, #512
    s.st.d       [s6, #8], s1
    s.movz       s1, #1024
    s.st.d       [s6, #16], s1
    s.movz       s1, #2048
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476737
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d1, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s6, #1024
    s.movz       s7, #16
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s8
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s10, s1, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s11, s10, s6
    br.nz        s11, endfor_2
    v.splat      v0, s10
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #1024
    s.movz       s12, #512
    s.movz       s13, #1024
    s.movz       s14, #512
    s.muli       s15, s8, #2048
    s.muli       s16, s8, #2048
    v.add        v6, v0, v3
    v.movi       v0, #0
    v.splat      v3, s11
    v.splat      v7, s8
    v.movi       v8, #0
    v.add        v9, v4, v5
    v.splat      v4, s12
    s.muli       s11, s10, #2
    s.muli       s12, s10, #2
    v.cmp.ge     p1, v6, v0
    v.movi       v0, #0
    v.cmp.lt     p2, v6, v3
    v.splat      v3, s13
    v.splat      v5, s8
    v.cmp.ge     p3, v7, v8
    v.movi       v6, #0
    v.cmp.lt     p4, v7, v4
    v.splat      v4, s14
    v.cmp.ge     p5, v9, v0
    s.add        s13, s2, s15
    p.and        p6, p1, p2
    v.cmp.lt     p1, v9, v3
    p.and        p2, p3, p4
    v.cmp.ge     p3, v5, v6
    s.add        s14, s3, s16
    p.and        p4, p5, p1
    v.cmp.lt     p1, v5, v4
    p.and        p5, p3, p1
    s.add        s15, s13, s11
    p.and        p1, p6, p2
    s.add        s11, s14, s12
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s15, #0]
    v.splat      v3, s10
    v.movi       v4, #1024
    v.add        v5, v3, v2
    v.cmp.lt     p1, v5, v4
    v.movi       v3, #0
    s.add        s12, s10, s7
    s.movz       s13, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s11, #0]
    vf.cvt.f16.f32 v5, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v5, v0
    vf.mul       v0, v4, v4
    vf.add       v4, v1, v0
    @p1 v.sel        v0, v4, v1
    v.mov        v3, v0
    v.mov        v1, v3
    s.mov        s10, s12
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s10, s1, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s11, s10, s6
    br.nz        s11, endfor_4
    v.splat      v0, s10
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #1024
    s.movz       s12, #512
    s.movz       s13, #1024
    s.movz       s14, #512
    s.muli       s15, s8, #2048
    s.muli       s16, s8, #2048
    v.add        v6, v0, v1
    v.movi       v0, #0
    v.splat      v1, s11
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s12
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s13
    s.muli       s11, s10, #2
    s.muli       s12, s10, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s8
    v.cmp.lt     p2, v6, v1
    v.movi       v1, #0
    v.splat      v6, s14
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s13, s2, s15
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v0, v1
    s.add        s14, s3, s16
    p.and        p4, p5, p1
    v.cmp.lt     p1, v0, v6
    p.and        p5, p3, p1
    s.add        s15, s13, s11
    p.and        p1, p6, p2
    s.add        s11, s14, s12
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s15, #0]
    v.splat      v1, s10
    v.movi       v4, #1024
    v.add        v5, v1, v2
    s.shli       s12, s10, #1                    // element offset -> bytes (x2)
    v.cmp.lt     p1, v5, v4
    .li       s13, #1149239296
    v.splat      v1, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #1065353216
    v.splat      v4, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #925353388
    v.splat      v6, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v7, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s13, #1077936128
    v.splat      v8, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #3204448256
    v.splat      v9, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s11, #0]
    s.add        s11, s4, s12                    // &in_ptr2[...]
    vf.cvt.f16.f32 v11, v0
    s.mul        s12, s8, s6
    s.add        s13, s10, s7
    s.movz       s14, #1
    s.add        s15, s10, s12
    v.splat      v0, s12
    s.shli       s12, s15, #1                    // element offset -> bytes (x2)
    s.add        s15, s5, s12                    // &out_ptr1[...]
    v.add        v12, v5, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s11, #0]
    vf.cvt.f16.f32 v5, v10
    vf.add       v10, v11, v5
    vf.fms       v5, v1, v7, v4
    vf.cvt.f16.f32 v1, v0
    vf.fms       v0, v7, v5, v7
    vf.neg       v4, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v0, v4, v7
    vf.mul       v4, v3, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v4, v6
    v.rsqrt.approx v4, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v6, v4, v9
    vf.fms       v7, v0, v5, v8
    vf.mul       v0, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v5, v0, v4
    v.extract    s11, v5, #0
    v.splat      v0, s11
    vf.mul       v4, v10, v0
    vf.mul       v0, v4, v1
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s15, #0], v1
    s.mov        s10, s13
    br.nz        s14, for_3
endfor_4:
__rctx_next:
    s.addi       s10, s8, #2                     // the next program of this context: + 2
    s.cmp.lt     s11, s10, s9
    s.mov        s8, s10
    br.nz        s11, __rctx_program
    exit
