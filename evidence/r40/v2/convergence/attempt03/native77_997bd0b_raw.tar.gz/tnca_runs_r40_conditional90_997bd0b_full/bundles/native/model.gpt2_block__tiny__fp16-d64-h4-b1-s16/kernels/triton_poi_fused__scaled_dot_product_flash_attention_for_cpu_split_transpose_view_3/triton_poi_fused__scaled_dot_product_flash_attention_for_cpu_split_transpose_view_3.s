    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s5, pid.y
    s.shli       s6, s4, #4                      // x16 as a shift
    s.shli       s4, s5, #4                      // x16 as a shift
    s.rdspecial  s5, role_id
    s.movz       s7, #2560
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    s.mul        s8, s5, s7
    s.muli       s5, s6, #384
    v.add        v2, v0, v1
    s.ld.d       s7, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v0, #0
    v.splat      v1, s6
    v.movi       v3, #0
    s.muli       s2, s4, #2
    s.addi       s9, s3, #128
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #64
    v.cmp.ge     p3, v1, v3
    v.cmpi.lt    p4, v1, #16
    s.add        s3, s9, s5
    s.add        s5, s7, s8                      // this context's own scratch
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.movz       s7, #16
    s.addi       s8, s5, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #64
    s.movz       s11, #384
    s.movz       s12, #2
    s.add        s13, s3, s2
    .li       s2, #68719476752
    p.and        p2, p5, p1
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #0
    s.st.d       [s8, #0], s9
    .li       s1, #8589934592
    s.st.d       [s8, #8], s7
    s.addi       s7, s6, #1
    v.movi       v1, #0
    v.splat      v2, s7
    s.movz       s7, #1
    s.muli       s9, s7, #384
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p3, v2, #16
    p.and        p4, p1, p3
    s.st.d       [s8, #16], s10
    s.addi       s7, s5, #256
    p.and        p1, p5, p4
    s.add        s10, s13, s9
    s.st.d       [s8, #48], s11
    s.addi       s9, s6, #2
    v.splat      v0, s9
    s.addi       s9, s7, #64
    v.cmp.ge     p3, v0, v1
    s.st.d       [s8, #56], s12
    s.movz       s11, #2
    s.muli       s12, s11, #384
    s.st.d       [s8, #88], s2
    s.add        s2, s13, s12
    s.addi       s11, s7, #128
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s6, #3
    s.movz       s8, #3
    v.splat      v1, s1
    v.movi       v2, #0
    s.muli       s1, s8, #384
    s.addi       s8, s6, #4
    v.movi       v3, #0
    v.splat      v4, s8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s13, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p4, p3, p2
    v.cmp.ge     p2, v1, v2
    p.and        p3, p5, p4
    s.add        s8, s13, s1
    s.addi       s1, s7, #192
    v.st.w       [s7, #0], v5
    v.movi       v0, #0
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s10, #0]
    v.cmpi.lt    p1, v1, #16
    p.and        p4, p2, p1
    s.movz       s10, #4
    p.and        p1, p5, p4
    s.muli       s12, s10, #384
    v.cmp.ge     p2, v4, v3
    s.add        s10, s13, s12
    v.st.w       [s9, #0], v2
    s.addi       s9, s6, #5
    v.movi       v1, #0
    v.splat      v2, s9
    s.movz       s9, #5
    s.muli       s12, s9, #384
    s.add        s9, s13, s12
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s2, #0]
    v.cmpi.lt    p3, v4, #16
    p.and        p4, p2, p3
    v.cmp.ge     p2, v2, v0
    p.and        p3, p5, p4
    s.addi       s2, s7, #256
    v.st.w       [s11, #0], v3
    s.addi       s11, s6, #6
    v.movi       v0, #0
    v.splat      v3, s11
    s.movz       s11, #6
    s.muli       s12, s11, #384
    s.add        s11, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s8, #0]
    v.cmpi.lt    p1, v2, #16
    p.and        p4, p2, p1
    v.cmp.ge     p1, v3, v1
    p.and        p2, p5, p4
    s.addi       s8, s7, #320
    v.st.w       [s1, #0], v4
    s.addi       s1, s6, #7
    v.movi       v1, #0
    v.splat      v2, s1
    s.movz       s1, #7
    s.muli       s12, s1, #384
    s.add        s1, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s10, #0]
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v0
    p.and        p3, p5, p4
    s.addi       s10, s7, #384
    v.st.w       [s2, #0], v4
    s.addi       s2, s6, #8
    v.movi       v0, #0
    v.splat      v3, s2
    s.movz       s2, #8
    s.muli       s12, s2, #384
    s.add        s2, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s9, #0]
    v.cmpi.lt    p2, v2, #16
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v1
    p.and        p2, p5, p4
    s.addi       s9, s7, #448
    v.st.w       [s8, #0], v4
    s.addi       s8, s6, #9
    v.movi       v1, #0
    v.splat      v2, s8
    s.movz       s8, #9
    s.muli       s12, s8, #384
    s.add        s8, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s11, #0]
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v0
    p.and        p3, p5, p4
    s.addi       s11, s7, #512
    v.st.w       [s10, #0], v4
    s.addi       s10, s6, #10
    v.movi       v0, #0
    v.splat      v3, s10
    s.movz       s10, #10
    s.muli       s12, s10, #384
    s.add        s10, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s1, #0]
    v.cmpi.lt    p2, v2, #16
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v1
    p.and        p2, p5, p4
    s.addi       s1, s7, #576
    v.st.w       [s9, #0], v4
    s.addi       s9, s6, #11
    v.movi       v1, #0
    v.splat      v2, s9
    s.movz       s9, #11
    s.muli       s12, s9, #384
    s.add        s9, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s2, #0]
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v0
    p.and        p3, p5, p4
    s.addi       s2, s7, #640
    v.st.w       [s11, #0], v4
    s.addi       s11, s6, #12
    v.movi       v0, #0
    v.splat      v3, s11
    s.movz       s11, #12
    s.muli       s12, s11, #384
    s.add        s11, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s8, #0]
    v.cmpi.lt    p2, v2, #16
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v1
    p.and        p2, p5, p4
    s.addi       s8, s7, #704
    v.st.w       [s1, #0], v4
    s.addi       s1, s6, #13
    v.movi       v1, #0
    v.splat      v2, s1
    s.movz       s1, #13
    s.muli       s12, s1, #384
    s.add        s1, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s10, #0]
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v0
    p.and        p3, p5, p4
    s.addi       s10, s7, #768
    v.st.w       [s2, #0], v4
    s.addi       s2, s6, #14
    v.movi       v0, #0
    v.splat      v3, s2
    s.movz       s2, #14
    s.muli       s12, s2, #384
    s.add        s2, s13, s12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s9, #0]
    v.cmpi.lt    p2, v2, #16
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v1
    p.and        p2, p5, p4
    s.addi       s9, s7, #832
    v.st.w       [s8, #0], v4
    s.addi       s8, s6, #15
    v.splat      v1, s8
    s.movz       s8, #15
    s.muli       s12, s8, #384
    s.add        s8, s13, s12
    s.addi       s12, s7, #896
    s.addi       s13, s7, #960
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s11, #0]
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p1, p3
    v.cmp.ge     p1, v1, v0
    p.and        p3, p5, p4
    // tile epilogue: 16 rows through the vector unit, as f16 (ISA sec 9B)
    s.addi       s7, s5, #256
    v.st.w       [s10, #0], v2
    s.addi       s10, s5, #1280                  // 512 bytes of repack scratch
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v0, [s1, #0]
    v.cmpi.lt    p2, v1, #16
    p.and        p4, p1, p2
    s.addi       s1, s5, #320
    p.and        p1, p5, p4
    v.st.w       [s9, #0], v0
    s.movz       s9, #1
    s.muli       s11, s9, #32
    s.add        s9, s10, s11
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    s.addi       s2, s5, #384
    v.st.w       [s12, #0], v0
    s.movz       s11, #2
    s.muli       s12, s11, #32
    s.add        s11, s10, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s8, #0]
    s.addi       s8, s5, #448
    v.st.w       [s13, #0], v0
    fence.acq_rel.device
    s.movz       s12, #3
    s.muli       s13, s12, #32
    s.add        s12, s10, s13
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s5, #512
    v.st.h       [s10, #0], v0
    v.ld.w       v0, [s1, #0]
    s.movz       s1, #4
    s.muli       s13, s1, #32
    s.add        s1, s10, s13
    v.st.h       [s9, #0], v0
    s.addi       s9, s5, #576
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #5
    s.muli       s13, s2, #32
    s.add        s2, s10, s13
    v.st.h       [s11, #0], v0
    s.addi       s11, s5, #640
    v.ld.w       v0, [s8, #0]
    s.movz       s8, #6
    s.muli       s13, s8, #32
    s.add        s8, s10, s13
    v.st.h       [s12, #0], v0
    s.addi       s12, s5, #704
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #7
    s.muli       s13, s7, #32
    s.add        s7, s10, s13
    v.st.h       [s1, #0], v0
    s.addi       s1, s5, #768
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #8
    s.muli       s13, s9, #32
    s.add        s9, s10, s13
    v.st.h       [s2, #0], v0
    s.addi       s2, s5, #832
    v.ld.w       v0, [s11, #0]
    s.movz       s11, #9
    s.muli       s13, s11, #32
    s.add        s11, s10, s13
    v.st.h       [s8, #0], v0
    s.addi       s8, s5, #896
    v.ld.w       v0, [s12, #0]
    s.movz       s12, #10
    s.muli       s13, s12, #32
    s.add        s12, s10, s13
    v.st.h       [s7, #0], v0
    s.addi       s7, s5, #960
    v.ld.w       v0, [s1, #0]
    s.movz       s1, #11
    s.muli       s13, s1, #32
    s.add        s1, s10, s13
    v.st.h       [s9, #0], v0
    s.addi       s9, s5, #1024
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #12
    // tl.trans: 16 columns, gathered %c336:scalar elements apart (ISA sec 9.1)
    v.iota       v1                              // arange(0, VLEN)
    s.muli       s13, s2, #32
    s.add        s2, s10, s13
    v.st.h       [s11, #0], v0
    s.addi       s11, s5, #1088
    v.ld.w       v0, [s8, #0]
    s.movz       s8, #13
    s.muli       s13, s8, #32
    s.add        s8, s10, s13
    v.st.h       [s12, #0], v0
    s.addi       s12, s5, #1152
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #14
    s.muli       s13, s7, #32
    s.add        s7, s10, s13
    v.st.h       [s1, #0], v0
    s.addi       s1, s5, #1216
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #0
    s.muli       s13, s9, #32
    s.add        s9, s10, s13
    v.st.h       [s2, #0], v0
    s.movz       s2, #0
    s.muli       s13, s2, #2
    s.add        s2, s9, s13
    s.movz       s9, #15
    s.muli       s13, s9, #32
    v.ld.w       v0, [s11, #0]
    s.movz       s9, #16
    s.add        s11, s10, s13
    v.splat      v2, s9
    s.addi       s9, s2, #2                      // column 1
    s.addi       s10, s2, #4                     // column 2
    v.mul        v3, v1, v2                      // one element per source row
    v.st.h       [s8, #0], v0
    s.addi       s8, s2, #6                      // column 3
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s2, #8                     // column 4
    v.st.h       [s7, #0], v0
    s.addi       s7, s2, #10                     // column 5
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s2, #12                     // column 6
    v.st.h       [s11, #0], v0
    s.addi       s11, s2, #14                    // column 7
    fence.acq_rel.device
    v.ld.gather.h v0, [s2, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.h v1, [s9, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s2, #16                     // column 8
    v.ld.gather.h v2, [s10, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s10, s2, #18                    // column 9
    v.ld.gather.h v4, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s8, s2, #20                     // column 10
    v.ld.gather.h v5, [s12, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s12, s2, #22                    // column 11
    v.ld.gather.h v6, [s7, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s2, #24                     // column 12
    v.ld.gather.h v7, [s1, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s1, s2, #26                     // column 13
    v.ld.gather.h v8, [s11, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #28                    // column 14
    s.addi       s13, s2, #30                    // column 15
    v.ld.gather.h v9, [s9, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s2, s5, #1792                   // 512 bytes of repack scratch
    s.addi       s9, s5, #2304                   // TensorMap 1: a repacked tile
    v.ld.gather.h v10, [s10, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s5, s2, #32                     // row 1
    v.ld.gather.h v11, [s8, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s8, s2, #64                     // row 2
    v.ld.gather.h v12, [s12, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s10, s2, #96                    // row 3
    v.ld.gather.h v13, [s7, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s7, s2, #128                    // row 4
    v.ld.gather.h v14, [s1, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s1, s2, #160                    // row 5
    v.ld.gather.h v15, [s11, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #192                   // row 6
    v.ld.gather.h v16, [s13, v3]                 // index is in elements (ISA sec 9.1)
    s.movz       s12, #0
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s2, #0], v0
    v.st.h       [s5, #0], v1
    s.addi       s5, s2, #224                    // row 7
    v.st.h       [s8, #0], v2
    s.muli       s8, s12, #32
    s.add        s13, s2, s8
    v.st.h       [s10, #0], v4
    s.muli       s8, s12, #2
    s.add        s10, s13, s8
    s.addi       s8, s2, #256                    // row 8
    v.st.h       [s7, #0], v5
    s.addi       s7, s2, #288                    // row 9
    .li       s13, #1056964608
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.h       [s1, #0], v6
    s.addi       s1, s2, #320                    // row 10
    v.st.h       [s11, #0], v7
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s11, #0
    v.st.h       [s5, #0], v8
    s.muli       s5, s11, #32
    s.addi       s11, s2, #352                   // row 11
    s.add        s13, s10, s5
    v.st.h       [s8, #0], v9
    s.addi       s5, s2, #384                    // row 12
    v.st.h       [s7, #0], v10
    s.addi       s7, s2, #416                    // row 13
    v.st.h       [s1, #0], v11
    s.addi       s1, s2, #448                    // row 14
    v.iota       v1                              // arange(0, VLEN)
    v.st.h       [s11, #0], v12
    s.addi       s8, s2, #480                    // row 15
    v.st.h       [s5, #0], v13
    s.movz       s5, #16
    v.st.h       [s7, #0], v14
    s.movz       s7, #16
    v.st.h       [s1, #0], v15
    s.movz       s1, #32
    v.st.h       [s8, #0], v16
    s.movz       s8, #2
    s.st.d       [s9, #0], s2
    .li       s2, #68719476752
    s.st.d       [s9, #8], s5
    .li       s5, #8589934592
    s.st.d       [s9, #16], s7
    s.movz       s7, #0
    s.add        s11, s7, s6                     // the tile origin
    s.muli       s7, s6, #4                      // a runtime tile origin, x4
    v.splat      v2, s11
    s.movz       s6, #0
    s.add        s11, s6, s4                     // the tile origin
    s.muli       s6, s4, #64                     // a runtime tile origin, x64
    v.add        v3, v1, v2
    s.st.d       [s9, #48], s1
    s.movz       s1, #1
    v.splat      v1, s11
    s.muli       s4, s1, #32
    s.add        s1, s3, s7                      // the tile origin
    v.cmpi.lt    p1, v3, #16
    v.cmpi.lt    p2, v1, #64
    s.add        s3, s1, s6                      // the tile origin
    p.and        p3, p1, p2
    s.add        s1, s10, s4
    s.addi       s4, s11, #1
    s.st.d       [s9, #56], s8
    v.splat      v1, s4
    s.addi       s4, s3, #64                     // row 1
    v.cmpi.lt    p2, v1, #64
    p.and        p4, p1, p2
    s.st.d       [s9, #88], s2
    s.movz       s2, #2
    s.st.d       [s9, #104], s5
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s5, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.muli       s6, s2, #32
    s.addi       s2, s3, #128                    // row 2
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s7, s12                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s8, s12                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d1, s7, s5
    mb.wait      s5
    s.movz       s7, #3
    s.add        s8, s10, s6
    v.ld.h       v1, [s13, #0]
    s.addi       s6, s11, #2
    s.muli       s9, s7, #32
    v.splat      v2, s6
    s.addi       s6, s11, #3
    s.addi       s7, s3, #192                    // row 3
    v.cmpi.lt    p2, v2, #64
    p.and        p5, p1, p2
    s.add        s12, s10, s9
    v.splat      v2, s6
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.movz       s6, #4
    s.addi       s9, s11, #4
    s.muli       s13, s6, #32
    v.splat      v3, s9
    @p3 v.st.w       [s3, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p3, p1, p2
    s.add        s6, s10, s13
    s.movz       s9, #5
    s.addi       s13, s3, #256                   // row 4
    s.muli       s14, s9, #32
    s.add        s9, s10, s14
    v.ld.h       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s11, #5
    v.splat      v2, s1
    s.addi       s1, s3, #320                    // row 5
    @p4 v.st.w       [s4, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p4, p1, p2
    s.movz       s4, #6
    s.muli       s14, s4, #32
    s.add        s4, s10, s14
    v.ld.h       v1, [s8, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s8, s11, #6
    v.splat      v3, s8
    s.addi       s8, s3, #384                    // row 6
    @p5 v.st.w       [s2, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p5, p1, p2
    s.movz       s2, #7
    s.muli       s14, s2, #32
    s.add        s2, s10, s14
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s12, s11, #7
    v.splat      v2, s12
    s.addi       s12, s3, #448                   // row 7
    @p3 v.st.w       [s7, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.muli       s14, s7, #32
    s.add        s7, s10, s14
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s6, s11, #8
    v.splat      v3, s6
    s.addi       s6, s3, #512                    // row 8
    @p4 v.st.w       [s13, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p4, p1, p2
    s.movz       s13, #9
    s.muli       s14, s13, #32
    s.add        s13, s10, s14
    v.ld.h       v1, [s9, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s9, s11, #9
    v.splat      v2, s9
    s.addi       s9, s3, #576                    // row 9
    @p5 v.st.w       [s1, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p5, p1, p2
    s.movz       s1, #10
    s.muli       s14, s1, #32
    s.add        s1, s10, s14
    v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s4, s11, #10
    v.splat      v3, s4
    s.addi       s4, s3, #640                    // row 10
    @p3 v.st.w       [s8, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p3, p1, p2
    s.movz       s8, #11
    s.muli       s14, s8, #32
    s.add        s8, s10, s14
    v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s2, s11, #11
    v.splat      v2, s2
    s.addi       s2, s3, #704                    // row 11
    @p4 v.st.w       [s12, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p4, p1, p2
    s.movz       s12, #12
    s.muli       s14, s12, #32
    s.add        s12, s10, s14
    v.ld.h       v1, [s7, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s7, s11, #12
    v.splat      v3, s7
    s.addi       s7, s3, #768                    // row 12
    @p5 v.st.w       [s6, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p5, p1, p2
    s.movz       s6, #13
    s.muli       s14, s6, #32
    s.add        s6, s10, s14
    v.ld.h       v1, [s13, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s13, s11, #13
    v.splat      v2, s13
    s.addi       s13, s3, #832                   // row 13
    @p3 v.st.w       [s9, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p3, p1, p2
    s.movz       s9, #14
    s.muli       s14, s9, #32
    s.add        s9, s10, s14
    v.ld.h       v1, [s1, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s1, s11, #14
    v.splat      v3, s1
    s.addi       s1, s3, #896                    // row 14
    @p4 v.st.w       [s4, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p4, p1, p2
    s.movz       s4, #15
    s.muli       s14, s4, #32
    s.add        s4, s10, s14
    v.ld.h       v1, [s8, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s8, s11, #15
    s.addi       s10, s3, #960                   // row 15
    v.splat      v2, s8
    @p5 v.st.w       [s2, #0], v1
    v.cmpi.lt    p2, v3, #64
    p.and        p5, p1, p2
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    @p3 v.st.w       [s7, #0], v1
    v.cmpi.lt    p2, v2, #64
    p.and        p3, p1, p2
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p4 v.st.w       [s13, #0], v1
    v.ld.h       v1, [s9, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p5 v.st.w       [s1, #0], v1
    v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p3 v.st.w       [s10, #0], v1
__rctx_next:
    exit
