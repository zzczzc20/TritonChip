    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    s.movz       s1, #64
    s.st.d       [s8, #8], s1
    s.movz       s1, #160
    s.st.d       [s8, #16], s1
    s.movz       s1, #320
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #8589934592
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #160
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    s.mul        s11, s4, s8
    v.splat      v3, s10
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s12, #160
    s.movz       s13, #64
    s.muli       s14, s4, #320
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s12
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s13
    v.splat      v9, s10
    s.muli       s12, s10, #2
    s.add        s13, s10, s11
    v.cmp.ge     p1, v5, v3
    v.cmp.lt     p2, v5, v4
    v.cmp.ge     p3, v6, v7
    v.cmp.lt     p4, v6, v8
    v.add        v3, v9, v0
    v.movi       v4, #160
    s.shli       s15, s13, #1                    // element offset -> bytes (x2)
    s.add        s13, s3, s14
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s14, s2, s15                    // &in_ptr0[...]
    s.add        s15, s13, s12
    p.and        p2, p5, p1
    v.cmp.lt     p1, v3, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    v.movi       v5, #0
    v.splat      v6, s11
    s.add        s11, s10, s9
    s.movz       s12, #1
    v.add        v7, v3, v6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s15, #0]
    vf.cvt.f16.f32 v6, v4
    vf.cvt.f16.f32 v4, v3
    vf.add       v3, v6, v4
    vf.add       v4, v2, v3
    @p1 v.sel        v3, v4, v2
    v.mov        v5, v3
    v.mov        v2, v5
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    .li       s10, #1126170624
    v.splat      v3, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1065353216
    v.splat      v4, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v5, v2
    v.rcp.approx v2, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0
    v.movi       v7, #0
    s.addi       s10, s1, #0
    vf.add       v8, v5, v6
    v.mov        v7, v1
    vf.fms       v1, v3, v2, v4
    vf.fms       v5, v2, v1, v2
    vf.neg       v1, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v5, v1, v2
    vf.mul       v1, v8, v5                      // a/y as a refined reciprocal (ISA has no divide)
for_3:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_4
    s.mul        s11, s4, s8
    v.splat      v2, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #160
    s.movz       s13, #64
    s.muli       s14, s4, #320
    v.add        v8, v2, v5
    v.movi       v2, #0
    v.splat      v5, s12
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s13
    v.splat      v12, s10
    s.muli       s12, s10, #2
    s.add        s13, s10, s11
    v.cmp.ge     p1, v8, v2
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.add        v2, v12, v0
    v.movi       v5, #160
    s.shli       s15, s13, #1                    // element offset -> bytes (x2)
    s.add        s13, s3, s14
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s14, s2, s15                    // &in_ptr0[...]
    s.add        s15, s13, s12
    p.and        p2, p5, p1
    v.cmp.lt     p1, v2, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s14, #0]
    v.extract    s12, v1, #0
    v.movi       v8, #0
    v.splat      v9, s12
    v.splat      v10, s11
    s.add        s11, s10, s9
    s.movz       s12, #1
    v.add        v11, v2, v10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s15, #0]
    vf.cvt.f16.f32 v10, v5
    vf.cvt.f16.f32 v5, v2
    vf.add       v2, v10, v5
    vf.sub       v5, v2, v9
    vf.mul       v2, v5, v5
    vf.add       v5, v7, v2
    @p1 v.sel        v2, v5, v7
    v.mov        v8, v2
    v.mov        v7, v8
    s.mov        s10, s11
    br.nz        s12, for_3
endfor_4:
    vf.reduce.add.b v2, v7
    s.addi       s10, s1, #0
    vf.add       v5, v2, v6
for_5:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_6
    v.rcp.approx v2, v3                          // ISA 8.8: <= 2**-22 relative
    s.mul        s1, s4, s8
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s11, #160
    s.movz       s12, #64
    s.muli       s13, s4, #320
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s11
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s12
    s.muli       s11, s10, #2
    s.add        s12, s10, s1
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s10
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.add        v7, v6, v0
    v.movi       v6, #160
    s.shli       s14, s12, #1                    // element offset -> bytes (x2)
    s.add        s12, s3, s13
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s13, s2, s14                    // &in_ptr0[...]
    s.add        s15, s12, s11
    vf.fms       v8, v3, v2, v4
    p.and        p2, p5, p1
    v.cmp.lt     p1, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s13, #0]
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    vf.fms       v9, v2, v8, v2
    s.add        s12, s5, s11                    // &in_ptr2[...]
    s.add        s13, s6, s11                    // &in_ptr3[...]
    v.extract    s11, v1, #0
    v.splat      v8, s1
    vf.neg       v10, v9                         // Newton step: r0*(2 - x*r0)
    .li       s1, #925353388
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v11, s11
    v.add        v12, v7, v8
    .li       s1, #1077936128
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s15, #0]
    vf.cvt.f16.f32 v10, v6
    vf.mul       v6, v5, v8                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s1, #3204448256
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s7, s14                     // &out_ptr1[...]
    s.add        s11, s10, s9
    s.movz       s14, #1
    vf.add       v12, v6, v9
    v.rsqrt.approx v6, v12                       // ISA 8.8: <= 2**-22 relative
    vf.cvt.f16.f32 v9, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s12, #0]
    vf.add       v13, v10, v9
    vf.sub       v9, v13, v11
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s13, #0]
    vf.cvt.f16.f32 v11, v2
    vf.mul       v2, v6, v6
    vf.mul       v13, v6, v8
    vf.cvt.f16.f32 v8, v10
    vf.fms       v10, v12, v2, v7
    vf.mul       v2, v13, v10                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v7, v2, v6
    v.extract    s12, v7, #0
    v.splat      v2, s12
    vf.mul       v6, v9, v2
    vf.mul       v2, v6, v11
    vf.add       v6, v2, v8
    vf.cvt.f32.f16 v2, v6
    @p1 v.st.h       [s1, #0], v2
    s.mov        s10, s11
    br.nz        s14, for_5
endfor_6:
__rctx_next:
    exit
