    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #32
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #5
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #32
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s6, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s6, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #5
    s.movz       s15, #0
    s.muli       s16, s3, #32
    s.movz       s3, #0
    s.sub        s17, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.sub        s15, s14, s16
    s.xor        s14, s12, s17
    s.xor        s12, s15, s13
    s.xor        s15, s6, s8
    s.sub        s6, s12, s13
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s6, s5
    s.sub        s5, s14, s17
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s6, s9
    s.movz       s6, #1
    s.sub        s13, s15, s8
    s.xor        s8, s1, s12
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.addi       s15, s3, #0
    s.cmp.eq     s3, s5, s6
    s.add        s6, s10, s13
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s15, s14
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s15, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s14, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s13, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s13, s5
    s.shl        s16, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s18, s16, s10
    s.sub        s10, s13, s12
    s.or         s12, s15, s18
    s.mov        s8, s10
    s.mov        s15, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s3, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s9, s17
    s.mul        s9, s6, s3
    s.mul        s10, s4, s5
    s.xor        s4, s15, s8
    s.rdspecial  s5, pid.y
    s.sub        s12, s4, s8
    s.andi       s4, s9, #511
    s.mul        s8, s12, s3
    s.add        s13, s5, s10
    s.movz       s5, #31
    s.movz       s10, #32768
    s.min.s      s14, s13, s5
    s.muli       s5, s4, #64                     // a runtime tile origin, x64
    s.mul        s15, s14, s10
    s.rdspecial  s10, role_id
    s.movz       s14, #6144
    s.andi       s16, s8, #511
    s.movz       s17, #0
    s.rdspecial  s18, arg_base
    s.mul        s19, s10, s14
    s.add        s10, s17, s5                    // the tile origin
    s.ld.d       s5, [s18, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s14, s10, s15                   // the tile origin
    s.movz       s10, #0
    s.add        s17, s5, s19                    // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s5, s17, #0
    v.splat      v1, s14
    v.splat      v2, s6
    v.splat      v3, s10
    s.addi       s6, s14, #64
    v.splat      v4, s12
    v.splat      v5, s10
    v.add        v6, v0, v1
    s.addi       s12, s5, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v1
    v.cmp.ge     p1, v4, v5
    s.addi       s6, s14, #128
    v.splat      v1, s9
    v.splat      v4, s6
    s.addi       s6, s5, #128
    v.add        v5, v0, v4
    v.add        v4, v1, v2
    s.addi       s18, s14, #192
    v.splat      v1, s8
    s.addi       s19, s5, #192
    v.add        v4, v1, v2
    v.splat      v1, s18
    v.splat      v2, s4
    v.add        v4, v0, v1
    s.addi       s4, s5, #256
    s.movz       s18, #64
    s.addi       s20, s10, #0
    v.st.w       [s5, #0], v6
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s10, s14, #256
    v.add        v6, v2, v1
    v.splat      v1, s10
    v.splat      v2, s16
    v.add        v6, v0, v1
    v.st.w       [s12, #0], v3
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s10, s5, #320
    v.add        v3, v2, v1
    s.addi       s12, s14, #320
    s.addi       s21, s14, #384
    v.splat      v1, s12
    s.addi       s12, s14, #448
    v.splat      v2, s21
    s.addi       s21, s14, #512
    v.add        v3, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s6, #0], v5
    s.addi       s6, s14, #576
    v.splat      v2, s12
    s.addi       s12, s14, #640
    v.add        v5, v0, v2
    v.st.w       [s19, #0], v4
    s.addi       s19, s14, #704
    v.splat      v2, s21
    s.addi       s21, s14, #768
    v.add        v4, v0, v2
    v.st.w       [s4, #0], v6
    s.addi       s4, s14, #832
    v.splat      v2, s6
    s.addi       s6, s14, #896
    s.addi       s22, s14, #960
    v.add        v6, v0, v2
    v.st.w       [s10, #0], v3
    v.splat      v2, s12
    s.addi       s10, s5, #384
    s.addi       s12, s17, #1024
    v.add        v3, v0, v2
    v.st.w       [s10, #0], v1
    s.movz       s10, #0
    v.splat      v1, s19
    s.addi       s14, s5, #448
    s.add        s19, s10, s16                   // the tile origin
    s.addi       s10, s5, #512
    s.add        s16, s19, s15                   // the tile origin
    s.addi       s15, s5, #576
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s16, #512
    v.splat      v1, s21
    s.addi       s19, s5, #640
    v.add        v5, v0, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s16, #1024
    v.splat      v1, s4
    s.addi       s4, s5, #704
    v.add        v4, v0, v1
    v.st.w       [s15, #0], v6
    s.addi       s15, s16, #1536
    v.splat      v1, s6
    s.addi       s6, s5, #768
    v.add        v6, v0, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s16, #2048
    v.splat      v1, s22
    s.addi       s21, s5, #832
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s16, #2560
    v.splat      v1, s16
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    s.addi       s6, s16, #3072
    v.splat      v1, s14
    s.addi       s14, s5, #896
    s.addi       s22, s5, #960
    v.add        v5, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s5, s16, #3584
    v.splat      v1, s10
    s.addi       s10, s12, #64
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v6
    s.addi       s14, s16, #4096
    v.splat      v1, s15
    s.addi       s15, s12, #128
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v3
    v.splat      v1, s19
    s.addi       s19, s12, #192
    s.addi       s21, s12, #256
    v.add        v3, v0, v1
    fence.acq_rel.device
    v.st.w       [s12, #0], v2
    v.splat      v1, s4
    s.addi       s4, s16, #4608
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v5
    s.addi       s10, s16, #5120
    v.splat      v1, s6
    s.addi       s6, s16, #5632
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s16, #6144
    v.splat      v1, s5
    s.addi       s5, s16, #6656
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s16, #7168
    v.splat      v1, s14
    s.addi       s14, s12, #320
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s16, #7680
    v.splat      v1, s4
    s.addi       s4, s12, #384
    s.addi       s16, s12, #448
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v2
    v.splat      v1, s10
    s.addi       s10, s12, #512
    s.addi       s14, s12, #576
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v5
    v.splat      v1, s6
    s.addi       s4, s12, #640
    s.addi       s6, s12, #704
    v.add        v5, v0, v1
    v.st.w       [s16, #0], v4
    v.splat      v1, s15
    s.addi       s15, s12, #768
    v.add        v4, v0, v1
    s.addi       s16, s12, #832
    v.st.w       [s10, #0], v6
    v.splat      v1, s5
    s.addi       s5, s12, #896
    v.add        v6, v0, v1
    s.addi       s10, s12, #960
    v.st.w       [s14, #0], v3
    v.splat      v1, s19
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    v.splat      v1, s21
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    v.st.w       [s15, #0], v4
    v.st.w       [s16, #0], v6
    v.st.w       [s5, #0], v3
    v.st.w       [s10, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s20, s18
    br.nz        s4, endfor_6
    s.addi       s4, s17, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #64
    s.movz       s6, #1
    s.addi       s10, s17, #128
    s.movz       s12, #2
    s.addi       s14, s17, #192
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s5, v2
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #3
    s.addi       s5, s17, #256
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s6, #4
    s.addi       s10, s17, #320
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s12, #5
    s.addi       s14, s17, #384
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #6
    s.addi       s5, s17, #448
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s6, #7
    s.addi       s10, s17, #512
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s12, #8
    s.addi       s14, s17, #576
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #9
    s.addi       s5, s17, #640
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s6, #10
    s.addi       s10, s17, #704
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s12, #11
    s.addi       s14, s17, #768
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #12
    s.addi       s5, s17, #832
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s6, #13
    s.addi       s10, s17, #896
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s12, #14
    s.addi       s14, s17, #960
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #15
    s.addi       s5, s17, #1024
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s10, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.addi       s10, s17, #1088
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s12, #1
    s.addi       s14, s17, #1152
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s15, #2
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.addi       s4, s17, #1216
    s.movz       s5, #3
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v2
    v.ld.w       v1, [s10, #0]
    s.addi       s6, s17, #1280
    s.movz       s10, #4
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v2
    v.ld.w       v1, [s14, #0]
    s.addi       s12, s17, #1344
    s.movz       s14, #5
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1408
    s.movz       s15, #6
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s5, v2
    v.ld.w       v1, [s6, #0]
    s.addi       s5, s17, #1472
    s.movz       s6, #7
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v2
    v.ld.w       v1, [s12, #0]
    s.addi       s10, s17, #1536
    s.movz       s12, #8
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1600
    s.movz       s14, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1664
    s.movz       s15, #10
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v3
    v.ld.w       v1, [s10, #0]
    s.addi       s6, s17, #1728
    s.movz       s10, #11
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1792
    s.movz       s12, #12
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1856
    s.movz       s14, #13
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #1920
    s.movz       s15, #14
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v3
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1984
    s.movz       s10, #15
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    s.movz       s12, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    s.movz       s14, #2
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #3
    s.movz       s15, #4
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s16, #5
    a.vwrite     a2, s10, v3
    a.vread      v1, a1, s5
    a.vread      v3, a2, s12
    v.extract    s5, v1, #0
    v.splat      v4, s5
    v.extract    s5, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s5
    a.vread      v4, a2, s6
    v.extract    s5, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s5
    a.vread      v4, a2, s14
    v.extract    s5, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    v.extract    s4, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    v.extract    s4, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s4
    a.vread      v4, a2, s16
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s10, #1
    s.movz       s12, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s4
    a.vread      v3, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s4
    a.vread      v3, a2, s12
    s.movz       s4, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #3
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #4
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #5
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #6
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #7
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #8
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #10
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #11
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #12
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #13
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #14
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v2, a2, s5
    s.addi       s5, s17, #0
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s3
    s.addi       s6, s17, #2048
    s.addi       s10, s17, #64
    a.vwrite     a3, s4, v3
    v.ld.w       v2, [s5, #0]
    s.addi       s4, s6, #64
    s.addi       s5, s17, #128
    s.addi       s12, s6, #128
    s.addi       s14, s17, #192
    s.addi       s15, s6, #192
    s.addi       s16, s17, #256
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s6, #256
    v.add        v3, v2, v1
    v.st.w       [s4, #0], v3
    s.addi       s4, s17, #320
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #320
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s17, #384
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s6, #384
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s17, #448
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s6, #448
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s17, #512
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s6, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s17, #576
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s6, #576
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s17, #640
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s6, #640
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s17, #704
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s6, #704
    v.add        v3, v2, v1
    v.st.w       [s4, #0], v3
    s.addi       s4, s17, #768
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #768
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s17, #832
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s6, #832
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s17, #896
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s6, #896
    s.addi       s19, s6, #960
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s6, s17, #960
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s17, #1024
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.movz       s5, #8192
    v.splat      v2, s5
    s.addi       s5, s17, #3072
    v.ld.w       v3, [s12, #0]
    s.addi       s10, s17, #1088
    v.add        v4, v3, v1
    v.st.w       [s14, #0], v4
    s.addi       s12, s5, #64
    v.ld.w       v3, [s15, #0]
    s.addi       s14, s17, #1152
    v.add        v4, v3, v1
    v.st.w       [s16, #0], v4
    s.addi       s15, s5, #128
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s17, #1216
    v.add        v4, v3, v1
    v.st.w       [s19, #0], v4
    fence.acq_rel.device
    s.addi       s16, s5, #192
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1280
    v.add        v3, v1, v2
    v.st.w       [s5, #0], v3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s5, #256
    v.add        v3, v1, v2
    v.st.w       [s12, #0], v3
    s.addi       s12, s17, #1344
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s5, #320
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s17, #1408
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s5, #384
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s17, #1472
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s5, #448
    v.add        v3, v1, v2
    v.st.w       [s10, #0], v3
    s.addi       s10, s17, #1536
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s5, #512
    v.add        v3, v1, v2
    v.st.w       [s14, #0], v3
    s.addi       s14, s17, #1600
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s5, #576
    v.add        v3, v1, v2
    v.st.w       [s6, #0], v3
    s.addi       s6, s17, #1664
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #640
    v.add        v3, v1, v2
    v.st.w       [s4, #0], v3
    s.addi       s4, s17, #1728
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s5, #704
    v.add        v3, v1, v2
    v.st.w       [s12, #0], v3
    s.addi       s12, s17, #1792
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s5, #768
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s17, #1856
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s5, #832
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s17, #1920
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s5, #896
    s.addi       s19, s5, #960
    v.add        v3, v1, v2
    v.st.w       [s10, #0], v3
    s.addi       s5, s17, #1984
    v.ld.w       v1, [s12, #0]
    s.addi       s10, s17, #2048
    v.add        v3, v1, v2
    v.st.w       [s14, #0], v3
    s.addi       s12, s17, #4096
    v.ld.w       v1, [s15, #0]
    s.addi       s14, s17, #2112
    v.add        v3, v1, v2
    v.st.w       [s6, #0], v3
    s.addi       s6, s12, #64
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s17, #2176
    v.add        v3, v1, v2
    v.st.w       [s4, #0], v3
    s.addi       s4, s12, #128
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #2240
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    fence.acq_rel.device
    s.addi       s16, s12, #192
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #2304
    v.st.w       [s12, #0], v1
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #256
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #2368
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #320
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #2432
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #384
    v.st.w       [s16, #0], v1
    s.addi       s16, s17, #2496
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s12, #448
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #2560
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s12, #512
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #2624
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s12, #576
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #2688
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s12, #640
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #2752
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #704
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #2816
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #768
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #2880
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #832
    v.st.w       [s16, #0], v1
    s.addi       s16, s17, #2944
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s12, #896
    s.addi       s19, s12, #960
    v.st.w       [s14, #0], v1
    s.addi       s12, s17, #3008
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #3072
    v.st.w       [s15, #0], v1
    s.addi       s14, s17, #5120
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3136
    v.st.w       [s5, #0], v1
    s.addi       s5, s14, #64
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s17, #3200
    v.st.w       [s10, #0], v1
    s.addi       s10, s14, #128
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #3264
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    s.addi       s16, s14, #192
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #3328
    v.st.w       [s14, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s14, #256
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #3392
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #320
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #3456
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s14, #384
    v.st.w       [s16, #0], v1
    s.addi       s16, s17, #3520
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s14, #448
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #3584
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s14, #512
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #3648
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s14, #576
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #3712
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s14, #640
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #3776
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s14, #704
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #3840
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #768
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #3904
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s14, #832
    v.st.w       [s16, #0], v1
    s.addi       s16, s17, #3968
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s14, #896
    s.addi       s19, s14, #960
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #4032
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    v.st.w       [s15, #0], v1
    s.movz       s14, #0
    v.ld.w       v1, [s10, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    v.st.w       [s12, #0], v1
    s.movz       s12, #1
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #1
    v.st.w       [s6, #0], v1
    s.movz       s6, #1
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #2
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s5
    a.vread      v2, a3, s14
    s.movz       s5, #2
    vf.add       v3, v1, v2
    s.movz       s14, #2
    s.movz       s16, #3
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s15
    s.movz       s10, #3
    vf.add       v3, v1, v2
    s.movz       s12, #3
    s.movz       s15, #4
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s4
    a.vread      v2, a3, s5
    s.movz       s4, #4
    vf.add       v3, v1, v2
    s.movz       s5, #4
    s.movz       s6, #5
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s10
    s.movz       s10, #5
    vf.add       v3, v1, v2
    s.movz       s14, #5
    s.movz       s16, #6
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s4
    s.movz       s4, #6
    vf.add       v3, v1, v2
    s.movz       s12, #6
    s.movz       s15, #7
    a.vwrite     a4, s5, v3
    a.vread      v1, a0, s6
    a.vread      v2, a3, s10
    s.movz       s5, #7
    vf.add       v3, v1, v2
    s.movz       s6, #7
    s.movz       s10, #8
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s4
    s.movz       s4, #8
    vf.add       v3, v1, v2
    s.movz       s14, #8
    s.movz       s16, #9
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s5
    s.movz       s5, #9
    vf.add       v3, v1, v2
    s.movz       s12, #9
    s.movz       s15, #10
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s10
    a.vread      v2, a3, s4
    s.movz       s4, #10
    vf.add       v3, v1, v2
    s.movz       s6, #10
    s.movz       s10, #11
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s5
    s.movz       s5, #11
    vf.add       v3, v1, v2
    s.movz       s14, #11
    s.movz       s16, #12
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s4
    s.movz       s4, #12
    vf.add       v3, v1, v2
    s.movz       s12, #12
    s.movz       s15, #13
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s10
    a.vread      v2, a3, s5
    s.movz       s5, #13
    vf.add       v3, v1, v2
    s.movz       s6, #13
    s.movz       s10, #14
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s4
    s.movz       s4, #14
    vf.add       v3, v1, v2
    s.movz       s14, #14
    s.movz       s16, #15
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s5
    s.movz       s5, #15
    vf.add       v3, v1, v2
    s.movz       s12, #15
    s.addi       s15, s17, #4096
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s10
    a.vread      v2, a3, s4
    s.addi       s4, s17, #0
    vf.add       v3, v1, v2
    s.addi       s6, s17, #4160
    s.addi       s10, s17, #64
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s5
    s.addi       s5, s17, #4224
    vf.add       v3, v1, v2
    s.addi       s14, s17, #128
    s.addi       s16, s17, #4288
    a.vwrite     a4, s12, v3
    v.ld.w       v1, [s15, #0]
    s.addi       s12, s17, #192
    s.addi       s15, s17, #4352
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #256
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #4416
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #4480
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #384
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #4544
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #448
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #4608
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #512
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #4672
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #4736
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #4800
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #704
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #4864
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #4928
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #4992
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #896
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #5056
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #5120
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #1024
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #5184
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #1088
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #5248
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #1152
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #5312
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s12, s17, #1216
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #5376
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #1280
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #5440
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #1344
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #5504
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #1408
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #5568
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #1472
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #5632
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #1536
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #5696
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #1600
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #5760
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #1664
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #5824
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #1728
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #5888
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #1792
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #5952
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #1856
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #6016
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #1920
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #6080
    s.addi       s19, s17, #1984
    v.st.w       [s12, #0], v1
    s.movz       s12, #0
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #0
    v.st.w       [s4, #0], v1
    s.movz       s4, #1
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    v.st.w       [s10, #0], v1
    s.movz       s10, #2
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #2
    v.st.w       [s14, #0], v1
    s.movz       s14, #3
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #3
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s12
    s.movz       s12, #4
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s4
    s.movz       s4, #4
    a.vwrite     a0, s6, v1
    a.vread      v1, a4, s10
    s.movz       s6, #5
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s14
    s.movz       s5, #5
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s12
    s.movz       s10, #6
    a.vwrite     a0, s4, v1
    a.vread      v1, a4, s6
    s.movz       s4, #6
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s10
    s.movz       s5, #7
    a.vwrite     a0, s4, v1
    s.movz       s4, #7
    a.vread      v1, a4, s5
    s.movz       s5, #8
    a.vwrite     a0, s4, v1
    s.movz       s4, #8
    a.vread      v1, a4, s5
    s.movz       s5, #9
    a.vwrite     a0, s4, v1
    s.movz       s4, #9
    a.vread      v1, a4, s5
    s.movz       s5, #10
    a.vwrite     a0, s4, v1
    s.movz       s4, #10
    a.vread      v1, a4, s5
    s.movz       s5, #11
    a.vwrite     a0, s4, v1
    s.movz       s4, #11
    a.vread      v1, a4, s5
    s.movz       s5, #12
    a.vwrite     a0, s4, v1
    s.movz       s4, #12
    a.vread      v1, a4, s5
    s.movz       s5, #13
    a.vwrite     a0, s4, v1
    s.movz       s4, #13
    a.vread      v1, a4, s5
    s.movz       s5, #14
    a.vwrite     a0, s4, v1
    s.movz       s4, #14
    a.vread      v1, a4, s5
    s.movz       s5, #15
    a.vwrite     a0, s4, v1
    s.movz       s4, #15
    a.vread      v1, a4, s5
    s.add        s5, s20, s3
    s.movz       s6, #1
    a.vwrite     a0, s4, v1
    s.mov        s20, s5
    br.nz        s6, for_5
endfor_6:
    .li       s2, #262144
    s.movz       s3, #0
    s.mul        s4, s13, s2
    s.muli       s2, s8, #4                      // a runtime tile origin, x4
    s.movz       s5, #0
    s.add        s6, s3, s8                      // the tile origin
    s.muli       s3, s9, #2048                   // a runtime tile origin, x2048
    s.add        s8, s5, s9                      // the tile origin
    s.movz       s5, #512
    v.splat      v1, s6
    s.muli       s6, s4, #4                      // a runtime tile origin, x4
    v.splat      v2, s8
    v.splat      v3, s5
    v.add        v4, v0, v1
    v.splat      v0, s5
    s.addi       s4, s8, #1
    s.add        s5, s7, s2                      // the tile origin
    v.splat      v1, s13
    v.splat      v5, s1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s4
    s.addi       s1, s8, #2
    s.add        s2, s5, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s1
    s.addi       s1, s8, #3
    s.add        s4, s2, s6                      // the tile origin
    a.vread      v1, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #1
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s8, #4
    @p5 v.st.w       [s4, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s2
    s.addi       s2, s4, #2048                   // row 1
    p.and        p5, p3, p1
    s.movz       s3, #2
    p.and        p3, p4, p2
    v.splat      v1, s1
    s.addi       s1, s8, #5
    s.addi       s5, s4, #4096                   // row 2
    @p5 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #3
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s8, #6
    s.addi       s3, s4, #6144                   // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s2
    s.movz       s2, #4
    p.and        p5, p3, p2
    v.splat      v1, s1
    s.addi       s1, s8, #7
    s.addi       s5, s4, #8192                   // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    @p4 v.st.w       [s3, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s2
    p.and        p5, p4, p2
    v.splat      v2, s1
    s.addi       s1, s8, #8
    s.addi       s2, s4, #10240                  // row 5
    p.and        p4, p5, p1
    s.movz       s3, #6
    v.splat      v4, s1
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s8, #9
    s.addi       s5, s4, #12288                  // row 6
    p.and        p3, p5, p1
    s.movz       s6, #7
    v.splat      v1, s1
    s.addi       s1, s8, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    s.addi       s2, s4, #14336                  // row 7
    p.and        p4, p5, p1
    s.movz       s3, #8
    v.splat      v2, s1
    s.addi       s1, s8, #11
    s.addi       s7, s4, #16384                  // row 8
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.movz       s5, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s8, #12
    s.addi       s6, s4, #18432                  // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s8, #13
    s.addi       s2, s4, #20480                  // row 10
    s.movz       s3, #11
    v.splat      v5, s1
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s5
    p.and        p5, p3, p2
    s.addi       s1, s8, #14
    p.and        p3, p5, p1
    s.addi       s5, s4, #22528                  // row 11
    s.movz       s7, #12
    v.splat      v2, s1
    s.addi       s1, s4, #24576                  // row 12
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s6, s8, #15
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v4, s6
    s.addi       s6, s4, #26624                  // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    s.addi       s2, s4, #28672                  // row 14
    p.and        p3, p5, p1
    s.movz       s3, #15
    s.addi       s10, s4, #30720                 // row 15
    @p4 v.st.w       [s5, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s7
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s8
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s3
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
