.org 0
mb.arm s1, b0, #0, #0
mb.wait s1
mb.arm s1, b1, #0, #0
mb.wait s1
mb.arm s1, b2, #0, #0
mb.wait s1
exit
