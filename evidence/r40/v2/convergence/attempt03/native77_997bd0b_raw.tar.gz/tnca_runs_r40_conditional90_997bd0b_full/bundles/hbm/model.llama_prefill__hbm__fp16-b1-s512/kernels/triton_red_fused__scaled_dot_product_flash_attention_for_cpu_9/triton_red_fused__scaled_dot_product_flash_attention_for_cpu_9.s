    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.splat      v0, s4
    s.ld.d       s2, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.rdspecial  s3, role_id
    v.sub        v2, v1, v0
    s.movz       s5, #512
    v.cmp.lt     p1, v0, v1
    s.mul        s6, s3, s5
    @p1 v.sel        v3, v2, v0
    v.movi       v0, #511
    v.movi       v2, #512
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    v.and        v4, v3, v0
    s.add        s5, s2, s6                      // this context's own scratch
    v.movi       v0, #0
    v.movi       v3, #0
    v.sub        v5, v1, v2
    v.sub        v6, v1, v4
    s.addi       s2, s5, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #8192
    s.movz       s7, #512
    s.movz       s8, #2048
    s.movz       s9, #4
    .li       s10, #68719476737
    .li       s11, #2207613190144
    s.movz       s12, #0
    v.cmp.lt     p2, v2, v1
    v.cmp.ne     p3, v0, v3
    s.ld.d       s13, [s1, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.movz       s1, #0
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v7, #1
    @p2 v.sel        v7, v5, v2
    @p1 v.sel        v2, v6, v4
    p.mov        p1, p3
    s.st.d       [s2, #0], s3
    s.st.d       [s2, #8], s6
    s.movz       s1, #512
    s.st.d       [s2, #16], s7
    s.movz       s6, #16
    s.st.d       [s2, #48], s8
    s.addi       s7, s12, #0
    s.st.d       [s2, #56], s9
    s.st.d       [s2, #88], s10
    s.st.d       [s2, #104], s11
    fence.release.device
    td.load      d0, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s2, s7, s1
    br.nz        s2, endfor_2
    v.movi       v4, #-1
    v.splat      v5, s7
    v.splat      v6, s7
    v.mul        v7, v2, v4
    v.add        v4, v5, v3
    v.iota       v5                              // arange(0, VLEN)
    v.extract    s2, v7, #0
    s.movz       s8, #512
    v.splat      v7, s2
    s.movz       s2, #8192
    s.muli       s9, s4, #2048
    v.add        v8, v4, v7
    v.add        v7, v6, v5
    v.movi       v5, #0
    v.splat      v6, s8
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s2
    v.extract    s2, v8, #0
    s.muli       s8, s7, #4
    s.shli       s10, s2, #32
    v.cmp.ge     p2, v7, v5
    v.cmp.lt     p3, v7, v6
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s2, v8, #1
    s.add        s11, s3, s9
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s9, s10, #32
    v.movi       v5, #0
    v.movi       v6, #0
    s.shli       s10, s2, #32
    s.add        s2, s11, s8
    p.and        p3, p6, p2
    s.lshri      s8, s9, #32
    v.extract    s11, v8, #2
    s.ashri      s14, s10, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s2, #0]
    v.insert     v5, s9, #0
    v.insert     v6, s8, #0
    s.shli       s2, s11, #32
    s.lshri      s8, s14, #32
    s.ashri      s9, s2, #32
    v.insert     v5, s14, #1
    v.insert     v6, s8, #1
    v.movi       v9, #512
    s.lshri      s2, s9, #32
    v.insert     v5, s9, #2
    v.cmp.lt     p2, v4, v9
    v.extract    s8, v8, #3
    v.extract    s9, v8, #4
    s.shli       s10, s8, #32
    v.insert     v6, s2, #2
    s.ashri      s2, s10, #32
    s.shli       s8, s9, #32
    s.lshri      s9, s2, #32
    v.extract    s10, v8, #5
    s.ashri      s11, s8, #32
    v.insert     v5, s2, #3
    v.insert     v6, s9, #3
    s.shli       s2, s10, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #6
    s.ashri      s10, s2, #32
    v.insert     v5, s11, #4
    v.insert     v6, s8, #4
    s.shli       s2, s9, #32
    s.lshri      s8, s10, #32
    s.ashri      s9, s2, #32
    v.insert     v5, s10, #5
    v.insert     v6, s8, #5
    .li       s2, #-1
    v.extract    s2, v8, #7
    s.lshri      s8, s9, #32
    s.shli       s10, s2, #32
    v.extract    s2, v8, #8
    s.ashri      s11, s10, #32
    v.insert     v5, s9, #6
    v.insert     v6, s8, #6
    s.shli       s8, s2, #32
    s.lshri      s2, s11, #32
    v.extract    s9, v8, #9
    s.ashri      s10, s8, #32
    v.insert     v5, s11, #7
    v.insert     v6, s2, #7
    s.shli       s2, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #10
    s.ashri      s11, s2, #32
    v.insert     v5, s10, #8
    v.insert     v6, s8, #8
    s.shli       s2, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #11
    s.ashri      s10, s2, #32
    v.insert     v5, s11, #9
    v.insert     v6, s8, #9
    s.shli       s2, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #12
    s.ashri      s11, s2, #32
    v.insert     v5, s10, #10
    v.insert     v6, s8, #10
    s.shli       s2, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #13
    s.ashri      s10, s2, #32
    v.insert     v5, s11, #11
    v.insert     v6, s8, #11
    s.shli       s2, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #14
    s.ashri      s11, s2, #32
    v.insert     v5, s10, #12
    v.insert     v6, s8, #12
    s.shli       s2, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #15
    s.ashri      s10, s2, #32
    v.insert     v5, s11, #13
    v.insert     v6, s8, #13
    s.shli       s2, s9, #32
    s.lshri      s8, s10, #32
    s.ashri      s9, s2, #32
    v.insert     v5, s10, #14
    v.insert     v6, s8, #14
    s.lshri      s2, s9, #32
    v.insert     v5, s9, #15
    v.insert     v6, s2, #15
    s.movz       s2, #0
    v.extract    s8, v5, #0
    v.extract    s9, v6, #0
    v.extract    s10, v6, #1
    s.shli       s11, s9, #32
    v.movi       v4, #0
    s.or         s9, s8, s11
    v.extract    s8, v5, #1
    s.shli       s11, s10, #32
    s.cmp.le     s10, s9, s2
    v.extract    s2, v6, #2
    s.or         s9, s8, s11
    s.movz       s8, #0
    v.insert     v4, s10, #0
    v.extract    s10, v5, #2
    s.shli       s11, s2, #32
    s.cmp.le     s2, s9, s8
    v.extract    s8, v6, #3
    s.or         s9, s10, s11
    s.movz       s10, #0
    v.insert     v4, s2, #1
    v.extract    s2, v5, #3
    s.shli       s11, s8, #32
    s.cmp.le     s8, s9, s10
    v.extract    s9, v6, #4
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #2
    v.extract    s8, v5, #4
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s2
    v.extract    s2, v6, #5
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #3
    v.extract    s9, v5, #5
    s.shli       s11, s2, #32
    s.cmp.le     s2, s10, s8
    v.extract    s8, v6, #6
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #4
    v.extract    s2, v5, #6
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v6, #7
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #5
    v.extract    s8, v5, #7
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s2
    v.extract    s2, v6, #8
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #6
    v.extract    s9, v5, #8
    s.shli       s11, s2, #32
    s.cmp.le     s2, s10, s8
    v.extract    s8, v6, #9
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #7
    v.extract    s2, v5, #9
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v6, #10
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #8
    v.extract    s8, v5, #10
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s2
    v.extract    s2, v6, #11
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #9
    v.extract    s9, v5, #11
    s.shli       s11, s2, #32
    s.cmp.le     s2, s10, s8
    v.extract    s8, v6, #12
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #10
    v.extract    s2, v5, #12
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v6, #13
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #11
    v.extract    s8, v5, #13
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s2
    v.extract    s2, v6, #14
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #12
    v.extract    s9, v5, #14
    s.shli       s11, s2, #32
    s.cmp.le     s2, s10, s8
    v.extract    s8, v6, #15
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #13
    v.extract    s2, v5, #15
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    s.or         s9, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #14
    s.cmp.le     s8, s9, s2
    v.movi       v5, #0
    v.insert     v4, s8, #15
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.ne     p3, v4, v5
    @p3 v.sel        v4, v6, v0
    v.movi       v5, #0
    v.movi       v6, #0
    vf.add       v9, v7, v4
    v.movi       v4, #1
    v.movi       v7, #0
    v.movi       v10, #1
    v.movi       v11, #0
    vf.cmp.eq    p3, v9, v0
    @p3 v.sel        v12, v8, v5
    v.movi       v5, #1
    v.movi       v8, #0
    v.cmp.eq     p3, v12, v6
    @p3 v.sel        v6, v4, v7
    @p3 v.sel        v4, v10, v11
    v.movi       v7, #0
    v.extract    s2, v6, #0
    v.movi       v6, #0
    s.lshri      s8, s2, #32
    v.extract    s9, v4, #1
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s2, #0
    v.insert     v6, s8, #0
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #2
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #1
    v.insert     v6, s2, #1
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #3
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #2
    v.insert     v6, s2, #2
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #4
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #3
    v.insert     v6, s2, #3
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #5
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #4
    v.insert     v6, s2, #4
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #6
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #5
    v.insert     v6, s2, #5
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #7
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #6
    v.insert     v6, s2, #6
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #8
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #7
    v.insert     v6, s2, #7
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #9
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #8
    v.insert     v6, s2, #8
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #10
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #9
    v.insert     v6, s2, #9
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #11
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #10
    v.insert     v6, s2, #10
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #12
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s9, #11
    v.insert     v6, s2, #11
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #13
    @p3 v.sel        v4, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.insert     v7, s8, #12
    v.insert     v6, s2, #12
    s.lshri      s2, s9, #32
    v.extract    s8, v4, #14
    @p3 v.sel        v4, v5, v8
    v.insert     v7, s9, #13
    v.insert     v6, s2, #13
    s.lshri      s2, s8, #32
    v.extract    s9, v4, #15
    v.insert     v7, s8, #14
    v.insert     v6, s2, #14
    s.lshri      s2, s9, #32
    v.insert     v7, s9, #15
    v.insert     v6, s2, #15
    s.movz       s2, #0
    v.extract    s8, v7, #0
    v.extract    s9, v6, #0
    v.extract    s10, v6, #1
    s.shli       s11, s9, #32
    v.movi       v4, #0
    s.or         s9, s8, s11
    v.extract    s8, v7, #1
    s.shli       s11, s10, #32
    s.cmp.ne     s10, s9, s2
    v.extract    s2, v6, #2
    s.or         s9, s8, s11
    s.movz       s8, #0
    v.insert     v4, s10, #0
    v.extract    s10, v7, #2
    s.shli       s11, s2, #32
    s.cmp.ne     s2, s9, s8
    v.extract    s8, v6, #3
    s.or         s9, s10, s11
    s.movz       s10, #0
    v.insert     v4, s2, #1
    v.extract    s2, v7, #3
    s.shli       s11, s8, #32
    s.cmp.ne     s8, s9, s10
    v.extract    s9, v6, #4
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #2
    v.extract    s8, v7, #4
    s.shli       s11, s9, #32
    s.cmp.ne     s9, s10, s2
    v.extract    s2, v6, #5
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #3
    v.extract    s9, v7, #5
    s.shli       s11, s2, #32
    s.cmp.ne     s2, s10, s8
    v.extract    s8, v6, #6
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #4
    v.extract    s2, v7, #6
    s.shli       s11, s8, #32
    s.cmp.ne     s8, s10, s9
    v.extract    s9, v6, #7
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #5
    v.extract    s8, v7, #7
    s.shli       s11, s9, #32
    s.cmp.ne     s9, s10, s2
    v.extract    s2, v6, #8
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #6
    v.extract    s9, v7, #8
    s.shli       s11, s2, #32
    s.cmp.ne     s2, s10, s8
    v.extract    s8, v6, #9
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #7
    v.extract    s2, v7, #9
    s.shli       s11, s8, #32
    s.cmp.ne     s8, s10, s9
    v.extract    s9, v6, #10
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #8
    v.extract    s8, v7, #10
    s.shli       s11, s9, #32
    s.cmp.ne     s9, s10, s2
    v.extract    s2, v6, #11
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #9
    v.extract    s9, v7, #11
    s.shli       s11, s2, #32
    s.cmp.ne     s2, s10, s8
    v.extract    s8, v6, #12
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #10
    v.extract    s2, v7, #12
    s.shli       s11, s8, #32
    s.cmp.ne     s8, s10, s9
    v.extract    s9, v6, #13
    s.or         s10, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #11
    v.extract    s8, v7, #13
    s.shli       s11, s9, #32
    s.cmp.ne     s9, s10, s2
    v.extract    s2, v6, #14
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v4, s9, #12
    v.extract    s9, v7, #14
    s.shli       s11, s2, #32
    s.cmp.ne     s2, s10, s8
    v.extract    s8, v6, #15
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v4, s2, #13
    v.extract    s2, v7, #15
    s.shli       s11, s8, #32
    s.cmp.ne     s8, s10, s9
    s.or         s9, s2, s11
    s.movz       s2, #0
    v.insert     v4, s8, #14
    s.cmp.ne     s8, s9, s2
    v.movi       v5, #0
    v.insert     v4, s8, #15
    vf.max       v6, v1, v9
    p.not        p3, p2
    v.cmp.ne     p4, v4, v5
    p.or         p5, p1, p4
    p.and        p4, p3, p1
    p.and        p3, p2, p5
    @p2 v.sel        v4, v6, v1
    v.movi       v5, #0
    p.or         p2, p3, p4
    s.add        s2, s7, s6
    p.mov        p3, p2
    v.mov        v5, v4
    s.movz       s8, #1
    p.mov        p1, p3
    v.mov        v1, v5
    s.mov        s7, s2
    br.nz        s8, for_1
endfor_2:
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p2, v1, v1
    v.movi       v6, #1
    @p2 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.movi       v5, #0
    v.reduce.or.b v8, v7
    vf.reduce.max.b v7, v1
    .li       s2, #2143289344
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v6, v4
    v.cmp.ne     p1, v8, v5
    @p1 v.sel        v4, v1, v7
    v.movi       v1, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.reduce.or  s2, v9
    vf.add       v7, v4, v1
    v.splat      v4, s2
    s.addi       s2, s12, #0
    v.mov        v6, v5
for_3:
    s.cmp.ge     s7, s2, s1
    br.nz        s7, endfor_4
    v.movi       v8, #-1
    v.splat      v9, s2
    v.splat      v10, s2
    v.mul        v11, v2, v8
    v.add        v8, v9, v3
    v.iota       v9                              // arange(0, VLEN)
    v.extract    s7, v11, #0
    s.movz       s8, #512
    v.splat      v11, s7
    s.movz       s7, #8192
    s.muli       s9, s4, #2048
    v.add        v12, v8, v11
    v.add        v11, v10, v9
    v.movi       v9, #0
    v.splat      v10, s8
    v.splat      v13, s4
    v.movi       v14, #0
    v.splat      v15, s7
    v.extract    s7, v12, #0
    s.muli       s8, s2, #4
    s.shli       s10, s7, #32
    v.cmp.ge     p1, v11, v9
    v.cmp.lt     p2, v11, v10
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    v.extract    s7, v12, #1
    s.add        s11, s3, s9
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s9, s10, #32
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s10, s7, #32
    s.add        s7, s11, s8
    p.and        p2, p5, p1
    s.lshri      s8, s9, #32
    v.extract    s11, v12, #2
    s.ashri      s14, s10, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s7, #0]
    v.insert     v9, s9, #0
    v.insert     v10, s8, #0
    s.shli       s7, s11, #32
    s.lshri      s8, s14, #32
    s.ashri      s9, s7, #32
    v.insert     v9, s14, #1
    v.insert     v10, s8, #1
    v.movi       v13, #512
    s.lshri      s7, s9, #32
    v.insert     v9, s9, #2
    v.cmp.lt     p1, v8, v13
    v.extract    s8, v12, #3
    v.extract    s9, v12, #4
    s.shli       s10, s8, #32
    v.insert     v10, s7, #2
    s.ashri      s7, s10, #32
    s.shli       s8, s9, #32
    s.lshri      s9, s7, #32
    v.extract    s10, v12, #5
    s.ashri      s11, s8, #32
    v.insert     v9, s7, #3
    v.insert     v10, s9, #3
    s.shli       s7, s10, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v12, #6
    s.ashri      s10, s7, #32
    v.insert     v9, s11, #4
    v.insert     v10, s8, #4
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    s.ashri      s9, s7, #32
    v.insert     v9, s10, #5
    v.insert     v10, s8, #5
    .li       s7, #-1
    v.extract    s7, v12, #7
    s.lshri      s8, s9, #32
    s.shli       s10, s7, #32
    v.extract    s7, v12, #8
    s.ashri      s11, s10, #32
    v.insert     v9, s9, #6
    v.insert     v10, s8, #6
    s.shli       s8, s7, #32
    s.lshri      s7, s11, #32
    v.extract    s9, v12, #9
    s.ashri      s10, s8, #32
    v.insert     v9, s11, #7
    v.insert     v10, s7, #7
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v12, #10
    s.ashri      s11, s7, #32
    v.insert     v9, s10, #8
    v.insert     v10, s8, #8
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v12, #11
    s.ashri      s10, s7, #32
    v.insert     v9, s11, #9
    v.insert     v10, s8, #9
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v12, #12
    s.ashri      s11, s7, #32
    v.insert     v9, s10, #10
    v.insert     v10, s8, #10
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v12, #13
    s.ashri      s10, s7, #32
    v.insert     v9, s11, #11
    v.insert     v10, s8, #11
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v12, #14
    s.ashri      s11, s7, #32
    v.insert     v9, s10, #12
    v.insert     v10, s8, #12
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v12, #15
    s.ashri      s10, s7, #32
    v.insert     v9, s11, #13
    v.insert     v10, s8, #13
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    s.ashri      s9, s7, #32
    v.insert     v9, s10, #14
    v.insert     v10, s8, #14
    s.lshri      s7, s9, #32
    v.insert     v9, s9, #15
    v.insert     v10, s7, #15
    s.movz       s7, #0
    v.extract    s8, v9, #0
    v.extract    s9, v10, #0
    v.extract    s10, v10, #1
    s.shli       s11, s9, #32
    v.movi       v12, #0
    s.or         s9, s8, s11
    v.extract    s8, v9, #1
    s.shli       s11, s10, #32
    s.cmp.le     s10, s9, s7
    v.extract    s7, v10, #2
    s.or         s9, s8, s11
    s.movz       s8, #0
    v.insert     v12, s10, #0
    v.extract    s10, v9, #2
    s.shli       s11, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v10, #3
    s.or         s9, s10, s11
    s.movz       s10, #0
    v.insert     v12, s7, #1
    v.extract    s7, v9, #3
    s.shli       s11, s8, #32
    s.cmp.le     s8, s9, s10
    v.extract    s9, v10, #4
    s.or         s10, s7, s11
    s.movz       s7, #0
    v.insert     v12, s8, #2
    v.extract    s8, v9, #4
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s7
    v.extract    s7, v10, #5
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v12, s9, #3
    v.extract    s9, v9, #5
    s.shli       s11, s7, #32
    s.cmp.le     s7, s10, s8
    v.extract    s8, v10, #6
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v12, s7, #4
    v.extract    s7, v9, #6
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v10, #7
    s.or         s10, s7, s11
    s.movz       s7, #0
    v.insert     v12, s8, #5
    v.extract    s8, v9, #7
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s7
    v.extract    s7, v10, #8
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v12, s9, #6
    v.extract    s9, v9, #8
    s.shli       s11, s7, #32
    s.cmp.le     s7, s10, s8
    v.extract    s8, v10, #9
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v12, s7, #7
    v.extract    s7, v9, #9
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v10, #10
    s.or         s10, s7, s11
    s.movz       s7, #0
    v.insert     v12, s8, #8
    v.extract    s8, v9, #10
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s7
    v.extract    s7, v10, #11
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v12, s9, #9
    v.extract    s9, v9, #11
    s.shli       s11, s7, #32
    s.cmp.le     s7, s10, s8
    v.extract    s8, v10, #12
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v12, s7, #10
    v.extract    s7, v9, #12
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    v.extract    s9, v10, #13
    s.or         s10, s7, s11
    s.movz       s7, #0
    v.insert     v12, s8, #11
    v.extract    s8, v9, #13
    s.shli       s11, s9, #32
    s.cmp.le     s9, s10, s7
    v.extract    s7, v10, #14
    s.or         s10, s8, s11
    s.movz       s8, #0
    v.insert     v12, s9, #12
    v.extract    s9, v9, #14
    s.shli       s11, s7, #32
    s.cmp.le     s7, s10, s8
    v.extract    s8, v10, #15
    s.or         s10, s9, s11
    s.movz       s9, #0
    v.insert     v12, s7, #13
    v.extract    s7, v9, #15
    s.shli       s11, s8, #32
    s.cmp.le     s8, s10, s9
    s.or         s9, s7, s11
    s.movz       s7, #0
    v.insert     v12, s8, #14
    s.cmp.le     s8, s9, s7
    v.movi       v9, #0
    v.insert     v12, s8, #15
    v.extract    s7, v7, #0
    .li       s8, #1069066811
    v.splat      v10, s8                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v12, v9
    @p2 v.sel        v9, v5, v0
    v.splat      v12, s7
    .li       s7, #1060205080
    v.splat      v13, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v14, v11, v9
    s.mul        s7, s4, s1
    v.movi       v9, #0
    s.add        s8, s2, s6
    s.movz       s9, #1
    vf.sub       v11, v14, v12
    s.add        s10, s2, s7
    v.splat      v12, s7
    s.shli       s7, s10, #2                     // element offset -> bytes (x4)
    vf.mul       v14, v11, v10
    s.add        s10, s13, s7                    // &in_out_ptr0[...]
    v.add        v15, v8, v12
    v.exp2.approx v8, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v11, v10, v14              // the exact rounding error of x*log2(e)
    vf.mul       v10, v12, v13
    vf.fma       v11, v8, v10, v8                // 2**t * 2**d
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v10, v11, v8
    vf.add       v8, v6, v10
    @p1 v.st.w       [s10, #0], v10
    @p1 v.sel        v10, v8, v6
    v.mov        v9, v10
    v.mov        v6, v9
    s.mov        s2, s8
    br.nz        s9, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    vf.add       v2, v0, v1
    s.addi       s2, s5, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s3, #0
    s.st.d       [s2, #0], s13
    s.movz       s3, #8192
    s.st.d       [s2, #8], s3
    s.movz       s3, #512
    s.st.d       [s2, #16], s3
    s.movz       s3, #2048
    s.st.d       [s2, #48], s3
    s.movz       s3, #4
    s.st.d       [s2, #56], s3
    .li       s3, #68719476737
    s.st.d       [s2, #88], s3
    .li       s3, #2207613190144
    s.st.d       [s2, #104], s3
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s2, s12, #0
for_5:
    s.cmp.ge     s3, s2, s1
    br.nz        s3, endfor_6
    v.extract    s3, v2, #0
    v.splat      v0, s2
    v.splat      v1, s3
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s3, #512
    v.rcp.approx v7, v1                          // ISA 8.8: <= 2**-22 relative
    s.movz       s5, #8192
    s.muli       s7, s4, #2048
    v.add        v8, v0, v6
    v.movi       v0, #0
    v.splat      v6, s3
    v.splat      v9, s4
    v.movi       v10, #0
    s.muli       s3, s2, #4
    v.cmp.ge     p1, v8, v0
    v.splat      v0, s5
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v0
    s.add        s5, s13, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s7, #1065353216
    v.splat      v0, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s7, s5, s3
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s7, #0]
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    v.cmp.eq     p1, v4, v8
    s.mul        s3, s4, s1
    @p1 v.sel        v8, v9, v10
    vf.fms       v9, v1, v7, v0
    v.splat      v0, s2
    v.extract    s5, v8, #0
    v.movi       v1, #0
    v.splat      v8, s5
    vf.fms       v10, v7, v9, v7
    v.add        v9, v0, v3
    v.movi       v0, #512
    s.add        s5, s2, s3
    v.cmp.ne     p1, v8, v1
    vf.neg       v1, v10                         // Newton step: r0*(2 - x*r0)
    v.splat      v8, s3
    v.cmp.lt     p2, v9, v0
    s.shli       s3, s5, #2                      // element offset -> bytes (x4)
    s.add        s5, s2, s6
    vf.cmp.o     p3, v1, v1
    @p3 v.sel        v0, v1, v7
    s.add        s7, s13, s3                     // &in_out_ptr0[...]
    s.movz       s3, #1
    vf.mul       v1, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    v.add        v0, v9, v8
    @p1 v.sel        v0, v5, v1
    @p2 v.st.w       [s7, #0], v0
    s.mov        s2, s5
    br.nz        s3, for_5
endfor_6:
__rctx_next:
    exit
