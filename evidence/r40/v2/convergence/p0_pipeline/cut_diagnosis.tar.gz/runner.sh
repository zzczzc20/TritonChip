source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd "$HOME/tnca_build/r40_p0_cuts"
timeout -k 15 600 vivado -mode batch -source diagnose.tcl -tclargs "$HOME/tnca_build/r40_p0ab_screen/case11/synth.dcp" "$PWD/reports" range-slice-cuts > stdout.log 2>&1
echo $? > exit
