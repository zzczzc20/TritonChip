    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #15
    v.sub        v4, v1, v0
    v.sub        v5, v2, v0
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v6, v4, v0
    @p2 v.sel        v4, v5, v0
    v.movi       v0, #4
    v.movi       v5, #16
    v.and        v7, v6, v3
    v.lshr       v3, v4, v0
    v.sub        v0, v1, v5
    v.sub        v4, v1, v7
    v.sub        v6, v2, v5
    v.sub        v8, v2, v3
    v.movi       v9, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.cmp.lt     p3, v5, v1
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #128
    s.movz       s6, #16
    v.movi       v10, #1
    @p3 v.sel        v10, v0, v5
    v.cmp.lt     p3, v5, v2
    v.iota       v0                              // arange(0, VLEN)
    @p1 v.sel        v2, v4, v7
    v.movi       v4, #1
    @p3 v.sel        v4, v6, v5
    @p2 v.sel        v4, v8, v3
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.addi       s8, s2, #0
    s.ld.d       s9, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // out_ptr2: device_ptr64 at arg_base+24
    v.mov        v1, v9
for_1:
    s.cmp.ge     s1, s8, s5
    br.nz        s1, endfor_2
    v.movi       v3, #128
    v.splat      v5, s8
    v.movi       v6, #6144
    v.mul        v7, v2, v3
    v.add        v3, v5, v0
    v.movi       v5, #2048
    v.extract    s1, v7, #0
    v.mul        v7, v4, v6
    v.add        v6, v3, v5
    v.splat      v5, s1
    v.extract    s1, v7, #0
    v.movi       v7, #128
    v.add        v8, v6, v5
    v.splat      v5, s1
    v.cmp.lt     p1, v3, v7
    .li       s1, #1069066811
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v8, v5
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s3, v7]               // index is in elements (ISA sec 9.1)
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s1, s4, s5
    v.movi       v10, #0
    s.movz       s11, #2048
    s.add        s11, s8, s6
    s.movz       s12, #1
    s.add        s13, s8, s1
    v.splat      v11, s1
    s.shli       s1, s13, #2                     // element offset -> bytes (x4)
    s.movz       s13, #6144
    s.add        s13, s7, s1                     // &out_ptr0[...]
    v.add        v12, v3, v11
    vf.neg       v3, v9
    vf.mul       v11, v3, v6
    v.exp2.approx v12, v11                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v3, v6, v11                // the exact rounding error of x*log2(e)
    vf.mul       v3, v13, v5
    vf.fma       v5, v12, v3, v12                // 2**t * 2**d
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v3, v5, v12
    vf.add       v5, v3, v8
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v5, v3, v7
    vf.fms       v5, v3, v6, v3
    vf.neg       v6, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v5, v6, v3
    vf.mul       v3, v9, v5                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v5, v3, v3
    @p1 v.st.w       [s13, #0], v3
    vf.add       v3, v1, v5
    @p1 v.sel        v5, v3, v1
    v.mov        v10, v5
    v.mov        v1, v10
    s.mov        s8, s11
    br.nz        s12, for_1
endfor_2:
    vf.reduce.add.b v3, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s3, s4, #2                      // element offset -> bytes (x4)
    vf.add       v5, v3, v1
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s1
    s.add        s1, s9, s3                      // &out_ptr1[...]
    s.rdspecial  s3, arg_base
    v.cmp.lt     p1, v1, v3
    @p1 v.st.w       [s1, #0], v5
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.movz       s9, #2048
    s.mul        s11, s1, s8
    s.movz       s1, #128
    s.movz       s8, #512
    s.movz       s12, #4
    .li       s13, #68719476737
    s.movz       s14, #0
    s.addi       s14, s2, #0
    s.ld.d       s2, [s3, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s3, s2, s11                     // this context's own scratch
    .li       s2, #2207613190144
    s.addi       s11, s3, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.st.d       [s11, #0], s7
    s.st.d       [s11, #8], s9
    s.st.d       [s11, #16], s1
    s.st.d       [s11, #48], s8
    s.st.d       [s11, #56], s12
    s.st.d       [s11, #88], s13
    s.st.d       [s11, #104], s2
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
for_3:
    s.cmp.ge     s1, s14, s5
    br.nz        s1, endfor_4
    .li       s1, #897988541
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v3, s14
    v.iota       v6                              // arange(0, VLEN)
    vf.add       v7, v5, v1
    s.movz       s1, #128
    s.movz       s2, #2048
    s.muli       s3, s4, #512
    v.add        v1, v3, v6
    v.rsqrt.approx v3, v7                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0
    v.splat      v8, s1
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s2
    s.muli       s1, s14, #4
    v.cmp.ge     p1, v1, v6
    v.cmp.lt     p2, v1, v8
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s2, s7, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s3, #1077936128
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #3204448256
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s3, s2, s1
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s3, #0]
    v.movi       v9, #128
    v.movi       v10, #16384
    v.splat      v11, s14
    v.mul        v12, v4, v9
    v.mul        v9, v2, v10
    v.add        v10, v11, v0
    v.extract    s1, v12, #0
    v.extract    s2, v9, #0
    vf.mul       v9, v3, v3
    vf.mul       v11, v3, v6
    v.splat      v6, s1
    v.movi       v12, #128
    v.splat      v13, s2
    vf.fms       v14, v7, v9, v1
    v.add        v1, v10, v6
    v.cmp.lt     p1, v10, v12
    s.add        s1, s14, s6
    v.add        v6, v1, v13
    vf.mul       v1, v11, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    s.movz       s2, #1
    s.movz       s3, #16384
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v7, v1, v3
    v.extract    s3, v7, #0
    v.splat      v1, s3
    vf.mul       v3, v8, v1
    @p1 v.st.scatter.w [s10, v6], v3
    s.mov        s14, s1
    br.nz        s2, for_3
endfor_4:
__rctx_next:
    exit
