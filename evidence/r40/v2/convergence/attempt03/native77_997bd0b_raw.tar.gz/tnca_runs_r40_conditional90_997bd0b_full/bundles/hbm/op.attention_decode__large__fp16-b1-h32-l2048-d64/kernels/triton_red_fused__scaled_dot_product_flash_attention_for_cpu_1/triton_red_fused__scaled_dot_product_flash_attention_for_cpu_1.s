    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr3: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s2
    s.movz       s1, #32
    s.st.d       [s7, #8], s1
    s.movz       s1, #2048
    s.st.d       [s7, #16], s1
    s.movz       s1, #8192
    s.st.d       [s7, #48], s1
    s.movz       s1, #4
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #2048
    s.movz       s8, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s9, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.mov        p2, p1
    .li       s10, #4286578688
    v.splat      v1, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_2
    v.splat      v3, s9
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s10, #2048
    s.movz       s11, #32
    s.muli       s12, s4, #8192
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s10
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s11
    s.muli       s10, s9, #4
    v.cmp.ge     p1, v5, v3
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s11, s2, s12
    p.and        p6, p1, p3
    p.and        p1, p4, p5
    s.add        s12, s11, s10
    p.and        p3, p6, p1
    v.movi       v3, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s12, #0]
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v7, #1
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    vf.cmp.eq    p1, v4, v1
    @p1 v.sel        v11, v3, v5
    v.movi       v3, #0
    v.movi       v5, #0
    v.cmp.eq     p1, v11, v6
    @p1 v.sel        v6, v7, v8
    @p1 v.sel        v7, v9, v10
    v.splat      v8, s9
    v.extract    s10, v6, #0
    v.movi       v6, #1
    s.lshri      s11, s10, #32
    v.extract    s12, v7, #1
    v.insert     v3, s10, #0
    v.insert     v5, s11, #0
    s.lshri      s10, s12, #32
    v.insert     v3, s12, #1
    v.insert     v5, s10, #1
    v.add        v7, v8, v0
    v.movi       v8, #0
    v.movi       v9, #2048
    @p1 v.sel        v10, v6, v8
    v.cmp.lt     p3, v7, v9
    v.movi       v6, #1
    v.movi       v7, #0
    v.extract    s10, v10, #2
    v.movi       v8, #1
    @p1 v.sel        v9, v6, v7
    v.movi       v6, #0
    s.lshri      s11, s10, #32
    v.extract    s12, v9, #3
    @p1 v.sel        v7, v8, v6
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s10, #2
    v.insert     v5, s11, #2
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #4
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s12, #3
    v.insert     v5, s10, #3
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #5
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s11, #4
    v.insert     v5, s10, #4
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #6
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s12, #5
    v.insert     v5, s10, #5
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #7
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s11, #6
    v.insert     v5, s10, #6
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s12, #7
    v.insert     v5, s10, #7
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #9
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s11, #8
    v.insert     v5, s10, #8
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #10
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s12, #9
    v.insert     v5, s10, #9
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #11
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s11, #10
    v.insert     v5, s10, #10
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #12
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s12, #11
    v.insert     v5, s10, #11
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #13
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #1
    v.movi       v8, #0
    v.insert     v3, s11, #12
    v.insert     v5, s10, #12
    s.lshri      s10, s12, #32
    v.extract    s11, v7, #14
    @p1 v.sel        v7, v6, v8
    v.insert     v3, s12, #13
    v.insert     v5, s10, #13
    s.lshri      s10, s11, #32
    v.extract    s12, v7, #15
    v.insert     v3, s11, #14
    v.insert     v5, s10, #14
    s.lshri      s10, s12, #32
    v.insert     v3, s12, #15
    v.insert     v5, s10, #15
    s.movz       s10, #0
    v.extract    s11, v3, #0
    v.extract    s12, v5, #0
    v.extract    s13, v5, #1
    s.shli       s14, s12, #32
    v.movi       v6, #0
    s.or         s12, s11, s14
    v.extract    s11, v3, #1
    s.shli       s14, s13, #32
    s.cmp.ne     s13, s12, s10
    v.extract    s10, v5, #2
    s.or         s12, s11, s14
    s.movz       s11, #0
    v.insert     v6, s13, #0
    v.extract    s13, v3, #2
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s12, s11
    v.extract    s11, v5, #3
    s.or         s12, s13, s14
    s.movz       s13, #0
    v.insert     v6, s10, #1
    v.extract    s10, v3, #3
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s12, s13
    v.extract    s12, v5, #4
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #2
    v.extract    s11, v3, #4
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v5, #5
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s12, #3
    v.extract    s12, v3, #5
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v5, #6
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v6, s10, #4
    v.extract    s10, v3, #6
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v5, #7
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #5
    v.extract    s11, v3, #7
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v5, #8
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s12, #6
    v.extract    s12, v3, #8
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v5, #9
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v6, s10, #7
    v.extract    s10, v3, #9
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v5, #10
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #8
    v.extract    s11, v3, #10
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v5, #11
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s12, #9
    v.extract    s12, v3, #11
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v5, #12
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v6, s10, #10
    v.extract    s10, v3, #12
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v5, #13
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #11
    v.extract    s11, v3, #13
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v5, #14
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s12, #12
    v.extract    s12, v3, #14
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v5, #15
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v6, s10, #13
    v.extract    s10, v3, #15
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    s.or         s12, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #14
    s.cmp.ne     s11, s12, s10
    v.movi       v3, #0
    v.insert     v6, s11, #15
    vf.max       v5, v2, v4
    p.not        p1, p3
    v.cmp.ne     p4, v6, v3
    p.or         p5, p2, p4
    p.and        p4, p1, p2
    p.and        p1, p3, p5
    @p3 v.sel        v3, v5, v2
    v.movi       v4, #0
    p.or         p3, p1, p4
    s.add        s10, s9, s8
    p.mov        p1, p3
    v.mov        v4, v3
    s.movz       s11, #1
    p.mov        p2, p1
    v.mov        v2, v4
    s.mov        s9, s10
    br.nz        s11, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v3, #0
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v2, v2
    @p1 v.sel        v6, v1, v3
    @p2 v.sel        v1, v4, v5
    v.movi       v3, #0
    v.reduce.or.b v4, v6
    vf.reduce.max.b v5, v2
    .li       s9, #2143289344
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s9, #1
    v.reduce.or  s10, v1
    v.cmp.ne     p1, v4, v3
    s.shli       s11, s4, #0                     // element offset -> bytes (x1)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s9
    v.splat      v4, s10
    @p1 v.sel        v6, v2, v5
    v.movi       v2, #0
    v.movi       v5, #0
    v.movi       v7, #0
    s.add        s9, s3, s11                     // &out_ptr0[...]
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v6, v2
    @p1 v.st.b       [s9, #0], v4
    s.addi       s3, s1, #0
    v.mov        v7, v5
for_3:
    s.cmp.ge     s1, s3, s7
    br.nz        s1, endfor_4
    v.splat      v3, s3
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s1, #2048
    s.movz       s9, #32
    s.muli       s10, s4, #8192
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s1
    v.splat      v6, s4
    v.movi       v8, #0
    v.splat      v9, s9
    s.muli       s1, s3, #4
    v.cmp.ge     p1, v5, v3
    v.cmp.lt     p2, v5, v4
    v.cmp.ge     p3, v6, v8
    v.cmp.lt     p4, v6, v9
    s.add        s9, s2, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s9, s1
    p.and        p2, p5, p1
    v.extract    s1, v1, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s10, #0]
    v.splat      v4, s1
    .li       s1, #1069066811
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s1, s4, s7
    v.splat      v8, s3
    v.movi       v9, #2048
    v.movi       v10, #0
    v.add        v11, v8, v0
    s.add        s9, s3, s1
    v.splat      v8, s1
    v.cmp.lt     p1, v11, v9
    s.shli       s1, s9, #2                      // element offset -> bytes (x4)
    s.add        s9, s3, s8
    s.add        s10, s5, s1                     // &out_ptr2[...]
    s.movz       s1, #1
    v.add        v9, v11, v8
    vf.sub       v8, v3, v4
    vf.mul       v3, v8, v5
    v.exp2.approx v4, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v8, v5, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v9, v6
    vf.fma       v5, v4, v3, v4                  // 2**t * 2**d
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v3, v5, v4
    vf.add       v4, v7, v3
    @p1 v.st.w       [s10, #0], v3
    @p1 v.sel        v3, v4, v7
    v.mov        v10, v3
    v.mov        v7, v10
    s.mov        s3, s9
    br.nz        s1, for_3
endfor_4:
    vf.reduce.add.b v0, v7
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v1, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s6, s2                      // &out_ptr3[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
