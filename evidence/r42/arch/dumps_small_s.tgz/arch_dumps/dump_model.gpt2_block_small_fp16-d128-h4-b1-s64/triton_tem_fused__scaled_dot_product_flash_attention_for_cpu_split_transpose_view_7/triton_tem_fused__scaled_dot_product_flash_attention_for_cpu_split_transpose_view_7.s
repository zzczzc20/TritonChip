    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #256
    s.st.d       [s5, #48], s2
    s.movz       s2, #4
    s.st.d       [s5, #56], s2
    .li       s6, #68719476752
    s.st.d       [s5, #88], s6
    .li       s7, #2207613190144
    s.st.d       [s5, #104], s7
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s8, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s9, #512
    s.mul        s10, s5, s9
    s.add        s5, s8, s10                     // this context's own scratch
    s.addi       s8, s5, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.st.d       [s8, #0], s3
    s.st.d       [s8, #8], s1
    s.st.d       [s8, #16], s1
    s.movz       s1, #128
    s.st.d       [s8, #48], s1
    s.st.d       [s8, #56], s2
    s.st.d       [s8, #88], s6
    s.st.d       [s8, #104], s7
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #2
    s.movz       s3, #0
    s.cmp.lt     s5, s1, s3
    s.sub        s1, s3, s5
    s.movz       s5, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
__rctx_program:
    s.cmp.lt     s8, s6, s3
    s.addi       s9, s3, #0
    s.sub        s10, s3, s8
    s.addi       s8, s3, #0
    s.xor        s11, s6, s10
    s.xor        s12, s10, s1
    s.sub        s13, s11, s10
    s.lshri      s14, s13, #1
    s.mov        s9, s13
    s.xor        s15, s14, s12
    s.sub        s14, s15, s12
    s.sub        s12, s2, s14
    s.min.s      s15, s12, s5
    s.cmp.lt     s12, s15, s3
    s.sub        s16, s3, s12
    s.xor        s12, s15, s16
    s.sub        s15, s12, s16
    s.cmp.eq     s12, s15, s5
    br.nz        s12, sdiv_done_1
    s.movz       s17, #0
    s.movz       s18, #31
    s.mov        s9, s17
    s.addi       s19, s18, #0
sdiv_2:
    s.lshr       s18, s13, s19
    s.shli       s20, s8, #1
    s.andi       s21, s18, #1
    s.shl        s18, s5, s19
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s15
    s.sub        s21, s17, s20
    s.and        s20, s15, s21
    s.and        s23, s18, s21
    s.sub        s8, s22, s20
    s.or         s9, s9, s23
    s.subi       s19, s19, #1
    s.cmp.ge     s18, s19, s17
    br.nz        s18, sdiv_2
sdiv_done_1:
    s.sub        s9, s11, s10
    s.xor        s11, s8, s10
    s.lshri      s8, s9, #1
    s.sub        s13, s11, s10
    s.muli       s11, s8, #2
    s.addi       s8, s3, #0
    s.add        s17, s14, s13
    s.addi       s13, s3, #0
    s.sub        s14, s9, s11
    s.xor        s9, s14, s10
    s.sub        s11, s9, s10
    s.cmp.lt     s9, s11, s3
    s.sub        s10, s3, s9
    s.xor        s9, s11, s10
    s.sub        s11, s9, s10
    s.mov        s8, s11
    br.nz        s12, sdiv_done_3
    s.movz       s9, #0
    s.movz       s12, #31
    s.mov        s8, s9
    s.addi       s14, s12, #0
    s.movz       s12, #1
sdiv_4:
    s.lshr       s18, s11, s14
    s.shli       s19, s13, #1
    s.andi       s20, s18, #1
    s.shl        s18, s12, s14
    s.or         s21, s19, s20
    s.cmp.geu    s19, s21, s15
    s.sub        s20, s9, s19
    s.and        s19, s15, s20
    s.and        s22, s18, s20
    s.sub        s13, s21, s19
    s.or         s8, s8, s22
    s.subi       s14, s14, #1
    s.cmp.ge     s18, s14, s9
    br.nz        s18, sdiv_4
sdiv_done_3:
    s.xor        s9, s10, s16
    s.rdspecial  s10, pid.z
    s.rdspecial  s11, npid.y
    s.xor        s12, s8, s9
    s.mul        s8, s10, s11
    s.sub        s10, s12, s9
    s.movz       s9, #16
    s.rdspecial  s11, pid.y
    s.mul        s12, s17, s9
    s.mul        s13, s10, s9
    s.add        s10, s11, s8
    s.movz       s8, #3
    s.movz       s11, #0
    s.min.s      s14, s10, s8
    s.movz       s8, #4096
    s.movz       s15, #2048
    s.andi       s16, s12, #63
    s.andi       s17, s13, #31
    s.mul        s18, s14, s8
    s.mul        s8, s14, s15
    s.movz       s14, #64
    s.addi       s19, s11, #0
    s.addi       s20, s11, #0
    s.addi       s21, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s22, s19, s14
    br.nz        s22, endfor_6
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s23, s18, s20
    s.add        s24, s17, s8
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s25, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s23                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s25, s22
    mb.wait      s22
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s23, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    s.add        s25, s24, s21
    v.movi       v1, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s26, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s26, s23
    mb.wait      s23
    v.permute    v2, v48, v0
    v.permute    v3, v49, v0
    v.permute    v4, v50, v0
    v.permute    v5, v51, v0
    v.movi       v6, #1
    vf.fma       v7, v2, v32, v1
    vf.fma       v2, v3, v32, v1
    vf.fma       v3, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    v.permute    v5, v48, v6
    v.permute    v8, v49, v6
    v.permute    v9, v50, v6
    v.permute    v10, v51, v6
    v.movi       v11, #2
    vf.fma       v12, v5, v33, v7
    vf.fma       v5, v8, v33, v2
    vf.fma       v2, v9, v33, v3
    vf.fma       v3, v10, v33, v4
    v.permute    v4, v48, v11
    v.permute    v7, v49, v11
    v.permute    v8, v50, v11
    v.permute    v9, v51, v11
    v.movi       v10, #3
    vf.fma       v13, v4, v34, v12
    vf.fma       v4, v7, v34, v5
    vf.fma       v5, v8, v34, v2
    vf.fma       v2, v9, v34, v3
    v.permute    v3, v48, v10
    v.permute    v7, v49, v10
    v.permute    v8, v50, v10
    v.permute    v9, v51, v10
    v.movi       v12, #4
    vf.fma       v14, v3, v35, v13
    vf.fma       v3, v7, v35, v4
    vf.fma       v4, v8, v35, v5
    vf.fma       v5, v9, v35, v2
    v.permute    v2, v48, v12
    v.permute    v7, v49, v12
    v.permute    v8, v50, v12
    v.permute    v9, v51, v12
    v.movi       v13, #5
    vf.fma       v15, v2, v36, v14
    vf.fma       v2, v7, v36, v3
    vf.fma       v3, v8, v36, v4
    vf.fma       v4, v9, v36, v5
    v.permute    v5, v48, v13
    v.permute    v7, v49, v13
    v.permute    v8, v50, v13
    v.permute    v9, v51, v13
    v.movi       v14, #6
    vf.fma       v16, v5, v37, v15
    vf.fma       v5, v7, v37, v2
    vf.fma       v2, v8, v37, v3
    vf.fma       v3, v9, v37, v4
    v.permute    v4, v48, v14
    v.permute    v7, v49, v14
    v.permute    v8, v50, v14
    v.permute    v9, v51, v14
    v.movi       v15, #7
    vf.fma       v17, v4, v38, v16
    vf.fma       v4, v7, v38, v5
    vf.fma       v5, v8, v38, v2
    vf.fma       v2, v9, v38, v3
    v.permute    v3, v48, v15
    v.permute    v7, v49, v15
    v.permute    v8, v50, v15
    v.permute    v9, v51, v15
    v.movi       v16, #8
    vf.fma       v18, v3, v39, v17
    vf.fma       v3, v7, v39, v4
    vf.fma       v4, v8, v39, v5
    vf.fma       v5, v9, v39, v2
    v.permute    v2, v48, v16
    v.permute    v7, v49, v16
    v.permute    v8, v50, v16
    v.permute    v9, v51, v16
    v.movi       v17, #9
    vf.fma       v19, v2, v40, v18
    vf.fma       v2, v7, v40, v3
    vf.fma       v3, v8, v40, v4
    vf.fma       v4, v9, v40, v5
    v.permute    v5, v48, v17
    v.permute    v7, v49, v17
    v.permute    v8, v50, v17
    v.permute    v9, v51, v17
    v.movi       v18, #10
    vf.fma       v20, v5, v41, v19
    vf.fma       v5, v7, v41, v2
    vf.fma       v2, v8, v41, v3
    vf.fma       v3, v9, v41, v4
    v.permute    v4, v48, v18
    v.permute    v7, v49, v18
    v.permute    v8, v50, v18
    v.permute    v9, v51, v18
    v.movi       v19, #11
    vf.fma       v21, v4, v42, v20
    vf.fma       v4, v7, v42, v5
    vf.fma       v5, v8, v42, v2
    vf.fma       v2, v9, v42, v3
    v.permute    v3, v48, v19
    v.permute    v7, v49, v19
    v.permute    v8, v50, v19
    v.permute    v9, v51, v19
    v.movi       v20, #12
    vf.fma       v22, v3, v43, v21
    vf.fma       v3, v7, v43, v4
    vf.fma       v4, v8, v43, v5
    vf.fma       v5, v9, v43, v2
    v.permute    v2, v48, v20
    v.permute    v7, v49, v20
    v.permute    v8, v50, v20
    v.permute    v9, v51, v20
    v.movi       v21, #13
    vf.fma       v23, v2, v44, v22
    vf.fma       v2, v7, v44, v3
    vf.fma       v3, v8, v44, v4
    vf.fma       v4, v9, v44, v5
    v.permute    v5, v48, v21
    v.permute    v7, v49, v21
    v.permute    v8, v50, v21
    v.permute    v9, v51, v21
    v.movi       v22, #14
    vf.fma       v24, v5, v45, v23
    vf.fma       v5, v7, v45, v2
    vf.fma       v2, v8, v45, v3
    vf.fma       v3, v9, v45, v4
    v.permute    v4, v48, v22
    v.permute    v7, v49, v22
    v.permute    v8, v50, v22
    v.permute    v9, v51, v22
    v.movi       v23, #15
    vf.fma       v25, v4, v46, v24
    vf.fma       v4, v7, v46, v5
    vf.fma       v5, v8, v46, v2
    vf.fma       v2, v9, v46, v3
    v.permute    v3, v48, v23
    v.permute    v7, v49, v23
    v.permute    v8, v50, v23
    v.permute    v9, v51, v23
    vf.fma       v24, v3, v47, v25
    vf.fma       v3, v7, v47, v4
    vf.fma       v4, v8, v47, v5
    vf.fma       v5, v9, v47, v2
    a.vread      v2, a0, s11
    s.movz       s24, #1
    s.movz       s25, #2
    vf.add       v7, v2, v24
    s.movz       s26, #3
    a.vwrite     a0, s11, v7
    a.vread      v2, a0, s24
    vf.add       v7, v2, v3
    a.vwrite     a0, s24, v7
    a.vread      v2, a0, s25
    vf.add       v3, v2, v4
    a.vwrite     a0, s25, v3
    a.vread      v2, a0, s26
    vf.add       v3, v2, v5
    a.vwrite     a0, s26, v3
    v.permute    v2, v52, v0
    v.permute    v3, v53, v0
    v.permute    v4, v54, v0
    v.permute    v5, v55, v0
    vf.fma       v7, v2, v32, v1
    vf.fma       v2, v3, v32, v1
    vf.fma       v3, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    v.permute    v5, v52, v6
    v.permute    v8, v53, v6
    v.permute    v9, v54, v6
    v.permute    v24, v55, v6
    vf.fma       v25, v5, v33, v7
    vf.fma       v5, v8, v33, v2
    vf.fma       v2, v9, v33, v3
    vf.fma       v3, v24, v33, v4
    v.permute    v4, v52, v11
    v.permute    v7, v53, v11
    v.permute    v8, v54, v11
    v.permute    v9, v55, v11
    vf.fma       v24, v4, v34, v25
    vf.fma       v4, v7, v34, v5
    vf.fma       v5, v8, v34, v2
    vf.fma       v2, v9, v34, v3
    v.permute    v3, v52, v10
    v.permute    v7, v53, v10
    v.permute    v8, v54, v10
    v.permute    v9, v55, v10
    vf.fma       v25, v3, v35, v24
    vf.fma       v3, v7, v35, v4
    vf.fma       v4, v8, v35, v5
    vf.fma       v5, v9, v35, v2
    v.permute    v2, v52, v12
    v.permute    v7, v53, v12
    v.permute    v8, v54, v12
    v.permute    v9, v55, v12
    vf.fma       v24, v2, v36, v25
    vf.fma       v2, v7, v36, v3
    vf.fma       v3, v8, v36, v4
    vf.fma       v4, v9, v36, v5
    v.permute    v5, v52, v13
    v.permute    v7, v53, v13
    v.permute    v8, v54, v13
    v.permute    v9, v55, v13
    vf.fma       v25, v5, v37, v24
    vf.fma       v5, v7, v37, v2
    vf.fma       v2, v8, v37, v3
    vf.fma       v3, v9, v37, v4
    v.permute    v4, v52, v14
    v.permute    v7, v53, v14
    v.permute    v8, v54, v14
    v.permute    v9, v55, v14
    vf.fma       v24, v4, v38, v25
    vf.fma       v4, v7, v38, v5
    vf.fma       v5, v8, v38, v2
    vf.fma       v2, v9, v38, v3
    v.permute    v3, v52, v15
    v.permute    v7, v53, v15
    v.permute    v8, v54, v15
    v.permute    v9, v55, v15
    vf.fma       v25, v3, v39, v24
    vf.fma       v3, v7, v39, v4
    vf.fma       v4, v8, v39, v5
    vf.fma       v5, v9, v39, v2
    v.permute    v2, v52, v16
    v.permute    v7, v53, v16
    v.permute    v8, v54, v16
    v.permute    v9, v55, v16
    vf.fma       v24, v2, v40, v25
    vf.fma       v2, v7, v40, v3
    vf.fma       v3, v8, v40, v4
    vf.fma       v4, v9, v40, v5
    v.permute    v5, v52, v17
    v.permute    v7, v53, v17
    v.permute    v8, v54, v17
    v.permute    v9, v55, v17
    vf.fma       v25, v5, v41, v24
    vf.fma       v5, v7, v41, v2
    vf.fma       v2, v8, v41, v3
    vf.fma       v3, v9, v41, v4
    v.permute    v4, v52, v18
    v.permute    v7, v53, v18
    v.permute    v8, v54, v18
    v.permute    v9, v55, v18
    vf.fma       v24, v4, v42, v25
    vf.fma       v4, v7, v42, v5
    vf.fma       v5, v8, v42, v2
    vf.fma       v2, v9, v42, v3
    v.permute    v3, v52, v19
    v.permute    v7, v53, v19
    v.permute    v8, v54, v19
    v.permute    v9, v55, v19
    vf.fma       v25, v3, v43, v24
    vf.fma       v3, v7, v43, v4
    vf.fma       v4, v8, v43, v5
    vf.fma       v5, v9, v43, v2
    v.permute    v2, v52, v20
    v.permute    v7, v53, v20
    v.permute    v8, v54, v20
    v.permute    v9, v55, v20
    vf.fma       v24, v2, v44, v25
    vf.fma       v2, v7, v44, v3
    vf.fma       v3, v8, v44, v4
    vf.fma       v4, v9, v44, v5
    v.permute    v5, v52, v21
    v.permute    v7, v53, v21
    v.permute    v8, v54, v21
    v.permute    v9, v55, v21
    vf.fma       v25, v5, v45, v24
    vf.fma       v5, v7, v45, v2
    vf.fma       v2, v8, v45, v3
    vf.fma       v3, v9, v45, v4
    v.permute    v4, v52, v22
    v.permute    v7, v53, v22
    v.permute    v8, v54, v22
    v.permute    v9, v55, v22
    vf.fma       v24, v4, v46, v25
    vf.fma       v4, v7, v46, v5
    vf.fma       v5, v8, v46, v2
    vf.fma       v2, v9, v46, v3
    v.permute    v3, v52, v23
    v.permute    v7, v53, v23
    v.permute    v8, v54, v23
    v.permute    v9, v55, v23
    vf.fma       v25, v3, v47, v24
    s.movz       s25, #4
    vf.fma       v3, v7, v47, v4
    vf.fma       v4, v8, v47, v5
    vf.fma       v5, v9, v47, v2
    a.vread      v2, a0, s25
    s.movz       s26, #5
    s.movz       s27, #6
    vf.add       v7, v2, v25
    s.movz       s28, #7
    a.vwrite     a0, s25, v7
    a.vread      v2, a0, s26
    vf.add       v7, v2, v3
    a.vwrite     a0, s26, v7
    a.vread      v2, a0, s27
    vf.add       v3, v2, v4
    a.vwrite     a0, s27, v3
    a.vread      v2, a0, s28
    vf.add       v3, v2, v5
    a.vwrite     a0, s28, v3
    v.permute    v2, v56, v0
    v.permute    v3, v57, v0
    v.permute    v4, v58, v0
    v.permute    v5, v59, v0
    vf.fma       v7, v2, v32, v1
    vf.fma       v2, v3, v32, v1
    vf.fma       v3, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    v.permute    v5, v56, v6
    v.permute    v8, v57, v6
    v.permute    v9, v58, v6
    v.permute    v24, v59, v6
    vf.fma       v25, v5, v33, v7
    vf.fma       v5, v8, v33, v2
    vf.fma       v2, v9, v33, v3
    vf.fma       v3, v24, v33, v4
    v.permute    v4, v56, v11
    v.permute    v7, v57, v11
    v.permute    v8, v58, v11
    v.permute    v9, v59, v11
    vf.fma       v24, v4, v34, v25
    vf.fma       v4, v7, v34, v5
    vf.fma       v5, v8, v34, v2
    vf.fma       v2, v9, v34, v3
    v.permute    v3, v56, v10
    v.permute    v7, v57, v10
    v.permute    v8, v58, v10
    v.permute    v9, v59, v10
    vf.fma       v25, v3, v35, v24
    vf.fma       v3, v7, v35, v4
    vf.fma       v4, v8, v35, v5
    vf.fma       v5, v9, v35, v2
    v.permute    v2, v56, v12
    v.permute    v7, v57, v12
    v.permute    v8, v58, v12
    v.permute    v9, v59, v12
    vf.fma       v24, v2, v36, v25
    vf.fma       v2, v7, v36, v3
    vf.fma       v3, v8, v36, v4
    vf.fma       v4, v9, v36, v5
    v.permute    v5, v56, v13
    v.permute    v7, v57, v13
    v.permute    v8, v58, v13
    v.permute    v9, v59, v13
    vf.fma       v25, v5, v37, v24
    vf.fma       v5, v7, v37, v2
    vf.fma       v2, v8, v37, v3
    vf.fma       v3, v9, v37, v4
    v.permute    v4, v56, v14
    v.permute    v7, v57, v14
    v.permute    v8, v58, v14
    v.permute    v9, v59, v14
    vf.fma       v24, v4, v38, v25
    vf.fma       v4, v7, v38, v5
    vf.fma       v5, v8, v38, v2
    vf.fma       v2, v9, v38, v3
    v.permute    v3, v56, v15
    v.permute    v7, v57, v15
    v.permute    v8, v58, v15
    v.permute    v9, v59, v15
    vf.fma       v25, v3, v39, v24
    vf.fma       v3, v7, v39, v4
    vf.fma       v4, v8, v39, v5
    vf.fma       v5, v9, v39, v2
    v.permute    v2, v56, v16
    v.permute    v7, v57, v16
    v.permute    v8, v58, v16
    v.permute    v9, v59, v16
    vf.fma       v24, v2, v40, v25
    vf.fma       v2, v7, v40, v3
    vf.fma       v3, v8, v40, v4
    vf.fma       v4, v9, v40, v5
    v.permute    v5, v56, v17
    v.permute    v7, v57, v17
    v.permute    v8, v58, v17
    v.permute    v9, v59, v17
    vf.fma       v25, v5, v41, v24
    vf.fma       v5, v7, v41, v2
    vf.fma       v2, v8, v41, v3
    vf.fma       v3, v9, v41, v4
    v.permute    v4, v56, v18
    v.permute    v7, v57, v18
    v.permute    v8, v58, v18
    v.permute    v9, v59, v18
    vf.fma       v24, v4, v42, v25
    vf.fma       v4, v7, v42, v5
    vf.fma       v5, v8, v42, v2
    vf.fma       v2, v9, v42, v3
    v.permute    v3, v56, v19
    v.permute    v7, v57, v19
    v.permute    v8, v58, v19
    v.permute    v9, v59, v19
    vf.fma       v25, v3, v43, v24
    vf.fma       v3, v7, v43, v4
    vf.fma       v4, v8, v43, v5
    vf.fma       v5, v9, v43, v2
    v.permute    v2, v56, v20
    v.permute    v7, v57, v20
    v.permute    v8, v58, v20
    v.permute    v9, v59, v20
    vf.fma       v24, v2, v44, v25
    vf.fma       v2, v7, v44, v3
    vf.fma       v3, v8, v44, v4
    vf.fma       v4, v9, v44, v5
    v.permute    v5, v56, v21
    v.permute    v7, v57, v21
    v.permute    v8, v58, v21
    v.permute    v9, v59, v21
    vf.fma       v25, v5, v45, v24
    vf.fma       v5, v7, v45, v2
    vf.fma       v2, v8, v45, v3
    vf.fma       v3, v9, v45, v4
    v.permute    v4, v56, v22
    v.permute    v7, v57, v22
    v.permute    v8, v58, v22
    v.permute    v9, v59, v22
    vf.fma       v24, v4, v46, v25
    vf.fma       v4, v7, v46, v5
    vf.fma       v5, v8, v46, v2
    vf.fma       v2, v9, v46, v3
    v.permute    v3, v56, v23
    v.permute    v7, v57, v23
    v.permute    v8, v58, v23
    v.permute    v9, v59, v23
    vf.fma       v25, v3, v47, v24
    s.movz       s25, #8
    vf.fma       v3, v7, v47, v4
    vf.fma       v4, v8, v47, v5
    vf.fma       v5, v9, v47, v2
    a.vread      v2, a0, s25
    s.movz       s26, #9
    s.movz       s27, #10
    vf.add       v7, v2, v25
    s.movz       s28, #11
    a.vwrite     a0, s25, v7
    a.vread      v2, a0, s26
    vf.add       v7, v2, v3
    a.vwrite     a0, s26, v7
    a.vread      v2, a0, s27
    vf.add       v3, v2, v4
    a.vwrite     a0, s27, v3
    a.vread      v2, a0, s28
    vf.add       v3, v2, v5
    a.vwrite     a0, s28, v3
    v.permute    v2, v60, v0
    v.permute    v3, v61, v0
    v.permute    v4, v62, v0
    v.permute    v5, v63, v0
    vf.fma       v0, v2, v32, v1
    vf.fma       v2, v3, v32, v1
    vf.fma       v3, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    v.permute    v1, v60, v6
    v.permute    v5, v61, v6
    v.permute    v7, v62, v6
    v.permute    v8, v63, v6
    vf.fma       v6, v1, v33, v0
    vf.fma       v0, v5, v33, v2
    vf.fma       v1, v7, v33, v3
    vf.fma       v2, v8, v33, v4
    v.permute    v3, v60, v11
    v.permute    v4, v61, v11
    v.permute    v5, v62, v11
    v.permute    v7, v63, v11
    vf.fma       v8, v3, v34, v6
    vf.fma       v3, v4, v34, v0
    vf.fma       v0, v5, v34, v1
    vf.fma       v1, v7, v34, v2
    v.permute    v2, v60, v10
    v.permute    v4, v61, v10
    v.permute    v5, v62, v10
    v.permute    v6, v63, v10
    vf.fma       v7, v2, v35, v8
    vf.fma       v2, v4, v35, v3
    vf.fma       v3, v5, v35, v0
    vf.fma       v0, v6, v35, v1
    v.permute    v1, v60, v12
    v.permute    v4, v61, v12
    v.permute    v5, v62, v12
    v.permute    v6, v63, v12
    vf.fma       v8, v1, v36, v7
    vf.fma       v1, v4, v36, v2
    vf.fma       v2, v5, v36, v3
    vf.fma       v3, v6, v36, v0
    v.permute    v0, v60, v13
    v.permute    v4, v61, v13
    v.permute    v5, v62, v13
    v.permute    v6, v63, v13
    vf.fma       v7, v0, v37, v8
    vf.fma       v0, v4, v37, v1
    vf.fma       v1, v5, v37, v2
    vf.fma       v2, v6, v37, v3
    v.permute    v3, v60, v14
    v.permute    v4, v61, v14
    v.permute    v5, v62, v14
    v.permute    v6, v63, v14
    vf.fma       v8, v3, v38, v7
    vf.fma       v3, v4, v38, v0
    vf.fma       v0, v5, v38, v1
    vf.fma       v1, v6, v38, v2
    v.permute    v2, v60, v15
    v.permute    v4, v61, v15
    v.permute    v5, v62, v15
    v.permute    v6, v63, v15
    vf.fma       v7, v2, v39, v8
    vf.fma       v2, v4, v39, v3
    vf.fma       v3, v5, v39, v0
    vf.fma       v0, v6, v39, v1
    v.permute    v1, v60, v16
    v.permute    v4, v61, v16
    v.permute    v5, v62, v16
    v.permute    v6, v63, v16
    vf.fma       v8, v1, v40, v7
    vf.fma       v1, v4, v40, v2
    vf.fma       v2, v5, v40, v3
    vf.fma       v3, v6, v40, v0
    v.permute    v0, v60, v17
    v.permute    v4, v61, v17
    v.permute    v5, v62, v17
    v.permute    v6, v63, v17
    vf.fma       v7, v0, v41, v8
    vf.fma       v0, v4, v41, v1
    vf.fma       v1, v5, v41, v2
    vf.fma       v2, v6, v41, v3
    v.permute    v3, v60, v18
    v.permute    v4, v61, v18
    v.permute    v5, v62, v18
    v.permute    v6, v63, v18
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v4, v42, v0
    vf.fma       v0, v5, v42, v1
    vf.fma       v1, v6, v42, v2
    v.permute    v2, v60, v19
    v.permute    v4, v61, v19
    v.permute    v5, v62, v19
    v.permute    v6, v63, v19
    vf.fma       v7, v2, v43, v8
    vf.fma       v2, v4, v43, v3
    vf.fma       v3, v5, v43, v0
    vf.fma       v0, v6, v43, v1
    v.permute    v1, v60, v20
    v.permute    v4, v61, v20
    v.permute    v5, v62, v20
    v.permute    v6, v63, v20
    vf.fma       v8, v1, v44, v7
    vf.fma       v1, v4, v44, v2
    vf.fma       v2, v5, v44, v3
    vf.fma       v3, v6, v44, v0
    v.permute    v0, v60, v21
    v.permute    v4, v61, v21
    v.permute    v5, v62, v21
    v.permute    v6, v63, v21
    vf.fma       v7, v0, v45, v8
    vf.fma       v0, v4, v45, v1
    vf.fma       v1, v5, v45, v2
    vf.fma       v2, v6, v45, v3
    v.permute    v3, v60, v22
    v.permute    v4, v61, v22
    v.permute    v5, v62, v22
    v.permute    v6, v63, v22
    vf.fma       v8, v3, v46, v7
    vf.fma       v3, v4, v46, v0
    vf.fma       v0, v5, v46, v1
    vf.fma       v1, v6, v46, v2
    v.permute    v2, v60, v23
    v.permute    v4, v61, v23
    v.permute    v5, v62, v23
    v.permute    v6, v63, v23
    vf.fma       v7, v2, v47, v8
    s.movz       s25, #12
    vf.fma       v2, v4, v47, v3
    vf.fma       v3, v5, v47, v0
    vf.fma       v0, v6, v47, v1
    a.vread      v1, a0, s25
    s.movz       s26, #13
    s.movz       s27, #14
    vf.add       v4, v1, v7
    s.movz       s28, #15
    a.vwrite     a0, s25, v4
    a.vread      v1, a0, s26
    vf.add       v4, v1, v2
    a.vwrite     a0, s26, v4
    a.vread      v1, a0, s27
    vf.add       v2, v1, v3
    a.vwrite     a0, s27, v2
    a.vread      v1, a0, s28
    vf.add       v2, v1, v0
    a.vwrite     a0, s28, v2
    s.addi       s20, s20, #16
    s.addi       s21, s21, #512
    s.add        s19, s19, s9
    br.nz        s24, for_5
endfor_6:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s8, #0
    s.mul        s9, s10, s15
    s.add        s11, s8, s13                    // the tile origin
    s.muli       s15, s13, #4                    // a runtime tile origin, x4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.add        s11, s8, s12                    // the tile origin
    s.movz       s13, #32
    s.muli       s16, s12, #128                  // a runtime tile origin, x128
    v.splat      v2, s11
    v.splat      v3, s14
    v.add        v4, v0, v1
    v.splat      v0, s13
    s.muli       s12, s9, #4                     // a runtime tile origin, x4
    s.addi       s9, s11, #1
    v.splat      v1, s10
    v.splat      v5, s2
    s.add        s10, s4, s15                    // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s9
    s.add        s9, s10, s16                    // the tile origin
    p.and        p3, p1, p2
    s.addi       s10, s11, #2
    v.cmp.lt     p1, v1, v5
    a.vread      v1, a0, s8
    s.add        s8, s9, s12                     // the tile origin
    p.and        p4, p3, p1
    s.movz       s9, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s10
    p.and        p5, p3, p2
    s.addi       s10, s11, #3
    @p4 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s9
    s.addi       s9, s8, #128                    // row 1
    p.and        p3, p5, p1
    s.movz       s12, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s10
    p.and        p5, p4, p2
    s.addi       s10, s11, #4
    s.addi       s13, s8, #256                   // row 2
    p.and        p4, p5, p1
    s.movz       s14, #3
    v.splat      v2, s10
    s.addi       s10, s11, #5
    s.addi       s15, s8, #384                   // row 3
    s.movz       s16, #4
    v.splat      v4, s10
    s.addi       s10, s11, #6
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s12
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s9, s8, #512                    // row 4
    p.and        p3, p5, p1
    s.movz       s12, #5
    v.splat      v0, s10
    s.addi       s10, s11, #7
    s.addi       s17, s8, #640                   // row 5
    v.splat      v5, s10
    s.movz       s10, #6
    @p4 v.st.w       [s13, #0], v1
    a.vread      v1, a0, s14
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s13, s11, #8
    p.and        p4, p5, p1
    s.addi       s14, s8, #768                   // row 6
    v.splat      v2, s13
    s.movz       s13, #7
    @p3 v.st.w       [s15, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s15, s11, #9
    p.and        p3, p5, p1
    s.addi       s16, s8, #896                   // row 7
    v.splat      v4, s15
    s.movz       s15, #8
    @p4 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s12
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s9, s11, #10
    p.and        p4, p5, p1
    s.addi       s12, s8, #1024                  // row 8
    v.splat      v0, s9
    s.movz       s9, #9
    @p3 v.st.w       [s17, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s10, s11, #11
    p.and        p3, p5, p1
    s.addi       s17, s8, #1152                  // row 9
    v.splat      v5, s10
    s.movz       s10, #10
    @p4 v.st.w       [s14, #0], v1
    a.vread      v1, a0, s13
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s13, s11, #12
    p.and        p4, p5, p1
    s.addi       s14, s8, #1280                  // row 10
    v.splat      v2, s13
    s.movz       s13, #11
    @p3 v.st.w       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s15, s11, #13
    p.and        p3, p5, p1
    s.addi       s16, s8, #1408                  // row 11
    v.splat      v4, s15
    s.movz       s15, #12
    @p4 v.st.w       [s12, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s9, s11, #14
    p.and        p4, p5, p1
    s.addi       s12, s8, #1536                  // row 12
    v.splat      v0, s9
    s.movz       s9, #13
    @p3 v.st.w       [s17, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s10, s11, #15
    p.and        p3, p5, p1
    s.addi       s11, s8, #1664                  // row 13
    s.movz       s17, #14
    v.splat      v5, s10
    s.addi       s10, s8, #1792                  // row 14
    s.addi       s18, s8, #1920                  // row 15
    @p4 v.st.w       [s14, #0], v1
    a.vread      v1, a0, s13
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s8, #15
    p.and        p4, p5, p1
    @p3 v.st.w       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s12, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s11, #0], v1
    a.vread      v0, a0, s17
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s10, #0], v0
    a.vread      v0, a0, s8
    @p2 v.st.w       [s18, #0], v0
__rctx_next:
    s.addi       s8, s6, #2                      // the next program of this context: + 2
    s.cmp.lt     s9, s8, s7
    s.mov        s6, s8
    br.nz        s9, __rctx_program
    exit
