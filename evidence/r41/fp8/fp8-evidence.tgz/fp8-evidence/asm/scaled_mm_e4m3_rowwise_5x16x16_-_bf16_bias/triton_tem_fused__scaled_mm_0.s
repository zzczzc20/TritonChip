    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #1
    s.movz       s2, #0
    s.sub        s3, s1, s4
    s.movz       s5, #0
    s.min.s      s6, s3, s1
    s.movz       s1, #0
    s.cmp.lt     s3, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s4, s5
    s.sub        s5, s1, s3
    s.sub        s1, s2, s7
    s.xor        s2, s6, s5
    s.movz       s3, #0
    s.movz       s7, #1
    s.xor        s8, s4, s1
    s.sub        s9, s2, s5
    s.rdspecial  s2, arg_base
    s.movz       s5, #0
    s.sub        s10, s8, s1
    s.addi       s8, s3, #0
    s.cmp.eq     s3, s9, s7
    s.ld.d       s7, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s11, s5, #0
    s.ld.d       s5, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s12, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s13, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s14, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s15, [s2, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s8, s10
    br.nz        s3, sdiv_done_1
    s.movz       s2, #0
    s.movz       s3, #31
    s.mov        s8, s2
    s.addi       s2, s3, #0
sdiv_2:
    s.lshr       s3, s10, s2
    s.shli       s16, s11, #1
    s.andi       s17, s3, #1
    s.movz       s3, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s9
    s.shl        s19, s16, s2
    s.sub        s16, s3, s17
    s.subi       s3, s2, #1
    s.and        s17, s9, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s8, s20
    s.mov        s11, s16
    s.mov        s8, s17
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s16, s2, s3
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s16, s3, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s16
    s.xor        s2, s6, s8
    s.xor        s6, s11, s1
    s.xor        s10, s3, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s16, #1
    s.sub        s17, s6, s1
    s.sub        s1, s10, s9
    s.movz       s6, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s16
    s.add        s16, s4, s17
    s.addi       s4, s6, #0
    s.mov        s10, s1
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s6, #31
    s.mov        s10, s2
    s.addi       s2, s6, #0
sdiv_4:
    s.lshr       s6, s1, s2
    s.shli       s17, s4, #1
    s.andi       s18, s6, #1
    s.movz       s6, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s11
    s.shl        s20, s17, s2
    s.sub        s17, s6, s18
    s.subi       s6, s2, #1
    s.and        s18, s11, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s10, s21
    s.mov        s4, s17
    s.mov        s10, s18
    s.mov        s2, s6
    s.movz       s6, #0
    s.cmp.ge     s17, s2, s6
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.xor        s2, s9, s8
    s.mul        s4, s16, s1
    s.xor        s6, s10, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s8, s6, s2
    v.movi       v1, #5
    v.splat      v2, s4
    s.mul        s2, s8, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    v.splat      v2, s16
    v.splat      v5, s3
    v.splat      v6, s8
    v.splat      v7, s3
    v.splat      v8, s2
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s6, #31
idiv_5:
    v.splat      v6, s6
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s8, s6, #1
    v.and        v6, v8, v0
    s.movz       s9, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s9
    br.nz        s8, idiv_5
    v.sub        v0, v3, v2
    s.rdspecial  s6, arg_base
    s.rdspecial  s8, role_id
    @p1 v.sel        v1, v0, v2
    s.ld.d       s9, [s6, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s6, #1536
    v.extract    s10, v1, #0
    v.extract    s11, v1, #1
    v.extract    s16, v1, #2
    v.extract    s17, v1, #3
    v.extract    s18, v1, #4
    v.splat      v0, s10
    v.splat      v2, s1
    v.splat      v3, s11
    v.splat      v4, s16
    v.splat      v5, s17
    v.splat      v6, s18
    s.mul        s10, s8, s6
    v.iota       v7                              // arange(0, VLEN)
    v.mul        v8, v0, v2
    v.mul        v0, v3, v2
    v.mul        v3, v4, v2
    v.mul        v4, v5, v2
    v.mul        v5, v6, v2
    s.add        s6, s9, s10                     // this context's own scratch
    v.splat      v6, s3
    v.add        v9, v7, v8
    v.add        v8, v7, v0
    v.add        v0, v7, v3
    v.add        v3, v7, v4
    v.add        v4, v7, v5
    s.addi       s3, s6, #0
    v.add        v5, v6, v9
    v.add        v9, v6, v8
    v.add        v8, v6, v0
    v.add        v0, v6, v3
    v.add        v3, v6, v4
    s.addi       s8, s3, #64
    s.addi       s9, s3, #128
    s.addi       s10, s3, #192
    s.addi       s11, s3, #256
    v.st.w       [s3, #0], v5
    s.andi       s16, s2, #15
    s.addi       s17, s3, #320
    v.splat      v4, s16
    v.extract    s18, v1, #5
    v.st.w       [s8, #0], v9
    v.iota       v5                              // arange(0, VLEN)
    v.add        v9, v4, v5
    v.extract    s8, v1, #6
    v.splat      v4, s18
    v.extract    s18, v1, #7
    v.splat      v5, s8
    v.extract    s8, v1, #8
    v.mul        v9, v4, v2
    v.mul        v4, v5, v2
    v.add        v5, v7, v9
    v.add        v9, v7, v4
    v.add        v4, v6, v5
    v.add        v5, v6, v9
    v.st.w       [s9, #0], v8
    v.extract    s9, v1, #9
    v.splat      v8, s18
    v.extract    s18, v1, #10
    v.mul        v9, v8, v2
    v.add        v8, v7, v9
    v.add        v9, v6, v8
    v.st.w       [s10, #0], v0
    v.extract    s10, v1, #11
    v.splat      v0, s8
    s.addi       s8, s3, #384
    v.mul        v8, v0, v2
    v.add        v0, v7, v8
    v.add        v8, v6, v0
    v.st.w       [s11, #0], v3
    v.extract    s11, v1, #12
    v.splat      v0, s9
    s.addi       s9, s3, #448
    v.mul        v3, v0, v2
    v.add        v0, v7, v3
    v.add        v3, v6, v0
    v.st.w       [s17, #0], v4
    v.extract    s17, v1, #13
    v.splat      v0, s18
    s.addi       s18, s3, #512
    v.mul        v4, v0, v2
    v.add        v0, v7, v4
    v.add        v4, v6, v0
    v.st.w       [s8, #0], v5
    v.extract    s8, v1, #14
    v.splat      v0, s10
    s.addi       s10, s3, #576
    v.mul        v5, v0, v2
    v.add        v0, v7, v5
    v.add        v5, v6, v0
    v.st.w       [s9, #0], v9
    v.extract    s9, v1, #15
    v.splat      v0, s11
    v.splat      v1, s17
    s.addi       s11, s3, #640
    v.mul        v9, v0, v2
    v.mul        v0, v1, v2
    s.addi       s17, s3, #704
    v.add        v1, v7, v9
    v.add        v9, v7, v0
    v.add        v0, v6, v1
    v.add        v1, v6, v9
    v.st.w       [s18, #0], v8
    v.splat      v8, s8
    s.addi       s8, s3, #768
    s.addi       s18, s3, #832
    v.mul        v9, v8, v2
    v.add        v8, v7, v9
    v.add        v9, v6, v8
    v.st.w       [s10, #0], v3
    v.splat      v3, s9
    s.addi       s9, s3, #896
    s.addi       s10, s3, #960
    v.mul        v8, v3, v2
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s3, s6, #0
    v.add        v2, v7, v8
    v.add        v3, v6, v2
    v.st.w       [s11, #0], v4
    s.addi       s11, s6, #1024                  // 256 bytes of repack scratch
    v.st.w       [s17, #0], v5
    s.addi       s17, s6, #64
    v.st.w       [s8, #0], v0
    s.addi       s8, s11, #16                    // row 1
    v.st.w       [s18, #0], v1
    s.addi       s18, s6, #128
    v.st.w       [s9, #0], v9
    s.addi       s9, s11, #32                    // row 2
    v.st.w       [s10, #0], v3
    fence.acq_rel.device
    s.addi       s10, s6, #192
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #48                    // row 3
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s11, #0], v1
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s6, #256
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v1
    s.addi       s8, s11, #64                    // row 4
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s6, #320
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v1
    s.addi       s9, s11, #80                    // row 5
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s6, #384
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v1
    s.addi       s3, s11, #96                    // row 6
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s6, #448
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v1
    s.addi       s8, s11, #112                   // row 7
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s6, #512
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v1
    s.addi       s9, s11, #128                   // row 8
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s6, #576
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v1
    s.addi       s3, s11, #144                   // row 9
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s6, #640
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v1
    s.addi       s8, s11, #160                   // row 10
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s6, #704
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v1
    s.addi       s9, s11, #176                   // row 11
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s6, #768
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.muli       s19, s16, #16                   // a runtime tile origin, x16
    v.st.b       [s3, #0], v1
    s.addi       s3, s11, #192                   // row 12
    v.iota       v0                              // arange(0, VLEN)
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s6, #832
    v.ld.gather.b v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v2
    s.addi       s8, s11, #208                   // row 13
    v.ld.w       v1, [s18, #0]
    s.addi       s17, s6, #896
    v.ld.gather.b v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v2
    s.addi       s9, s11, #224                   // row 14
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s6, #960
    s.addi       s18, s6, #1280                  // 256 bytes of repack scratch
    v.ld.gather.b v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v2
    s.addi       s3, s11, #240                   // row 15
    v.ld.w       v1, [s16, #0]
    s.addi       s6, s11, #64
    v.ld.gather.b v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v2
    s.addi       s8, s11, #128
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s11, #192
    v.ld.gather.b v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v2
    s.movz       s9, #16
    v.splat      v1, s9
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s9, #0
    s.add        s17, s9, s19                    // the tile origin
    v.mul        v2, v0, v1
    v.splat      v0, s17
    s.addi       s9, s17, #1
    v.add        v1, v2, v0
    v.ld.w       v0, [s10, #0]
    v.splat      v3, s9
    s.addi       s9, s17, #2
    s.addi       s10, s18, #16                   // row 1
    v.add        v4, v2, v3
    v.splat      v3, s9
    s.addi       s9, s17, #3
    v.add        v5, v2, v3
    v.splat      v3, s9
    s.addi       s9, s18, #32                    // row 2
    v.add        v6, v2, v3
    v.ld.gather.b v3, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s17, #4
    v.splat      v0, s7
    s.addi       s7, s18, #48                    // row 3
    v.add        v8, v2, v0
    v.st.b       [s3, #0], v3
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    s.addi       s3, s17, #5
    v.ld.w       v0, [s11, #0]
    v.splat      v3, s3
    s.addi       s3, s18, #64                    // row 4
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s6, #0]
    v.add        v9, v2, v3
    s.addi       s6, s18, #80                    // row 5
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s17, #6
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s16, #0]
    s.addi       s11, s18, #96                   // row 6
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s8
    s.addi       s8, s17, #7
    s.addi       s16, s17, #8
    v.add        v3, v2, v1
    v.st.b       [s18, #0], v0
    v.splat      v0, s8
    s.addi       s8, s18, #112                   // row 7
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s10, #0], v0
    v.splat      v0, s16
    s.addi       s10, s17, #9
    s.addi       s16, s18, #128                  // row 8
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v0
    v.splat      v0, s10
    s.addi       s9, s17, #10
    s.addi       s10, s18, #144                  // row 9
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s7, #0], v0
    v.splat      v0, s9
    s.addi       s7, s17, #11
    s.addi       s9, s18, #160                   // row 10
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s5, v8]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v0
    v.splat      v0, s7
    s.addi       s3, s17, #12
    s.addi       s7, s18, #176                   // row 11
    v.add        v8, v2, v0
    v.ld.gather.b v0, [s5, v9]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s6, #0], v0
    v.splat      v0, s3
    s.addi       s3, s17, #13
    s.addi       s6, s18, #192                   // row 12
    v.add        v9, v2, v0
    v.ld.gather.b v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s11, #0], v0
    v.splat      v0, s3
    s.addi       s3, s17, #14
    s.addi       s11, s18, #208                  // row 13
    v.add        v3, v2, v0
    s.addi       s19, s17, #15
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s8, #0], v0
    v.splat      v0, s3
    s.addi       s3, s18, #224                   // row 14
    s.addi       s8, s18, #240                   // row 15
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    v.splat      v0, s19
    s.addi       s16, s18, #64
    s.addi       s17, s18, #128
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s10, #0], v0
    s.addi       s10, s18, #192
    v.ld.gather.b v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v0
    s.movz       s9, #0
    v.movi       v0, #0
    s.add        s19, s9, s4                     // the tile origin
    v.ld.gather.b v2, [s5, v8]                   // index is in elements (ISA sec 9.1)
    v.splat      v5, s19
    v.st.b       [s7, #0], v2
    s.movz       s7, #0
    s.add        s9, s7, s4                      // the tile origin
    v.splat      v2, s9
    v.ld.gather.b v6, [s5, v9]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s6, #0], v6
    s.movz       s6, #0
    v.splat      v6, s1
    s.add        s1, s6, s2                      // the tile origin
    s.movz       s6, #5
    v.splat      v8, s1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    v.add        v9, v7, v8
    v.splat      v7, s6
    v.ld.gather.b v8, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    v.cmp.lt     p2, v9, v6
    p.and        p3, p1, p2
    v.st.b       [s11, #0], v8
    s.addi       s6, s19, #1
    s.movz       s7, #1
    v.ld.gather.b v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s6
    s.addi       s6, s9, #1
    v.st.b       [s3, #0], v2
    v.splat      v2, s6
    v.cmp.lt     p1, v2, v7
    p.and        p4, p1, p2
    v.ld.gather.b v2, [s5, v4]                   // index is in elements (ISA sec 9.1)
    s.movz       s3, #2
    v.st.b       [s8, #0], v2
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    s.addi       s5, s9, #2
    s.addi       s6, s19, #2
    v.splat      v2, s6
    v.ld.w       v3, [s18, #0]
    v.splat      v4, s5
    v.mov        v56, v3                         // hand off through the shared window (sec 7.3)
    v.ld.w       v3, [s16, #0]
    v.mov        v57, v3                         // hand off through the shared window (sec 7.3)
    v.ld.w       v3, [s17, #0]
    s.addi       s5, s19, #3
    s.movz       s6, #3
    v.mov        v58, v3                         // hand off through the shared window (sec 7.3)
    v.ld.w       v3, [s10, #0]
    s.addi       s8, s9, #3
    v.splat      v6, s5
    v.splat      v8, s8
    v.mov        v59, v3                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s5, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s5
    mb.wait      s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    s.addi       s8, s9, #4
    s.addi       s10, s19, #4
    v.splat      v4, s8
    v.splat      v5, s10
    s.addi       s8, s9, #5
    s.addi       s10, s19, #5
    s.movz       s11, #4
    s.addi       s16, s19, #6
    s.movz       s17, #5
    s.movz       s18, #6
    a.vwrite     a1, s1, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v7
    p.and        p4, p1, p2
    v.splat      v1, s8
    v.splat      v8, s10
    s.addi       s1, s9, #6
    s.addi       s8, s19, #7
    s.movz       s10, #7
    a.vwrite     a1, s7, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v4, s16
    s.addi       s1, s9, #7
    s.addi       s7, s19, #8
    s.movz       s16, #8
    a.vwrite     a1, s3, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v6, s8
    s.addi       s1, s9, #8
    s.addi       s3, s19, #9
    s.movz       s8, #9
    a.vwrite     a1, s6, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v5, s7
    s.addi       s1, s9, #9
    s.addi       s6, s19, #10
    s.movz       s7, #10
    a.vwrite     a1, s11, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v8, s3
    s.addi       s1, s9, #10
    s.addi       s3, s19, #11
    s.movz       s11, #11
    a.vwrite     a1, s17, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v4, s6
    s.addi       s1, s9, #11
    s.addi       s6, s19, #12
    s.movz       s17, #12
    a.vwrite     a1, s18, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v6, s3
    s.addi       s1, s9, #12
    s.addi       s3, s19, #13
    s.movz       s18, #13
    a.vwrite     a1, s10, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v5, s6
    s.addi       s1, s9, #13
    s.addi       s6, s19, #14
    s.movz       s10, #14
    a.vwrite     a1, s16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v8, s3
    s.addi       s1, s9, #14
    s.addi       s3, s19, #15
    s.movz       s16, #15
    a.vwrite     a1, s8, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v4, s6
    s.addi       s1, s9, #15
    s.muli       s6, s2, #4                      // a runtime tile origin, x4
    s.add        s8, s13, s6                     // the tile origin
    a.vwrite     a1, s7, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v6, s3
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s2, #2                      // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s2, #2                      // a runtime tile origin, x2
    s.muli       s2, s4, #32                     // a runtime tile origin, x32
    s.add        s4, s14, s3                     // the tile origin
    s.add        s3, s15, s6                     // the tile origin
    s.add        s6, s3, s2                      // the tile origin
    a.vwrite     a1, s11, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.splat      v2, s9
    s.movz       s2, #0
    v.splat      v5, s9
    a.vwrite     a1, s17, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    v.splat      v1, s9
    a.vwrite     a1, s18, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s12, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    s.addi       s3, s9, #1
    s.movz       s7, #1
    v.splat      v2, s3
    s.movz       s3, #1
    a.vwrite     a1, s10, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s12, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p4, p1, p2
    s.addi       s10, s9, #1
    v.splat      v4, s10
    a.vwrite     a1, s16, v3
    a.vread      v3, a0, s1
    a.vread      v5, a1, s2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s8, #0]
    vf.add       v8, v3, v0
    v.cmp.lt     p1, v1, v7
    p.and        p3, p1, p2
    s.addi       s1, s9, #1
    s.addi       s2, s9, #2
    v.splat      v1, s1
    v.splat      v3, s2
    s.addi       s1, s6, #32                     // row 1
    s.movz       s2, #2
    s.movz       s10, #2
    vf.mul       v9, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s4, #0]
    v.cmp.lt     p1, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v8, v9
    s.addi       s11, s9, #2
    v.splat      v6, s11
    vf.cvt.bf16.f32 v8, v5
    vf.add       v5, v2, v8
    vf.cvt.f32.bf16 v2, v5
    s.addi       s11, s6, #64                    // row 2
    @p3 v.st.h       [s6, #0], v2
    a.vread      v2, a0, s7
    a.vread      v5, a1, s3
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    vf.add       v4, v2, v0
    s.addi       s3, s9, #2
    s.movz       s7, #3
    v.splat      v2, s3
    s.movz       s3, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    s.addi       s12, s9, #3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.mul       v9, v5, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s12
    vf.mul       v5, v4, v9
    s.addi       s12, s9, #3
    vf.cvt.bf16.f32 v4, v1
    v.splat      v1, s12
    vf.add       v8, v5, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s12, s6, #96                    // row 3
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a0, s2
    a.vread      v5, a1, s10
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p2
    vf.add       v6, v4, v0
    s.addi       s1, s9, #3
    s.movz       s2, #4
    v.splat      v4, s1
    s.movz       s1, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    s.addi       s10, s9, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    vf.mul       v9, v5, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s10
    vf.mul       v5, v6, v9
    s.addi       s10, s9, #4
    vf.cvt.bf16.f32 v6, v2
    v.splat      v2, s10
    vf.add       v8, v5, v6
    vf.cvt.f32.bf16 v5, v8
    s.addi       s10, s6, #128                   // row 4
    @p3 v.st.h       [s11, #0], v5
    a.vread      v5, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v1, v7
    p.and        p3, p1, p2
    vf.add       v1, v5, v0
    s.addi       s3, s9, #4
    s.movz       s7, #5
    v.splat      v5, s3
    s.movz       s3, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v4, v7
    p.and        p4, p1, p2
    s.addi       s11, s9, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s11
    vf.mul       v6, v1, v9
    s.addi       s11, s9, #5
    vf.cvt.bf16.f32 v1, v4
    v.splat      v4, s11
    vf.add       v8, v6, v1
    vf.cvt.f32.bf16 v1, v8
    s.addi       s11, s6, #160                   // row 5
    @p4 v.st.h       [s12, #0], v1
    a.vread      v1, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v2, v7
    p.and        p4, p1, p2
    vf.add       v2, v1, v0
    s.addi       s1, s9, #5
    s.movz       s2, #6
    v.splat      v1, s1
    s.movz       s1, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v5, v7
    p.and        p3, p1, p2
    s.addi       s12, s9, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s12
    vf.mul       v6, v2, v9
    s.addi       s12, s9, #6
    vf.cvt.bf16.f32 v2, v5
    v.splat      v5, s12
    vf.add       v8, v6, v2
    vf.cvt.f32.bf16 v2, v8
    s.addi       s12, s6, #192                   // row 6
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    vf.add       v4, v2, v0
    s.addi       s3, s9, #6
    s.movz       s7, #7
    v.splat      v2, s3
    s.movz       s3, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    s.addi       s10, s9, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s10
    vf.mul       v6, v4, v9
    s.addi       s10, s9, #7
    vf.cvt.bf16.f32 v4, v1
    v.splat      v1, s10
    vf.add       v8, v6, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s10, s6, #224                   // row 7
    @p4 v.st.h       [s11, #0], v4
    a.vread      v4, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v5, v7
    p.and        p4, p1, p2
    vf.add       v5, v4, v0
    s.addi       s1, s9, #7
    s.movz       s2, #8
    v.splat      v4, s1
    s.movz       s1, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    s.addi       s11, s9, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s11
    vf.mul       v6, v5, v9
    s.addi       s11, s9, #8
    vf.cvt.bf16.f32 v5, v2
    v.splat      v2, s11
    vf.add       v8, v6, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s11, s6, #256                   // row 8
    @p3 v.st.h       [s12, #0], v5
    a.vread      v5, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v1, v7
    p.and        p3, p1, p2
    vf.add       v1, v5, v0
    s.addi       s3, s9, #8
    s.movz       s7, #9
    v.splat      v5, s3
    s.movz       s3, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v4, v7
    p.and        p4, p1, p2
    s.addi       s12, s9, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s12
    vf.mul       v6, v1, v9
    s.addi       s12, s9, #9
    vf.cvt.bf16.f32 v1, v4
    v.splat      v4, s12
    vf.add       v8, v6, v1
    vf.cvt.f32.bf16 v1, v8
    s.addi       s12, s6, #288                   // row 9
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v2, v7
    p.and        p4, p1, p2
    vf.add       v2, v1, v0
    s.addi       s1, s9, #9
    s.movz       s2, #10
    v.splat      v1, s1
    s.movz       s1, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v5, v7
    p.and        p3, p1, p2
    s.addi       s10, s9, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s10
    vf.mul       v6, v2, v9
    s.addi       s10, s9, #10
    vf.cvt.bf16.f32 v2, v5
    v.splat      v5, s10
    vf.add       v8, v6, v2
    vf.cvt.f32.bf16 v2, v8
    s.addi       s10, s6, #320                   // row 10
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    vf.add       v4, v2, v0
    s.addi       s3, s9, #10
    s.movz       s7, #11
    v.splat      v2, s3
    s.movz       s3, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    s.addi       s11, s9, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s11
    vf.mul       v6, v4, v9
    s.addi       s11, s9, #11
    vf.cvt.bf16.f32 v4, v1
    v.splat      v1, s11
    vf.add       v8, v6, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s11, s6, #352                   // row 11
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v5, v7
    p.and        p4, p1, p2
    vf.add       v5, v4, v0
    s.addi       s1, s9, #11
    s.movz       s2, #12
    v.splat      v4, s1
    s.movz       s1, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    s.addi       s12, s9, #12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s12
    vf.mul       v6, v5, v9
    s.addi       s12, s9, #12
    vf.cvt.bf16.f32 v5, v2
    v.splat      v2, s12
    vf.add       v8, v6, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s12, s6, #384                   // row 12
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v1, v7
    p.and        p3, p1, p2
    vf.add       v1, v5, v0
    s.addi       s3, s9, #12
    s.movz       s7, #13
    v.splat      v5, s3
    s.movz       s3, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v4, v7
    p.and        p4, p1, p2
    s.addi       s10, s9, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s10
    vf.mul       v6, v1, v9
    s.addi       s10, s9, #13
    vf.cvt.bf16.f32 v1, v4
    v.splat      v4, s10
    vf.add       v8, v6, v1
    vf.cvt.f32.bf16 v1, v8
    s.addi       s10, s6, #416                   // row 13
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v2, v7
    p.and        p4, p1, p2
    vf.add       v2, v1, v0
    s.addi       s1, s9, #13
    s.movz       s2, #14
    v.splat      v1, s1
    s.movz       s1, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v5, v7
    p.and        p3, p1, p2
    s.addi       s11, s9, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    v.splat      v3, s11
    vf.mul       v6, v2, v9
    s.addi       s11, s9, #14
    vf.cvt.bf16.f32 v2, v5
    v.splat      v5, s11
    vf.add       v8, v6, v2
    vf.cvt.f32.bf16 v2, v8
    s.addi       s11, s6, #448                   // row 14
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a0, s7
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v4, v7
    p.and        p3, p1, p2
    vf.add       v4, v2, v0
    s.addi       s3, s9, #14
    s.movz       s7, #15
    v.splat      v2, s3
    s.movz       s3, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v1, v7
    p.and        p4, p1, p2
    s.addi       s12, s9, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p3, p1, p2
    v.splat      v3, s12
    vf.mul       v6, v4, v9
    s.addi       s12, s9, #15
    vf.cvt.bf16.f32 v4, v1
    v.splat      v1, s12
    vf.add       v8, v6, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s12, s6, #480                   // row 15
    @p4 v.st.h       [s10, #0], v4
    a.vread      v4, a0, s2
    a.vread      v6, a1, s1
    v.cmp.lt     p1, v5, v7
    p.and        p4, p1, p2
    vf.add       v5, v4, v0
    s.addi       s1, s9, #15
    v.splat      v4, s1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v2, v7
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v3, v7
    p.and        p4, p1, p2
    vf.mul       v3, v5, v9
    vf.cvt.bf16.f32 v5, v2
    vf.add       v2, v3, v5
    vf.cvt.f32.bf16 v3, v2
    @p3 v.st.h       [s11, #0], v3
    a.vread      v2, a0, s7
    a.vread      v3, a1, s3
    v.cmp.lt     p1, v1, v7
    p.and        p3, p1, p2
    vf.add       v1, v2, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s8, #0]
    v.cmp.lt     p1, v4, v7
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    vf.mul       v4, v3, v0
    vf.mul       v0, v1, v4
    vf.cvt.bf16.f32 v1, v2
    vf.add       v2, v0, v1
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s12, #0], v0
__rctx_next:
    exit
