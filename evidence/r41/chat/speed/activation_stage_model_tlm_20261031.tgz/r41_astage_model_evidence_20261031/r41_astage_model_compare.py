import json,math,torch
from pathlib import Path
from safetensors.torch import load_file
h=Path.home(); roots=[h/'r41_profile_model_lru',h/'r41_profile_model_astage_lru'];result={'schema':'r41-activation-stage-model-tlm-ab/1','scope':'one-layer VL, uncalibrated DP TLM, not board','routes':[]}
for d in roots:
 r=json.load(open(d/'report.json'));j=json.load(open(d/'profile/launches.json'));row={'route':d.name,'status':r.get('status'),'cpu_numerical_fallback':r.get('cpu_numerical_fallback'),'generated_tokens':r.get('generated_tokens'),'steps':[]}
 for step,kind in ((1,'prefill'),(2,'decode')):
  xs=[x for x in j['launches'] if x['step']==step and not x.get('skipped',False)]; fs=[x for x in xs if x['kernel']=='w8a8_block_dynamic_fp8_matmul_kernel'];mac=ins=0
  for x in fs:
   a=next(z for z in x['args'] if z.get('role')=='act' and z.get('dtype')=='bfloat16'); w=next(z for z in x['args'] if z.get('role')=='weight' and z.get('dtype')=='float8_e4m3fn');mac+=math.prod(a['shape'][:-1])*math.prod(w['shape']);ins+=sum(v for k,v in x['counters'].items() if k.startswith('core_') and k.endswith('_instructions'))
  reported=next(z for z in r['steps'] if z['kind']==kind)
  row['steps'].append(dict(kind=kind,launches=len(xs),device_cycles=sum(x['device_cycles'] for x in xs),code_loads=sum(x['code_load_count'] for x in xs),code_bytes=sum(x['code_upload_bytes'] for x in xs),evictions=sum(x['evicted'] for x in xs),host_read_calls=reported['transfers_inside_step']['host_read_calls'],fp8_launches=len(fs),fp8_macs=mac,fp8_instructions=ins,fp8_instructions_per_mac=ins/mac,fp8_cycles=sum(x['device_cycles'] for x in fs)))
 result['routes'].append(row)
a=load_file(str(roots[0]/'logits.safetensors'));b=load_file(str(roots[1]/'logits.safetensors'))
result['logits']={k:dict(elements=a[k].numel(),bit_mismatches=int((a[k].contiguous().view(torch.int16)!=b[k].contiguous().view(torch.int16)).sum())) for k in a}
result['caveat']='reduced-depth output compared against TLM baseline, not independently against full CPU model; counters from completed events'
p=h/'r41_astage_model_compare_20261031.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
