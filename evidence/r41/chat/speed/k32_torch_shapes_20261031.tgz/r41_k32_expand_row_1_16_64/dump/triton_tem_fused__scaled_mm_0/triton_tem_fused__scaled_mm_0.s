    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s7, #4096                   // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s7, #0
    s.st.d       [s1, #0], s3
    .li       s3, #2147483647
    s.st.d       [s1, #8], s3
    s.st.d       [s1, #16], s3
    s.movz       s3, #64
    s.st.d       [s1, #48], s3
    s.movz       s3, #1
    s.st.d       [s1, #56], s3
    .li       s8, #68719476752
    s.st.d       [s1, #88], s8
    .li       s8, #7705171329024
    s.st.d       [s1, #104], s8
    fence.release.device
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, pid.x
    s.sub        s8, s3, s1
    s.min.s      s9, s8, s3
    s.cmp.lt     s8, s1, s7
    s.sub        s10, s7, s8
    s.cmp.lt     s8, s9, s7
    s.sub        s11, s7, s8
    s.xor        s8, s1, s10
    s.sub        s12, s8, s10
    s.xor        s8, s9, s11
    s.sub        s13, s8, s11
    s.addi       s8, s7, #0
    s.addi       s11, s7, #0
    s.cmp.eq     s14, s13, s3
    s.mov        s8, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s8, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s11, #1
    s.andi       s17, s15, #1
    s.shl        s15, s3, s14
    s.or         s18, s16, s17
    s.subi       s16, s14, #1
    s.cmp.geu    s17, s18, s13
    s.sub        s19, s7, s17
    s.and        s17, s13, s19
    s.and        s20, s15, s19
    s.sub        s15, s18, s17
    s.or         s17, s8, s20
    s.mov        s11, s15
    s.mov        s8, s17
    s.mov        s14, s16
    s.cmp.ge     s15, s14, s7
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s7, #0
    s.xor        s8, s11, s10
    s.cmp.lt     s11, s9, s7
    s.cmp.lt     s12, s7, s7
    s.sub        s13, s7, s11
    s.sub        s11, s7, s12
    s.xor        s12, s9, s13
    s.xor        s9, s7, s11
    s.sub        s14, s12, s13
    s.movz       s12, #1
    s.sub        s15, s8, s10
    s.sub        s8, s9, s11
    s.addi       s9, s7, #0
    s.cmp.eq     s10, s14, s12
    s.add        s16, s1, s15
    s.addi       s1, s7, #0
    s.mov        s9, s8
    br.nz        s10, sdiv_done_3
    s.movz       s10, #0
    s.movz       s15, #31
    s.mov        s9, s10
    s.addi       s10, s15, #0
sdiv_4:
    s.lshr       s15, s8, s10
    s.shli       s17, s1, #1
    s.andi       s18, s15, #1
    s.shl        s15, s12, s10
    s.or         s19, s17, s18
    s.subi       s17, s10, #1
    s.cmp.geu    s18, s19, s14
    s.sub        s20, s7, s18
    s.and        s18, s14, s20
    s.and        s21, s15, s20
    s.sub        s15, s19, s18
    s.or         s18, s9, s21
    s.mov        s1, s15
    s.mov        s9, s18
    s.mov        s10, s17
    s.cmp.ge     s15, s10, s7
    br.nz        s15, sdiv_4
sdiv_done_3:
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.rdspecial  s1, arg_base
    v.ld.b       v0, [s2, #0]
    s.addi       s8, s2, #0                      // row 1
    s.movz       s10, #16
    s.movz       s12, #32
    s.movz       s14, #48
    s.xor        s15, s11, s13
    v.splat      v1, s16
    s.xor        s11, s9, s15
    v.splat      v2, s7
    s.sub        s7, s11, s15
    v.iota       v3                              // arange(0, VLEN)
    s.mul        s9, s7, s10
    s.ld.d       s11, [s1, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s7
    v.movi       v5, #16
    v.iota       v6                              // arange(0, VLEN)
    s.andi       s1, s9, #15
    v.splat      v7, s9
    v.splat      v8, s1
    v.movi       v9, #32
    v.movi       v10, #48
    v.cmp.ge     p1, v1, v2
    v.cmp.ge     p1, v4, v2
    s.addi       s7, s11, #0
    v.add        v1, v7, v3
    v.st.w       [s7, #0], v0
    s.addi       s13, s7, #64
    s.addi       s15, s7, #128
    s.addi       s17, s7, #192
    s.addi       s18, s7, #256
    s.addi       s19, s7, #320
    v.add        v0, v8, v3
    v.add        v0, v3, v5
    v.add        v0, v6, v9
    v.add        v0, v6, v10
    v.ld.b       v0, [s8, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s7, #384
    v.ld.b       v0, [s8, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s7, #448
    v.ld.b       v0, [s8, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s7, #512
    v.ld.b       v0, [s8, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s7, #576
    v.ld.b       v0, [s8, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s7, #640
    v.ld.b       v0, [s8, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s7, #704
    v.ld.b       v0, [s8, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s7, #768
    v.ld.b       v0, [s8, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s7, #832
    v.ld.b       v0, [s8, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s7, #896
    s.addi       s20, s7, #960
    v.ld.b       v0, [s8, #0]
    v.st.w       [s19, #0], v0
    s.add        s7, s2, s10                     // the tile origin
    v.ld.b       v0, [s8, #0]
    v.st.w       [s13, #0], v0
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s13, s11, #1024
    v.ld.b       v0, [s8, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s7, #0                     // row 1
    v.ld.b       v0, [s8, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s13, #64
    v.ld.b       v0, [s8, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #128
    v.ld.b       v0, [s8, #0]
    s.addi       s8, s13, #192
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.addi       s19, s13, #256
    v.ld.b       v0, [s7, #0]
    s.addi       s7, s13, #320
    v.st.w       [s13, #0], v0
    v.ld.b       v0, [s15, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s13, #384
    v.ld.b       v0, [s15, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #448
    v.ld.b       v0, [s15, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s13, #512
    v.ld.b       v0, [s15, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s13, #576
    v.ld.b       v0, [s15, #0]
    v.st.w       [s7, #0], v0
    s.addi       s7, s13, #640
    v.ld.b       v0, [s15, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s13, #704
    v.ld.b       v0, [s15, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #768
    v.ld.b       v0, [s15, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s13, #832
    v.ld.b       v0, [s15, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s13, #896
    s.addi       s20, s13, #960
    v.ld.b       v0, [s15, #0]
    v.st.w       [s7, #0], v0
    s.add        s7, s2, s12                     // the tile origin
    v.ld.b       v0, [s15, #0]
    v.st.w       [s17, #0], v0
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s13, s11, #2048
    v.ld.b       v0, [s15, #0]
    v.st.w       [s18, #0], v0
    s.addi       s17, s7, #0                     // row 1
    v.ld.b       v0, [s15, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s13, #64
    v.ld.b       v0, [s15, #0]
    v.st.w       [s19, #0], v0
    s.addi       s18, s13, #128
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s13, #192
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.addi       s19, s13, #256
    v.ld.b       v0, [s7, #0]
    s.addi       s7, s13, #320
    v.st.w       [s13, #0], v0
    s.add        s20, s2, s14                    // the tile origin
    v.ld.b       v0, [s17, #0]
    v.st.w       [s8, #0], v0
    s.addi       s2, s13, #384
    v.ld.b       v0, [s17, #0]
    v.st.w       [s18, #0], v0
    s.addi       s8, s13, #448
    v.ld.b       v0, [s17, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s13, #512
    v.ld.b       v0, [s17, #0]
    v.st.w       [s19, #0], v0
    s.addi       s18, s13, #576
    v.ld.b       v0, [s17, #0]
    v.st.w       [s7, #0], v0
    s.addi       s7, s13, #640
    v.ld.b       v0, [s17, #0]
    v.st.w       [s2, #0], v0
    s.addi       s2, s13, #704
    v.ld.b       v0, [s17, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s13, #768
    v.ld.b       v0, [s17, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s13, #832
    v.ld.b       v0, [s17, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #896
    s.addi       s19, s13, #960
    v.ld.b       v0, [s17, #0]
    v.st.w       [s7, #0], v0
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s7, s11, #3072
    v.ld.b       v0, [s17, #0]
    v.st.w       [s2, #0], v0
    s.addi       s2, s20, #0                     // row 1
    v.ld.b       v0, [s17, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s7, #64
    v.ld.b       v0, [s17, #0]
    v.st.w       [s15, #0], v0
    s.addi       s13, s7, #128
    v.ld.b       v0, [s17, #0]
    v.st.w       [s18, #0], v0
    s.addi       s15, s7, #192
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s7, #256
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.addi       s18, s7, #320
    v.ld.b       v0, [s20, #0]
    s.addi       s19, s7, #384
    v.st.w       [s7, #0], v0
    v.ld.b       v0, [s2, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s7, #448
    v.ld.b       v0, [s2, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s7, #512
    v.ld.b       v0, [s2, #0]
    v.st.w       [s15, #0], v0
    s.addi       s15, s7, #576
    v.ld.b       v0, [s2, #0]
    v.st.w       [s17, #0], v0
    s.addi       s17, s7, #640
    v.ld.b       v0, [s2, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s7, #704
    v.ld.b       v0, [s2, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s7, #768
    v.ld.b       v0, [s2, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s7, #832
    v.ld.b       v0, [s2, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s7, #896
    s.addi       s20, s7, #960
    v.ld.b       v0, [s2, #0]
    v.st.w       [s15, #0], v0
    s.movz       s7, #0
    v.ld.b       v0, [s2, #0]
    v.st.w       [s17, #0], v0
    s.addi       s15, s11, #0
    v.ld.b       v0, [s2, #0]
    v.st.w       [s18, #0], v0
    s.addi       s17, s11, #4352                 // 1024 bytes of repack scratch
    v.ld.b       v0, [s2, #0]
    v.st.w       [s19, #0], v0
    s.addi       s18, s11, #64
    v.ld.b       v0, [s2, #0]
    v.st.w       [s8, #0], v0
    s.addi       s8, s17, #64
    v.ld.b       v0, [s2, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #128
    v.ld.b       v0, [s2, #0]
    s.addi       s2, s17, #128
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    w.def        w0, #16, #4                     // v16..v19
    mb.arm       s19, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s20, s11, #192
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s21, s1                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w0, d0, s21, s19
    mb.wait      s19
    w.def        w1, #20, #4                     // v20..v23
    mb.arm       s7, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s21, s17, #192
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s22, s1                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w1, d0, s22, s7
    mb.wait      s7
    w.def        w2, #24, #4                     // v24..v27
    mb.arm       s22, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s23, s1                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w2, d0, s23, s22
    mb.wait      s22
    w.def        w3, #28, #4                     // v28..v31
    mb.arm       s12, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s23, s11, #256
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s24, s1                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w3, d0, s24, s12
    mb.wait      s12
    v.ld.w       v0, [s15, #0]
    s.addi       s1, s17, #256
    s.addi       s14, s11, #320
    s.addi       s15, s17, #320
    v.st.b       [s17, #0], v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #384
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #384
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #448
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #448
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #512
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #512
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #576
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #576
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #640
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #640
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #704
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #704
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #768
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #768
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #832
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #832
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #896
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #896
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #960
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #960
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #1024
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #16
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1088
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #80
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #1152
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #144
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #1216
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #208
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #1280
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #272
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #1344
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #336
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1408
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #400
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #1472
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #464
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #1536
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #528
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #1600
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #592
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #1664
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #656
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1728
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #720
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #1792
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #784
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #1856
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #848
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #1920
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #912
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #1984
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #976
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #2048
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #32
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #2112
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #96
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #2176
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #160
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #2240
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #224
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #2304
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #288
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #2368
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #352
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #2432
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #416
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #2496
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #480
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #2560
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #544
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #2624
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #608
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #2688
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #672
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #2752
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #736
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #2816
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #800
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #2880
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #864
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #2944
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #928
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3008
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #992
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #3072
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #48
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #3136
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #112
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #3200
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #176
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #3264
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #240
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3328
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #304
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #3392
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #368
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #3456
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #432
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #3520
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #496
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #3584
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #560
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3648
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #624
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s11, #3712
    v.st.b       [s21, #0], v0
    s.addi       s21, s17, #688
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s11, #3776
    v.st.b       [s1, #0], v0
    s.addi       s1, s17, #752
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #3840
    v.st.b       [s15, #0], v0
    s.addi       s15, s17, #816
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s11, #3904
    v.st.b       [s8, #0], v0
    s.addi       s8, s17, #880
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3968
    v.st.b       [s2, #0], v0
    s.addi       s2, s17, #944
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #8
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s11, #4032
    s.addi       s24, s11, #5376                 // TensorMap 1: K-wide matrix repack
    v.cmp.lt     p1, v0, v1
    v.st.b       [s21, #0], v2
    s.addi       s11, s17, #1008
    v.ld.w       v0, [s23, #0]
    s.movz       s21, #16
    v.st.b       [s1, #0], v0
    s.movz       s1, #64
    v.ld.w       v0, [s14, #0]
    s.movz       s14, #1
    v.st.b       [s15, #0], v0
    .li       s15, #274877906960
    v.ld.w       v0, [s18, #0]
    .li       s18, #7705171329024
    v.st.b       [s8, #0], v0
    s.movz       s8, #0
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #8
    v.st.b       [s2, #0], v0
    v.ld.w       v0, [s20, #0]
    v.st.b       [s11, #0], v0
    fence.acq_rel.device
    s.st.d       [s24, #0], s17
    s.st.d       [s24, #8], s21
    s.st.d       [s24, #16], s1
    s.st.d       [s24, #48], s1
    s.st.d       [s24, #56], s14
    s.st.d       [s24, #88], s15
    s.st.d       [s24, #104], s18
    fence.release.device
    td.load      d1, [s24]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w4, #32, #16                    // v32..v47
    mb.arm       s1, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    // K-wide matrix repack: one tile into a window (ISA sec 9E)
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w4, d1, s14, s1
    mb.wait      s1
    w.def        w5, #48, #8                     // v48..v55
    w.def        w6, #56, #8                     // v56..v63
    v.shuffle.up v0, v33, s13
    @p1 v.sel        v1, v32, v0
    v.mov        v48, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v35, s13
    @p1 v.sel        v1, v34, v0
    v.mov        v49, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v57, v17                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v37, s13
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #8
    @p1 v.sel        v4, v36, v0
    v.cmp.lt     p2, v1, v2
    v.mov        v50, v4                         // hand off through the shared window (sec 7.3)
    v.mov        v58, v18                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v39, s13
    s.movz       s2, #8
    @p1 v.sel        v1, v38, v0
    v.mov        v51, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v41, s13
    @p1 v.sel        v1, v40, v0
    v.mov        v52, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v60, v20                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v43, s13
    @p1 v.sel        v1, v42, v0
    v.mov        v53, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v45, s13
    @p1 v.sel        v1, v44, v0
    v.mov        v54, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.shuffle.up v0, v47, s13
    @p1 v.sel        v1, v46, v0
    v.mov        v55, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v63, v23                        // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s8, b5, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v48, v56, s8
    mb.wait      s8
    w.def        w7, #16, #8                     // v16..v23
    w.def        w8, #48, #8                     // v48..v55
    v.shuffle.down v0, v32, s2
    @p2 v.sel        v1, v0, v33
    v.mov        v16, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v48, v24                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v0, v34, s2
    @p2 v.sel        v1, v0, v35
    v.mov        v17, v1                         // hand off through the shared window (sec 7.3)
    v.mov        v49, v25                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v0, v36, s2
    v.movi       v1, #0
    s.mul        s11, s16, s10
    @p2 v.sel        v2, v0, v37
    v.mov        v18, v2                         // hand off through the shared window (sec 7.3)
    v.mov        v50, v26                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v0, v38, s2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s13, #0
    s.muli       s14, s9, #2                     // a runtime tile origin, x2
    @p2 v.sel        v2, v0, v39
    v.splat      v0, s11
    v.mov        v19, v2                         // hand off through the shared window (sec 7.3)
    v.mov        v51, v27                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v2, v40, s2
    s.add        s15, s13, s11                   // the tile origin
    v.splat      v4, s3
    @p2 v.sel        v5, v2, v41
    s.add        s3, s13, s9                     // the tile origin
    v.splat      v2, s15
    v.mov        v20, v5                         // hand off through the shared window (sec 7.3)
    v.mov        v52, v28                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v5, v42, s2
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s3
    @p2 v.sel        v8, v5, v43
    v.splat      v5, s10
    v.add        v9, v6, v7
    v.mov        v21, v8                         // hand off through the shared window (sec 7.3)
    v.mov        v53, v29                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v6, v44, s2
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p3, v9, v5
    @p2 v.sel        v2, v6, v45
    s.add        s3, s6, s14                     // the tile origin
    p.and        p4, p1, p3
    v.mov        v22, v2                         // hand off through the shared window (sec 7.3)
    v.mov        v54, v30                        // hand off through the shared window (sec 7.3)
    v.shuffle.down v2, v46, s2
    s.movz       s2, #1
    s.addi       s6, s15, #1
    @p2 v.sel        v5, v2, v47
    v.splat      v2, s6
    s.movz       s6, #2
    v.mov        v23, v5                         // hand off through the shared window (sec 7.3)
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s9, b6, #0, #1                  // 0 arrival(s), 1 operation(s)
    v.cmp.lt     p1, v2, v4
    p.and        p2, p1, p3
    m.mma.dp.async.k32.e4m3 a0, v16, v48, s9
    mb.wait      s9
    s.ld.w       s10, [s4, #0]                   // one element, not a vector
    s.addi       s4, s15, #2
    s.movz       s11, #3
    v.splat      v2, s4
    v.add        v5, v0, v3
    s.ld.w       s4, [s5, #0]                    // one element, not a vector
    v.splat      v0, s10
    a.vread      v3, a0, s13
    vf.add       v5, v3, v1
    v.splat      v3, s4
    s.addi       s4, s15, #3
    vf.mul       v6, v0, v3
    vf.mul       v7, v0, v3
    vf.mul       v8, v0, v3
    vf.mul       v9, v0, v3
    v.splat      v10, s4
    vf.mul       v11, v5, v6
    s.movz       s4, #4
    vf.cvt.f32.bf16 v5, v11
    vf.mul       v6, v0, v3
    s.addi       s5, s15, #4
    s.movz       s10, #5
    @p4 v.st.h       [s3, #0], v5
    a.vread      v5, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p3
    vf.add       v2, v5, v1
    v.splat      v5, s5
    s.addi       s2, s15, #5
    vf.mul       v11, v2, v7
    vf.mul       v2, v0, v3
    vf.cvt.f32.bf16 v7, v11
    s.movz       s5, #6
    @p2 v.st.h       [s3, #0], v7
    a.vread      v7, a0, s6
    v.cmp.lt     p1, v10, v4
    p.and        p2, p1, p3
    vf.add       v10, v7, v1
    v.splat      v7, s2
    s.addi       s2, s15, #6
    vf.mul       v11, v10, v8
    vf.mul       v8, v0, v3
    vf.cvt.f32.bf16 v10, v11
    s.movz       s6, #7
    @p4 v.st.h       [s3, #0], v10
    a.vread      v10, a0, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p3
    vf.add       v5, v10, v1
    v.splat      v10, s2
    s.addi       s2, s15, #7
    vf.mul       v11, v5, v9
    vf.mul       v5, v0, v3
    vf.cvt.f32.bf16 v9, v11
    s.movz       s11, #8
    @p2 v.st.h       [s3, #0], v9
    a.vread      v9, a0, s4
    v.cmp.lt     p1, v7, v4
    p.and        p2, p1, p3
    vf.add       v7, v9, v1
    v.splat      v9, s2
    s.addi       s2, s15, #8
    vf.mul       v11, v7, v6
    vf.mul       v6, v0, v3
    vf.cvt.f32.bf16 v7, v11
    s.movz       s4, #9
    @p4 v.st.h       [s3, #0], v7
    a.vread      v7, a0, s10
    v.cmp.lt     p1, v10, v4
    p.and        p4, p1, p3
    vf.add       v10, v7, v1
    v.splat      v7, s2
    s.addi       s2, s15, #9
    vf.mul       v11, v10, v2
    vf.mul       v2, v0, v3
    vf.cvt.f32.bf16 v10, v11
    s.movz       s10, #10
    @p2 v.st.h       [s3, #0], v10
    a.vread      v10, a0, s5
    v.cmp.lt     p1, v9, v4
    p.and        p2, p1, p3
    vf.add       v9, v10, v1
    v.splat      v10, s2
    s.addi       s2, s15, #10
    vf.mul       v11, v9, v8
    vf.mul       v8, v0, v3
    vf.cvt.f32.bf16 v9, v11
    s.movz       s5, #11
    @p4 v.st.h       [s3, #0], v9
    a.vread      v9, a0, s6
    v.cmp.lt     p1, v7, v4
    p.and        p4, p1, p3
    vf.add       v7, v9, v1
    v.splat      v9, s2
    s.addi       s2, s15, #11
    vf.mul       v11, v7, v5
    vf.mul       v5, v0, v3
    vf.cvt.f32.bf16 v7, v11
    s.movz       s6, #12
    @p2 v.st.h       [s3, #0], v7
    a.vread      v7, a0, s11
    v.cmp.lt     p1, v10, v4
    p.and        p2, p1, p3
    vf.add       v10, v7, v1
    v.splat      v7, s2
    s.addi       s2, s15, #12
    vf.mul       v11, v10, v6
    vf.mul       v6, v0, v3
    vf.cvt.f32.bf16 v10, v11
    s.movz       s11, #13
    @p4 v.st.h       [s3, #0], v10
    a.vread      v10, a0, s4
    v.cmp.lt     p1, v9, v4
    p.and        p4, p1, p3
    vf.add       v9, v10, v1
    v.splat      v10, s2
    s.addi       s2, s15, #13
    vf.mul       v11, v9, v2
    vf.mul       v2, v0, v3
    vf.cvt.f32.bf16 v9, v11
    s.movz       s4, #14
    @p2 v.st.h       [s3, #0], v9
    a.vread      v9, a0, s10
    v.cmp.lt     p1, v7, v4
    p.and        p2, p1, p3
    vf.add       v7, v9, v1
    v.splat      v9, s2
    s.addi       s2, s15, #14
    vf.mul       v11, v7, v8
    vf.mul       v7, v0, v3
    vf.cvt.f32.bf16 v8, v11
    s.movz       s10, #15
    @p4 v.st.h       [s3, #0], v8
    a.vread      v8, a0, s5
    v.cmp.lt     p1, v10, v4
    p.and        p4, p1, p3
    vf.add       v10, v8, v1
    v.splat      v8, s2
    vf.mul       v11, v0, v3
    s.addi       s2, s15, #15
    vf.mul       v0, v10, v5
    v.splat      v3, s2
    vf.cvt.f32.bf16 v5, v0
    @p2 v.st.h       [s3, #0], v5
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v9, v4
    p.and        p2, p1, p3
    vf.add       v5, v0, v1
    vf.mul       v0, v5, v6
    vf.cvt.f32.bf16 v5, v0
    @p4 v.st.h       [s3, #0], v5
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v8, v4
    p.and        p4, p1, p3
    vf.add       v5, v0, v1
    vf.mul       v0, v5, v2
    vf.cvt.f32.bf16 v2, v0
    @p2 v.st.h       [s3, #0], v2
    a.vread      v0, a0, s4
    v.cmp.lt     p1, v3, v4
    p.and        p2, p1, p3
    vf.add       v2, v0, v1
    vf.mul       v0, v2, v7
    vf.cvt.f32.bf16 v2, v0
    @p4 v.st.h       [s3, #0], v2
    a.vread      v0, a0, s10
    vf.add       v2, v0, v1
    vf.mul       v0, v2, v11
    vf.cvt.f32.bf16 v1, v0
    @p2 v.st.h       [s3, #0], v1
    exit
    exit
