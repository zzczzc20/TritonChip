module miter(input [2:0] way_claimed,input [23:0] keys,input [2:0] dead);
localparam WAYS=3,WAY_W=2,VICTIM_LEAVES=4,VICTIM_RECORD_W=10+WAY_W;
wire [VICTIM_RECORD_W-1:0] victim_tree [0:2*VICTIM_LEAVES-2];
genvar rank_way,rank_node;
generate for(rank_way=0;rank_way<VICTIM_LEAVES;rank_way=rank_way+1)begin
 if(rank_way<WAYS)begin
  wire [7:0] rank_key=keys[rank_way*8+:8];wire is_dead=dead[rank_way];
  assign victim_tree[VICTIM_LEAVES-1+rank_way] =
                    way_claimed[rank_way] ? {VICTIM_RECORD_W{1'b1}} :
                    {1'b0,rank_key,rank_way[WAY_W-1:0],is_dead};
 end else assign victim_tree[VICTIM_LEAVES-1+rank_way]={VICTIM_RECORD_W{1'b1}};
end
for(rank_node=0;rank_node<VICTIM_LEAVES-1;rank_node=rank_node+1)begin
 assign victim_tree[rank_node] =
                (victim_tree[2*rank_node+1] <= victim_tree[2*rank_node+2]) ?
                 victim_tree[2*rank_node+1] : victim_tree[2*rank_node+2];
end endgenerate
reg ok,chosen_dead;reg [WAY_W-1:0] chosen;reg [7:0] best;integer i;
always @*begin
 ok=0;chosen_dead=0;chosen=0;best=8'hff;
 for(i=0;i<WAYS;i=i+1)if(!way_claimed[i] && (!ok || keys[i*8+:8]<best))begin
  ok=1;chosen=i;chosen_dead=dead[i];best=keys[i*8+:8];
 end
 assert(ok==!victim_tree[0][VICTIM_RECORD_W-1]);
 if(ok)begin assert(chosen==victim_tree[0][WAY_W:1]);assert(chosen_dead==victim_tree[0][0]);end
end
endmodule
