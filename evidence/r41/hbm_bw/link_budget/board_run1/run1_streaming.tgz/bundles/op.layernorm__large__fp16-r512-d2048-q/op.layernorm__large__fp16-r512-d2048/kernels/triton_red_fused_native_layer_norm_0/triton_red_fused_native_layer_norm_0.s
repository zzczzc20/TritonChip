    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #2048
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.splat      v4, s4
    v.iota       v4                              // arange(0, VLEN)
    s.ld.d       s8, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.addi       s9, s2, #0
    s.ld.d       s10, [s1, #24]                  // out_ptr2: device_ptr64 at arg_base+24
    v.mov        v1, v0
    v.mov        v2, v0
    v.mov        v3, v0
for_1:
    s.cmp.ge     s1, s9, s5
    br.nz        s1, endfor_2
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s1, s4, s5
    vf.add       v6, v3, v5
    v.splat      v7, s9
    v.movi       v8, #2048
    v.add        v9, v7, v4
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    s.add        s11, s9, s1
    .li       s12, #1065353216
    v.splat      v10, s12                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s12, s11, #1                    // element offset -> bytes (x2)
    v.cmp.lt     p1, v9, v8
    s.add        s11, s3, s12                    // &in_ptr0[...]
    v.splat      v8, s9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s11, #0]
    v.splat      v12, s2
    v.movi       v13, #0
    v.cmp.eq     p2, v8, v12
    @p2 v.sel        v8, v5, v6
    v.movi       v5, #0
    vf.cvt.f16.f32 v12, v11
    @p1 v.sel        v11, v8, v3
    v.movi       v8, #0
    v.splat      v14, s1
    s.add        s1, s9, s6
    s.movz       s11, #1
    v.add        v15, v9, v14
    vf.sub       v9, v12, v1
    vf.fms       v14, v6, v7, v10
    vf.fms       v6, v7, v14, v7
    vf.neg       v10, v6                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v6, v10, v7
    vf.mul       v7, v9, v6                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v6, v1, v7
    vf.sub       v7, v12, v6
    @p2 v.sel        v10, v12, v6
    @p1 v.sel        v6, v10, v1
    vf.mul       v10, v9, v7
    v.mov        v13, v6
    vf.add       v6, v2, v10
    @p2 v.sel        v7, v0, v6
    @p1 v.sel        v6, v7, v2
    v.mov        v5, v6
    v.mov        v8, v11
    v.mov        v1, v13
    v.mov        v2, v5
    v.mov        v3, v8
    s.mov        s9, s1
    br.nz        s11, for_1
endfor_2:
    v.extract    s1, v1, #0
    v.splat      v0, s1
    v.extract    s1, v1, #1
    v.splat      v5, s1
    v.extract    s1, v1, #2
    v.splat      v6, s1
    v.extract    s1, v1, #3
    v.splat      v7, s1
    v.extract    s1, v1, #4
    v.splat      v8, s1
    v.extract    s1, v1, #5
    v.splat      v9, s1
    v.extract    s1, v1, #6
    v.splat      v10, s1
    v.extract    s1, v1, #7
    v.splat      v11, s1
    v.extract    s1, v1, #8
    v.splat      v12, s1
    v.extract    s1, v1, #9
    v.splat      v13, s1
    v.extract    s1, v1, #10
    v.splat      v14, s1
    v.extract    s1, v1, #11
    v.splat      v15, s1
    v.extract    s1, v1, #12
    v.splat      v16, s1
    v.extract    s1, v1, #13
    v.splat      v17, s1
    v.extract    s1, v1, #14
    v.splat      v18, s1
    v.extract    s1, v1, #15
    v.splat      v1, s1
    v.extract    s1, v2, #0
    v.splat      v19, s1
    v.extract    s1, v2, #1
    v.splat      v20, s1
    v.extract    s1, v2, #2
    v.splat      v21, s1
    v.extract    s1, v2, #3
    v.splat      v22, s1
    v.extract    s1, v2, #4
    v.splat      v23, s1
    v.extract    s1, v2, #5
    v.splat      v24, s1
    v.extract    s1, v2, #6
    v.splat      v25, s1
    v.extract    s1, v2, #7
    v.splat      v26, s1
    v.extract    s1, v2, #8
    v.splat      v27, s1
    v.extract    s1, v2, #9
    v.splat      v28, s1
    v.extract    s1, v2, #10
    v.splat      v29, s1
    v.extract    s1, v2, #11
    v.splat      v30, s1
    v.extract    s1, v2, #12
    v.splat      v31, s1
    v.extract    s1, v2, #13
    v.splat      v32, s1
    v.extract    s1, v2, #14
    v.splat      v33, s1
    v.extract    s1, v2, #15
    v.splat      v2, s1
    v.extract    s1, v3, #0
    v.splat      v34, s1
    v.extract    s1, v3, #1
    v.splat      v35, s1
    v.extract    s1, v3, #2
    v.splat      v36, s1
    v.extract    s1, v3, #3
    v.splat      v37, s1
    v.extract    s1, v3, #4
    v.splat      v38, s1
    v.extract    s1, v3, #5
    v.splat      v39, s1
    v.extract    s1, v3, #6
    v.splat      v40, s1
    v.extract    s1, v3, #7
    v.splat      v41, s1
    v.extract    s1, v3, #8
    v.splat      v42, s1
    v.extract    s1, v3, #9
    v.splat      v43, s1
    v.extract    s1, v3, #10
    v.splat      v44, s1
    v.extract    s1, v3, #11
    v.splat      v45, s1
    v.extract    s1, v3, #12
    v.splat      v46, s1
    v.extract    s1, v3, #13
    v.splat      v47, s1
    v.extract    s1, v3, #14
    v.splat      v48, s1
    v.extract    s1, v3, #15
    v.splat      v3, s1
    vf.cmp.eq    p1, v0, v5
    vf.sub       v49, v5, v0
    v.movi       v5, #0
    @p1 v.sel        v50, v5, v49
    vf.add       v49, v34, v35
    vf.cmp.eq    p1, v49, v5
    v.rcp.approx v51, v49                        // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v52, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v53, v49, v51, v52
    vf.fms       v54, v51, v53, v51
    vf.neg       v53, v54                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v53, v53
    @p2 v.sel        v54, v53, v51
    vf.mul       v51, v35, v54                   // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v35, v5, v51
    vf.mul       v51, v50, v35
    vf.add       v53, v0, v51
    vf.add       v0, v19, v20
    vf.mul       v19, v50, v50
    vf.mul       v20, v19, v34
    vf.mul       v19, v20, v35
    vf.add       v20, v0, v19
    vf.cmp.eq    p1, v53, v6
    vf.sub       v0, v6, v53
    @p1 v.sel        v6, v5, v0
    vf.add       v0, v49, v36
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v19, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v0, v19, v52
    vf.fms       v35, v19, v34, v19
    vf.neg       v34, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v34, v34
    @p2 v.sel        v35, v34, v19
    vf.mul       v19, v36, v35                   // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v34, v5, v19
    vf.mul       v19, v6, v34
    vf.add       v35, v53, v19
    vf.add       v19, v20, v21
    vf.mul       v20, v6, v6
    vf.mul       v6, v20, v49
    vf.mul       v20, v6, v34
    vf.add       v6, v19, v20
    vf.cmp.eq    p1, v35, v7
    vf.sub       v19, v7, v35
    @p1 v.sel        v7, v5, v19
    vf.add       v19, v0, v37
    vf.cmp.eq    p1, v19, v5
    v.rcp.approx v20, v19                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v21, v19, v20, v52
    vf.fms       v34, v20, v21, v20
    vf.neg       v21, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v21, v21
    @p2 v.sel        v34, v21, v20
    vf.mul       v20, v37, v34                   // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v21, v5, v20
    vf.mul       v20, v7, v21
    vf.add       v34, v35, v20
    vf.add       v20, v6, v22
    vf.mul       v6, v7, v7
    vf.mul       v7, v6, v0
    vf.mul       v0, v7, v21
    vf.add       v6, v20, v0
    vf.cmp.eq    p1, v34, v8
    vf.sub       v0, v8, v34
    @p1 v.sel        v7, v5, v0
    vf.add       v0, v19, v38
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v8, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v20, v0, v8, v52
    vf.fms       v21, v8, v20, v8
    vf.neg       v20, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v20, v20
    @p2 v.sel        v21, v20, v8
    vf.mul       v8, v38, v21                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v20, v5, v8
    vf.mul       v8, v7, v20
    vf.add       v21, v34, v8
    vf.add       v8, v6, v23
    vf.mul       v6, v7, v7
    vf.mul       v7, v6, v19
    vf.mul       v6, v7, v20
    vf.add       v7, v8, v6
    vf.cmp.eq    p1, v21, v9
    vf.sub       v6, v9, v21
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v0, v39
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v19, v6, v9, v52
    vf.fms       v20, v9, v19, v9
    vf.neg       v19, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v20, v19, v9
    vf.mul       v9, v39, v20                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v19, v5, v9
    vf.mul       v9, v8, v19
    vf.add       v20, v21, v9
    vf.add       v9, v7, v24
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v0
    vf.mul       v0, v8, v19
    vf.add       v7, v9, v0
    vf.cmp.eq    p1, v20, v10
    vf.sub       v0, v10, v20
    @p1 v.sel        v8, v5, v0
    vf.add       v0, v6, v40
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v9, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v0, v9, v52
    vf.fms       v19, v9, v10, v9
    vf.neg       v10, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v19, v10, v9
    vf.mul       v9, v40, v19                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v19, v20, v9
    vf.add       v9, v7, v25
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v10
    vf.add       v7, v9, v6
    vf.cmp.eq    p1, v19, v11
    vf.sub       v6, v11, v19
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v0, v41
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v41, v11                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v11, v19, v9
    vf.add       v9, v7, v26
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v0
    vf.mul       v0, v8, v10
    vf.add       v7, v9, v0
    vf.cmp.eq    p1, v11, v12
    vf.sub       v0, v12, v11
    @p1 v.sel        v8, v5, v0
    vf.add       v0, v6, v42
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v9, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v0, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v42, v12                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v12, v11, v9
    vf.add       v9, v7, v27
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v10
    vf.add       v7, v9, v6
    vf.cmp.eq    p1, v12, v13
    vf.sub       v6, v13, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v0, v43
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v43, v11                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v11, v12, v9
    vf.add       v9, v7, v28
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v0
    vf.mul       v0, v8, v10
    vf.add       v7, v9, v0
    vf.cmp.eq    p1, v11, v14
    vf.sub       v0, v14, v11
    @p1 v.sel        v8, v5, v0
    vf.add       v0, v6, v44
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v9, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v0, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v44, v12                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v12, v11, v9
    vf.add       v9, v7, v29
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v10
    vf.add       v7, v9, v6
    vf.cmp.eq    p1, v12, v15
    vf.sub       v6, v15, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v0, v45
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v45, v11                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v11, v12, v9
    vf.add       v9, v7, v30
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v0
    vf.mul       v0, v8, v10
    vf.add       v7, v9, v0
    vf.cmp.eq    p1, v11, v16
    vf.sub       v0, v16, v11
    @p1 v.sel        v8, v5, v0
    vf.add       v0, v6, v46
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v9, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v0, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v46, v12                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v12, v11, v9
    vf.add       v9, v7, v31
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v10
    vf.add       v7, v9, v6
    vf.cmp.eq    p1, v12, v17
    vf.sub       v6, v17, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v0, v47
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v47, v11                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v11, v12, v9
    vf.add       v9, v7, v32
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v0
    vf.mul       v0, v8, v10
    vf.add       v7, v9, v0
    vf.cmp.eq    p1, v11, v18
    vf.sub       v0, v18, v11
    @p1 v.sel        v8, v5, v0
    vf.add       v0, v6, v48
    vf.cmp.eq    p1, v0, v5
    v.rcp.approx v9, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v0, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v48, v12                    // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v10, v5, v9
    vf.mul       v9, v8, v10
    vf.add       v12, v11, v9
    vf.add       v9, v7, v33
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v10
    vf.add       v7, v9, v6
    vf.cmp.eq    p1, v12, v1
    vf.sub       v6, v1, v12
    @p1 v.sel        v1, v5, v6
    vf.add       v6, v0, v3
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v8, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v6, v8, v52
    vf.fms       v6, v8, v9, v8
    vf.neg       v9, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v6, v9, v8
    vf.mul       v8, v3, v6                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v3, v5, v8
    vf.mul       v5, v1, v3
    vf.add       v6, v12, v5
    vf.add       v5, v7, v2
    vf.mul       v2, v1, v1
    vf.mul       v1, v2, v0
    vf.mul       v0, v1, v3
    vf.add       v1, v5, v0
    v.movi       v0, #0
    vf.add       v2, v6, v0
    vf.add       v3, v1, v0
    s.addi       s1, s2, #0
for_3:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_4
    .li       s2, #1157627904
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #925353388
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    s.mul        s2, s4, s5
    v.splat      v6, s1
    v.movi       v7, #2048
    v.add        v8, v6, v4
    .li       s9, #1077936128
    v.splat      v6, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s9, s1, s2
    .li       s11, #3204448256
    v.splat      v9, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s11, s9, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v8, v7
    s.add        s9, s3, s11                     // &in_ptr0[...]
    s.shli       s12, s1, #1                     // element offset -> bytes (x2)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s9, #0]
    s.add        s9, s7, s12                     // &in_ptr1[...]
    v.extract    s13, v2, #0
    v.splat      v10, s13
    s.add        s13, s8, s12                    // &in_ptr2[...]
    v.splat      v11, s2
    vf.cvt.f16.f32 v12, v7
    s.add        s2, s10, s11                    // &out_ptr2[...]
    s.add        s11, s1, s6
    s.movz       s12, #1
    vf.sub       v7, v12, v10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s9, #0]
    v.add        v12, v8, v11
    vf.fms       v8, v0, v5, v52
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s13, #0]
    vf.cvt.f16.f32 v11, v10
    vf.fms       v10, v5, v8, v5
    vf.neg       v8, v10                         // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v10, v0
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v0, v8, v5
    vf.mul       v5, v3, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v5, v1
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v1, v1
    vf.mul       v8, v1, v9
    vf.fms       v9, v0, v5, v6
    vf.mul       v0, v8, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v5, v0, v1
    v.extract    s9, v5, #0
    v.splat      v0, s9
    vf.mul       v1, v7, v0
    vf.mul       v0, v1, v11
    vf.add       v1, v0, v10
    vf.cvt.f32.f16 v0, v1
    @p1 v.st.h       [s2, #0], v0
    s.mov        s1, s11
    br.nz        s12, for_3
endfor_4:
__rctx_next:
    exit
