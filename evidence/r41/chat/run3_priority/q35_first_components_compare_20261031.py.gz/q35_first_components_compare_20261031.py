#!/usr/bin/env python3
import json,os,select,sys
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home()
for pid in map(int,sys.argv[1:]):
 try:
  fd=os.pidfd_open(pid);p=select.poll();p.register(fd,select.POLLIN);p.poll();os.close(fd)
 except ProcessLookupError:pass
cdir=h/'r41_q35_first_components_cpu_20261031_diag';tdir=h/'r41_q35_first_components_tlm_20261031_diag'
c=json.loads((cdir/'result.json').read_text());t=json.loads((tdir/'result.json').read_text())
for k in ('input_ids','model','revision','chat_sha256'):
 if c[k]!=t[k]:raise ValueError('mismatch '+k)
a=load_file(str(cdir/'states.safetensors'));b=load_file(str(tdir/'states.safetensors'))
if set(a)!=set(b):raise ValueError('capture keys differ')
def cmp(x,y):
 if x.shape!=y.shape or x.dtype!=y.dtype:raise ValueError(f'shape or dtype mismatch {x.shape} {y.shape}')
 dt={2:torch.int16,4:torch.int32,8:torch.int64}.get(x.element_size())
 if dt is None:raise TypeError(str(x.dtype))
 f=x.float();g=y.float();d=(f-g).abs();return {'shape':list(x.shape),'elements':x.numel(),'bit_mismatches':int((x.view(dt)!=y.view(dt)).sum()),'relative_l2':float((f-g).norm()/f.norm().clamp_min(1e-30)),'max_abs':float(d.max())}
basecpu=load_file(str(h/'r41_q35_layers_cpu_20261031_diag/states.safetensors'))
basetlm=load_file(str(h/'r41_q35_first_headless_v2_tlm_20261031_diag/states.safetensors'))
out={'schema':'r41-q35-first-components-comparison/1','scope':'one-layer CPU vs DP TLM, graph hooks and truncation may alter results; not board acceptance','input_ids':c['input_ids'],'components':{k:cmp(a[k],b[k]) for k in sorted(a)},'instrumented_cpu_vs_full_cpu':{'embedding':cmp(basecpu['hidden_00'],a['embedding']),'first_layer':cmp(basecpu['hidden_01'],a['layer_output'])},'instrumented_tlm_vs_two_layer_tlm':{'embedding':cmp(basetlm['hidden_00'],b['embedding']),'first_layer':cmp(basetlm['hidden_01'],b['layer_output'])}}
(h/'r41_q35_first_components_compare_20261031.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
