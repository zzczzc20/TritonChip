    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #32
    s.movz       s5, #16
    s.movz       s6, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
    s.ld.d       s9, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s10, [s1, #16]                  // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    v.splat      v0, s7
    v.movi       v1, #0
    v.movi       v2, #8
    s.mul        s1, s7, s4
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v4, #32
    @p1 v.sel        v5, v3, v0
    v.movi       v0, #256
    s.addi       s11, s2, #0
    v.lshr       v3, v5, v2
    s.add        s12, s11, s1
    v.sub        v2, v1, v0
    v.sub        v5, v1, v3
    v.movi       v6, #0
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v3
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v0, v1
    v.mul        v1, v8, v4
    v.iota       v3                              // arange(0, VLEN)
    @p1 v.sel        v4, v2, v0
    v.extract    s12, v1, #0
    v.mov        v7, v6
    v.splat      v0, s12
    .li       s12, #1054295293
    v.splat      v1, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s12, s9, s1                     // &in_ptr1[...]
for_1:
    v.splat      v2, s11
    v.ld.h       v4, [s12, #0]
    v.add        v5, v2, v3
    v.add        v2, v5, v0
    v.ld.gather.h v5, [s3, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v2, v1
    vf.cvt.f16.f32 v2, v5
    vf.mul       v5, v2, v1
    vf.mul       v2, v5, v4
    vf.add       v7, v7, v2
    s.addi       s12, s12, #32                   // the next iteration's address
    s.add        s11, s11, s5
    s.cmp.lt     s1, s11, s4
    br.nz        s1, for_1
endfor_2:
    vf.reduce.add.b v0, v7
    v.movi       v1, #0
    s.shli       s1, s7, #2                      // element offset -> bytes (x4)
    v.iota       v2                              // arange(0, VLEN)
    vf.add       v3, v0, v1
    v.splat      v0, s6
    s.add        s11, s10, s1                    // &out_ptr0[...]
    v.cmp.lt     p1, v2, v0
    @p1 v.st.w       [s11, #0], v3
__rctx_next:
    s.addi       s1, s7, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s8
    s.mov        s7, s1
    br.nz        s11, __rctx_program
    exit
