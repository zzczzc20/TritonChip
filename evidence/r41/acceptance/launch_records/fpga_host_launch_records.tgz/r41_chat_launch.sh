#!/bin/bash
# Lead-only: run Kimi's staged full-model chat queue (immutable 68b9191) with the venv-preserving interpreter wrapper.
export TNCA_BOARD=u280
L=~/r41_chat_launch.log
U=/sys/bus/pci/devices/0000:04:00.1/xclbinuuid; WANT=49964b17-e0b4-5bd2-dd40-7fc37b1205d3
[ "$(cat $U)" = "$WANT" ] || { echo "$(date -u +%FT%TZ) card holds $(cat $U), not the 100 MHz image; not running" >> $L; exit 5; }
echo "$(date -u +%FT%TZ) starting the chat queue (it waits for 15 idle minutes itself)" >> $L
cd ~/r41_chat_68b9191 || exit 6
~/bin/torchenv-python tools/performance_harness/launches/acceptance_queue.py --root "$PWD" --out ~/r41_chat_68b9191_out --python ~/bin/torchenv-python --budget-seconds 10800 --manifest spec/r41/chat/s2-qwen-chat.json > ~/r41_chat_68b9191_out.log 2>&1
echo "$(date -u +%FT%TZ) chat queue exit $?" >> $L
