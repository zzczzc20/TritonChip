import subprocess,json
from pathlib import Path
r=Path.cwd();out=r/"quick_amo"
args=['iverilog', '-g2012', '-I', 'rtl/common', '-s', 'tb_nuca_slice', '-Ptb_nuca_slice.SETS=32', '-Ptb_nuca_slice.SET_W=5', '-Ptb_nuca_slice.WAYS=8', '-Ptb_nuca_slice.WAY_W=3', '-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1', '-Ptb_nuca_slice.AMO_TRAFFIC=1', '-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1', '-o', '/home/zhongchun/r40_r4_functional_v2_20261017/quick_amo/test.vvp', 'rtl/nuca/tnca_nuca_slice.v', 'tb/common/tnca_dram_model.v', 'tb/nuca/tb_nuca_slice.v']
p=subprocess.run(args,capture_output=True,text=True);(out/"build.log").write_text(p.stdout+p.stderr);assert p.returncode==0
p=subprocess.run(["vvp",str(out/"test.vvp"),"+nreq=4000","+seed=23","+min_wb=1"],capture_output=True,text=True,timeout=180);text=p.stdout+p.stderr;(out/"run.log").write_text(text);assert p.returncode==0 and "PASS" in text.splitlines() and "FATAL" not in text and "FAIL" not in text,text
(out/"report.json").write_text(json.dumps(dict(status="functional-pass",scope="numeric oracle plus cycle miter, no physical or gate credit",stdout=text),indent=2)+"\n")
