    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #1024
    s.movz       s4, #2
    s.ld.d       s5, [s2, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.addi       s6, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s7, #16
    s.ld.d       s8, [s2, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    .li       s9, #4294967296
    s.addi       s10, s3, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #1024
    s.movz       s11, #2
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s12, [s2, #16]                  // in_ptr1: device_ptr64 at arg_base+16
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s2, #0
    s.st.d       [s6, #0], s5
    s.movz       s2, #0
    s.st.d       [s6, #8], s1
    s.movz       s1, #16
    s.st.d       [s6, #48], s4
    .li       s2, #4294967296
    s.st.d       [s6, #88], s7
    s.movz       s4, #0
    s.st.d       [s6, #104], s9
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #1024
    s.st.d       [s10, #0], s8
    s.movz       s7, #16
    s.st.d       [s10, #8], s3
    s.addi       s3, s4, #0
    s.st.d       [s10, #48], s11
    s.st.d       [s10, #88], s1
    s.st.d       [s10, #104], s2
    td.load      d1, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s3, s6
    br.nz        s1, endfor_2
    s.muli       s1, s3, #2
    v.splat      v0, s3
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s2, #1024
    s.muli       s9, s3, #2
    v.splat      v4, s3
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s10, #1024
    v.add        v6, v0, v3
    v.movi       v0, #0
    v.splat      v3, s2
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s10
    v.cmp.ge     p1, v6, v0
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.add        s2, s5, s1
    p.and        p5, p1, p2
    s.add        s1, s8, s9
    p.and        p1, p3, p4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v0, [s2, #0]
    v.splat      v3, s3
    v.movi       v4, #1024
    v.add        v5, v3, v2
    v.movi       v3, #0
    v.cmp.lt     p2, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s1, #0]
    vf.cvt.f16.f32 v5, v0
    s.add        s1, s3, s7
    s.movz       s2, #1
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v5, v0
    vf.mul       v0, v4, v4
    vf.add       v4, v1, v0
    @p2 v.sel        v0, v4, v1
    v.mov        v3, v0
    v.mov        v1, v3
    s.mov        s3, s1
    br.nz        s2, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s4, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s6
    br.nz        s2, endfor_4
    .li       s2, #1149239296
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #925353388
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s2, s1, #2
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s3, #1024
    s.muli       s4, s1, #2
    v.splat      v8, s1
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s9, #1024
    v.add        v10, v6, v7
    v.movi       v6, #0
    v.add        v7, v8, v9
    v.splat      v8, s3
    v.cmp.ge     p1, v10, v6
    v.movi       v6, #0
    v.cmp.lt     p2, v10, v8
    v.splat      v8, s9
    v.cmp.ge     p3, v7, v6
    v.cmp.lt     p4, v7, v8
    s.add        s3, s5, s2
    p.and        p5, p1, p2
    s.add        s2, s8, s4
    p.and        p1, p3, p4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v6, [s3, #0]
    v.splat      v7, s1
    .li       s3, #1077936128
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v9, v0, v4, v1
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.add        v0, v7, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s2, #0]
    vf.fms       v7, v4, v9, v4
    v.movi       v9, #1024
    .li       s2, #3204448256
    v.splat      v10, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v11, v6
    vf.neg       v6, v7                          // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v7, v1
    s.add        s2, s12, s3                     // &in_ptr1[...]
    v.cmp.lt     p1, v0, v9
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v0, v6, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s2, #0]
    vf.mul       v4, v3, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v11, v7
    s.add        s2, s5, s3                      // &in_out_ptr0[...]
    s.add        s3, s1, s7
    vf.add       v6, v4, v5
    vf.cvt.f16.f32 v4, v1
    s.movz       s4, #1
    v.rsqrt.approx v1, v6                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v1, v1
    vf.mul       v7, v1, v10
    vf.fms       v9, v6, v5, v8
    vf.mul       v5, v7, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v6, v5, v1
    v.extract    s9, v6, #0
    v.splat      v1, s9
    vf.mul       v5, v0, v1
    vf.mul       v0, v5, v4
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s2, #0], v1
    s.mov        s1, s3
    br.nz        s4, for_3
endfor_4:
    exit
    exit
