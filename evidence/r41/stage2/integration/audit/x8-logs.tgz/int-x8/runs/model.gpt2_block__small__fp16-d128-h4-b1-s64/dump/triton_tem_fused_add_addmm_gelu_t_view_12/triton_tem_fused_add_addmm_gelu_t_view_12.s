    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #1024
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #1024
    s.movz       s18, #2
    s.ld.d       s19, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    .li       s20, #68719476752
    .li       s21, #8589934592
    s.ld.d       s22, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s23, #8
    s.movz       s24, #0
    s.ld.d       s24, [s2, #40]                  // out_ptr1: device_ptr64 at arg_base+40
    s.movz       s2, #0
    s.movz       s25, #0
    s.st.d       [s5, #0], s1
    s.movz       s1, #0
    s.st.d       [s5, #8], s7
    s.movz       s7, #0
    s.cmp.lt     s25, s23, s7
    s.st.d       [s5, #16], s8
    s.movz       s7, #0
    s.sub        s8, s7, s25
    s.movz       s7, #4
    s.st.d       [s5, #48], s9
    s.movz       s9, #1
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #0
    s.sub        s25, s1, s10
    s.movz       s1, #0
    s.st.d       [s5, #88], s11
    s.xor        s10, s4, s25
    s.sub        s11, s10, s25
    s.st.d       [s5, #104], s12
    s.lshri      s10, s11, #3
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s25, s8
    s.movz       s12, #0
    s.ld.d       s25, [s13, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s13, s25, s14                   // this context's own scratch
    s.xor        s14, s10, s5
    s.cmp.lt     s25, s4, s1
    s.sub        s1, s14, s5
    s.movz       s5, #0
    s.sub        s14, s7, s1
    s.muli       s7, s10, #8
    s.min.s      s10, s14, s9
    s.addi       s14, s13, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.cmp.lt     s13, s10, s2
    s.sub        s2, s5, s25
    s.movz       s5, #0
    s.st.d       [s14, #0], s16
    s.sub        s16, s12, s13
    s.movz       s12, #1
    s.xor        s13, s4, s2
    s.st.d       [s14, #8], s6
    s.xor        s6, s10, s16
    s.sub        s25, s13, s2
    s.st.d       [s14, #16], s15
    s.sub        s13, s6, s16
    s.xor        s6, s23, s8
    s.movz       s15, #0
    s.addi       s16, s5, #0
    s.st.d       [s14, #48], s17
    s.cmp.eq     s5, s13, s12
    s.sub        s12, s6, s8
    s.st.d       [s14, #56], s18
    s.sub        s6, s11, s7
    s.addi       s6, s15, #0
    s.st.d       [s14, #88], s20
    s.st.d       [s14, #104], s21
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s16, s25
    br.nz        s5, sdiv_done_1
    s.movz       s5, #0
    s.movz       s7, #31
    s.mov        s16, s5
    s.addi       s5, s7, #0
sdiv_2:
    s.lshr       s7, s25, s5
    s.shli       s8, s6, #1
    s.andi       s11, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s11
    s.movz       s8, #1
    s.cmp.geu    s11, s12, s13
    s.shl        s14, s8, s5
    s.sub        s8, s7, s11
    s.subi       s7, s5, #1
    s.and        s11, s13, s8
    s.and        s15, s14, s8
    s.sub        s8, s12, s11
    s.or         s11, s16, s15
    s.mov        s6, s8
    s.mov        s16, s11
    s.mov        s5, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s5, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s5, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s4, s5
    s.movz       s5, #0
    s.sub        s11, s7, s8
    s.movz       s7, #0
    s.xor        s8, s4, s11
    s.movz       s4, #0
    s.sub        s12, s8, s11
    s.cmp.lt     s8, s10, s5
    s.lshri      s5, s12, #3
    s.movz       s13, #0
    s.muli       s14, s5, #8
    s.sub        s5, s4, s8
    s.movz       s4, #0
    s.cmp.lt     s8, s23, s13
    s.xor        s13, s10, s5
    s.sub        s10, s12, s14
    s.movz       s12, #0
    s.xor        s14, s10, s11
    s.xor        s10, s6, s2
    s.sub        s6, s14, s11
    s.sub        s11, s12, s8
    s.cmp.lt     s8, s6, s7
    s.sub        s7, s13, s5
    s.sub        s12, s4, s8
    s.movz       s4, #0
    s.xor        s8, s6, s12
    s.movz       s6, #1
    s.sub        s13, s10, s2
    s.xor        s2, s23, s11
    s.sub        s10, s8, s12
    s.movz       s8, #0
    s.addi       s14, s4, #0
    s.cmp.eq     s4, s7, s6
    s.add        s6, s1, s13
    s.sub        s1, s2, s11
    s.addi       s1, s8, #0
    s.mov        s14, s10
    br.nz        s4, sdiv_done_3
    s.movz       s2, #0
    s.movz       s4, #31
    s.mov        s14, s2
    s.addi       s2, s4, #0
sdiv_4:
    s.lshr       s4, s10, s2
    s.shli       s8, s1, #1
    s.andi       s11, s4, #1
    s.movz       s4, #0
    s.or         s13, s8, s11
    s.movz       s8, #1
    s.cmp.geu    s11, s13, s7
    s.shl        s15, s8, s2
    s.sub        s8, s4, s11
    s.subi       s4, s2, #1
    s.and        s11, s7, s8
    s.and        s16, s15, s8
    s.sub        s8, s13, s11
    s.or         s11, s14, s16
    s.mov        s1, s8
    s.mov        s14, s11
    s.mov        s2, s4
    s.movz       s4, #0
    s.cmp.ge     s8, s2, s4
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s1, s12, s5
    s.movz       s2, #16
    s.xor        s4, s14, s1
    s.mul        s5, s6, s2
    s.sub        s7, s4, s1
    s.movz       s1, #0
    s.mul        s4, s7, s2
    v.splat      v0, s6
    s.andi       s6, s5, #63
    v.splat      v1, s1
    v.splat      v2, s7
    s.andi       s7, s4, #127
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s5
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s4
    v.splat      v1, s6
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s7
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #32
    s.addi       s10, s1, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_6
    s.mul        s1, s10, s2
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s10, s9
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s1, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s1
    mb.wait      s1
    s.mov        s10, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s4, #2                      // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s7, s4, #2                      // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s8, #0
    s.add        s9, s2, s4                      // the tile origin
    s.muli       s2, s4, #2                      // a runtime tile origin, x2
    s.add        s10, s8, s5                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    s.muli       s8, s5, #256                    // a runtime tile origin, x256
    v.splat      v2, s10
    v.add        v3, v0, v1
    v.splat      v0, s10
    v.splat      v1, s10
    s.add        s9, s19, s6                     // the tile origin
    s.muli       s6, s5, #256                    // a runtime tile origin, x256
    s.add        s12, s22, s7                    // the tile origin
    s.movz       s7, #64
    s.add        s13, s3, s2                     // the tile origin
    s.movz       s2, #128
    v.splat      v4, s7
    v.splat      v5, s2
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p2, v3, v5
    v.cmp.lt     p3, v0, v4
    s.add        s2, s9, s8                      // the tile origin
    s.add        s3, s12, s6                     // the tile origin
    p.and        p4, p1, p2
    p.and        p1, p3, p2
    s.movz       s6, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s2, #0]
    v.cmp.lt     p3, v1, v4
    p.and        p4, p3, p2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s7, s4, #2                      // a runtime tile origin, x2
    s.muli       s4, s5, #256                    // a runtime tile origin, x256
    s.addi       s5, s10, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s3, #0]
    a.vread      v2, a0, s6
    vf.cvt.f16.f32 v3, v0
    v.splat      v0, s10
    v.splat      v5, s5
    s.add        s5, s24, s7                     // the tile origin
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s13, #0]
    vf.cvt.f16.f32 v7, v1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p3, v5, v4
    s.add        s6, s5, s4                      // the tile origin
    vf.add       v0, v3, v7
    vf.cvt.f16.f32 v1, v6
    s.addi       s4, s10, #1
    s.addi       s5, s10, #1
    v.splat      v3, s4
    vf.add       v5, v2, v1
    v.splat      v1, s5
    p.and        p4, p1, p2
    s.addi       s4, s2, #256                    // row 1
    vf.cvt.f32.f16 v2, v5
    p.and        p1, p3, p2
    s.addi       s5, s3, #256                    // row 1
    s.movz       s7, #1
    vf.cvt.f16.f32 v5, v2
    s.addi       s8, s10, #1
    s.addi       s9, s10, #2
    v.splat      v2, s8
    vf.add       v6, v0, v5
    s.addi       s8, s10, #2
    v.splat      v0, s9
    s.addi       s9, s6, #256                    // row 1
    vf.cvt.f32.f16 v5, v6
    v.splat      v6, s8
    s.addi       s8, s2, #512                    // row 2
    s.addi       s12, s3, #512                   // row 2
    @p4 v.st.h       [s6, #0], v5
    v.cmp.lt     p3, v3, v4
    p.and        p4, p3, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s4, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s4, s10, #2
    v.splat      v1, s4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s5, #0]
    a.vread      v7, a0, s7
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.add       v0, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #2
    s.addi       s7, s10, #3
    v.splat      v2, s5
    vf.add       v5, v7, v3
    v.splat      v3, s7
    s.addi       s5, s6, #512                    // row 2
    s.addi       s7, s2, #768                    // row 3
    vf.cvt.f32.f16 v7, v5
    vf.cvt.f16.f32 v5, v7
    vf.add       v7, v0, v5
    vf.cvt.f32.f16 v0, v7
    @p4 v.st.h       [s9, #0], v0
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    s.addi       s9, s10, #3
    v.splat      v0, s9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s8, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s8, s10, #3
    s.addi       s9, s3, #768                    // row 3
    v.splat      v1, s8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s12, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s8, s10, #3
    s.addi       s12, s10, #4
    v.splat      v2, s8
    vf.add       v6, v7, v5
    v.splat      v5, s12
    s.addi       s8, s6, #768                    // row 3
    s.addi       s12, s2, #1024                  // row 4
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #4
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s7, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #4
    s.addi       s7, s3, #1024                   // row 4
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s9, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #4
    s.addi       s9, s10, #5
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s9
    s.addi       s5, s6, #1024                   // row 4
    s.addi       s9, s2, #1280                   // row 5
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    @p4 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s8, s10, #5
    v.splat      v0, s8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s8, s10, #5
    s.addi       s12, s3, #1280                  // row 5
    v.splat      v1, s8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s7, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s7, s10, #5
    s.addi       s8, s10, #6
    v.splat      v2, s7
    vf.add       v6, v7, v5
    v.splat      v5, s8
    s.addi       s7, s6, #1280                   // row 5
    s.addi       s8, s2, #1536                   // row 6
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #6
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s9, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #6
    s.addi       s9, s3, #1536                   // row 6
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s12, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #6
    s.addi       s12, s10, #7
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s12
    s.addi       s5, s6, #1536                   // row 6
    s.addi       s12, s2, #1792                  // row 7
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    @p4 v.st.h       [s7, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s7, s10, #7
    v.splat      v0, s7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s8, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s7, s10, #7
    s.addi       s8, s3, #1792                   // row 7
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s9, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s7, s10, #7
    s.addi       s9, s10, #8
    v.splat      v2, s7
    vf.add       v6, v7, v5
    v.splat      v5, s9
    s.addi       s7, s6, #1792                   // row 7
    s.addi       s9, s2, #2048                   // row 8
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #8
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s12, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #8
    s.addi       s12, s3, #2048                  // row 8
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s8, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #8
    s.addi       s8, s10, #9
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s8
    s.addi       s5, s6, #2048                   // row 8
    s.addi       s8, s2, #2304                   // row 9
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    @p4 v.st.h       [s7, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s7, s10, #9
    v.splat      v0, s7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s9, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s7, s10, #9
    s.addi       s9, s3, #2304                   // row 9
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s12, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s7, s10, #9
    s.addi       s12, s10, #10
    v.splat      v2, s7
    vf.add       v6, v7, v5
    v.splat      v5, s12
    s.addi       s7, s6, #2304                   // row 9
    s.addi       s12, s2, #2560                  // row 10
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #10
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s8, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #10
    s.addi       s8, s3, #2560                   // row 10
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s9, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #10
    s.addi       s9, s10, #11
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s9
    s.addi       s5, s6, #2560                   // row 10
    s.addi       s9, s2, #2816                   // row 11
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    @p4 v.st.h       [s7, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s7, s10, #11
    v.splat      v0, s7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s7, s10, #11
    s.addi       s12, s3, #2816                  // row 11
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s8, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s7, s10, #11
    s.addi       s8, s10, #12
    v.splat      v2, s7
    vf.add       v6, v7, v5
    v.splat      v5, s8
    s.addi       s7, s6, #2816                   // row 11
    s.addi       s8, s2, #3072                   // row 12
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #12
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s9, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #12
    s.addi       s9, s3, #3072                   // row 12
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s12, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #12
    s.addi       s12, s10, #13
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s12
    s.addi       s5, s6, #3072                   // row 12
    s.addi       s12, s2, #3328                  // row 13
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    @p4 v.st.h       [s7, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s7, s10, #13
    v.splat      v0, s7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s8, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s7, s10, #13
    s.addi       s8, s3, #3328                   // row 13
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s9, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v3, v8, v5
    vf.cvt.f16.f32 v5, v2
    s.addi       s7, s10, #13
    s.addi       s9, s10, #14
    v.splat      v2, s7
    vf.add       v6, v7, v5
    v.splat      v5, s9
    s.addi       s7, s6, #3328                   // row 13
    s.addi       s9, s2, #3584                   // row 14
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v3, v6
    vf.cvt.f32.f16 v3, v7
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s10, #14
    v.splat      v0, s5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s12, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s10, #14
    s.addi       s12, s3, #3584                  // row 14
    v.splat      v1, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s8, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s4, #14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v3, v6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.add       v5, v8, v3
    vf.cvt.f16.f32 v3, v2
    s.addi       s5, s10, #14
    s.addi       s8, s10, #15
    v.splat      v2, s5
    vf.add       v6, v7, v3
    v.splat      v3, s8
    s.addi       s5, s6, #3584                   // row 14
    s.addi       s8, s2, #3840                   // row 15
    vf.cvt.f32.f16 v7, v6
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v5, v6
    vf.cvt.f32.f16 v5, v7
    s.addi       s2, s10, #15
    s.addi       s15, s3, #3840                  // row 15
    v.splat      v6, s2
    @p4 v.st.h       [s7, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s2, s10, #15
    s.movz       s3, #15
    v.splat      v0, s2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s9, #0]
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s12, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v5, v1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.add       v1, v8, v5
    vf.cvt.f16.f32 v3, v2
    s.addi       s2, s10, #15
    s.addi       s4, s6, #3840                   // row 15
    v.splat      v2, s2
    vf.add       v5, v7, v3
    vf.cvt.f32.f16 v3, v5
    vf.cvt.f16.f32 v5, v3
    vf.add       v3, v1, v5
    vf.cvt.f32.f16 v1, v3
    @p4 v.st.h       [s5, #0], v1
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s8, #0]
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s15, #0]
    a.vread      v3, a0, s3
    vf.cvt.f16.f32 v5, v1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s13, #0]
    vf.cvt.f16.f32 v2, v0
    vf.add       v0, v5, v2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v3, v2
    vf.cvt.f32.f16 v2, v1
    vf.cvt.f16.f32 v1, v2
    vf.add       v2, v0, v1
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s4, #0], v0
__rctx_next:
    exit
