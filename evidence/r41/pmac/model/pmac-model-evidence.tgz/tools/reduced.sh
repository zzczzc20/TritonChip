#!/bin/bash
# Reduced-scope runs: V3 primary what-if (G=4 e4m3 only, pipe+1), pf 0/1, on 8 points; then graph identity controls.
W=~/r41-pmac-model-work
R="bash $W/tools/run_cfg.sh"
P="op.w8a8_linear/hbm/bf16-m128-k2560-n9216 op.w8a8_linear/hbm/bf16-m128-k2048-n6144 op.bf16_linear/hbm/bf16-m128-k2560-n9216 op.bf16_linear/hbm/bf16-m128-k2048-n6144 op.w8a8_linear/hbm/bf16-m1-k2560-n9216 op.w8a8_linear/hbm/bf16-m1-k2048-n6144 op.bf16_linear/hbm/bf16-m1-k2560-n9216 op.bf16_linear/hbm/bf16-m1-k2048-n6144"
$R c-g4-pf0-pipe5 g4-pf0-pipe5 14-19 5 $P
$R c-g4-pf1-pipe5 g4-pf1-pipe5 14-19 5 $P
echo REDUCED-DONE > $W/runs/reduced.done
