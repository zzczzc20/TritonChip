source ~/tc_env/env.sh
cd /home/zhongchun/r40_r4_functional_v2_20261017
python3 quick_amo.py > quick_amo/runner.log 2>&1
echo $? > quick_amo/runner.exit
