    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s1, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v0, v2, v1
    .li       s3, #82944
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0
    v.movi       v1, #63
    v.sub        v4, v0, v3
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v4, #64
    v.and        v7, v6, v1
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v0, v7
    v.movi       v6, #0
    @p2 v.sel        v8, v1, v7
    s.ld.d       s4, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    v.sub        v7, v6, v3
    v.cmp.lt     p2, v3, v6
    v.sub        v9, v1, v5
    v.cmp.lt     p3, v5, v1
    @p3 v.sel        v10, v9, v5
    v.movi       v9, #15
    v.movi       v11, #16
    v.and        v12, v10, v9
    v.movi       v9, #1024
    v.sub        v10, v1, v12
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    @p2 v.sel        v13, v7, v3
    @p3 v.sel        v3, v10, v12
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v7, #128
    v.add        v10, v8, v4
    v.movi       v12, #10
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v14, [s4, v10]             // index is in elements (ISA sec 9.1)
    v.lshr       v15, v13, v12
    v.sub        v12, v0, v4
    v.sub        v13, v6, v15
    v.cmp.lt     p3, v4, v0
    v.mul        v0, v5, v7
    vf.cvt.bf16.f32 v16, v14
    v.add        v14, v10, v0
    @p2 v.sel        v10, v13, v15
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s3, v14]             // index is in elements (ISA sec 9.1)
    v.sub        v14, v2, v4
    v.cmp.lt     p2, v4, v2
    v.sub        v2, v1, v11
    v.cmp.lt     p4, v11, v1
    v.sub        v1, v6, v9
    vf.cvt.bf16.f32 v15, v13
    @p3 v.sel        v13, v12, v4
    .li       s1, #1124073472
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v13, [s2, v5]              // index is in elements (ISA sec 9.1)
    v.add        v5, v8, v0
    v.cmp.lt     p3, v9, v6
    v.rcp.approx v0, v12                         // ISA 8.8: <= 2**-22 relative
    @p2 v.sel        v6, v14, v4
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v14, v2, v11
    .li       s1, #1077936128
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v14, [s3, v5]              // index is in elements (ISA sec 9.1)
    @p3 v.sel        v5, v1, v9
    v.mul        v1, v10, v7
    v.movi       v5, #10368
    v.add        v7, v8, v1
    v.mul        v1, v3, v5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s4, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v14
    v.add        v8, v7, v1
    vf.cvt.bf16.f32 v1, v3
    vf.fms       v3, v12, v0, v4
    vf.fms       v4, v0, v3, v0
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v4, v3, v0
    vf.mul       v0, v13, v4                     // a/y: faithful quotient
    vf.fms       v3, v0, v12, v13
    vf.fms       v7, v3, v4, v0
    vf.neg       v3, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v4, v3, v0
    vf.add       v0, v4, v6
    v.rsqrt.approx v3, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v3, v3
    vf.mul       v6, v3, v11
    vf.fms       v7, v0, v4, v2
    vf.mul       v0, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v2, v0, v3
    vf.mul       v0, v15, v2
    vf.mul       v3, v5, v2
    vf.mul       v2, v16, v0
    vf.mul       v0, v1, v3
    vf.neg       v1, v2
    vf.cvt.f32.bf16 v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s5, v8], v0
    @p1 v.st.scatter.h [s6, v8], v2
__rctx_next:
    exit
