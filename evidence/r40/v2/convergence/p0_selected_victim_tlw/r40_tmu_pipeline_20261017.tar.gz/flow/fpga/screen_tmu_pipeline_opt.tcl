# Paired module screen only: three actual caches plus shared TMU, no cores/HBM.
if {[llength $argv]!=2} {error "expected SOURCE_ROOT FRESH_OUTPUT"}
set root [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
if {[file exists $out]} {error "fresh output required"}
file mkdir $out
set_param general.maxThreads 2
set f [open $root/flow/fpga/tnca_range_grid_ooc.v r]
set wrapper [read $f]
close $f
set marker {// P1_CACHE_BOUNDARY_ATTRIBUTE: experiment varies only this instance attribute.}
if {[string first $marker $wrapper]<0} {error "cache boundary marker missing"}
set wrapper [string map [list $marker {(* KEEP_HIERARCHY = "yes" *)}] $wrapper]
set marker "input wire clk,"
if {[string first $marker $wrapper]<0} {error "clock port marker missing"}
set wrapper [string map [list $marker "input wire raw_clk,"] $wrapper]
set marker {wire [(76)-1:0] dco_cfg;}
if {[string first $marker $wrapper]<0} {error "clock insertion marker missing"}
set wrapper [string map [list $marker "wire clk;\nBUFG clock_buffer(.I(raw_clk),.O(clk));\n$marker"] $wrapper]
set f [open $out/wrapper.v {WRONLY CREAT EXCL}]
puts $f $wrapper
close $f
read_verilog -sv [list $root/rtl/nuca/tnca_tmu.v $root/rtl/nuca/tnca_nuca_slice.v $out/wrapper.v]
set_property include_dirs [list $root/rtl/common] [current_fileset]
synth_design -top tnca_range_grid_ooc -part xcu280-fsvh2892-2L-e \
    -mode out_of_context -flatten_hierarchy rebuilt \
    -generic {N=3 MAINTENANCE=1 FULL_LINE_TAG=1 TAG_W=5 DCO_REGISTERED_RANGES=1 SYNC_TAG_BANK=1 REGISTER_VICTIM_OWNER=1 BALANCED_VICTIM=1 SETS=32 SET_W=5}
create_clock -name clk -period 10 [get_ports raw_clk]
opt_design
report_utilization -hierarchical -file $out/optimized_utilization.rpt
report_timing -max_paths 30 -nworst 1 -path_type full_clock_expanded -file $out/optimized_paths.rpt
puts R40_TMU_PIPELINE_POSTOPT_DONE
exit
