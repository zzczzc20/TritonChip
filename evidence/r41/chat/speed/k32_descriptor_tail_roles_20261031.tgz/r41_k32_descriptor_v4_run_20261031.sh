#!/bin/bash
set -u
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES=
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=3600
cd "$HOME/r41_k32_descriptor_v4_20261031" || exit 1
root="$HOME/r41_k32_descriptor_v4_results_20261031";mkdir "$root" || exit 1
bad=0
for k in 33; do
 for mode in control candidate; do
  if [[ "$mode" == control ]];then export TNCA_FP8_FORCE_K32=0;else unset TNCA_FP8_FORCE_K32;fi
  export TNCA_TLM_OUT="$root/${mode}${k}_tlm"
  "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_descriptor_gemm_k32.py --k "$k" --out "$root/${mode}${k}" > "$root/${mode}${k}.log" 2>&1
  rc=$?;echo "$mode k=$k exit=$rc" | tee -a "$root/status.log";if [[ "$rc" != 0 ]];then bad=1;fi
 done
done
exit "$bad"
