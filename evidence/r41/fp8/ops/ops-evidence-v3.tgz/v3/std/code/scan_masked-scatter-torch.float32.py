# AOT ID: ['27_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/3m/c3mkcodq4u63zwyr2jp2ouw73hfptkprgdiga45aoye3qfxiw4h2.py
# Topologically Sorted Source Nodes: [masked_scatter, eq, getitem], Original ATen: [aten.masked_scatter, aten.eq, aten.unsqueeze]
# Source node to ATen node mapping:
#   eq => eq
#   getitem => unsqueeze
#   masked_scatter => _unsafe_masked_index, clone, clone_1, cumsum, expand, sub, view, view_1, view_2, view_3, where
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 300][300, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %cumsum : Tensor "i64[19200][1]tnca:0" = PlaceHolder[target=cumsum]
#   %arg2_1 : Tensor "f32[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg0_1 : Tensor "f32[1, 300, 64][19200, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %view_3 : Tensor "f32[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg2_1, [8192]), kwargs = {})
#   %eq : Tensor "b8[1, 300][300, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg1_1, 3), kwargs = {})
#   %unsqueeze : Tensor "b8[1, 300, 1][300, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%eq, 2), kwargs = {})
#   %expand : Tensor "b8[1, 300, 64][300, 1, 0]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 300, 64]), kwargs = {})
#   %clone_1 : Tensor "b8[1, 300, 64][19200, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "b8[19200][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [19200]), kwargs = {})
#   %clone : Tensor "b8[1, 300, 64][19200, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "b8[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [19200]), kwargs = {})
#   %cumsum : Tensor "i64[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cumsum.default](args = (%view, 0), kwargs = {})
#   %sub : Tensor "i64[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%cumsum, 1), kwargs = {})
#   %_unsafe_masked_index : Tensor "f32[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten._unsafe_masked_index.default](args = (%view_3, %view_2, [%sub], 0), kwargs = {})
#   %view_1 : Tensor "f32[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [19200]), kwargs = {})
#   %where : Tensor "f32[19200][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view_2, %_unsafe_masked_index, %view_1), kwargs = {})
#   return %cumsum,%where
triton_red_fused_eq_masked_scatter_unsqueeze_0 = async_compile.triton('triton_red_fused_eq_masked_scatter_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_eq_masked_scatter_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'r0_': 232800}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_eq_masked_scatter_unsqueeze_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 19200
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp6 = tl.full([1], 0, tl.int64)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0 // 64), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.full([1], 3, tl.int64)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2.to(tl.int64)
        tmp4 = tmp3.to(tl.int64)
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7, = tl.associative_scan((tmp5,), 0, _triton_helper_fn_add0)
        tmp8 = triton_helpers.select_one((tmp7), rbase == (RBLOCK - 1), dim=-1, keep_dims=True)
        tmp9 = tmp6 + tmp8
        tmp10 = tmp6 + tmp7
        tmp11 = tl.where(roffset > 0, tmp10, tmp7)
        tmp6 = tl.where(roffset > 0, tmp9, tmp8)
        tmp12 = tl.full([1], 1, tl.int64)
        tmp13 = tmp11 - tmp12
        tmp14 = tl.load(in_ptr1 + (tl.broadcast_to(tmp13, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp16 = tl.where(tmp2, tmp14, tmp15)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp16, r0_mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg2_1, arg0_1), ((1, 300), (128, 64), (1, 300, 64)), ((300, 1), (64, 1), (19200, 64, 1)), 'input')
        buf1 = empty_strided((19200, ), (1, ), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [masked_scatter, eq, getitem], Original ATen: [aten.masked_scatter, aten.eq, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_eq_masked_scatter_unsqueeze_0.run(arg1_1, arg2_1, arg0_1, buf1, 1, 19200, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        return (reinterpret_tensor(buf1, (1, 300, 64), (19200, 64, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 300, 64), (19200, 64, 1), device='tnca:0', dtype=torch.float32)
    arg1_1 = rand_strided((1, 300), (300, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
