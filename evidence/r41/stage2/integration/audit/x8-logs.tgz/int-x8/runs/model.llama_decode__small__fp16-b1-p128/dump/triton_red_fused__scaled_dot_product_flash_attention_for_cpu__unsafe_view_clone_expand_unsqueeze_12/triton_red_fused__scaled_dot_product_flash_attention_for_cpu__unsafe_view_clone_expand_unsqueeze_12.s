    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #5
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v4, v3, v0
    s.rdspecial  s1, arg_base
    v.lshr       v3, v4, v2
    s.movz       s2, #1
    v.sub        v2, v1, v3
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s2
    @p1 v.sel        v6, v2, v3
    v.cmp.lt     p1, v4, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v2, [s3, v6]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.movi       v4, #31
    v.sub        v5, v3, v0
    v.cmp.lt     p1, v0, v3
    @p1 v.sel        v7, v5, v0
    s.movz       s2, #1
    v.movi       v0, #32
    v.and        v5, v7, v4
    v.iota       v4                              // arange(0, VLEN)
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.splat      v7, s2
    s.movz       s2, #0
    v.sub        v8, v1, v0
    v.movi       v9, #0
    v.sub        v10, v3, v0
    v.cmp.lt     p2, v0, v1
    v.sub        v1, v3, v5
    v.cmp.lt     p3, v4, v7
    v.movi       v4, #0
    v.cmp.lt     p4, v0, v3
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v3, #0
    s.movz       s6, #129
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s8, #16
    v.iota       v7                              // arange(0, VLEN)
    s.ld.d       s9, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v11, #1
    @p2 v.sel        v11, v8, v0
    v.cmp.ne     p2, v2, v9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v8, #1
    @p4 v.sel        v8, v10, v0
    @p1 v.sel        v0, v1, v5
    s.addi       s1, s2, #0
    v.mov        v3, v4
for_1:
    s.cmp.ge     s2, s1, s6
    br.nz        s2, endfor_2
    v.extract    s2, v2, #0
    v.splat      v1, s2
    v.movi       v5, #0
    v.rcp.approx v8, v1                          // ISA 8.8: <= 2**-22 relative
    v.sub        v9, v5, v6
    v.cmp.lt     p1, v6, v5
    v.movi       v10, #129
    @p1 v.sel        v11, v9, v6
    v.movi       v9, #1
    v.mul        v12, v6, v10
    v.lshr       v10, v11, v9
    .li       s2, #1065353216
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v11, s1
    v.extract    s2, v12, #0
    v.sub        v12, v5, v10
    v.add        v13, v11, v7
    v.splat      v11, s2
    v.movi       v14, #129
    @p1 v.sel        v15, v12, v10
    v.movi       v10, #4128
    v.add        v12, v13, v11
    v.movi       v11, #32
    v.cmp.lt     p1, v13, v14
    v.extract    s2, v0, #0
    v.mul        v14, v15, v10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s5, v12]             // index is in elements (ISA sec 9.1)
    v.mul        v12, v13, v11
    v.splat      v11, s2
    v.extract    s2, v14, #0
    v.add        v13, v11, v12
    vf.fms       v11, v1, v8, v9
    v.splat      v1, s2
    v.movi       v9, #1
    v.movi       v12, #0
    vf.fms       v14, v8, v11, v8
    v.add        v11, v13, v1
    @p2 v.sel        v1, v9, v12
    v.movi       v9, #0
    vf.neg       v12, v14                        // Newton step: r0*(2 - x*r0)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s7, v11]             // index is in elements (ISA sec 9.1)
    v.movi       v11, #1
    v.movi       v14, #0
    v.cmp.eq     p3, v1, v9
    vf.cmp.o     p4, v12, v12
    @p4 v.sel        v1, v12, v8
    @p3 v.sel        v8, v11, v14
    vf.mul       v9, v10, v1                     // a/y as a refined reciprocal (ISA has no divide)
    v.extract    s2, v8, #0
    v.splat      v1, s2
    v.movi       v8, #0
    vf.cvt.f16.f32 v10, v13
    v.movi       v11, #2
    s.movz       s2, #32
    v.cmp.ne     p3, v1, v8
    @p3 v.sel        v1, v4, v9
    v.movi       v8, #0
    vf.mul       v9, v1, v10
    v.sub        v1, v5, v11
    v.cmp.lt     p3, v11, v5
    v.movi       v5, #1
    vf.add       v5, v3, v9
    s.add        s2, s1, s8
    s.movz       s3, #1
    @p3 v.sel        v9, v1, v11
    @p1 v.sel        v1, v5, v3
    s.movz       s10, #4128
    v.mov        v8, v1
    v.mov        v3, v8
    s.mov        s1, s2
    br.nz        s3, for_1
endfor_2:
    vf.reduce.add.b v0, v3
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    vf.cvt.f32.f16 v3, v2
    s.add        s1, s9, s2                      // &out_ptr1[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
