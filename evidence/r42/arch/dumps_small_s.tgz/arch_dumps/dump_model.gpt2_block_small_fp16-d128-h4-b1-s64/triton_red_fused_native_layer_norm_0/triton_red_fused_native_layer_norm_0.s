    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #128
    s.movz       s5, #32
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s11, s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v2, #0
    s.add        s12, s11, s1
    v.mov        v1, v0
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    v.mov        v2, v0
    s.add        s12, s3, s13                    // &in_ptr0[...]
for_1:
    v.ld.h       v3, [s12, #0]
    v.ld.h       v4, [s12, #32]
    vf.cvt.f16.f32 v5, v3
    vf.add       v1, v1, v5
    vf.cvt.f16.f32 v3, v4
    vf.add       v2, v2, v3
    s.addi       s12, s12, #64                   // the next iteration's address
    s.add        s11, s11, s5
    s.cmp.lt     s13, s11, s4
    br.nz        s13, for_1
endfor_2:
    .li       s11, #1124073472
    v.splat      v3, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s11, #1065353216
    v.splat      v4, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v5, v1
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v2
    v.movi       v2, #0
    s.addi       s11, s2, #0
    vf.add       v7, v5, v6
    s.add        s12, s11, s1
    v.movi       v5, #0
    v.movi       v6, #0
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    vf.add       v8, v7, v2
    v.mov        v5, v0
    v.mov        v6, v0
    s.add        s12, s3, s1                     // &in_ptr0[...]
    vf.fms       v0, v3, v1, v4
    vf.fms       v7, v1, v0, v1
    vf.neg       v0, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v7, v0, v1
    vf.mul       v0, v8, v7                      // a/y as a refined reciprocal (ISA has no divide)
    v.extract    s1, v0, #0
    v.splat      v0, s1
for_3:
    v.ld.h       v1, [s12, #0]
    v.ld.h       v7, [s12, #32]
    vf.cvt.f16.f32 v8, v1
    vf.sub       v1, v8, v0
    vf.mul       v8, v1, v1
    vf.cvt.f16.f32 v1, v7
    vf.add       v5, v5, v8
    vf.sub       v7, v1, v0
    vf.mul       v1, v7, v7
    vf.add       v6, v6, v1
    s.addi       s12, s12, #64                   // the next iteration's address
    s.add        s11, s11, s5
    s.cmp.lt     s13, s11, s4
    br.nz        s13, for_3
endfor_4:
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v1, v5
    vf.reduce.add.b v5, v6
    .li       s11, #925353388
    v.splat      v6, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s11, #1077936128
    v.splat      v7, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v1, v5
    .li       s11, #3204448256
    v.splat      v1, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s11, s6, s4
    s.addi       s12, s2, #0
    v.splat      v5, s1
    vf.add       v9, v8, v2
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    s.add        s13, s12, s11
    s.add        s14, s12, s11
    s.shli       s11, s13, #1                    // element offset -> bytes (x2)
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    s.shli       s15, s14, #1                    // element offset -> bytes (x2)
    s.movz       s14, #1
    s.add        s14, s3, s11                    // &in_ptr0[...]
    s.add        s11, s8, s1                     // &in_ptr1[...]
    s.add        s1, s9, s13                     // &in_ptr2[...]
    s.add        s13, s10, s15                   // &out_ptr1[...]
    vf.fms       v2, v3, v0, v4
    vf.fms       v3, v0, v2, v0
    vf.neg       v2, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v3, v2, v0
    vf.mul       v0, v9, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v0, v6
    v.rsqrt.approx v0, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v0, v0
    vf.mul       v4, v0, v1
    vf.fms       v1, v2, v3, v7
    vf.mul       v2, v4, v1                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    v.extract    s15, v1, #0
    v.splat      v0, s15
for_5:
    v.ld.h       v1, [s14, #0]
    v.ld.h       v2, [s14, #32]
    vf.cvt.f16.f32 v3, v1
    vf.sub       v1, v3, v5
    vf.mul       v3, v1, v0
    v.ld.h       v1, [s11, #0]
    vf.cvt.f16.f32 v4, v2
    vf.sub       v2, v4, v5
    vf.mul       v4, v2, v0
    v.ld.h       v2, [s11, #32]
    vf.cvt.f16.f32 v6, v1
    vf.mul       v1, v3, v6
    v.ld.h       v3, [s1, #0]
    vf.cvt.f16.f32 v6, v2
    vf.mul       v2, v4, v6
    v.ld.h       v4, [s1, #32]
    vf.cvt.f16.f32 v6, v3
    vf.add       v3, v1, v6
    vf.cvt.f32.f16 v1, v3
    vf.cvt.f16.f32 v3, v4
    v.st.h       [s13, #0], v1
    vf.add       v1, v2, v3
    vf.cvt.f32.f16 v2, v1
    v.st.h       [s13, #32], v2
    s.addi       s14, s14, #64                   // the next iteration's address
    s.addi       s11, s11, #64                   // the next iteration's address
    s.addi       s1, s1, #64                     // the next iteration's address
    s.addi       s13, s13, #64                   // the next iteration's address
    s.add        s12, s12, s5
    s.cmp.lt     s15, s12, s4
    br.nz        s15, for_5
endfor_6:
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s7
    s.mov        s6, s1
    br.nz        s11, __rctx_program
    exit
