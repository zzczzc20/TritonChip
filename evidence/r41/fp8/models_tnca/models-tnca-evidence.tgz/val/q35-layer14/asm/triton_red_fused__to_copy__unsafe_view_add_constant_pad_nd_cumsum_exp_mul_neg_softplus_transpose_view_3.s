    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #0
    v.sub        v3, v1, v0
    v.sub        v4, v2, v0
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v5, v3, v0
    v.movi       v3, #5
    @p2 v.sel        v6, v4, v0
    v.movi       v0, #31
    v.movi       v4, #32
    v.lshr       v7, v5, v3
    v.and        v3, v6, v0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.sub        v0, v1, v4
    v.sub        v5, v1, v7
    v.sub        v6, v2, v4
    v.sub        v8, v2, v3
    .li       s3, #2143289344
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p3, v4, v1
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #64
    s.movz       s5, #16
    s.ld.d       s6, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v10, #1
    @p3 v.sel        v10, v0, v4
    v.cmp.lt     p3, v4, v2
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.iota       v0                              // arange(0, VLEN)
    @p1 v.sel        v2, v5, v7
    s.ld.d       s8, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.movi       v5, #1
    @p3 v.sel        v5, v6, v4
    @p2 v.sel        v4, v8, v3
    s.addi       s1, s2, #0
    v.mov        v1, v9
for_1:
    s.cmp.ge     s9, s1, s4
    br.nz        s9, endfor_2
    v.splat      v3, s1
    v.add        v5, v3, v0
    v.movi       v3, #64
    v.cmp.lt     p1, v5, v3
    v.movi       v3, #64
    v.mul        v6, v2, v3
    v.extract    s9, v6, #0
    v.splat      v3, s9
    v.add        v6, v5, v3
    v.movi       v3, #0
    v.movi       v5, #0
    v.extract    s9, v6, #0
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #0
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #0
    v.extract    s9, v6, #1
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #1
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #1
    v.extract    s9, v6, #2
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #2
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #2
    v.extract    s9, v6, #3
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #3
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #3
    v.extract    s9, v6, #4
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #4
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #4
    v.extract    s9, v6, #5
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #5
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #5
    v.extract    s9, v6, #6
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #6
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #6
    v.extract    s9, v6, #7
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #7
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #7
    v.extract    s9, v6, #8
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #8
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #8
    v.extract    s9, v6, #9
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #9
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #9
    v.extract    s9, v6, #10
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #10
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #10
    v.extract    s9, v6, #11
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #11
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #11
    v.extract    s9, v6, #12
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #12
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #12
    v.extract    s9, v6, #13
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #13
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #13
    v.extract    s9, v6, #14
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #14
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #14
    v.extract    s9, v6, #15
    s.shli       s10, s9, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s9, #15
    s.lshri      s10, s9, #32
    v.insert     v5, s10, #15
    v.movi       v7, #0
    v.extract    s9, v3, #0
    v.extract    s10, v5, #0
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #0
    v.extract    s9, v3, #1
    v.extract    s10, v5, #1
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #1
    v.extract    s9, v3, #2
    v.extract    s10, v5, #2
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #2
    v.extract    s9, v3, #3
    v.extract    s10, v5, #3
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #3
    v.extract    s9, v3, #4
    v.extract    s10, v5, #4
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #4
    v.extract    s9, v3, #5
    v.extract    s10, v5, #5
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #5
    v.extract    s9, v3, #6
    v.extract    s10, v5, #6
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #6
    v.extract    s9, v3, #7
    v.extract    s10, v5, #7
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #7
    v.extract    s9, v3, #8
    v.extract    s10, v5, #8
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #8
    v.extract    s9, v3, #9
    v.extract    s10, v5, #9
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #9
    v.extract    s9, v3, #10
    v.extract    s10, v5, #10
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #10
    v.extract    s9, v3, #11
    v.extract    s10, v5, #11
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #11
    v.extract    s9, v3, #12
    v.extract    s10, v5, #12
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #12
    v.extract    s9, v3, #13
    v.extract    s10, v5, #13
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #13
    v.extract    s9, v3, #14
    v.extract    s10, v5, #14
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #14
    v.extract    s9, v3, #15
    v.extract    s10, v5, #15
    s.shli       s11, s10, #32
    s.or         s10, s9, s11
    s.movz       s9, #85
    s.cmp.lt     s11, s10, s9
    v.insert     v7, s11, #15
    v.movi       v3, #0
    v.cmp.ne     p2, v7, v3
    v.extract    s9, v4, #0
    v.splat      v3, s9
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s3, v3]               // index is in elements (ISA sec 9.1)
    s.movz       s9, #32
    v.movi       v7, #32
    v.mul        v8, v6, v7
    v.add        v7, v3, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s6, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s7, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v8
    vf.add       v8, v7, v3
    .li       s9, #1101004800
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.gt    p3, v8, v3
    .li       s9, #1069066811
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v8, v3
    vf.fms       v9, v8, v3, v7                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v7                         // ISA 8.8: <= 2**-22 relative
    .li       s9, #1060205080
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v10, v9, v7
    vf.fma       v7, v3, v10, v3                 // 2**t * 2**d
    vf.cmp.o     p4, v7, v7
    @p4 v.sel        v9, v7, v3
    .li       s9, #1065353216
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v9, v3
    .li       s9, #4913933
    v.splat      v10, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v7, v10
    v.movi       v7, #23
    v.lshr       v10, v11, v7
    v.movi       v7, #127
    v.sub        v11, v10, v7
    v.movi       v7, #25
    v.min.s      v10, v11, v7
    v.movi       v7, #23
    v.shl        v12, v11, v7
    v.sub        v7, v9, v12
    v.movi       v12, #127
    v.sub        v13, v12, v10
    v.movi       v10, #23
    v.shl        v12, v13, v10
    vf.sub       v10, v12, v3
    vf.add       v3, v7, v10                     // f = x*2**-k + (2**-k - 1)
    vf.sub       v12, v3, v7
    vf.sub       v13, v3, v12
    vf.sub       v14, v7, v13
    vf.sub       v7, v10, v12
    vf.add       v10, v14, v7                    // TwoSum: the exact error of f
    vf.mul       v7, v3, v3
    .li       s9, #1032451959
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #3186590336
    v.splat      v13, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v12, v3, v13
    .li       s9, #1039390164
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v3, v12
    .li       s9, #3187543230
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v3, v12
    .li       s9, #1041339458
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v3, v12
    .li       s9, #3190467997
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v3, v12
    .li       s9, #1045222078
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v3, v12
    .li       s9, #3196059656
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v3, v12
    .li       s9, #1051372195
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v3, v12
    .li       s9, #3204448256
    v.splat      v12, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v3, v12
    vf.cvt.s32.f32 v12, v11
    vf.neg       v11, v3
    vf.fma       v13, v11, v10, v10              // f_lo/(1 + f_hi)
    .li       s9, #901758606
    v.splat      v10, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v11, v12, v10, v13
    vf.fma       v10, v7, v14, v11
    .li       s9, #1060205056
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v11, v12, v7                    // k*ln2_hi, exact
    vf.add       v7, v11, v3
    vf.sub       v12, v7, v11
    vf.sub       v11, v3, v12                    // Fast2Sum
    vf.add       v3, v11, v10
    vf.add       v10, v7, v3
    vf.abs       v3, v9
    .li       s9, #855638016
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.lt    p4, v3, v7
    @p4 v.sel        v3, v9, v10
    .li       s9, #3212836864
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p4, v9, v7
    .li       s9, #4286578688
    v.splat      v10, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v11, v10, v3
    vf.cmp.lt    p4, v9, v7
    .li       s9, #2143289344
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v7, v3, v11
    .li       s9, #2139095040
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p4, v9, v3
    @p4 v.sel        v3, v9, v7
    vf.cmp.uo    p4, v9, v9
    @p4 v.sel        v7, v9, v3
    @p3 v.sel        v3, v8, v7
    vf.mul       v7, v5, v3
    v.movi       v3, #0
    @p2 v.sel        v5, v7, v3
    v.extract    s9, v5, #0
    v.splat      v3, s9
    v.extract    s9, v5, #1
    v.splat      v7, s9
    v.extract    s9, v5, #2
    v.splat      v8, s9
    v.extract    s9, v5, #3
    v.splat      v9, s9
    v.extract    s9, v5, #4
    v.splat      v10, s9
    v.extract    s9, v5, #5
    v.splat      v11, s9
    v.extract    s9, v5, #6
    v.splat      v12, s9
    v.extract    s9, v5, #7
    v.splat      v13, s9
    v.extract    s9, v5, #8
    v.splat      v14, s9
    v.extract    s9, v5, #9
    v.splat      v15, s9
    v.extract    s9, v5, #10
    v.splat      v16, s9
    v.extract    s9, v5, #11
    v.splat      v17, s9
    v.extract    s9, v5, #12
    v.splat      v18, s9
    v.extract    s9, v5, #13
    v.splat      v19, s9
    v.extract    s9, v5, #14
    v.splat      v20, s9
    v.extract    s9, v5, #15
    v.splat      v5, s9
    vf.add       v21, v3, v7
    vf.add       v7, v21, v8
    vf.add       v8, v7, v9
    vf.add       v9, v8, v10
    vf.add       v10, v9, v11
    vf.add       v11, v10, v12
    vf.add       v12, v11, v13
    vf.add       v13, v12, v14
    vf.add       v14, v13, v15
    vf.add       v15, v14, v16
    vf.add       v16, v15, v17
    vf.add       v17, v16, v18
    vf.add       v18, v17, v19
    vf.add       v19, v18, v20
    vf.add       v20, v19, v5
    v.movi       v5, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s9, v3, #0
    v.insert     v5, s9, #0
    v.extract    s9, v21, #0
    v.insert     v5, s9, #1
    v.extract    s9, v7, #0
    v.insert     v5, s9, #2
    v.extract    s9, v8, #0
    v.insert     v5, s9, #3
    v.extract    s9, v9, #0
    v.insert     v5, s9, #4
    v.extract    s9, v10, #0
    v.insert     v5, s9, #5
    v.extract    s9, v11, #0
    v.insert     v5, s9, #6
    v.extract    s9, v12, #0
    v.insert     v5, s9, #7
    v.extract    s9, v13, #0
    v.insert     v5, s9, #8
    v.extract    s9, v14, #0
    v.insert     v5, s9, #9
    v.extract    s9, v15, #0
    v.insert     v5, s9, #10
    v.extract    s9, v16, #0
    v.insert     v5, s9, #11
    v.extract    s9, v17, #0
    v.insert     v5, s9, #12
    v.extract    s9, v18, #0
    v.insert     v5, s9, #13
    v.extract    s9, v19, #0
    v.insert     v5, s9, #14
    v.extract    s9, v20, #0
    v.insert     v5, s9, #15
    v.movi       v3, #15
    v.cmp.eq     p2, v0, v3
    v.movi       v3, #1
    v.movi       v7, #0
    @p2 v.sel        v8, v3, v7
    v.mul        v3, v5, v8
    v.reduce.add s9, v3
    v.splat      v3, s9
    vf.add       v7, v1, v3
    v.extract    s9, v1, #0
    v.splat      v8, s9
    vf.add       v9, v8, v5
    v.splat      v8, s1
    v.splat      v10, s2
    v.cmp.gt     p2, v8, v10
    @p2 v.sel        v8, v9, v5
    @p2 v.sel        v5, v7, v3
    s.movz       s9, #128
    v.movi       v3, #128
    v.mul        v7, v4, v3
    v.extract    s9, v7, #0
    v.splat      v3, s9
    v.add        v7, v6, v3
    @p1 v.st.scatter.w [s8, v7], v8
    v.movi       v3, #0
    v.mov        v3, v5
    v.mov        v1, v3
    s.add        s9, s1, s5
    s.mov        s1, s9
    s.movz       s9, #1
    br.nz        s9, for_1
endfor_2:
__rctx_next:
    exit
