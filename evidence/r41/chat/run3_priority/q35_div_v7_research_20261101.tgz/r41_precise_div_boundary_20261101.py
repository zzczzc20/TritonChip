#!/usr/bin/env python3
"""DP TLM div_rn special values; preserves zero signs and checks NaNs."""
import json,os,tempfile
from pathlib import Path
import torch,triton,triton.language as tl
from safetensors.torch import save_file
@triton.jit
def divide(A,B,C,BLOCK:tl.constexpr):
 i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);a=tl.load(A+i);b=tl.load(B+i);tl.store(C+i,a/b)
def main():
 from tnca import aot
 from tnca.runtime import Session
 import tlm_backend
 tlm_backend.register()
 positive=[0,1,2,3,0x007ffffd,0x007ffffe,0x007fffff,0x00800000,0x00800001,0x01000000,0x0f800000,0x1f800000,0x3eaaaaab,0x3f000000,0x3f7fffff,0x3f800000,0x3f800001,0x3fffffff,0x40000000,0x5f000000,0x6f800000,0x7e800000,0x7f000000,0x7f7ffffe,0x7f7fffff,0x7f800000,0x7fc00000]
 bits=positive+[x|0x80000000 for x in positive];signed=[x if x<2**31 else x-2**32 for x in bits];values=torch.tensor(signed,dtype=torch.int32).view(torch.float32);aa=values.repeat_interleave(len(values));bb=values.repeat(len(values));pad=(-aa.numel())%16
 if pad: aa=torch.cat((aa,torch.zeros(pad)));bb=torch.cat((bb,torch.ones(pad)))
 want=aa/bb;path=Path(tempfile.mkdtemp())/'divide.tnca';art=aot.compile_aot(divide,signature={'A':'*fp32','B':'*fp32','C':'*fp32','BLOCK':'constexpr'},constexprs={'BLOCK':16},profile='core-vrf-sync-v5-x8-g2c4-dp',options={'index_opt':1,'ieee_div':1},output=str(path))
 with Session(profile='core-vrf-sync-v5-x8-g2c4-dp',backend='systemc-tlm-grid',host_timeout=180) as sess:
  mod=sess.load(art.path);a,b,c=[sess.allocate(aa.numel()*4) for _ in range(3)];sess.upload(a,aa.numpy().tobytes());sess.upload(b,bb.numpy().tobytes());before=sess.dev.counters_snapshot();ev=sess.submit(mod,{'A':a,'B':b,'C':c},grid=(aa.numel()//16,1,1));sess.wait(ev);after=sess.dev.counters_snapshot()
  if not ev.ok:raise RuntimeError(str(ev.error))
  got=torch.frombuffer(bytearray(sess.download(c)),dtype=torch.float32).clone();is_nan=torch.isnan(want);bad=(got.view(torch.int32)!=want.view(torch.int32))&~is_nan | (torch.isnan(got)!=is_nan);ids=torch.nonzero(bad).flatten().tolist();ins=sum(v-before.get(k,0) for k,v in after.items() if k.startswith('core_') and k.endswith('_instructions'))
  rows=[{'index':i,'a_bits':f'{int(aa.view(torch.int32)[i])&0xffffffff:08x}','b_bits':f'{int(bb.view(torch.int32)[i])&0xffffffff:08x}','expected_bits':f'{int(want.view(torch.int32)[i])&0xffffffff:08x}','got_bits':f'{int(got.view(torch.int32)[i])&0xffffffff:08x}'} for i in ids[:20]]
  result={'scope':'DP TLM, IEEE special values, cartesian signed IEEE boundary inputs; NaNs compared by classification','elements':got.numel(),'bit_mismatches':len(ids),'first_mismatches':rows,'device_cycles':ev.device_cycles,'instructions':ins,'launches':1,'code_loads_during_launch':0};print(json.dumps(result,indent=2),flush=True)
  out=Path(os.environ['R41_DIV_SPECIAL_OUT']);out.write_text(json.dumps(result,indent=2)+'\n');save_file({'a':aa.contiguous(),'b':bb.contiguous(),'want':want.contiguous(),'got':got.contiguous()},str(out.with_suffix('.safetensors')))
if __name__=='__main__':main()
