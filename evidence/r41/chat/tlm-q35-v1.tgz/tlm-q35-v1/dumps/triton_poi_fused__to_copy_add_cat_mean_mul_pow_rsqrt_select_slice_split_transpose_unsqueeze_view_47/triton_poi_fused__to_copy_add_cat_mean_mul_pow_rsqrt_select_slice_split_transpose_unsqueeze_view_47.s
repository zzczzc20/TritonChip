    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #6
    v.movi       v4, #63
    v.splat      v5, s2
    v.movi       v6, #64
    v.movi       v7, #15
    v.add        v8, v5, v0
    v.movi       v0, #0
    v.movi       v5, #15360
    v.sub        v9, v1, v8
    v.cmp.lt     p1, v8, v1
    v.sub        v10, v2, v8
    @p1 v.sel        v11, v9, v8
    v.cmp.lt     p2, v8, v2
    @p2 v.sel        v9, v10, v8
    v.lshr       v10, v11, v3
    v.sub        v3, v2, v6
    v.and        v11, v9, v4
    v.sub        v4, v1, v10
    v.sub        v9, v1, v6
    v.sub        v12, v2, v11
    @p1 v.sel        v13, v4, v10
    v.sub        v4, v0, v7
    s.rdspecial  s1, arg_base
    v.cmp.lt     p1, v6, v2
    v.sub        v2, v0, v13
    v.cmp.lt     p3, v6, v1
    v.cmp.lt     p4, v13, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    @p1 v.sel        v1, v3, v6
    v.cmp.lt     p1, v7, v0
    @p2 v.sel        v1, v12, v11
    v.cmp.lt     p2, v8, v5
    v.movi       v3, #1
    @p3 v.sel        v3, v9, v6
    v.movi       v3, #1
    @p4 v.sel        v5, v2, v13
    @p1 v.sel        v2, v4, v7
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v4, #0
    v.movi       v6, #0
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s6, #31
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s1, #48]                  // out_ptr0: device_ptr64 at arg_base+48
idiv_1:
    v.splat      v7, s6
    v.shl        v9, v6, v3
    v.cmp.lt     p1, v6, v0
    v.lshr       v10, v5, v7
    v.shl        v11, v3, v7
    s.subi       s1, s6, #1
    v.and        v7, v10, v3
    s.movz       s11, #0
    v.or         v10, v9, v7
    v.cmp.geu    p3, v10, v2
    p.or         p5, p1, p3
    v.sub        v7, v10, v2
    @p5 v.sel        v9, v11, v0
    @p5 v.sel        v11, v7, v10
    v.or         v7, v4, v9
    v.mov        v6, v11
    v.mov        v4, v7
    s.mov        s6, s1
    s.cmp.ge     s1, s6, s11
    br.nz        s1, idiv_1
    v.movi       v2, #960
    v.movi       v3, #0
    v.sub        v4, v0, v6
    v.movi       v0, #1
    v.sub        v5, v3, v8
    v.sub        v7, v3, v2
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p3, v2, v3
    @p4 v.sel        v9, v4, v6
    @p1 v.sel        v4, v5, v8
    @p3 v.sel        v5, v7, v2
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v10, v6, v0
    v.cmp.lt     p4, v6, v3
    v.lshr       v11, v4, v7
    v.shl        v12, v0, v7
    s.subi       s6, s1, #1
    v.and        v7, v11, v0
    s.movz       s11, #0
    v.or         v11, v10, v7
    v.cmp.geu    p5, v11, v5
    p.or         p6, p4, p5
    v.sub        v7, v11, v5
    @p6 v.sel        v10, v12, v3
    @p6 v.sel        v12, v7, v11
    v.or         v7, v2, v10
    v.mov        v6, v12
    v.mov        v2, v7
    s.mov        s1, s6
    s.cmp.ge     s6, s1, s11
    br.nz        s6, idiv_2
    p.xor        p4, p1, p3
    v.sub        v0, v3, v2
    @p4 v.sel        v3, v0, v2
    s.movz       s1, #512
    v.movi       v0, #512
    v.mul        v2, v3, v0
    v.add        v0, v1, v2
    s.movz       s1, #8192
    v.movi       v2, #8192
    v.mul        v4, v9, v2
    v.add        v2, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s3, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v0
    v.movi       v0, #16
    v.mul        v4, v9, v0
    v.add        v0, v3, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s5, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v0
    s.movz       s1, #32
    v.movi       v0, #32
    v.mul        v5, v9, v0
    v.movi       v6, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p3, v0, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v9, v7, v1
    v.sub        v7, v6, v0
    @p3 v.sel        v10, v7, v0
    v.movi       v7, #31
    v.and        v10, v9, v7
    v.sub        v7, v6, v10
    @p1 v.sel        v6, v7, v10
    v.add        v7, v5, v6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s7, v7]               // index is in elements (ISA sec 9.1)
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    s.add        s2, s8, s1                      // &in_ptr4[...]
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s2, #0]
    vf.cvt.bf16.f32 v11, v10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s9, v7]              // index is in elements (ISA sec 9.1)
    .li       s1, #1132462080
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v12, v7                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v15, v7, v12, v14
    vf.fms       v14, v12, v15, v12
    vf.neg       v15, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v14, v15, v12
    vf.mul       v12, v3, v14                    // a/y: faithful quotient
    vf.fms       v15, v12, v7, v3
    vf.fms       v3, v15, v14, v12
    vf.neg       v7, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v3, v7, v12
    .li       s1, #897988541
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v12, v3, v7
    v.rsqrt.approx v3, v12                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v3, v3
    .li       s1, #1077936128
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v15, v12, v7, v14
    .li       s1, #3204448256
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v12, v3, v7
    vf.mul       v7, v12, v15                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v12, v7, v3
    vf.mul       v3, v2, v12
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v4, v2
    vf.mul       v2, v3, v7
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p3, v0, v3
    v.sub        v4, v3, v8
    @p1 v.sel        v7, v4, v8
    v.sub        v4, v3, v0
    @p3 v.sel        v8, v4, v0
    v.movi       v0, #31
    v.and        v4, v7, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #0
    v.movi       v4, #0
    v.extract    s1, v3, #0
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #0
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #0
    v.extract    s1, v3, #1
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #1
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #1
    v.extract    s1, v3, #2
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #2
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #2
    v.extract    s1, v3, #3
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #3
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #3
    v.extract    s1, v3, #4
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #4
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #4
    v.extract    s1, v3, #5
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #5
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #5
    v.extract    s1, v3, #6
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #6
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #6
    v.extract    s1, v3, #7
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #7
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #7
    v.extract    s1, v3, #8
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #8
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #8
    v.extract    s1, v3, #9
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #9
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #9
    v.extract    s1, v3, #10
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #10
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #10
    v.extract    s1, v3, #11
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #11
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #11
    v.extract    s1, v3, #12
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #12
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #12
    v.extract    s1, v3, #13
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #13
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #13
    v.extract    s1, v3, #14
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #14
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #14
    v.extract    s1, v3, #15
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #15
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #15
    v.movi       v3, #0
    v.extract    s1, v0, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #0
    v.extract    s1, v0, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #1
    v.extract    s1, v0, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #2
    v.extract    s1, v0, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #3
    v.extract    s1, v0, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #4
    v.extract    s1, v0, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #5
    v.extract    s1, v0, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #6
    v.extract    s1, v0, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #7
    v.extract    s1, v0, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #8
    v.extract    s1, v0, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #9
    v.extract    s1, v0, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #10
    v.extract    s1, v0, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #11
    v.extract    s1, v0, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #12
    v.extract    s1, v0, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #13
    v.extract    s1, v0, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #14
    v.extract    s1, v0, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2
    s.cmp.ge     s3, s2, s1
    v.insert     v3, s3, #15
    v.movi       v7, #0
    v.cmp.ne     p1, v3, v7
    v.movi       v3, #0
    v.extract    s1, v0, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #0
    v.extract    s1, v0, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #1
    v.extract    s1, v0, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #2
    v.extract    s1, v0, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #3
    v.extract    s1, v0, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #4
    v.extract    s1, v0, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #5
    v.extract    s1, v0, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #6
    v.extract    s1, v0, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #7
    v.extract    s1, v0, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #8
    v.extract    s1, v0, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #9
    v.extract    s1, v0, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #10
    v.extract    s1, v0, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #11
    v.extract    s1, v0, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #12
    v.extract    s1, v0, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #13
    v.extract    s1, v0, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #14
    v.extract    s1, v0, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #30
    s.cmp.lt     s3, s2, s1
    v.insert     v3, s3, #15
    v.movi       v0, #0
    v.cmp.ne     p3, v3, v0
    .li       s1, #-2
    v.movi       v0, #-2
    v.add        v3, v6, v0
    v.movi       v0, #3
    v.movi       v4, #0
    v.movi       v6, #1
    v.cmp.lt     p4, v3, v4
    v.cmp.lt     p5, v0, v4
    v.sub        v7, v4, v3
    @p4 v.sel        v8, v7, v3
    v.sub        v7, v4, v0
    @p5 v.sel        v12, v7, v0
    v.movi       v7, #0
    v.movi       v14, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v15, s1
    v.shl        v16, v14, v6
    v.cmp.lt     p5, v14, v4
    v.lshr       v17, v8, v15
    v.shl        v18, v6, v15
    s.subi       s2, s1, #1
    v.and        v15, v17, v6
    s.movz       s3, #0
    v.or         v17, v16, v15
    v.cmp.geu    p6, v17, v12
    p.or         p7, p5, p6
    v.sub        v15, v17, v12
    @p7 v.sel        v16, v18, v4
    @p7 v.sel        v18, v15, v17
    v.or         v15, v7, v16
    v.mov        v14, v18
    v.mov        v7, v15
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_3
    v.sub        v6, v4, v14
    v.movi       v4, #0
    v.movi       v7, #0
    @p4 v.sel        v8, v6, v14
    v.extract    s1, v8, #0
    v.extract    s2, v8, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    v.extract    s3, v8, #2
    s.lshri      s4, s2, #32
    s.ashri      s5, s1, #32
    v.insert     v4, s2, #0
    v.insert     v7, s4, #0
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #3
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #1
    v.insert     v7, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #4
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #2
    v.insert     v7, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #5
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #3
    v.insert     v7, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #6
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #4
    v.insert     v7, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #7
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #5
    v.insert     v7, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #8
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #6
    v.insert     v7, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #9
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #7
    v.insert     v7, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #10
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #8
    v.insert     v7, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #11
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #9
    v.insert     v7, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #12
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #10
    v.insert     v7, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #13
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #11
    v.insert     v7, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #14
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #12
    v.insert     v7, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #15
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #13
    v.insert     v7, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v4, s4, #14
    v.insert     v7, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v4, s3, #15
    v.insert     v7, s1, #15
    s.movz       s1, #0
    v.extract    s2, v4, #0
    v.extract    s3, v7, #0
    v.extract    s4, v7, #1
    s.shli       s5, s3, #32
    v.movi       v6, #0
    s.or         s3, s2, s5
    v.extract    s2, v4, #1
    s.shli       s5, s4, #32
    s.cmp.eq     s4, s3, s1
    v.extract    s1, v7, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v6, s4, #0
    v.extract    s4, v4, #2
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s3, s2
    v.extract    s2, v7, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v6, s1, #1
    v.extract    s1, v4, #3
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s3, s4
    v.extract    s3, v7, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v6, s2, #2
    v.extract    s2, v4, #4
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v6, s3, #3
    v.extract    s3, v4, #5
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v6, s1, #4
    v.extract    s1, v4, #6
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v6, s2, #5
    v.extract    s2, v4, #7
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v6, s3, #6
    v.extract    s3, v4, #8
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v6, s1, #7
    v.extract    s1, v4, #9
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v6, s2, #8
    v.extract    s2, v4, #10
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v6, s3, #9
    v.extract    s3, v4, #11
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v6, s1, #10
    v.extract    s1, v4, #12
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v6, s2, #11
    v.extract    s2, v4, #13
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v6, s3, #12
    v.extract    s3, v4, #14
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v6, s1, #13
    v.extract    s1, v4, #15
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v6, s2, #14
    s.cmp.eq     s2, s3, s1
    v.movi       v4, #0
    v.insert     v6, s2, #15
    v.movi       v7, #0
    v.sub        v12, v4, v3
    v.sub        v14, v4, v0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v6, v7
    v.cmp.lt     p3, v3, v4
    v.cmp.lt     p5, v0, v4
    p.and        p6, p4, p1
    v.movi       v6, #1
    @p3 v.sel        v7, v12, v3
    @p5 v.sel        v12, v14, v0
    v.movi       v14, #0
    v.movi       v15, #0
    s.movz       s1, #31
idiv_4:
    v.splat      v16, s1
    v.shl        v17, v15, v6
    v.cmp.lt     p1, v15, v4
    v.lshr       v18, v7, v16
    v.shl        v19, v6, v16
    s.subi       s2, s1, #1
    v.and        v16, v18, v6
    s.movz       s3, #0
    v.or         v18, v17, v16
    v.cmp.geu    p4, v18, v12
    p.or         p7, p1, p4
    v.sub        v16, v18, v12
    @p7 v.sel        v17, v19, v4
    @p7 v.sel        v19, v16, v18
    v.or         v16, v14, v17
    v.mov        v15, v19
    v.mov        v14, v16
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_4
    v.sub        v6, v4, v14
    p.xor        p1, p3, p5
    v.movi       v4, #1
    @p1 v.sel        v7, v6, v14
    v.movi       v6, #0
    v.movi       v12, #962
    v.sub        v14, v7, v4
    v.cmp.ne     p1, v8, v6
    v.cmp.lt     p3, v3, v6
    @p1 v.sel        v3, v14, v7
    p.and        p1, p6, p2
    v.movi       v4, #256
    @p3 v.sel        v6, v3, v7
    s.movz       s1, #1
    v.mul        v3, v13, v4
    v.mul        v4, v6, v0
    s.movz       s1, #3
    v.add        v0, v1, v3
    v.add        v1, v4, v12
    s.movz       s1, #962
    s.movz       s1, #256
    v.add        v3, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s7, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    @p6 v.sel        v3, v1, v9
    vf.mul       v1, v2, v3
    @p6 v.sel        v2, v4, v10
    vf.mul       v3, v11, v2
    vf.add       v2, v1, v3
    vf.cvt.f32.bf16 v1, v2
    @p2 v.st.scatter.h [s10, v0], v1
__rctx_next:
    exit
