#!/usr/bin/env python3
"""DP TLM projection probe on a real CPU-captured last-token activation."""
import argparse,json,sys,time
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
p=argparse.ArgumentParser();p.add_argument('--name',choices=['qkv','gate'],required=True);args=p.parse_args()
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
chat.L.use_tnca(str(tree));opts=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(opts);chat.L.install_fp8_route('official',dot='exact',scale_div='ieee')
a=load_file(str(h/'r41_q35_first_components_cpu_20261031_diag/states.safetensors'));layer=app.model.model.language_model.layers[0]
if args.name=='qkv':x=a['input_layernorm'];expected=a['linear_attn.in_proj_qkv'];mod=layer.linear_attn.in_proj_qkv
else:x=a['post_attention_layernorm'];expected=a['mlp.gate_proj'];mod=layer.mlp.gate_proj
x=x[:,-1:,:].contiguous();expected=expected[:,-1:,:].contiguous();stage,dev=chat.L.place(mod,'tnca','eager')
with torch.no_grad():got=stage(x.to(dev)).detach().cpu().contiguous().clone()
if got.shape!=expected.shape or got.dtype!=expected.dtype:raise ValueError('shape or dtype mismatch')
f=expected.float();g=got.float();diff=(f-g).abs();result={'schema':'r41-q35-first-projection-tlm/1','scope':'one-token isolated DP TLM on CPU-captured input; different graph and shape from full prefill; not board evidence','name':args.name,'input_shape':list(x.shape),'output_shape':list(got.shape),'elements':got.numel(),'bit_mismatches':int((got.view(torch.int16)!=expected.view(torch.int16)).sum()),'relative_l2':float((f-g).norm()/f.norm().clamp_min(1e-30)),'max_abs':float(diff.max()),'seconds':time.monotonic()-start}
out=h/f'r41_q35_first_projection_{args.name}_tlm_20261031_diag';out.mkdir(exist_ok=False);save_file({'got':got,'expected':expected.clone(),'input':x.clone()},str(out/'states.safetensors'));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
