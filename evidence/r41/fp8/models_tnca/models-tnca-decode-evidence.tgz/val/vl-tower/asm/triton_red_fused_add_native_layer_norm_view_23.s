    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr5: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr2: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #1280
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s2
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #4096
    s.st.d       [s11, #16], s12
    s.movz       s12, #8192
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #4096
    s.st.d       [s11, #16], s12
    s.movz       s12, #8192
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d1, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #512                   // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s5
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #4096
    s.st.d       [s11, #16], s12
    s.movz       s12, #8192
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d2, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #768                   // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s6
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #4096
    s.st.d       [s11, #16], s12
    s.movz       s12, #8192
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d3, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #1024                  // TensorMap 4: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s11, #0], s7
    s.movz       s1, #64
    s.st.d       [s11, #8], s1
    s.movz       s1, #4096
    s.st.d       [s11, #16], s1
    s.movz       s1, #8192
    s.st.d       [s11, #48], s1
    s.movz       s1, #2
    s.st.d       [s11, #56], s1
    .li       s1, #68719476737
    s.st.d       [s11, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s11, #104], s1
    fence.release.device
    td.load      d4, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s11, #4096
    s.movz       s12, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s13, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
    v.movi       v3, #0
    v.mov        v3, v1
    v.movi       v4, #0
    v.mov        v4, v1
for_1:
    s.cmp.ge     s14, s13, s11
    br.nz        s14, endfor_2
    s.muli       s14, s4, #8192
    v.splat      v5, s13
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s15, #4096
    s.movz       s16, #64
    s.muli       s17, s4, #8192
    v.splat      v7, s13
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s18, #4096
    s.movz       s19, #64
    v.add        v9, v5, v6
    v.movi       v5, #0
    v.splat      v6, s15
    s.muli       s15, s13, #2
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s16
    s.muli       s16, s13, #2
    v.add        v13, v7, v8
    v.movi       v7, #0
    v.splat      v8, s18
    v.splat      v14, s4
    v.movi       v15, #0
    v.splat      v16, s19
    v.cmp.ge     p1, v9, v5
    v.cmp.lt     p2, v9, v6
    v.cmp.ge     p3, v10, v11
    v.cmp.lt     p4, v10, v12
    v.cmp.ge     p5, v13, v7
    s.add        s18, s2, s14
    p.and        p6, p1, p2
    v.cmp.lt     p1, v13, v8
    p.and        p2, p3, p4
    v.cmp.ge     p3, v14, v15
    s.add        s14, s3, s17
    p.and        p4, p5, p1
    v.cmp.lt     p1, v14, v16
    p.and        p5, p3, p1
    s.add        s17, s18, s15
    p.and        p1, p6, p2
    s.add        s15, s14, s16
    p.and        p2, p4, p5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s17, #0]
    v.splat      v6, s13
    v.movi       v7, #4096
    v.add        v8, v6, v0
    s.muli       s14, s4, #8192
    v.cmp.lt     p1, v8, v7
    v.splat      v6, s13
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s16, #4096
    s.movz       s17, #64
    s.muli       s18, s13, #2
    v.add        v9, v6, v7
    v.movi       v6, #0
    v.splat      v7, s16
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s17
    v.cmp.ge     p3, v9, v6
    v.cmp.lt     p4, v9, v7
    v.cmp.ge     p5, v10, v11
    s.muli       s16, s4, #8192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s15, #0]
    v.cmp.lt     p2, v10, v12
    s.add        s15, s5, s14
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    s.add        s14, s15, s18
    p.and        p2, p6, p3
    vf.cvt.bf16.f32 v7, v5
    v.splat      v5, s13
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s15, #4096
    s.movz       s17, #64
    s.muli       s18, s13, #2
    v.add        v10, v5, v9
    v.movi       v5, #0
    v.splat      v9, s15
    v.splat      v11, s4
    v.movi       v12, #0
    v.splat      v13, s17
    v.cmp.ge     p3, v10, v5
    v.cmp.lt     p4, v10, v9
    v.cmp.ge     p5, v11, v12
    s.muli       s15, s4, #8192
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s14, #0]
    v.cmp.lt     p2, v11, v13
    s.add        s14, s6, s16
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v9, v6
    v.splat      v6, s13
    v.iota       v10                             // arange(0, VLEN)
    s.movz       s16, #4096
    s.movz       s17, #64
    s.muli       s19, s13, #2
    v.add        v11, v6, v10
    v.movi       v6, #0
    v.splat      v10, s16
    v.splat      v12, s4
    v.movi       v13, #0
    v.splat      v14, s17
    s.add        s16, s14, s18
    p.and        p2, p6, p3
    v.cmp.ge     p3, v11, v6
    v.cmp.lt     p4, v11, v10
    v.cmp.ge     p5, v12, v13
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s16, #0]
    v.cmp.lt     p2, v12, v14
    s.add        s14, s7, s15
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v10, v5
    .li       s15, #1065353216
    v.splat      v5, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s15, s14, s19
    vf.add       v11, v4, v5
    p.and        p2, p6, p3
    vf.add       v12, v7, v9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v7, [s15, #0]
    v.rcp.approx v9, v11                         // ISA 8.8: <= 2**-22 relative
    .li       s14, #1065353216
    v.splat      v13, s14                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v14, v6
    vf.add       v6, v12, v10
    s.mul        s14, s4, s11
    vf.cvt.bf16.f32 v10, v7
    v.splat      v7, s13
    vf.add       v12, v6, v14
    v.splat      v6, s1
    s.add        s15, s13, s14
    v.cmp.eq     p2, v7, v6
    vf.add       v6, v12, v10
    @p2 v.sel        v7, v5, v11
    s.shli       s16, s15, #1                    // element offset -> bytes (x2)
    @p1 v.sel        v5, v7, v4
    vf.sub       v7, v6, v2
    vf.cvt.f32.bf16 v10, v6
    s.add        s15, s2, s16                    // &in_out_ptr0[...]
    v.movi       v12, #0
    v.movi       v14, #0
    v.movi       v15, #0
    v.splat      v16, s14
    @p1 v.st.h       [s15, #0], v10
    s.add        s14, s13, s12
    s.movz       s15, #1
    v.add        v10, v8, v16
    vf.fms       v8, v11, v9, v13
    vf.fms       v10, v9, v8, v9
    vf.neg       v8, v10                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v10, v8, v9
    vf.mul       v8, v7, v10                     // a/y: faithful quotient
    vf.fms       v9, v8, v11, v7
    vf.fms       v11, v9, v10, v8
    vf.neg       v9, v11                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v9, v9
    @p3 v.sel        v10, v9, v8
    vf.add       v8, v2, v10
    vf.sub       v9, v6, v8
    @p2 v.sel        v10, v6, v8
    @p1 v.sel        v6, v10, v2
    vf.mul       v8, v7, v9
    v.mov        v12, v6
    vf.add       v6, v3, v8
    @p2 v.sel        v7, v1, v6
    @p1 v.sel        v6, v7, v3
    v.mov        v14, v6
    v.mov        v15, v5
    v.mov        v2, v12
    v.mov        v3, v14
    v.mov        v4, v15
    s.mov        s13, s14
    br.nz        s15, for_1
endfor_2:
    v.extract    s3, v2, #0
    v.splat      v1, s3
    v.extract    s3, v2, #1
    v.splat      v5, s3
    v.extract    s3, v2, #2
    v.splat      v6, s3
    v.extract    s3, v2, #3
    v.splat      v7, s3
    v.extract    s3, v2, #4
    v.splat      v8, s3
    v.extract    s3, v2, #5
    v.splat      v9, s3
    v.extract    s3, v2, #6
    v.splat      v10, s3
    v.extract    s3, v2, #7
    v.splat      v11, s3
    v.extract    s3, v2, #8
    v.splat      v12, s3
    v.extract    s3, v2, #9
    v.splat      v13, s3
    v.extract    s3, v2, #10
    v.splat      v14, s3
    v.extract    s3, v2, #11
    v.splat      v15, s3
    v.extract    s3, v2, #12
    v.splat      v16, s3
    v.extract    s3, v2, #13
    v.splat      v17, s3
    v.extract    s3, v2, #14
    v.splat      v18, s3
    v.extract    s3, v2, #15
    v.splat      v2, s3
    v.extract    s3, v3, #0
    v.splat      v19, s3
    v.extract    s3, v3, #1
    v.splat      v20, s3
    v.extract    s3, v3, #2
    v.splat      v21, s3
    v.extract    s3, v3, #3
    v.splat      v22, s3
    v.extract    s3, v3, #4
    v.splat      v23, s3
    v.extract    s3, v3, #5
    v.splat      v24, s3
    v.extract    s3, v3, #6
    v.splat      v25, s3
    v.extract    s3, v3, #7
    v.splat      v26, s3
    v.extract    s3, v3, #8
    v.splat      v27, s3
    v.extract    s3, v3, #9
    v.splat      v28, s3
    v.extract    s3, v3, #10
    v.splat      v29, s3
    v.extract    s3, v3, #11
    v.splat      v30, s3
    v.extract    s3, v3, #12
    v.splat      v31, s3
    v.extract    s3, v3, #13
    v.splat      v32, s3
    v.extract    s3, v3, #14
    v.splat      v33, s3
    v.extract    s3, v3, #15
    v.splat      v3, s3
    v.extract    s3, v4, #0
    v.splat      v34, s3
    v.extract    s3, v4, #1
    v.splat      v35, s3
    v.extract    s3, v4, #2
    v.splat      v36, s3
    v.extract    s3, v4, #3
    v.splat      v37, s3
    v.extract    s3, v4, #4
    v.splat      v38, s3
    v.extract    s3, v4, #5
    v.splat      v39, s3
    v.extract    s3, v4, #6
    v.splat      v40, s3
    v.extract    s3, v4, #7
    v.splat      v41, s3
    v.extract    s3, v4, #8
    v.splat      v42, s3
    v.extract    s3, v4, #9
    v.splat      v43, s3
    v.extract    s3, v4, #10
    v.splat      v44, s3
    v.extract    s3, v4, #11
    v.splat      v45, s3
    v.extract    s3, v4, #12
    v.splat      v46, s3
    v.extract    s3, v4, #13
    v.splat      v47, s3
    v.extract    s3, v4, #14
    v.splat      v48, s3
    v.extract    s3, v4, #15
    v.splat      v4, s3
    vf.cmp.eq    p1, v1, v5
    vf.sub       v49, v5, v1
    v.movi       v5, #0
    @p1 v.sel        v50, v5, v49
    vf.add       v49, v34, v35
    vf.cmp.eq    p1, v49, v5
    v.rcp.approx v51, v49                        // ISA 8.8: <= 2**-22 relative
    .li       s3, #1065353216
    v.splat      v52, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v53, v49, v51, v52
    vf.fms       v54, v51, v53, v51
    vf.neg       v53, v54                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v53, v53
    @p2 v.sel        v54, v53, v51
    vf.mul       v51, v35, v54                   // a/y: faithful quotient
    vf.fms       v53, v51, v49, v35
    vf.fms       v35, v53, v54, v51
    vf.neg       v53, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v53, v53
    @p2 v.sel        v35, v53, v51
    @p1 v.sel        v51, v5, v35
    vf.mul       v35, v50, v51
    vf.add       v53, v1, v35
    vf.add       v1, v19, v20
    vf.mul       v19, v50, v50
    vf.mul       v20, v19, v34
    vf.mul       v19, v20, v51
    vf.add       v20, v1, v19
    vf.cmp.eq    p1, v53, v6
    vf.sub       v1, v6, v53
    @p1 v.sel        v6, v5, v1
    vf.add       v1, v49, v36
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v19, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v1, v19, v52
    vf.fms       v35, v19, v34, v19
    vf.neg       v34, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v34, v34
    @p2 v.sel        v35, v34, v19
    vf.mul       v19, v36, v35                   // a/y: faithful quotient
    vf.fms       v34, v19, v1, v36
    vf.fms       v36, v34, v35, v19
    vf.neg       v34, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v34, v34
    @p2 v.sel        v35, v34, v19
    @p1 v.sel        v19, v5, v35
    vf.mul       v34, v6, v19
    vf.add       v35, v53, v34
    vf.add       v34, v20, v21
    vf.mul       v20, v6, v6
    vf.mul       v6, v20, v49
    vf.mul       v20, v6, v19
    vf.add       v6, v34, v20
    vf.cmp.eq    p1, v35, v7
    vf.sub       v19, v7, v35
    @p1 v.sel        v7, v5, v19
    vf.add       v19, v1, v37
    vf.cmp.eq    p1, v19, v5
    v.rcp.approx v20, v19                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v21, v19, v20, v52
    vf.fms       v34, v20, v21, v20
    vf.neg       v21, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v21, v21
    @p2 v.sel        v34, v21, v20
    vf.mul       v20, v37, v34                   // a/y: faithful quotient
    vf.fms       v21, v20, v19, v37
    vf.fms       v36, v21, v34, v20
    vf.neg       v21, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v21, v21
    @p2 v.sel        v34, v21, v20
    @p1 v.sel        v20, v5, v34
    vf.mul       v21, v7, v20
    vf.add       v34, v35, v21
    vf.add       v21, v6, v22
    vf.mul       v6, v7, v7
    vf.mul       v7, v6, v1
    vf.mul       v1, v7, v20
    vf.add       v6, v21, v1
    vf.cmp.eq    p1, v34, v8
    vf.sub       v1, v8, v34
    @p1 v.sel        v7, v5, v1
    vf.add       v1, v19, v38
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v8, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v20, v1, v8, v52
    vf.fms       v21, v8, v20, v8
    vf.neg       v20, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v20, v20
    @p2 v.sel        v21, v20, v8
    vf.mul       v8, v38, v21                    // a/y: faithful quotient
    vf.fms       v20, v8, v1, v38
    vf.fms       v22, v20, v21, v8
    vf.neg       v20, v22                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v20, v20
    @p2 v.sel        v21, v20, v8
    @p1 v.sel        v8, v5, v21
    vf.mul       v20, v7, v8
    vf.add       v21, v34, v20
    vf.add       v20, v6, v23
    vf.mul       v6, v7, v7
    vf.mul       v7, v6, v19
    vf.mul       v6, v7, v8
    vf.add       v7, v20, v6
    vf.cmp.eq    p1, v21, v9
    vf.sub       v6, v9, v21
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v1, v39
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v19, v6, v9, v52
    vf.fms       v20, v9, v19, v9
    vf.neg       v19, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v20, v19, v9
    vf.mul       v9, v39, v20                    // a/y: faithful quotient
    vf.fms       v19, v9, v6, v39
    vf.fms       v22, v19, v20, v9
    vf.neg       v19, v22                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v20, v19, v9
    @p1 v.sel        v9, v5, v20
    vf.mul       v19, v8, v9
    vf.add       v20, v21, v19
    vf.add       v19, v7, v24
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v1
    vf.mul       v1, v8, v9
    vf.add       v7, v19, v1
    vf.cmp.eq    p1, v20, v10
    vf.sub       v1, v10, v20
    @p1 v.sel        v8, v5, v1
    vf.add       v1, v6, v40
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v9, v52
    vf.fms       v19, v9, v10, v9
    vf.neg       v10, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v19, v10, v9
    vf.mul       v9, v40, v19                    // a/y: faithful quotient
    vf.fms       v10, v9, v1, v40
    vf.fms       v21, v10, v19, v9
    vf.neg       v10, v21                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v19, v10, v9
    @p1 v.sel        v9, v5, v19
    vf.mul       v10, v8, v9
    vf.add       v19, v20, v10
    vf.add       v10, v7, v25
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v9
    vf.add       v7, v10, v6
    vf.cmp.eq    p1, v19, v11
    vf.sub       v6, v11, v19
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v1, v41
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v41, v11                    // a/y: faithful quotient
    vf.fms       v10, v9, v6, v41
    vf.fms       v20, v10, v11, v9
    vf.neg       v10, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    @p1 v.sel        v9, v5, v11
    vf.mul       v10, v8, v9
    vf.add       v11, v19, v10
    vf.add       v10, v7, v26
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v1
    vf.mul       v1, v8, v9
    vf.add       v7, v10, v1
    vf.cmp.eq    p1, v11, v12
    vf.sub       v1, v12, v11
    @p1 v.sel        v8, v5, v1
    vf.add       v1, v6, v42
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v42, v12                    // a/y: faithful quotient
    vf.fms       v10, v9, v1, v42
    vf.fms       v19, v10, v12, v9
    vf.neg       v10, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    @p1 v.sel        v9, v5, v12
    vf.mul       v10, v8, v9
    vf.add       v12, v11, v10
    vf.add       v10, v7, v27
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v9
    vf.add       v7, v10, v6
    vf.cmp.eq    p1, v12, v13
    vf.sub       v6, v13, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v1, v43
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v43, v11                    // a/y: faithful quotient
    vf.fms       v10, v9, v6, v43
    vf.fms       v13, v10, v11, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    @p1 v.sel        v9, v5, v11
    vf.mul       v10, v8, v9
    vf.add       v11, v12, v10
    vf.add       v10, v7, v28
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v1
    vf.mul       v1, v8, v9
    vf.add       v7, v10, v1
    vf.cmp.eq    p1, v11, v14
    vf.sub       v1, v14, v11
    @p1 v.sel        v8, v5, v1
    vf.add       v1, v6, v44
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v44, v12                    // a/y: faithful quotient
    vf.fms       v10, v9, v1, v44
    vf.fms       v13, v10, v12, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    @p1 v.sel        v9, v5, v12
    vf.mul       v10, v8, v9
    vf.add       v12, v11, v10
    vf.add       v10, v7, v29
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v9
    vf.add       v7, v10, v6
    vf.cmp.eq    p1, v12, v15
    vf.sub       v6, v15, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v1, v45
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v45, v11                    // a/y: faithful quotient
    vf.fms       v10, v9, v6, v45
    vf.fms       v13, v10, v11, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    @p1 v.sel        v9, v5, v11
    vf.mul       v10, v8, v9
    vf.add       v11, v12, v10
    vf.add       v10, v7, v30
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v1
    vf.mul       v1, v8, v9
    vf.add       v7, v10, v1
    vf.cmp.eq    p1, v11, v16
    vf.sub       v1, v16, v11
    @p1 v.sel        v8, v5, v1
    vf.add       v1, v6, v46
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v46, v12                    // a/y: faithful quotient
    vf.fms       v10, v9, v1, v46
    vf.fms       v13, v10, v12, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    @p1 v.sel        v9, v5, v12
    vf.mul       v10, v8, v9
    vf.add       v12, v11, v10
    vf.add       v10, v7, v31
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v9
    vf.add       v7, v10, v6
    vf.cmp.eq    p1, v12, v17
    vf.sub       v6, v17, v12
    @p1 v.sel        v8, v5, v6
    vf.add       v6, v1, v47
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v9, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v9, v52
    vf.fms       v11, v9, v10, v9
    vf.neg       v10, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    vf.mul       v9, v47, v11                    // a/y: faithful quotient
    vf.fms       v10, v9, v6, v47
    vf.fms       v13, v10, v11, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v9
    @p1 v.sel        v9, v5, v11
    vf.mul       v10, v8, v9
    vf.add       v11, v12, v10
    vf.add       v10, v7, v32
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v1
    vf.mul       v1, v8, v9
    vf.add       v7, v10, v1
    vf.cmp.eq    p1, v11, v18
    vf.sub       v1, v18, v11
    @p1 v.sel        v8, v5, v1
    vf.add       v1, v6, v48
    vf.cmp.eq    p1, v1, v5
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v9, v52
    vf.fms       v12, v9, v10, v9
    vf.neg       v10, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    vf.mul       v9, v48, v12                    // a/y: faithful quotient
    vf.fms       v10, v9, v1, v48
    vf.fms       v13, v10, v12, v9
    vf.neg       v10, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v12, v10, v9
    @p1 v.sel        v9, v5, v12
    vf.mul       v10, v8, v9
    vf.add       v12, v11, v10
    vf.add       v10, v7, v33
    vf.mul       v7, v8, v8
    vf.mul       v8, v7, v6
    vf.mul       v6, v8, v9
    vf.add       v7, v10, v6
    vf.cmp.eq    p1, v12, v2
    vf.sub       v6, v2, v12
    @p1 v.sel        v2, v5, v6
    vf.add       v6, v1, v4
    vf.cmp.eq    p1, v6, v5
    v.rcp.approx v8, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v6, v8, v52
    vf.fms       v10, v8, v9, v8
    vf.neg       v9, v10                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v10, v9, v8
    vf.mul       v8, v4, v10                     // a/y: faithful quotient
    vf.fms       v9, v8, v6, v4
    vf.fms       v4, v9, v10, v8
    vf.neg       v6, v4                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v4, v6, v8
    @p1 v.sel        v6, v5, v4
    vf.mul       v4, v2, v6
    vf.add       v5, v12, v4
    vf.add       v4, v7, v3
    vf.mul       v3, v2, v2
    vf.mul       v2, v3, v1
    vf.mul       v1, v2, v6
    vf.add       v2, v4, v1
    v.movi       v1, #0
    vf.add       v3, v5, v1
    vf.add       v4, v2, v1
    s.addi       s3, s1, #0
for_3:
    s.cmp.ge     s1, s3, s11
    br.nz        s1, endfor_4
    .li       s1, #1166016512
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s4, #8192
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v5, s3
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s5, #4096
    s.movz       s6, #64
    s.muli       s7, s3, #2
    v.add        v7, v5, v6
    v.movi       v5, #0
    v.splat      v6, s5
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s6
    v.cmp.ge     p1, v7, v5
    v.cmp.lt     p2, v7, v6
    v.cmp.ge     p3, v8, v9
    v.cmp.lt     p4, v8, v10
    s.add        s5, s2, s1
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s1, s5, s7
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s1, #0]
    v.splat      v6, s3
    s.shli       s1, s3, #1                      // element offset -> bytes (x2)
    v.add        v7, v6, v0
    v.movi       v6, #4096
    vf.fms       v8, v1, v2, v52
    vf.cvt.bf16.f32 v9, v5
    s.add        s5, s8, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v7, v6
    vf.fms       v5, v2, v8, v2
    .li       s6, #897988541
    v.splat      v6, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1077936128
    v.splat      v8, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #3204448256
    v.splat      v10, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v11, v5                         // Newton step: r0*(2 - x*r0)
    v.extract    s6, v3, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s5, #0]
    v.splat      v12, s6
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v13, v11, v2
    s.add        s5, s9, s1                      // &in_ptr5[...]
    vf.mul       v2, v4, v13                     // a/y: faithful quotient
    vf.sub       v11, v9, v12
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s5, #0]
    vf.cvt.bf16.f32 v12, v5
    vf.fms       v5, v2, v1, v4
    s.mul        s1, s4, s11
    s.add        s5, s3, s12
    s.movz       s6, #1
    vf.fms       v1, v5, v13, v2
    vf.cvt.bf16.f32 v5, v9
    s.add        s7, s3, s1
    v.splat      v9, s1
    vf.neg       v13, v1                         // a/y: one correction to the IEEE quotient
    s.shli       s1, s7, #1                      // element offset -> bytes (x2)
    v.add        v1, v7, v9
    s.add        s7, s10, s1                     // &out_ptr2[...]
    vf.cmp.o     p2, v13, v13
    @p2 v.sel        v1, v13, v2
    vf.add       v2, v1, v6
    v.rsqrt.approx v1, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v1, v1
    vf.mul       v7, v1, v10
    vf.fms       v9, v2, v6, v8
    vf.mul       v2, v7, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v6, v2, v1
    v.extract    s1, v6, #0
    v.splat      v1, s1
    vf.mul       v2, v11, v1
    vf.mul       v1, v2, v12
    vf.add       v2, v1, v5
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s7, #0], v1
    s.mov        s3, s5
    br.nz        s6, for_3
endfor_4:
__rctx_next:
    exit
