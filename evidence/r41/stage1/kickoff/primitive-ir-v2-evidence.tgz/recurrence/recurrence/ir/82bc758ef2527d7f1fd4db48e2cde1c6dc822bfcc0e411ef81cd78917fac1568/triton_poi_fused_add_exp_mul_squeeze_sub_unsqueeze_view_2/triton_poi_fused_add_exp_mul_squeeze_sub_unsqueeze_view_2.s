    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #127
    s.ld.d       s3, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #7
    v.sub        v6, v4, v3
    v.and        v7, v5, v0
    v.cmp.lt     p2, v3, v4
    @p2 v.sel        v0, v6, v3
    v.sub        v3, v2, v7
    s.ld.d       s4, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.lshr       v5, v0, v1
    @p1 v.sel        v0, v3, v7
    s.shli       s5, s1, #2                      // element offset -> bytes (x4)
    v.sub        v1, v4, v5
    v.movi       v3, #128
    @p2 v.sel        v6, v1, v5
    v.sub        v1, v4, v3
    v.sub        v5, v2, v3
    v.cmp.lt     p1, v3, v4
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p2, v3, v2
    @p1 v.sel        v2, v1, v3
    @p2 v.sel        v1, v5, v3
    s.ld.d       s6, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.add        s7, s1, s5                      // &in_ptr0[...]
    s.ld.d       s1, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.ld.gather.w v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v2, [s4, v0]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    vf.sub       v0, v1, v2
    s.ld.w       s4, [s6, #0]                    // one element, not a vector
    v.ld.w       v1, [s7, #0]
    v.splat      v2, s4
    vf.mul       v3, v0, v2
    v.ld.gather.w v0, [s1, v6]                   // index is in elements (ISA sec 9.1)
    s.ld.w       s1, [s3, #0]                    // one element, not a vector
    vf.mul       v2, v0, v3
    s.ld.d       s3, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    v.splat      v0, s1
    vf.mul       v3, v1, v0
    vf.add       v0, v3, v2
    s.add        s1, s3, s5                      // &out_ptr0[...]
    v.st.w       [s1, #0], v0
__rctx_next:
    exit
