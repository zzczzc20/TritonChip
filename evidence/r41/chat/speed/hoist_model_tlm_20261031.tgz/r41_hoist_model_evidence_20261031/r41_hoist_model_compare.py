import json,math,torch
from pathlib import Path
from safetensors.torch import load_file
h=Path.home(); roots=[h/'r41_profile_model_astage_lru',h/'r41_profile_model_hoist_lru'];result={'schema':'r41-shape-hoist-model-tlm-ab/1','scope':'one-layer VL, uncalibrated DP TLM, before final device/shape guard; not board','routes':[]}
for d in roots:
 r=json.load(open(d/'report.json')); p=json.load(open(d/'profile/launches.json')); row={'route':d.name,'status':r.get('status'),'fp8_route':r.get('fp8_route_in_use'),'cpu_numerical_fallback':r.get('cpu_numerical_fallback'),'generated_tokens':r.get('generated_tokens'),'steps':[]}
 for step,kind in ((1,'prefill'),(2,'decode')):
  xs=[x for x in p['launches'] if x['step']==step and not x.get('skipped',False)];fs=[x for x in xs if x['kernel'] in ('w8a8_block_dynamic_fp8_matmul_kernel','w8a8_block_fp8_matmul_kernel')];qs=[x for x in xs if 'precise_block_quant' in x['kernel']];mac=0
  for x in fs:
   w=next(z for z in x['args'] if z.get('role')=='weight' and z.get('dtype')=='float8_e4m3fn');a=next(z for z in x['args'] if z.get('role')=='act' and z.get('dtype') in ('bfloat16','float8_e4m3fn'));mac+=math.prod(a['shape'][:-1])*math.prod(w['shape'])
  ins=sum(sum(v for k,v in x['counters'].items() if k.startswith('core_') and k.endswith('_instructions')) for x in fs+qs);reported=next(z for z in r['steps'] if z['kind']==kind)
  row['steps'].append(dict(kind=kind,launches=len(xs),device_cycles=sum(x['device_cycles'] for x in xs),code_loads=sum(x['code_load_count'] for x in xs),code_bytes=sum(x['code_upload_bytes'] for x in xs),evictions=sum(x['evicted'] for x in xs),host_read_calls=reported['transfers_inside_step']['host_read_calls'],hoisted_quant_launches=len(qs),fp8_macs=mac,fp8_instructions=ins,fp8_instructions_per_mac=ins/mac,fp8_cycles=sum(x['device_cycles'] for x in fs+qs)))
 result['routes'].append(row)
a=load_file(str(roots[0]/'logits.safetensors'));b=load_file(str(roots[1]/'logits.safetensors'))
result['logits']={k:dict(elements=a[k].numel(),bit_mismatches=int((a[k].contiguous().view(torch.int16)!=b[k].contiguous().view(torch.int16)).sum())) for k in a}
result['caveat']='reduced-depth model logits against TLM control; not independent full-model CPU quality or board throughput; non-default prototype';(h/'r41_hoist_model_compare_20261031.json').write_text(json.dumps(result,indent=2)+'\n')
