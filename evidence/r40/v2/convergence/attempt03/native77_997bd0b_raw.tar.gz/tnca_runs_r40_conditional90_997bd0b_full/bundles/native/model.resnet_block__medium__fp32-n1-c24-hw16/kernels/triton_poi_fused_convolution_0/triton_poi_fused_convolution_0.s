    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s5, s4, #4                      // x16 as a shift
    s.movz       s4, #0
    s.rdspecial  s6, pid.y
    s.rdspecial  s7, role_id
    s.movz       s8, #1280
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    s.add        s9, s4, s5                      // the tile origin
    s.shli       s10, s6, #4                     // x16 as a shift
    s.muli       s6, s5, #4                      // a runtime tile origin, x4
    s.mul        s11, s7, s8
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s7, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s9
    s.add        s2, s4, s10                     // the tile origin
    s.muli       s4, s10, #1024                  // a runtime tile origin, x1024
    v.add        v2, v0, v1
    v.splat      v0, s2
    s.add        s8, s3, s6                      // the tile origin
    v.cmpi.lt    p1, v2, #256
    v.cmpi.lt    p2, v0, #24
    s.add        s3, s8, s4                      // the tile origin
    s.movz       s4, #256
    s.ld.d       s6, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.add        s1, s7, s11                     // this context's own scratch
    s.movz       s7, #24
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #96
    s.movz       s11, #4
    .li       s12, #68719476752
    p.and        p3, p1, p2
    s.addi       s13, s1, #256                   // 1024 bytes of repack scratch
    s.st.d       [s8, #0], s6
    s.st.d       [s8, #8], s4
    .li       s1, #2207613190144
    s.st.d       [s8, #16], s7
    s.addi       s4, s2, #1
    v.splat      v0, s4
    s.addi       s4, s3, #1024                   // row 1
    v.cmpi.lt    p2, v0, #24
    p.and        p4, p1, p2
    s.st.d       [s8, #48], s9
    s.movz       s7, #1
    s.muli       s9, s7, #64
    s.add        s7, s13, s9
    s.st.d       [s8, #56], s11
    s.addi       s9, s2, #2
    v.splat      v0, s9
    s.addi       s9, s3, #2048                   // row 2
    v.cmpi.lt    p2, v0, #24
    p.and        p5, p1, p2
    s.st.d       [s8, #88], s12
    s.movz       s11, #2
    s.muli       s12, s11, #64
    s.add        s11, s13, s12
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s2, #3
    s.addi       s8, s3, #3072                   // row 3
    v.splat      v0, s1
    s.movz       s1, #3
    s.muli       s12, s1, #64
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s3, #0]
    v.cmpi.lt    p2, v0, #24
    p.and        p3, p1, p2
    s.add        s1, s13, s12
    v.st.w       [s13, #0], v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #4
    v.splat      v1, s4
    s.addi       s4, s3, #4096                   // row 4
    v.cmpi.lt    p2, v1, #24
    p.and        p4, p1, p2
    v.st.w       [s7, #0], v0
    s.movz       s7, #4
    s.muli       s12, s7, #64
    s.add        s7, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #5
    v.splat      v1, s9
    s.addi       s9, s3, #5120                   // row 5
    v.cmpi.lt    p2, v1, #24
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v0
    s.movz       s11, #5
    s.muli       s12, s11, #64
    s.add        s11, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #6
    v.splat      v1, s8
    s.addi       s8, s3, #6144                   // row 6
    v.cmpi.lt    p2, v1, #24
    p.and        p3, p1, p2
    v.st.w       [s1, #0], v0
    s.movz       s1, #6
    s.muli       s12, s1, #64
    s.add        s1, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #7
    v.splat      v1, s4
    s.addi       s4, s3, #7168                   // row 7
    v.cmpi.lt    p2, v1, #24
    p.and        p4, p1, p2
    v.st.w       [s7, #0], v0
    s.movz       s7, #7
    s.muli       s12, s7, #64
    s.add        s7, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #8
    v.splat      v1, s9
    s.addi       s9, s3, #8192                   // row 8
    v.cmpi.lt    p2, v1, #24
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v0
    s.movz       s11, #8
    s.muli       s12, s11, #64
    s.add        s11, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9
    v.splat      v1, s8
    s.addi       s8, s3, #9216                   // row 9
    v.cmpi.lt    p2, v1, #24
    p.and        p3, p1, p2
    v.st.w       [s1, #0], v0
    s.movz       s1, #9
    s.muli       s12, s1, #64
    s.add        s1, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #10
    v.splat      v1, s4
    s.addi       s4, s3, #10240                  // row 10
    v.cmpi.lt    p2, v1, #24
    p.and        p4, p1, p2
    v.st.w       [s7, #0], v0
    s.movz       s7, #10
    s.muli       s12, s7, #64
    s.add        s7, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #11
    v.splat      v1, s9
    s.addi       s9, s3, #11264                  // row 11
    v.cmpi.lt    p2, v1, #24
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v0
    s.movz       s11, #11
    s.muli       s12, s11, #64
    s.add        s11, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #12
    v.splat      v1, s8
    s.addi       s8, s3, #12288                  // row 12
    v.cmpi.lt    p2, v1, #24
    p.and        p3, p1, p2
    v.st.w       [s1, #0], v0
    s.movz       s1, #12
    s.muli       s12, s1, #64
    s.add        s1, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #13
    v.splat      v1, s4
    s.addi       s4, s3, #13312                  // row 13
    v.cmpi.lt    p2, v1, #24
    p.and        p4, p1, p2
    v.st.w       [s7, #0], v0
    s.movz       s7, #13
    s.muli       s12, s7, #64
    s.add        s7, s13, s12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #14
    s.addi       s12, s2, #15
    v.splat      v1, s9
    s.addi       s2, s3, #14336                  // row 14
    v.splat      v2, s12
    v.cmpi.lt    p2, v1, #24
    p.and        p5, p1, p2
    s.movz       s9, #14
    s.addi       s12, s3, #15360                 // row 15
    s.muli       s3, s9, #64
    s.add        s9, s13, s3
    v.st.w       [s11, #0], v0
    s.movz       s3, #0
    // tl.trans: 16 columns, gathered %c180:scalar elements apart (ISA sec 9.1)
    v.iota       v0                              // arange(0, VLEN)
    s.muli       s11, s3, #64
    s.add        s3, s13, s11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s8, #0]
    v.cmpi.lt    p2, v2, #24
    p.and        p3, p1, p2
    s.movz       s8, #0
    s.muli       s11, s8, #4
    s.add        s8, s3, s11
    s.movz       s3, #15
    s.muli       s11, s3, #64
    v.st.w       [s1, #0], v1
    s.movz       s1, #16
    s.add        s3, s13, s11
    v.splat      v1, s1
    s.addi       s1, s8, #4                      // column 1
    s.addi       s11, s8, #8                     // column 2
    v.mul        v2, v0, v1                      // one element per source row
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #12                     // column 3
    v.st.w       [s7, #0], v0
    s.addi       s7, s8, #16                     // column 4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #20                     // column 5
    v.st.w       [s9, #0], v0
    s.addi       s9, s8, #24                     // column 6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s12, #0]
    s.addi       s12, s8, #28                    // column 7
    v.splat      v1, s10
    s.muli       s13, s10, #4
    v.st.w       [s3, #0], v0
    s.addi       s3, s8, #32                     // column 8
    fence.acq_rel.device
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v3, #0
    v.splat      v4, s5
    v.add        v5, v1, v0
    v.movi       v0, #0
    v.cmpi.lt    p1, v4, #256
    v.cmp.ge     p2, v5, v3
    v.cmpi.lt    p3, v5, #24
    v.cmp.ge     p4, v4, v0
    p.and        p5, p2, p3
    p.and        p2, p4, p1
    p.and        p1, p5, p2
    v.ld.gather.w v0, [s8, v2]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v1, [s1, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s1, s8, #36                     // column 9
    v.ld.gather.w v3, [s11, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s10, s8, #40                    // column 10
    v.ld.gather.w v4, [s4, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s8, #44                     // column 11
    v.movi       v5, #0
    v.ld.gather.w v6, [s7, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s8, #48                     // column 12
    v.ld.gather.w v7, [s2, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s2, s8, #52                     // column 13
    v.ld.gather.w v8, [s9, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s8, #56                     // column 14
    s.addi       s11, s8, #60                    // column 15
    v.ld.gather.w v9, [s12, v2]                  // index is in elements (ISA sec 9.1)
    s.muli       s8, s5, #96
    s.add        s12, s6, s8
    s.addi       s6, s5, #1
    s.add        s8, s12, s13
    s.addi       s12, s5, #2
    v.splat      v10, s6
    s.movz       s6, #1
    s.muli       s13, s6, #96
    v.cmp.ge     p2, v10, v5
    v.cmpi.lt    p3, v10, #256
    p.and        p4, p2, p3
    v.ld.gather.w v5, [s3, v2]                   // index is in elements (ISA sec 9.1)
    s.movz       s3, #2
    v.splat      v10, s12
    v.movi       v11, #0
    s.muli       s6, s3, #96
    s.add        s3, s8, s13
    p.and        p2, p5, p4
    s.add        s12, s8, s6
    v.ld.gather.w v12, [s1, v2]                  // index is in elements (ISA sec 9.1)
    v.cmp.ge     p3, v10, v11
    v.ld.gather.w v11, [s10, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s4, v2]                  // index is in elements (ISA sec 9.1)
    s.movz       s1, #3
    v.ld.gather.w v14, [s7, v2]                  // index is in elements (ISA sec 9.1)
    s.muli       s4, s1, #96
    s.add        s1, s8, s4
    v.ld.gather.w v15, [s2, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s2, s5, #3
    v.splat      v16, s2
    v.ld.gather.w v17, [s9, v2]                  // index is in elements (ISA sec 9.1)
    v.movi       v18, #0
    v.ld.gather.w v19, [s11, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s2, s5, #4
    s.movz       s4, #4
    s.movz       s6, #5
    v.splat      v2, s2
    v.movi       v20, #0
    s.muli       s2, s4, #96
    s.muli       s4, s6, #96
    s.add        s6, s8, s2
    s.add        s2, s8, s4
    @p1 v.st.w       [s8, #0], v0
    s.addi       s4, s5, #5
    s.movz       s7, #6
    v.splat      v0, s4
    v.movi       v21, #0
    s.muli       s4, s7, #96
    v.cmpi.lt    p1, v10, #256
    p.and        p4, p3, p1
    v.cmp.ge     p1, v16, v18
    p.and        p3, p5, p4
    s.add        s7, s8, s4
    @p2 v.st.w       [s3, #0], v1
    s.addi       s3, s5, #6
    s.movz       s4, #7
    v.splat      v1, s3
    v.movi       v10, #0
    s.muli       s3, s4, #96
    v.cmpi.lt    p2, v16, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v2, v20
    p.and        p2, p5, p4
    s.add        s4, s8, s3
    @p3 v.st.w       [s12, #0], v3
    s.addi       s3, s5, #7
    s.movz       s9, #8
    v.splat      v3, s3
    v.movi       v16, #0
    s.muli       s3, s9, #96
    v.cmpi.lt    p3, v2, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v21
    p.and        p3, p5, p4
    s.add        s9, s8, s3
    @p2 v.st.w       [s1, #0], v4
    s.addi       s1, s5, #8
    s.movz       s3, #9
    v.splat      v2, s1
    v.movi       v4, #0
    s.muli       s1, s3, #96
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v10
    p.and        p2, p5, p4
    s.add        s3, s8, s1
    @p3 v.st.w       [s6, #0], v6
    s.addi       s1, s5, #9
    s.movz       s6, #10
    v.splat      v0, s1
    v.movi       v6, #0
    s.muli       s1, s6, #96
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v3, v16
    p.and        p3, p5, p4
    s.add        s6, s8, s1
    @p2 v.st.w       [s2, #0], v7
    s.addi       s1, s5, #10
    s.movz       s2, #11
    v.splat      v1, s1
    v.movi       v7, #0
    s.muli       s1, s2, #96
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v2, v4
    p.and        p2, p5, p4
    s.add        s2, s8, s1
    @p3 v.st.w       [s7, #0], v8
    s.addi       s1, s5, #11
    s.movz       s7, #12
    v.splat      v3, s1
    v.movi       v4, #0
    s.muli       s1, s7, #96
    v.cmpi.lt    p3, v2, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v6
    p.and        p3, p5, p4
    s.add        s7, s8, s1
    @p2 v.st.w       [s4, #0], v9
    s.addi       s1, s5, #12
    s.movz       s4, #13
    v.splat      v2, s1
    v.movi       v6, #0
    s.muli       s1, s4, #96
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v7
    p.and        p2, p5, p4
    s.add        s4, s8, s1
    @p3 v.st.w       [s9, #0], v5
    s.addi       s1, s5, #13
    s.movz       s9, #14
    v.splat      v0, s1
    v.movi       v5, #0
    s.muli       s1, s9, #96
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v3, v4
    p.and        p3, p5, p4
    s.add        s9, s8, s1
    @p2 v.st.w       [s3, #0], v12
    s.addi       s1, s5, #14
    s.movz       s3, #15
    v.splat      v1, s1
    v.movi       v4, #0
    s.muli       s1, s3, #96
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v2, v6
    p.and        p2, p5, p4
    s.add        s3, s8, s1
    @p3 v.st.w       [s6, #0], v11
    s.addi       s1, s5, #15
    v.movi       v3, #0
    v.splat      v6, s1
    v.cmpi.lt    p3, v2, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v5
    p.and        p3, p5, p4
    @p2 v.st.w       [s2, #0], v13
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v4
    p.and        p2, p5, p4
    @p3 v.st.w       [s7, #0], v14
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v6, v3
    p.and        p3, p5, p4
    @p2 v.st.w       [s4, #0], v15
    v.cmpi.lt    p2, v6, #256
    p.and        p4, p1, p2
    p.and        p1, p5, p4
    @p3 v.st.w       [s9, #0], v17
    @p1 v.st.w       [s3, #0], v19
__rctx_next:
    exit
