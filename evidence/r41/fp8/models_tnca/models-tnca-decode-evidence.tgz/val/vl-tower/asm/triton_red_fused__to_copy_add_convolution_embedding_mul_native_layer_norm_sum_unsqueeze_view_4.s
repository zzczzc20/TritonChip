    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr5: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #256
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s11, #0], s2
    s.movz       s1, #256
    s.st.d       [s11, #8], s1
    s.movz       s1, #1024
    s.st.d       [s11, #16], s1
    s.movz       s1, #2048
    s.st.d       [s11, #48], s1
    s.movz       s1, #2
    s.st.d       [s11, #56], s1
    .li       s1, #68719476737
    s.st.d       [s11, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s11, #104], s1
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #4
    s.movz       s11, #1
    s.movz       s12, #1
    s.movz       s13, #1
    s.movz       s14, #1
    s.movz       s15, #1
    s.movz       s16, #2
    s.movz       s17, #1
    s.movz       s18, #1
    s.movz       s19, #3
    s.movz       s20, #1
    s.movz       s21, #1
    s.movz       s22, #0
    s.movz       s23, #1024
    s.movz       s24, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s25, s4, s1
    v.splat      v1, s25
    s.shli       s1, s25, #3                     // element offset -> bytes (x8)
    s.add        s26, s5, s1                     // &in_ptr1[...]
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s11
    v.cmp.lt     p1, v2, v3
    v.movi       v2, #1
    v.shl        v3, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s26, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s1, s26, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s1, v3]               // index is in elements (ISA sec 9.1)
    s.shli       s1, s25, #2                     // element offset -> bytes (x4)
    s.add        s11, s7, s1                     // &in_ptr3[...]
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s12
    v.cmp.lt     p1, v3, v4
    v.movi       v3, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s11, v3]              // index is in elements (ISA sec 9.1)
    s.add        s1, s25, s13
    v.splat      v3, s1
    s.shli       s11, s1, #3                     // element offset -> bytes (x8)
    s.add        s12, s5, s11                    // &in_ptr1[...]
    v.movi       v3, #0
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s14
    v.cmp.lt     p1, v5, v6
    v.movi       v5, #1
    v.shl        v6, v3, v5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s12, v6]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s12, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s11, v6]              // index is in elements (ISA sec 9.1)
    s.shli       s11, s1, #2                     // element offset -> bytes (x4)
    s.add        s1, s7, s11                     // &in_ptr3[...]
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s15
    v.cmp.lt     p1, v6, v7
    v.movi       v6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s1, v6]               // index is in elements (ISA sec 9.1)
    s.add        s1, s25, s16
    v.splat      v6, s1
    s.shli       s11, s1, #3                     // element offset -> bytes (x8)
    s.add        s12, s5, s11                    // &in_ptr1[...]
    v.movi       v6, #0
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s17
    v.cmp.lt     p1, v8, v9
    v.movi       v8, #1
    v.shl        v9, v6, v8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s12, v9]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s12, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s11, v9]              // index is in elements (ISA sec 9.1)
    s.shli       s11, s1, #2                     // element offset -> bytes (x4)
    s.add        s1, s7, s11                     // &in_ptr3[...]
    v.iota       v9                              // arange(0, VLEN)
    v.splat      v10, s18
    v.cmp.lt     p1, v9, v10
    v.movi       v9, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s1, v9]              // index is in elements (ISA sec 9.1)
    s.add        s1, s25, s19
    v.splat      v9, s1
    s.shli       s11, s1, #3                     // element offset -> bytes (x8)
    s.add        s12, s5, s11                    // &in_ptr1[...]
    v.movi       v9, #0
    v.iota       v11                             // arange(0, VLEN)
    v.splat      v12, s20
    v.cmp.lt     p1, v11, v12
    v.movi       v11, #1
    v.shl        v12, v9, v11
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s12, v12]             // index is in elements (ISA sec 9.1)
    s.addi       s5, s12, #4
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v11, [s5, v12]             // index is in elements (ISA sec 9.1)
    s.shli       s5, s1, #2                      // element offset -> bytes (x4)
    s.add        s1, s7, s5                      // &in_ptr3[...]
    v.iota       v12                             // arange(0, VLEN)
    v.splat      v13, s21
    v.cmp.lt     p1, v12, v13
    v.movi       v12, #0
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v13, [s1, v12]             // index is in elements (ISA sec 9.1)
    s.addi       s1, s22, #0
    v.movi       v12, #0
    v.movi       v14, #0
    v.mov        v14, v12
for_1:
    s.cmp.ge     s5, s1, s23
    br.nz        s5, endfor_2
    s.muli       s5, s4, #2048
    v.splat      v15, s1
    v.iota       v16                             // arange(0, VLEN)
    s.movz       s7, #1024
    s.movz       s11, #256
    s.muli       s12, s1, #2
    v.add        v17, v15, v16
    v.movi       v15, #0
    v.splat      v16, s7
    v.splat      v18, s4
    v.movi       v19, #0
    v.splat      v20, s11
    v.extract    s7, v2, #0
    v.extract    s11, v2, #0
    s.shli       s13, s7, #32
    s.shli       s7, s11, #32
    v.splat      v21, s1
    v.cmp.ge     p1, v17, v15
    v.cmp.lt     p2, v17, v16
    v.cmp.ge     p3, v18, v19
    v.cmp.lt     p4, v18, v20
    v.extract    s11, v1, #0
    v.extract    s14, v1, #0
    s.add        s15, s2, s5
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.or         s5, s11, s13
    s.shli       s11, s1, #1                     // element offset -> bytes (x2)
    s.or         s13, s14, s7
    s.movz       s7, #0
    v.add        v15, v21, v0
    v.movi       v16, #1024
    s.add        s14, s15, s12
    s.movz       s12, #2304
    p.and        p2, p5, p1
    s.add        s15, s3, s11                    // &in_ptr0[...]
    v.movi       v17, #0
    s.cmp.ge     s11, s5, s7
    v.movi       v18, #0
    s.cmp.lt     s5, s13, s12
    v.cmp.lt     p1, v15, v16
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v16, [s14, #0]
    v.movi       v19, #0
    v.movi       v20, #0
    s.movz       s7, #1
    v.movi       v21, #0
    v.movi       v22, #1
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v23, [s15, #0]
    v.insert     v17, s11, #0
    v.insert     v18, s5, #0
    v.cmp.ne     p2, v17, v19
    v.cmp.ne     p3, v18, v20
    p.and        p4, p2, p3
    v.iota       v17                             // arange(0, VLEN)
    v.splat      v18, s7
    @p4 v.sel        v19, v21, v22
    vf.cvt.bf16.f32 v20, v16
    vf.cvt.bf16.f32 v16, v23
    v.cmp.lt     p2, v17, v18
    s.movz       s5, #0
    @p2 v.reduce.or  s7, v19
    s.cmp.eq     s11, s7, s5
    vf.add       v17, v20, v16
    br.nz        s11, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s5, v2, #0
    s.shli       s7, s5, #32
    v.extract    s5, v1, #0
    s.or         s11, s5, s7
    s.movz       s5, #1024
    v.extract    s7, v15, #0
    s.mul        s12, s11, s5
    s.shli       s5, s7, #32
    v.extract    s7, v15, #1
    s.ashri      s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #2
    v.movi       v16, #0
    v.movi       v18, #0
    s.lshri      s13, s12, #32
    v.movi       v19, #0
    v.movi       v20, #0
    s.lshri      s14, s11, #32
    s.ashri      s15, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #3
    v.insert     v16, s12, #0
    v.insert     v18, s13, #0
    v.insert     v19, s11, #0
    v.insert     v20, s14, #0
    s.lshri      s11, s15, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #4
    v.insert     v19, s15, #1
    v.insert     v20, s11, #1
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #5
    v.insert     v19, s12, #2
    v.insert     v20, s11, #2
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #6
    v.insert     v19, s13, #3
    v.insert     v20, s11, #3
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #7
    v.insert     v19, s12, #4
    v.insert     v20, s11, #4
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #8
    v.insert     v19, s13, #5
    v.insert     v20, s11, #5
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #9
    v.insert     v19, s12, #6
    v.insert     v20, s11, #6
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #10
    v.insert     v19, s13, #7
    v.insert     v20, s11, #7
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #11
    v.insert     v19, s12, #8
    v.insert     v20, s11, #8
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #12
    v.insert     v19, s13, #9
    v.insert     v20, s11, #9
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #13
    v.insert     v19, s12, #10
    v.insert     v20, s11, #10
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #14
    v.insert     v19, s13, #11
    v.insert     v20, s11, #11
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v15, #15
    v.extract    s14, v18, #0
    v.insert     v19, s12, #12
    v.insert     v20, s11, #12
    s.lshri      s11, s13, #32
    s.ashri      s12, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s14, #32
    v.extract    s14, v16, #0
    v.extract    s15, v18, #0
    v.insert     v19, s13, #13
    v.insert     v20, s11, #13
    s.lshri      s11, s12, #32
    s.ashri      s13, s5, #32
    s.or         s5, s14, s7
    s.shli       s7, s15, #32
    v.extract    s14, v16, #0
    v.extract    s15, v18, #0
    v.insert     v19, s12, #14
    v.insert     v20, s11, #14
    s.lshri      s11, s13, #32
    v.movi       v21, #0
    v.movi       v22, #0
    s.lshri      s12, s5, #32
    s.or         s16, s14, s7
    s.shli       s7, s15, #32
    v.extract    s14, v16, #0
    v.insert     v19, s13, #15
    v.extract    s13, v18, #0
    v.insert     v20, s11, #15
    v.insert     v21, s5, #0
    v.insert     v22, s12, #0
    s.lshri      s5, s16, #32
    s.or         s11, s14, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s16, #1
    v.insert     v22, s5, #1
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #2
    v.insert     v22, s5, #2
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s14, #3
    v.insert     v22, s5, #3
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #4
    v.insert     v22, s5, #4
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s14, #5
    v.insert     v22, s5, #5
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #6
    v.insert     v22, s5, #6
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s14, #7
    v.insert     v22, s5, #7
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #8
    v.insert     v22, s5, #8
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s14, #9
    v.insert     v22, s5, #9
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #10
    v.insert     v22, s5, #10
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s14, #11
    v.insert     v22, s5, #11
    s.lshri      s5, s11, #32
    s.or         s14, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.extract    s13, v18, #0
    v.insert     v21, s11, #12
    v.insert     v22, s5, #12
    s.lshri      s5, s14, #32
    s.or         s11, s12, s7
    s.shli       s7, s13, #32
    v.extract    s12, v16, #0
    v.insert     v21, s14, #13
    v.insert     v22, s5, #13
    s.lshri      s5, s11, #32
    s.or         s13, s12, s7
    v.insert     v21, s11, #14
    v.insert     v22, s5, #14
    s.lshri      s5, s13, #32
    v.insert     v21, s13, #15
    v.insert     v22, s5, #15
    v.extract    s5, v20, #0
    v.extract    s7, v22, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #0
    v.extract    s12, v21, #0
    v.extract    s13, v20, #1
    v.extract    s14, v22, #1
    s.or         s15, s7, s11
    s.or         s7, s12, s5
    s.shli       s5, s13, #32
    s.shli       s11, s14, #32
    v.extract    s12, v19, #1
    v.extract    s13, v21, #1
    v.extract    s14, v20, #2
    v.movi       v16, #0
    s.add        s16, s15, s7
    v.extract    s7, v22, #2
    s.or         s15, s12, s5
    s.or         s5, s13, s11
    s.shli       s11, s14, #32
    s.shli       s12, s7, #32
    v.extract    s7, v19, #2
    v.extract    s13, v21, #2
    v.movi       v18, #0
    v.insert     v16, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s5
    v.extract    s5, v20, #3
    s.or         s15, s7, s11
    v.extract    s7, v22, #3
    s.or         s11, s13, s12
    s.shli       s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #3
    v.insert     v18, s14, #0
    v.extract    s13, v21, #3
    v.insert     v16, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #4
    s.or         s15, s7, s12
    v.extract    s7, v22, #4
    s.or         s12, s13, s5
    s.shli       s5, s11, #32
    s.shli       s11, s7, #32
    v.extract    s7, v19, #4
    v.insert     v18, s14, #1
    v.extract    s13, v21, #4
    v.insert     v16, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #5
    s.or         s15, s7, s5
    v.extract    s5, v22, #5
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #5
    v.insert     v18, s14, #2
    v.extract    s13, v21, #5
    v.insert     v16, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #6
    s.or         s15, s5, s11
    v.extract    s5, v22, #6
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #6
    v.insert     v18, s14, #3
    v.extract    s13, v21, #6
    v.insert     v16, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #7
    s.or         s15, s5, s12
    v.extract    s5, v22, #7
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #7
    v.insert     v18, s14, #4
    v.extract    s13, v21, #7
    v.insert     v16, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #8
    s.or         s15, s5, s7
    v.extract    s5, v22, #8
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #8
    v.insert     v18, s14, #5
    v.extract    s13, v21, #8
    v.insert     v16, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #9
    s.or         s15, s5, s11
    v.extract    s5, v22, #9
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #9
    v.insert     v18, s14, #6
    v.extract    s13, v21, #9
    v.insert     v16, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #10
    s.or         s15, s5, s12
    v.extract    s5, v22, #10
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #10
    v.insert     v18, s14, #7
    v.extract    s13, v21, #10
    v.insert     v16, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #11
    s.or         s15, s5, s7
    v.extract    s5, v22, #11
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #11
    v.insert     v18, s14, #8
    v.extract    s13, v21, #11
    v.insert     v16, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #12
    s.or         s15, s5, s11
    v.extract    s5, v22, #12
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #12
    v.insert     v18, s14, #9
    v.extract    s13, v21, #12
    v.insert     v16, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #13
    s.or         s15, s5, s12
    v.extract    s5, v22, #13
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #13
    v.insert     v18, s14, #10
    v.extract    s13, v21, #13
    v.insert     v16, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #14
    s.or         s15, s5, s7
    v.extract    s5, v22, #14
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #14
    v.insert     v18, s14, #11
    v.extract    s13, v21, #14
    v.insert     v16, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #15
    s.or         s15, s5, s11
    v.extract    s5, v22, #15
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #15
    v.insert     v18, s14, #12
    v.extract    s13, v21, #15
    v.insert     v16, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    s.or         s11, s5, s12
    s.or         s5, s13, s7
    v.insert     v18, s14, #13
    v.insert     v16, s16, #14
    s.lshri      s7, s16, #32
    s.add        s12, s11, s5
    v.insert     v18, s7, #14
    v.insert     v16, s12, #15
    s.lshri      s5, s12, #32
    v.movi       v21, #31
    v.insert     v18, s5, #15
    v.ashr       v22, v16, v21
    v.movi       v21, #1
    v.movi       v23, #0
    v.cmp.ne     p2, v18, v22
    @p2 v.sel        v18, v21, v23
    s.movz       s5, #0
    v.reduce.or  s7, v18
    s.cmp.eq     s11, s7, s5
    br.nz        s11, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.extract    s5, v5, #0
    v.extract    s7, v5, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v3, #0
    v.extract    s12, v3, #0
    s.or         s13, s7, s11
    s.movz       s7, #0
    s.or         s11, s12, s5
    s.movz       s5, #2304
    v.movi       v18, #0
    s.cmp.ge     s12, s13, s7
    v.movi       v21, #0
    s.cmp.lt     s7, s11, s5
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v22, [s6, v16]             // index is in elements (ISA sec 9.1)
    v.insert     v18, s12, #0
    v.movi       v16, #0
    v.insert     v21, s7, #0
    v.movi       v23, #0
    v.cmp.ne     p2, v18, v16
    v.cmp.ne     p3, v21, v23
    s.movz       s5, #1
    p.and        p4, p2, p3
    v.movi       v16, #0
    v.movi       v18, #1
    v.iota       v21                             // arange(0, VLEN)
    v.splat      v23, s5
    @p4 v.sel        v24, v16, v18
    vf.cvt.bf16.f32 v16, v22
    v.cmp.lt     p2, v21, v23
    s.movz       s5, #0
    v.extract    s7, v4, #0
    @p2 v.reduce.or  s11, v24
    v.splat      v18, s7
    s.cmp.eq     s7, s11, s5
    vf.mul       v21, v16, v18
    br.nz        s7, assert_ok_5
    trap         #677351
assert_ok_5:
    v.extract    s5, v5, #0
    s.shli       s7, s5, #32
    v.extract    s5, v3, #0
    s.or         s11, s5, s7
    s.movz       s5, #1024
    v.movi       v16, #0
    s.mul        s7, s11, s5
    v.movi       v18, #0
    v.movi       v22, #0
    v.movi       v23, #0
    s.lshri      s5, s7, #32
    v.insert     v16, s7, #0
    v.insert     v18, s5, #0
    v.extract    s5, v16, #0
    v.extract    s7, v18, #0
    s.shli       s11, s7, #32
    v.extract    s7, v18, #0
    s.or         s12, s5, s11
    s.shli       s5, s7, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    s.lshri      s13, s12, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s12, #0
    v.insert     v23, s13, #0
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #1
    v.insert     v23, s12, #1
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #2
    v.insert     v23, s12, #2
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #3
    v.insert     v23, s12, #3
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #4
    v.insert     v23, s12, #4
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #5
    v.insert     v23, s12, #5
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #6
    v.insert     v23, s12, #6
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #7
    v.insert     v23, s12, #7
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #8
    v.insert     v23, s12, #8
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #9
    v.insert     v23, s12, #9
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #10
    v.insert     v23, s12, #10
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #11
    v.insert     v23, s12, #11
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #12
    v.insert     v23, s12, #12
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.insert     v22, s14, #13
    v.insert     v23, s12, #13
    s.lshri      s11, s13, #32
    s.or         s12, s7, s5
    v.insert     v22, s13, #14
    v.insert     v23, s11, #14
    s.lshri      s5, s12, #32
    v.insert     v22, s12, #15
    v.insert     v23, s5, #15
    v.extract    s5, v20, #0
    v.extract    s7, v23, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #0
    v.extract    s12, v22, #0
    v.extract    s13, v20, #1
    v.extract    s14, v23, #1
    s.or         s15, s7, s11
    s.or         s7, s12, s5
    s.shli       s5, s13, #32
    s.shli       s11, s14, #32
    v.extract    s12, v19, #1
    v.extract    s13, v22, #1
    v.extract    s14, v20, #2
    v.movi       v16, #0
    s.add        s16, s15, s7
    v.extract    s7, v23, #2
    s.or         s15, s12, s5
    s.or         s5, s13, s11
    s.shli       s11, s14, #32
    s.shli       s12, s7, #32
    v.extract    s7, v19, #2
    v.extract    s13, v22, #2
    v.movi       v18, #0
    v.insert     v16, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s5
    v.extract    s5, v20, #3
    s.or         s15, s7, s11
    v.extract    s7, v23, #3
    s.or         s11, s13, s12
    s.shli       s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #3
    v.insert     v18, s14, #0
    v.extract    s13, v22, #3
    v.insert     v16, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #4
    s.or         s15, s7, s12
    v.extract    s7, v23, #4
    s.or         s12, s13, s5
    s.shli       s5, s11, #32
    s.shli       s11, s7, #32
    v.extract    s7, v19, #4
    v.insert     v18, s14, #1
    v.extract    s13, v22, #4
    v.insert     v16, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #5
    s.or         s15, s7, s5
    v.extract    s5, v23, #5
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #5
    v.insert     v18, s14, #2
    v.extract    s13, v22, #5
    v.insert     v16, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #6
    s.or         s15, s5, s11
    v.extract    s5, v23, #6
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #6
    v.insert     v18, s14, #3
    v.extract    s13, v22, #6
    v.insert     v16, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #7
    s.or         s15, s5, s12
    v.extract    s5, v23, #7
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #7
    v.insert     v18, s14, #4
    v.extract    s13, v22, #7
    v.insert     v16, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #8
    s.or         s15, s5, s7
    v.extract    s5, v23, #8
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #8
    v.insert     v18, s14, #5
    v.extract    s13, v22, #8
    v.insert     v16, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #9
    s.or         s15, s5, s11
    v.extract    s5, v23, #9
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #9
    v.insert     v18, s14, #6
    v.extract    s13, v22, #9
    v.insert     v16, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #10
    s.or         s15, s5, s12
    v.extract    s5, v23, #10
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #10
    v.insert     v18, s14, #7
    v.extract    s13, v22, #10
    v.insert     v16, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #11
    s.or         s15, s5, s7
    v.extract    s5, v23, #11
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #11
    v.insert     v18, s14, #8
    v.extract    s13, v22, #11
    v.insert     v16, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #12
    s.or         s15, s5, s11
    v.extract    s5, v23, #12
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #12
    v.insert     v18, s14, #9
    v.extract    s13, v22, #12
    v.insert     v16, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #13
    s.or         s15, s5, s12
    v.extract    s5, v23, #13
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #13
    v.insert     v18, s14, #10
    v.extract    s13, v22, #13
    v.insert     v16, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #14
    s.or         s15, s5, s7
    v.extract    s5, v23, #14
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #14
    v.insert     v18, s14, #11
    v.extract    s13, v22, #14
    v.insert     v16, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #15
    s.or         s15, s5, s11
    v.extract    s5, v23, #15
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #15
    v.insert     v18, s14, #12
    v.extract    s13, v22, #15
    v.insert     v16, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    s.or         s11, s5, s12
    s.or         s5, s13, s7
    v.insert     v18, s14, #13
    v.insert     v16, s16, #14
    s.lshri      s7, s16, #32
    s.add        s12, s11, s5
    v.insert     v18, s7, #14
    v.insert     v16, s12, #15
    s.lshri      s5, s12, #32
    v.movi       v22, #31
    v.insert     v18, s5, #15
    v.ashr       v23, v16, v22
    v.movi       v22, #1
    v.movi       v24, #0
    v.cmp.ne     p2, v18, v23
    @p2 v.sel        v18, v22, v24
    s.movz       s5, #0
    v.reduce.or  s7, v18
    s.cmp.eq     s11, s7, s5
    br.nz        s11, narrow_ok_6
    trap         #677220
narrow_ok_6:
    v.extract    s5, v8, #0
    v.extract    s7, v8, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v6, #0
    v.extract    s12, v6, #0
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v18, [s6, v16]             // index is in elements (ISA sec 9.1)
    s.or         s13, s7, s11
    s.movz       s7, #0
    s.or         s11, s12, s5
    s.movz       s5, #2304
    v.movi       v16, #0
    s.cmp.ge     s12, s13, s7
    v.movi       v22, #0
    s.cmp.lt     s7, s11, s5
    v.insert     v16, s12, #0
    v.movi       v23, #0
    v.insert     v22, s7, #0
    v.movi       v24, #0
    vf.cvt.bf16.f32 v25, v18
    v.cmp.ne     p2, v16, v23
    v.cmp.ne     p3, v22, v24
    s.movz       s5, #1
    v.extract    s7, v7, #0
    p.and        p4, p2, p3
    v.movi       v16, #0
    v.movi       v18, #1
    v.splat      v22, s7
    v.iota       v23                             // arange(0, VLEN)
    v.splat      v24, s5
    @p4 v.sel        v26, v16, v18
    vf.mul       v16, v25, v22
    v.cmp.lt     p2, v23, v24
    s.movz       s5, #0
    @p2 v.reduce.or  s7, v26
    s.cmp.eq     s11, s7, s5
    vf.add       v18, v21, v16
    br.nz        s11, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s5, v8, #0
    s.shli       s7, s5, #32
    v.extract    s5, v6, #0
    s.or         s11, s5, s7
    s.movz       s5, #1024
    v.movi       v16, #0
    s.mul        s7, s11, s5
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v23, #0
    s.lshri      s5, s7, #32
    v.insert     v16, s7, #0
    v.insert     v21, s5, #0
    v.extract    s5, v16, #0
    v.extract    s7, v21, #0
    s.shli       s11, s7, #32
    v.extract    s7, v21, #0
    s.or         s12, s5, s11
    s.shli       s5, s7, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    s.lshri      s13, s12, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s12, #0
    v.insert     v23, s13, #0
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #1
    v.insert     v23, s12, #1
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #2
    v.insert     v23, s12, #2
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #3
    v.insert     v23, s12, #3
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #4
    v.insert     v23, s12, #4
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #5
    v.insert     v23, s12, #5
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #6
    v.insert     v23, s12, #6
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #7
    v.insert     v23, s12, #7
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #8
    v.insert     v23, s12, #8
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #9
    v.insert     v23, s12, #9
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #10
    v.insert     v23, s12, #10
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s14, #11
    v.insert     v23, s12, #11
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v21, #0
    v.insert     v22, s13, #12
    v.insert     v23, s12, #12
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.insert     v22, s14, #13
    v.insert     v23, s12, #13
    s.lshri      s11, s13, #32
    s.or         s12, s7, s5
    v.insert     v22, s13, #14
    v.insert     v23, s11, #14
    s.lshri      s5, s12, #32
    v.insert     v22, s12, #15
    v.insert     v23, s5, #15
    v.extract    s5, v20, #0
    v.extract    s7, v23, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #0
    v.extract    s12, v22, #0
    v.extract    s13, v20, #1
    v.extract    s14, v23, #1
    s.or         s15, s7, s11
    s.or         s7, s12, s5
    s.shli       s5, s13, #32
    s.shli       s11, s14, #32
    v.extract    s12, v19, #1
    v.extract    s13, v22, #1
    v.extract    s14, v20, #2
    v.movi       v16, #0
    s.add        s16, s15, s7
    v.extract    s7, v23, #2
    s.or         s15, s12, s5
    s.or         s5, s13, s11
    s.shli       s11, s14, #32
    s.shli       s12, s7, #32
    v.extract    s7, v19, #2
    v.extract    s13, v22, #2
    v.movi       v21, #0
    v.insert     v16, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s5
    v.extract    s5, v20, #3
    s.or         s15, s7, s11
    v.extract    s7, v23, #3
    s.or         s11, s13, s12
    s.shli       s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #3
    v.insert     v21, s14, #0
    v.extract    s13, v22, #3
    v.insert     v16, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #4
    s.or         s15, s7, s12
    v.extract    s7, v23, #4
    s.or         s12, s13, s5
    s.shli       s5, s11, #32
    s.shli       s11, s7, #32
    v.extract    s7, v19, #4
    v.insert     v21, s14, #1
    v.extract    s13, v22, #4
    v.insert     v16, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #5
    s.or         s15, s7, s5
    v.extract    s5, v23, #5
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #5
    v.insert     v21, s14, #2
    v.extract    s13, v22, #5
    v.insert     v16, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #6
    s.or         s15, s5, s11
    v.extract    s5, v23, #6
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #6
    v.insert     v21, s14, #3
    v.extract    s13, v22, #6
    v.insert     v16, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #7
    s.or         s15, s5, s12
    v.extract    s5, v23, #7
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #7
    v.insert     v21, s14, #4
    v.extract    s13, v22, #7
    v.insert     v16, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #8
    s.or         s15, s5, s7
    v.extract    s5, v23, #8
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #8
    v.insert     v21, s14, #5
    v.extract    s13, v22, #8
    v.insert     v16, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #9
    s.or         s15, s5, s11
    v.extract    s5, v23, #9
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #9
    v.insert     v21, s14, #6
    v.extract    s13, v22, #9
    v.insert     v16, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #10
    s.or         s15, s5, s12
    v.extract    s5, v23, #10
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #10
    v.insert     v21, s14, #7
    v.extract    s13, v22, #10
    v.insert     v16, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #11
    s.or         s15, s5, s7
    v.extract    s5, v23, #11
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #11
    v.insert     v21, s14, #8
    v.extract    s13, v22, #11
    v.insert     v16, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #12
    s.or         s15, s5, s11
    v.extract    s5, v23, #12
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #12
    v.insert     v21, s14, #9
    v.extract    s13, v22, #12
    v.insert     v16, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #13
    s.or         s15, s5, s12
    v.extract    s5, v23, #13
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #13
    v.insert     v21, s14, #10
    v.extract    s13, v22, #13
    v.insert     v16, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #14
    s.or         s15, s5, s7
    v.extract    s5, v23, #14
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #14
    v.insert     v21, s14, #11
    v.extract    s13, v22, #14
    v.insert     v16, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #15
    s.or         s15, s5, s11
    v.extract    s5, v23, #15
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #15
    v.insert     v21, s14, #12
    v.extract    s13, v22, #15
    v.insert     v16, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    s.or         s11, s5, s12
    s.or         s5, s13, s7
    v.insert     v21, s14, #13
    v.insert     v16, s16, #14
    s.lshri      s7, s16, #32
    s.add        s12, s11, s5
    v.insert     v21, s7, #14
    v.insert     v16, s12, #15
    s.lshri      s5, s12, #32
    v.movi       v22, #31
    v.insert     v21, s5, #15
    v.ashr       v23, v16, v22
    v.movi       v22, #1
    v.movi       v24, #0
    v.cmp.ne     p2, v21, v23
    @p2 v.sel        v21, v22, v24
    s.movz       s5, #0
    v.reduce.or  s7, v21
    s.cmp.eq     s11, s7, s5
    br.nz        s11, narrow_ok_8
    trap         #677220
narrow_ok_8:
    v.extract    s5, v11, #0
    v.extract    s7, v11, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v9, #0
    v.extract    s12, v9, #0
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v21, [s6, v16]             // index is in elements (ISA sec 9.1)
    s.or         s13, s7, s11
    s.movz       s7, #0
    s.or         s11, s12, s5
    s.movz       s5, #2304
    v.movi       v16, #0
    s.cmp.ge     s12, s13, s7
    v.movi       v22, #0
    s.cmp.lt     s7, s11, s5
    v.insert     v16, s12, #0
    v.movi       v23, #0
    v.insert     v22, s7, #0
    v.movi       v24, #0
    vf.cvt.bf16.f32 v25, v21
    v.cmp.ne     p2, v16, v23
    v.cmp.ne     p3, v22, v24
    s.movz       s5, #1
    v.extract    s7, v10, #0
    p.and        p4, p2, p3
    v.movi       v16, #0
    v.movi       v21, #1
    v.splat      v22, s7
    v.iota       v23                             // arange(0, VLEN)
    v.splat      v24, s5
    @p4 v.sel        v26, v16, v21
    vf.mul       v16, v25, v22
    v.cmp.lt     p2, v23, v24
    s.movz       s5, #0
    @p2 v.reduce.or  s7, v26
    s.cmp.eq     s11, s7, s5
    vf.add       v21, v18, v16
    br.nz        s11, assert_ok_9
    trap         #677351
assert_ok_9:
    v.extract    s5, v11, #0
    s.shli       s7, s5, #32
    v.extract    s5, v9, #0
    s.or         s11, s5, s7
    s.movz       s5, #1024
    v.movi       v16, #0
    s.mul        s7, s11, s5
    v.movi       v18, #0
    v.movi       v22, #0
    v.movi       v23, #0
    s.lshri      s5, s7, #32
    v.insert     v16, s7, #0
    v.insert     v18, s5, #0
    v.extract    s5, v16, #0
    v.extract    s7, v18, #0
    s.shli       s11, s7, #32
    v.extract    s7, v18, #0
    s.or         s12, s5, s11
    s.shli       s5, s7, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    s.lshri      s13, s12, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s12, #0
    v.insert     v23, s13, #0
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #1
    v.insert     v23, s12, #1
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #2
    v.insert     v23, s12, #2
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #3
    v.insert     v23, s12, #3
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #4
    v.insert     v23, s12, #4
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #5
    v.insert     v23, s12, #5
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #6
    v.insert     v23, s12, #6
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #7
    v.insert     v23, s12, #7
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #8
    v.insert     v23, s12, #8
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #9
    v.insert     v23, s12, #9
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #10
    v.insert     v23, s12, #10
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s14, #11
    v.insert     v23, s12, #11
    s.lshri      s12, s13, #32
    s.or         s14, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.extract    s11, v18, #0
    v.insert     v22, s13, #12
    v.insert     v23, s12, #12
    s.lshri      s12, s14, #32
    s.or         s13, s7, s5
    s.shli       s5, s11, #32
    v.extract    s7, v16, #0
    v.insert     v22, s14, #13
    v.insert     v23, s12, #13
    s.lshri      s11, s13, #32
    s.or         s12, s7, s5
    v.insert     v22, s13, #14
    v.insert     v23, s11, #14
    s.lshri      s5, s12, #32
    v.insert     v22, s12, #15
    v.insert     v23, s5, #15
    v.extract    s5, v20, #0
    v.extract    s7, v23, #0
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #0
    v.extract    s12, v22, #0
    v.extract    s13, v20, #1
    v.extract    s14, v23, #1
    s.or         s15, s7, s11
    s.or         s7, s12, s5
    s.shli       s5, s13, #32
    s.shli       s11, s14, #32
    v.extract    s12, v19, #1
    v.extract    s13, v22, #1
    v.extract    s14, v20, #2
    v.movi       v16, #0
    s.add        s16, s15, s7
    v.extract    s7, v23, #2
    s.or         s15, s12, s5
    s.or         s5, s13, s11
    s.shli       s11, s14, #32
    s.shli       s12, s7, #32
    v.extract    s7, v19, #2
    v.extract    s13, v22, #2
    v.movi       v18, #0
    v.insert     v16, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s5
    v.extract    s5, v20, #3
    s.or         s15, s7, s11
    v.extract    s7, v23, #3
    s.or         s11, s13, s12
    s.shli       s12, s5, #32
    s.shli       s5, s7, #32
    v.extract    s7, v19, #3
    v.insert     v18, s14, #0
    v.extract    s13, v22, #3
    v.insert     v16, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #4
    s.or         s15, s7, s12
    v.extract    s7, v23, #4
    s.or         s12, s13, s5
    s.shli       s5, s11, #32
    s.shli       s11, s7, #32
    v.extract    s7, v19, #4
    v.insert     v18, s14, #1
    v.extract    s13, v22, #4
    v.insert     v16, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #5
    s.or         s15, s7, s5
    v.extract    s5, v23, #5
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #5
    v.insert     v18, s14, #2
    v.extract    s13, v22, #5
    v.insert     v16, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #6
    s.or         s15, s5, s11
    v.extract    s5, v23, #6
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #6
    v.insert     v18, s14, #3
    v.extract    s13, v22, #6
    v.insert     v16, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #7
    s.or         s15, s5, s12
    v.extract    s5, v23, #7
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #7
    v.insert     v18, s14, #4
    v.extract    s13, v22, #7
    v.insert     v16, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #8
    s.or         s15, s5, s7
    v.extract    s5, v23, #8
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #8
    v.insert     v18, s14, #5
    v.extract    s13, v22, #8
    v.insert     v16, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #9
    s.or         s15, s5, s11
    v.extract    s5, v23, #9
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #9
    v.insert     v18, s14, #6
    v.extract    s13, v22, #9
    v.insert     v16, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #10
    s.or         s15, s5, s12
    v.extract    s5, v23, #10
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #10
    v.insert     v18, s14, #7
    v.extract    s13, v22, #10
    v.insert     v16, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #11
    s.or         s15, s5, s7
    v.extract    s5, v23, #11
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #11
    v.insert     v18, s14, #8
    v.extract    s13, v22, #11
    v.insert     v16, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #12
    s.or         s15, s5, s11
    v.extract    s5, v23, #12
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #12
    v.insert     v18, s14, #9
    v.extract    s13, v22, #12
    v.insert     v16, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v20, #13
    s.or         s15, s5, s12
    v.extract    s5, v23, #13
    s.or         s12, s13, s7
    s.shli       s7, s11, #32
    s.shli       s11, s5, #32
    v.extract    s5, v19, #13
    v.insert     v18, s14, #10
    v.extract    s13, v22, #13
    v.insert     v16, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v20, #14
    s.or         s15, s5, s7
    v.extract    s5, v23, #14
    s.or         s7, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s5, #32
    v.extract    s5, v19, #14
    v.insert     v18, s14, #11
    v.extract    s13, v22, #14
    v.insert     v16, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s7
    v.extract    s7, v20, #15
    s.or         s15, s5, s11
    v.extract    s5, v23, #15
    s.or         s11, s13, s12
    s.shli       s12, s7, #32
    s.shli       s7, s5, #32
    v.extract    s5, v19, #15
    v.insert     v18, s14, #12
    v.extract    s13, v22, #15
    v.insert     v16, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    s.or         s11, s5, s12
    s.or         s5, s13, s7
    v.insert     v18, s14, #13
    v.insert     v16, s16, #14
    s.lshri      s7, s16, #32
    s.add        s12, s11, s5
    v.insert     v18, s7, #14
    v.insert     v16, s12, #15
    s.lshri      s5, s12, #32
    v.movi       v19, #31
    v.insert     v18, s5, #15
    v.ashr       v20, v16, v19
    v.movi       v19, #1
    v.movi       v22, #0
    v.cmp.ne     p2, v18, v20
    @p2 v.sel        v18, v19, v22
    s.movz       s5, #0
    v.reduce.or  s7, v18
    s.cmp.eq     s11, s7, s5
    br.nz        s11, narrow_ok_10
    trap         #677220
narrow_ok_10:
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v18, [s6, v16]             // index is in elements (ISA sec 9.1)
    v.extract    s5, v13, #0
    v.splat      v16, s5
    s.mul        s5, s4, s23
    v.movi       v19, #0
    s.add        s7, s1, s24
    vf.cvt.bf16.f32 v20, v18
    s.movz       s11, #1
    s.add        s12, s1, s5
    v.splat      v18, s5
    vf.mul       v22, v20, v16
    s.shli       s5, s12, #1                     // element offset -> bytes (x2)
    v.add        v16, v15, v18
    s.add        s12, s2, s5                     // &in_out_ptr0[...]
    vf.add       v15, v21, v22
    vf.add       v16, v17, v15
    vf.add       v15, v14, v16
    vf.cvt.f32.bf16 v17, v16
    @p1 v.sel        v16, v15, v14
    @p1 v.st.h       [s12, #0], v17
    v.mov        v19, v16
    v.mov        v14, v19
    s.mov        s1, s7
    br.nz        s11, for_1
endfor_2:
    .li       s1, #1149239296
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v3, v1                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v4, v14
    v.movi       v5, #0
    v.movi       v6, #0
    vf.add       v7, v4, v5
    s.addi       s1, s22, #0
    v.mov        v6, v12
    vf.fms       v4, v1, v3, v2
    vf.fms       v8, v3, v4, v3
    vf.neg       v4, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v8, v4, v3
    vf.mul       v3, v7, v8                      // a/y: faithful quotient
    vf.fms       v4, v3, v1, v7
    vf.fms       v7, v4, v8, v3
    vf.neg       v4, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v7, v4, v3
for_11:
    s.cmp.ge     s3, s1, s23
    br.nz        s3, endfor_12
    s.muli       s3, s4, #2048
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s5, #1024
    s.movz       s6, #256
    s.muli       s7, s1, #2
    v.add        v8, v3, v4
    v.movi       v3, #0
    v.splat      v4, s5
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s6
    v.cmp.ge     p1, v8, v3
    v.cmp.lt     p2, v8, v4
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s5, s2, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s3, s5, s7
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s3, #0]
    v.extract    s3, v7, #0
    v.splat      v4, s3
    v.splat      v8, s1
    v.movi       v9, #1024
    v.add        v10, v8, v0
    vf.cvt.bf16.f32 v8, v3
    v.cmp.lt     p1, v10, v9
    v.movi       v3, #0
    s.add        s3, s1, s24
    vf.sub       v9, v8, v4
    s.movz       s5, #1
    vf.mul       v4, v9, v9
    vf.add       v8, v6, v4
    @p1 v.sel        v4, v8, v6
    v.mov        v3, v4
    v.mov        v6, v3
    s.mov        s1, s3
    br.nz        s5, for_11
endfor_12:
    vf.reduce.add.b v3, v6
    s.addi       s1, s22, #0
    vf.add       v4, v3, v5
for_13:
    s.cmp.ge     s3, s1, s23
    br.nz        s3, endfor_14
    v.rcp.approx v3, v1                          // ISA 8.8: <= 2**-22 relative
    s.muli       s3, s4, #2048
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s5, #1024
    s.movz       s6, #256
    s.muli       s7, s1, #2
    v.add        v8, v5, v6
    v.movi       v5, #0
    v.splat      v6, s5
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s6
    v.cmp.ge     p1, v8, v5
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s5, s2, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s3, s5, s7
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s3, #0]
    v.splat      v6, s1
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.add        v8, v6, v0
    vf.fms       v6, v1, v3, v2
    v.movi       v9, #1024
    .li       s5, #897988541
    v.splat      v10, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v11, v5
    vf.fms       v5, v3, v6, v3
    s.add        s5, s8, s3                      // &in_ptr4[...]
    v.cmp.lt     p1, v8, v9
    .li       s6, #1077936128
    v.splat      v6, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v9, v5                          // Newton step: r0*(2 - x*r0)
    .li       s6, #3204448256
    v.splat      v5, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s6, v7, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s5, #0]
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v3
    v.splat      v3, s6
    vf.mul       v9, v4, v13                     // a/y: faithful quotient
    s.add        s5, s9, s3                      // &in_ptr5[...]
    vf.sub       v14, v11, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s5, #0]
    vf.fms       v11, v9, v1, v4
    vf.cvt.bf16.f32 v15, v12
    s.mul        s3, s4, s23
    s.add        s5, s1, s24
    vf.fms       v12, v11, v13, v9
    vf.cvt.bf16.f32 v11, v3
    s.movz       s6, #1
    s.add        s7, s1, s3
    vf.neg       v3, v12                         // a/y: one correction to the IEEE quotient
    s.shli       s11, s7, #1                     // element offset -> bytes (x2)
    v.splat      v12, s3
    s.add        s3, s10, s11                    // &out_ptr1[...]
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v13, v3, v9
    v.add        v3, v8, v12
    vf.add       v3, v13, v10
    v.rsqrt.approx v8, v3                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v9, v8, v8
    vf.mul       v10, v8, v5
    vf.fms       v5, v3, v9, v6
    vf.mul       v3, v10, v5                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v5, v3, v8
    v.extract    s7, v5, #0
    v.splat      v3, s7
    vf.mul       v5, v14, v3
    vf.mul       v3, v5, v15
    vf.add       v5, v3, v11
    vf.cvt.f32.bf16 v3, v5
    @p1 v.st.h       [s3, #0], v3
    s.mov        s1, s5
    br.nz        s6, for_13
endfor_14:
__rctx_next:
    exit
