import os,sys,tempfile,struct
from pathlib import Path
base=Path.home()/'r41_event_scan_candidate'
src=Path.home()/'r41_vl_reason_dp/src'
sys.path[:0]=[str(base/'python'),str(src/'compiler/python'),str(src/'tools/asm'),str(src/'tools/performance_harness/systemc')]
import tlm_backend
tlm_backend.register()
from tnca import aot
from tnca.runtime import Session
from tnca.errors import AdmissionError
profile='core-vrf-sync-v5-x8-g2c4-dp'
def program(b,target):
    dest=b.sload(b.special('arg_base'),0)
    b.sstore(dest,b.const(73),size='d');b.exit()
with tempfile.TemporaryDirectory() as tmp:
    path=aot.compile_aot(program,kernel_name='event_active_probe',source_kind='tnca-ir',profile=profile,signature={'out':'*i64'},output=str(Path(tmp)/'probe.tnca')).path
    opts=dict(profile=profile,backend='systemc-tlm-grid',binary=str(Path.home()/'r41_vl_reason_dp/build/tnca-chip'),config=str(src/'tools/performance_harness/systemc/configs/r41-mma-dp.cfg'),host_timeout=120)
    with Session(**opts) as s:
        m=s.load(path);out=s.allocate(8);first=None
        for i in range(20):
            e=s.submit(m,{'out':out},depends_on=(first,) if first else ())
            if first is None:first=e
            assert s.wait(e).ok
        s.drain();assert not s.unfinished
        assert len(s._events)==20 and not s._active_events
        assert struct.unpack('<Q',s.download(out))[0]==73
        assert s.unload(m)
        m=s.load(path)
        assert s.wait(s.submit(m,{'out':out},depends_on=(first,))).ok
        s.drain();assert not s.unfinished and len(s._events)==21
        print('PASS: TLM 21 submits; old dependency retained; drain and unload; output=73',flush=True)
