    s.rdspecial  s1, arg_base
    .li       s2, #1069066811
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s3, #1060205080
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.iota       v2                              // arange(0, VLEN)
    v.cmpi.lt    p1, v2, #1
    s.ld.w       s3, [s2, #0]                    // one element, not a vector
    v.splat      v2, s3
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v3, v2, v0
    v.exp2.approx v4, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v2, v0, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v1
    vf.fma       v1, v4, v0, v4                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v4
    @p1 v.st.w       [s2, #0], v0
    exit
    exit
