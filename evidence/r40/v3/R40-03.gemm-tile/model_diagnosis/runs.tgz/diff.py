import json,glob,sys
for pt in ("linear","matmul"):
    a=json.load(open(glob.glob(f"./op.{pt}*c9af45d482/**/summary.json",recursive=True)[0]))["counters"]
    b=json.load(open(glob.glob(f"./op.{pt}*56dc9373e2/**/summary.json",recursive=True)[0]))["counters"]
    print("==",pt,"16,16,16 vs 16,32,16; keys",len(a))
    rows=[]
    for k in set(a)|set(b):
        if not (k.startswith("core_0") or k.startswith("home_0") or k.startswith("outlet_0")): continue
        x,y=a.get(k,0),b.get(k,0)
        if max(x,y)>1000: rows.append((y-x,k,x,y))
    rows.sort(reverse=True)
    for d,k,x,y in rows[:24]:
        r=y/x if x else float("inf")
        print(f"  {k:48s} {x:>12} {y:>12}  x{r:.2f}")
