    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #256
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    s.movz       s1, #16
    s.st.d       [s6, #8], s1
    s.movz       s1, #256
    s.st.d       [s6, #16], s1
    s.movz       s1, #512
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476737
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s6, #256
    s.movz       s7, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #32
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #5
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v2, v4
    v.sub        v5, v4, v0
    @p1 v.sel        v6, v5, v0
    v.sub        v0, v4, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #31
    v.and        v2, v6, v0
    v.sub        v0, v4, v2
    @p1 v.sel        v4, v0, v2
    s.addi       s8, s1, #0
    v.movi       v0, #0
    v.movi       v2, #0
    v.mov        v2, v0
for_1:
    s.cmp.ge     s1, s8, s6
    br.nz        s1, endfor_2
    s.movz       s1, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s4, s1
    s.movz       s1, #32
    s.sub        s11, s9, s10
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s12, s1, s9
    s.xor        s9, s4, s11
    s.sub        s13, s10, s12
    s.sub        s10, s9, s11
    s.xor        s9, s11, s13
    s.lshri      s11, s10, #5
    v.movi       v0, #256
    s.xor        s12, s11, s9
    v.splat      v5, s8
    s.sub        s14, s12, s9
    v.iota       v6                              // arange(0, VLEN)
    s.muli       s9, s14, #512
    s.movz       s12, #256
    s.movz       s15, #16
    v.mul        v7, v4, v0
    v.splat      v0, s8
    s.muli       s16, s8, #2
    v.add        v8, v5, v6
    v.movi       v5, #0
    v.splat      v6, s12
    v.splat      v9, s14
    v.movi       v10, #0
    v.splat      v11, s15
    v.extract    s12, v7, #0
    v.add        v7, v0, v1
    v.splat      v0, s12
    v.cmp.ge     p1, v8, v5
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s12, s2, s9
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    v.movi       v5, #256
    v.add        v6, v7, v0
    s.add        s9, s12, s16
    p.and        p2, p5, p1
    v.cmp.lt     p1, v7, v5
    v.movi       v0, #0
    v.movi       v5, #2
    v.sub        v7, v0, v3
    v.cmp.lt     p3, v3, v0
    @p3 v.sel        v8, v7, v3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v7, [s9, #0]
    v.lshr       v9, v8, v5
    s.muli       s9, s11, #32
    v.sub        v5, v0, v9
    v.movi       v8, #4
    s.xor        s11, s1, s13
    @p3 v.sel        v10, v5, v9
    vf.cvt.bf16.f32 v5, v7
    v.sub        v7, v0, v8
    v.cmp.lt     p2, v8, v0
    s.sub        s1, s11, s13
    v.movi       v0, #8192
    s.sub        s1, s10, s9
    v.mul        v9, v10, v0
    .li       s1, #1048576000
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v9, #0
    v.splat      v9, s1
    vf.mul       v10, v5, v0
    v.add        v5, v6, v9
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s3, v5]               // index is in elements (ISA sec 9.1)
    s.add        s1, s8, s7
    s.movz       s9, #1
    v.movi       v5, #1
    @p2 v.sel        v5, v7, v8
    s.movz       s10, #8192
    vf.cvt.bf16.f32 v5, v9
    vf.mul       v7, v5, v0
    vf.mul       v0, v10, v7
    vf.add       v5, v2, v0
    @p1 v.sel        v0, v5, v2
    v.mov        v6, v0
    v.mov        v2, v6
    s.mov        s8, s1
    br.nz        s9, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s5, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
