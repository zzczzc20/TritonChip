    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // x_ptr: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    s.shli       s11, s4, #7                     // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v2, #32
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #48
    v.movi       v5, #64
    v.movi       v6, #80
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #96
    v.movi       v9, #112
    s.add        s12, s2, s11
    s.add        s2, s5, s11
    s.add        s5, s6, s11
    s.add        s6, s7, s11
    s.add        s7, s8, s11
    s.add        s8, s9, s11
    s.add        s9, s10, s11
    v.add        v10, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v3, v4
    v.add        v4, v3, v5
    v.add        v5, v3, v6
    v.add        v3, v7, v8
    v.add        v6, v7, v9
    v.movi       v7, #128
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    s.ld.d       s13, [s1, #8]                   // y_ptr: device_ptr64 at arg_base+8
    s.add        s14, s3, s10                    // &x_ptr[...]
    v.cmp.lt     p1, v0, v7
    v.cmp.lt     p2, v10, v7
    v.splat      v8, s11
    v.add        v9, v8, v0
    v.add        v9, v8, v10
    v.add        v9, v8, v1
    v.add        v9, v8, v2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s14, #0]
    v.add        v11, v8, v4
    v.add        v11, v8, v5
    v.add        v11, v8, v3
    v.add        v11, v8, v6
    s.ld.d       s10, [s1, #16]                  // s_ptr: device_ptr64 at arg_base+16
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    v.movi       v8, #128
    s.shli       s14, s2, #1                     // element offset -> bytes (x2)
    s.shli       s15, s5, #1                     // element offset -> bytes (x2)
    v.movi       v11, #128
    s.shli       s16, s6, #1                     // element offset -> bytes (x2)
    s.shli       s17, s7, #1                     // element offset -> bytes (x2)
    v.movi       v12, #128
    s.add        s18, s3, s1                     // &x_ptr[...]
    s.add        s1, s3, s14                     // &x_ptr[...]
    s.add        s14, s3, s15                    // &x_ptr[...]
    s.add        s15, s3, s16                    // &x_ptr[...]
    s.add        s16, s3, s17                    // &x_ptr[...]
    v.cmp.lt     p1, v1, v8
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s18, #0]
    s.shli       s17, s8, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p2, v2, v8
    s.add        s18, s3, s17                    // &x_ptr[...]
    vf.cvt.bf16.f32 v14, v9
    vf.abs       v9, v14
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v15, [s1, #0]
    s.shli       s1, s9, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p1, v4, v11
    s.add        s17, s3, s1                     // &x_ptr[...]
    vf.cvt.bf16.f32 v16, v13
    vf.reduce.max.b v13, v9
    vf.abs       v9, v16
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v17, [s14, #0]
    .li       s1, #1138753536
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p2, v5, v11
    vf.cvt.bf16.f32 v19, v15
    v.rcp.approx v15, v18                        // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.max.b v21, v9
    vf.abs       v9, v19
    vf.max       v22, v13, v21
    vf.reduce.max.b v13, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s15, #0]
    v.cmp.lt     p1, v3, v12
    vf.cvt.bf16.f32 v21, v17
    vf.abs       v17, v21
    vf.reduce.max.b v23, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v17, [s16, #0]
    v.cmp.lt     p2, v6, v12
    vf.cvt.bf16.f32 v24, v9
    vf.max       v9, v13, v23
    vf.fms       v13, v18, v15, v20
    .li       s1, #730643660
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v23, v24
    vf.max       v25, v22, v9
    vf.fms       v9, v15, v13, v15
    vf.reduce.max.b v13, v23
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s18, #0]
    vf.cvt.bf16.f32 v23, v17
    vf.neg       v17, v9                         // Newton step: r0*(2 - x*r0)
    vf.abs       v9, v23
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v26, v17, v15
    vf.reduce.max.b v15, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s17, #0]
    vf.cvt.bf16.f32 v17, v22
    vf.max       v22, v13, v15
    vf.abs       v13, v17
    vf.reduce.max.b v15, v13
    vf.cvt.bf16.f32 v13, v9
    vf.abs       v9, v13
    vf.reduce.max.b v27, v9
    vf.max       v9, v15, v27
    v.movi       v15, #24
    vf.max       v27, v22, v9
    v.movi       v9, #128
    vf.max       v22, v25, v27
    vf.mul       v25, v22, v26                   // a/y as a refined reciprocal (ISA has no divide)
    vf.max.ieee  v22, v25, v18
    v.rcp.approx v18, v22                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v26, v22                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v27, v22                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v28, v22                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v22, v18, v20
    vf.fms       v30, v22, v26, v20
    vf.fms       v31, v22, v27, v20
    vf.fms       v32, v22, v28, v20
    vf.fms       v20, v18, v29, v18
    vf.fms       v22, v26, v30, v26
    vf.fms       v29, v27, v31, v27
    vf.fms       v30, v28, v32, v28
    vf.neg       v31, v20                        // Newton step: r0*(2 - x*r0)
    vf.neg       v20, v22                        // Newton step: r0*(2 - x*r0)
    vf.neg       v22, v29                        // Newton step: r0*(2 - x*r0)
    vf.neg       v29, v30                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v31, v31
    vf.cmp.o     p2, v20, v20
    @p1 v.sel        v30, v31, v18
    vf.cmp.o     p1, v22, v22
    @p2 v.sel        v18, v20, v26
    vf.cmp.o     p2, v29, v29
    @p1 v.sel        v20, v22, v27
    @p2 v.sel        v22, v29, v28
    vf.mul       v26, v14, v30                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v14, v16, v30                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v16, v19, v18                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v19, v21, v18                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v18, v24, v20                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v21, v23, v20                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v20, v17, v22                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v17, v13, v22                   // a/y as a refined reciprocal (ISA has no divide)
    v.lshr       v13, v26, v15
    v.lshr       v22, v14, v15
    v.lshr       v23, v16, v15
    v.lshr       v24, v19, v15
    v.lshr       v27, v18, v15
    v.lshr       v28, v21, v15
    v.lshr       v29, v20, v15
    v.lshr       v30, v17, v15
    vf.cvt.f32.e4m3 v15, v26
    vf.cvt.f32.e4m3 v26, v14
    vf.cvt.f32.e4m3 v14, v16
    vf.cvt.f32.e4m3 v16, v19
    vf.cvt.f32.e4m3 v19, v18
    vf.cvt.f32.e4m3 v18, v21
    vf.cvt.f32.e4m3 v21, v20
    vf.cvt.f32.e4m3 v20, v17
    v.and        v17, v13, v9
    v.and        v13, v22, v9
    v.and        v22, v23, v9
    v.and        v23, v24, v9
    v.and        v24, v27, v9
    v.and        v27, v28, v9
    v.and        v28, v29, v9
    v.and        v29, v30, v9
    s.shli       s1, s11, #0                     // element offset -> bytes (x1)
    s.shli       s3, s12, #0                     // element offset -> bytes (x1)
    s.shli       s11, s2, #0                     // element offset -> bytes (x1)
    s.shli       s2, s5, #0                      // element offset -> bytes (x1)
    s.shli       s5, s6, #0                      // element offset -> bytes (x1)
    v.or         v9, v15, v17                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.shli       s6, s7, #0                      // element offset -> bytes (x1)
    v.or         v15, v26, v13                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.shli       s7, s8, #0                      // element offset -> bytes (x1)
    v.or         v13, v14, v22                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.shli       s8, s9, #0                      // element offset -> bytes (x1)
    v.or         v14, v16, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.shli       s9, s4, #2                      // element offset -> bytes (x4)
    v.iota       v16                             // arange(0, VLEN)
    v.or         v17, v19, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v19, v18, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v18, v21, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v21, v20, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s4, s13, s1                     // &y_ptr[...]
    s.add        s1, s13, s3                     // &y_ptr[...]
    s.add        s3, s13, s11                    // &y_ptr[...]
    s.add        s11, s13, s2                    // &y_ptr[...]
    s.add        s2, s13, s5                     // &y_ptr[...]
    s.add        s5, s13, s6                     // &y_ptr[...]
    s.add        s6, s13, s7                     // &y_ptr[...]
    s.add        s7, s13, s8                     // &y_ptr[...]
    s.add        s8, s10, s9                     // &s_ptr[...]
    v.cmp.lt     p1, v0, v7
    v.cmp.lt     p2, v10, v7
    @p1 v.st.b       [s4, #0], v9
    v.cmp.lt     p1, v1, v8
    @p2 v.st.b       [s1, #0], v15
    v.cmp.lt     p2, v2, v8
    @p1 v.st.b       [s3, #0], v13
    v.cmp.lt     p1, v4, v11
    @p2 v.st.b       [s11, #0], v14
    v.cmp.lt     p2, v5, v11
    @p1 v.st.b       [s2, #0], v17
    v.cmp.lt     p1, v3, v12
    @p2 v.st.b       [s5, #0], v19
    v.cmp.lt     p2, v6, v12
    @p1 v.st.b       [s6, #0], v18
    v.cmpi.lt    p1, v16, #1
    @p2 v.st.b       [s7, #0], v21
    @p1 v.st.w       [s8, #0], v25
__rctx_next:
    exit
