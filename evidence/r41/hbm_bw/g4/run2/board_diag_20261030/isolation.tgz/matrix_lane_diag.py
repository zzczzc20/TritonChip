import sys,struct
from pathlib import Path
r=Path.home()/"r41run2-auto/runtime_2eead82e";sys.path[:0]=[str(r/"python"),str(r/"compiler/python"),str(r/"tools/asm"),str(r/"tools/r41/run2_board")]
import auto
s="/sys/bus/pci/devices"; p=auto.probe(s)
if not auto.idle(p) or p["uuid"]!=auto.IMAGE_UUID or auto.clock_mhz(s)!=100:raise SystemExit("board busy or identity changed")
import triton
from tnca.runtime import Session
from tnca_asm import Assembler,build_image
profile="core-vrf-sync-v5-x8-g2c4-dp"
with Session(profile=profile,backend="fpga-u280-multicore",xclbin=str(Path.home()/"r41run2-auto/run2.xclbin"),image_profile=profile,core_count=3,memory_ports=3,hbm_dma=True,hbm_bytes=8<<30,device_clock=False,host_timeout=3600,deadline_cycles=200000000000) as session:
 a,b,out=session.allocate(512),session.allocate(512),session.allocate(1024)
 session.upload(a,struct.pack("<256H",*[0x3c00]*256));session.upload(b,struct.pack("<256H",*[0x3c00]*256))
 for op in ("m.mma.dp.async.k16.f16","m.mma.async.k16.f16"):
  parts=[f".li s10, #{a.addr}",f".li s11, #{b.addr}"]+[f"v.ld.w v{32+i}, [s10, #{i*64}]" for i in range(8)]+[f"v.ld.w v{40+i}, [s11, #{i*64}]" for i in range(8)] + ["m.zero a0","mb.init b0","mb.arm s12, b0, #0, #1",f"{op} a0, v32, v40, s12","mb.wait s12",f".li s14, #{out.addr}"]
  for i in range(16):parts += [f".li s13, #{i}","a.vread v8, a0, s13",f"v.st.w [s14, #{i*64}], v8"]
  parts += ["fence.release.device","exit"]
  code=b"".join(w.to_bytes(8,"little") for w in build_image(Assembler().assemble("\n".join(parts))))
  for core in range(3):
   session.upload(out,bytes(1024));assert session.dev.upload(0,code).ok
   reply=session.dev.launch_grid(0,0,(1,1,1),active_cores=1<<core);assert reply.ok,reply
   got=struct.unpack("<256f",session.download(out));bad=[(i,x) for i,x in enumerate(got) if x!=16.0]
   print(f"MATRIX op={op} core={core} mismatches={len(bad)} first={bad[:12]}",flush=True)
