    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s7, #0
    s.st.d       [s6, #0], s2
    s.movz       s7, #128
    s.st.d       [s6, #8], s7
    s.movz       s7, #2048
    s.st.d       [s6, #16], s7
    s.movz       s7, #4096
    s.st.d       [s6, #48], s7
    s.movz       s7, #2
    s.st.d       [s6, #56], s7
    .li       s7, #68719476737
    s.st.d       [s6, #88], s7
    .li       s7, #1108101562368
    s.st.d       [s6, #104], s7
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s6, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    s.movz       s1, #128
    s.st.d       [s6, #8], s1
    s.movz       s1, #2048
    s.st.d       [s6, #16], s1
    s.movz       s1, #4096
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476737
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d1, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s6, #2048
    s.movz       s7, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s8, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s9, s8, s6
    br.nz        s9, endfor_2
    v.splat      v1, s8
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s8
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s9, #2048
    s.movz       s10, #128
    s.movz       s11, #2048
    s.movz       s12, #128
    s.muli       s13, s4, #4096
    s.muli       s14, s4, #4096
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s9
    v.splat      v7, s4
    v.movi       v8, #0
    v.add        v9, v4, v5
    v.splat      v4, s10
    s.muli       s9, s8, #2
    s.muli       s10, s8, #2
    v.cmp.ge     p1, v6, v1
    v.movi       v1, #0
    v.cmp.lt     p2, v6, v3
    v.splat      v3, s11
    v.splat      v5, s4
    v.cmp.ge     p3, v7, v8
    v.movi       v6, #0
    v.cmp.lt     p4, v7, v4
    v.splat      v4, s12
    v.cmp.ge     p5, v9, v1
    s.add        s11, s2, s13
    p.and        p6, p1, p2
    v.cmp.lt     p1, v9, v3
    p.and        p2, p3, p4
    v.cmp.ge     p3, v5, v6
    s.add        s12, s3, s14
    p.and        p4, p5, p1
    v.cmp.lt     p1, v5, v4
    p.and        p5, p3, p1
    s.add        s13, s11, s9
    p.and        p1, p6, p2
    s.add        s9, s12, s10
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s13, #0]
    v.splat      v3, s8
    v.movi       v4, #2048
    v.add        v5, v3, v0
    v.cmp.lt     p1, v5, v4
    v.movi       v3, #0
    s.add        s10, s8, s7
    s.movz       s11, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s9, #0]
    vf.cvt.bf16.f32 v5, v1
    vf.cvt.bf16.f32 v1, v4
    vf.add       v4, v5, v1
    vf.mul       v1, v4, v4
    vf.add       v4, v2, v1
    @p1 v.sel        v1, v4, v2
    v.mov        v3, v1
    v.mov        v2, v3
    s.mov        s8, s10
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s8, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s8, s6
    br.nz        s1, endfor_4
    v.splat      v1, s8
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s8
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s1, #2048
    s.movz       s9, #128
    s.movz       s10, #2048
    s.movz       s11, #128
    s.muli       s12, s4, #4096
    s.muli       s13, s4, #4096
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s1
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s9
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s10
    s.muli       s1, s8, #2
    s.muli       s9, s8, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s4
    v.cmp.lt     p2, v6, v2
    v.movi       v2, #0
    v.splat      v6, s11
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s10, s2, s12
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v1, v2
    s.add        s11, s3, s13
    p.and        p4, p5, p1
    v.cmp.lt     p1, v1, v6
    p.and        p5, p3, p1
    v.splat      v1, s8
    s.add        s12, s10, s1
    p.and        p1, p6, p2
    s.add        s1, s11, s9
    p.and        p2, p4, p5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s12, #0]
    v.add        v4, v1, v0
    v.movi       v1, #2048
    s.shli       s9, s8, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p1, v4, v1
    .li       s10, #1157627904
    v.splat      v1, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1065353216
    v.splat      v5, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #897988541
    v.splat      v6, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v7, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s10, #1077936128
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #3204448256
    v.splat      v9, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s10, s5, s9                     // &in_ptr1[...]
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s1, #0]
    vf.cvt.bf16.f32 v11, v2
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s1, s4, s6
    s.add        s9, s8, s7
    s.movz       s11, #1
    s.add        s12, s8, s1
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    s.add        s12, s2, s13                    // &in_out_ptr0[...]
    vf.cvt.bf16.f32 v12, v10
    vf.add       v10, v11, v12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s10, #0]
    vf.fms       v12, v1, v7, v5
    v.splat      v1, s1
    v.add        v5, v4, v1
    vf.fms       v1, v7, v12, v7
    vf.neg       v4, v1                          // Newton step: r0*(2 - x*r0)
    vf.cvt.bf16.f32 v1, v11
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v5, v4, v7
    vf.add       v4, v1, v2
    vf.mul       v1, v3, v5                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v1, v6
    v.rsqrt.approx v1, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v1, v1
    vf.mul       v6, v1, v9
    vf.fms       v7, v2, v5, v8
    vf.mul       v2, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v5, v2, v1
    v.extract    s1, v5, #0
    v.splat      v1, s1
    vf.mul       v2, v10, v1
    vf.mul       v1, v2, v4
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s12, #0], v2
    s.mov        s8, s9
    br.nz        s11, for_3
endfor_4:
__rctx_next:
    exit
