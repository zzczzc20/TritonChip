    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: one row broadcast down a tile (outer stride 0) (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #2
    s.st.d       [s5, #56], s2
    .li       s6, #68719476752
    s.st.d       [s5, #88], s6
    .li       s7, #8589934592
    s.st.d       [s5, #104], s7
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s8, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s9, #512
    s.mul        s10, s5, s9
    s.add        s5, s8, s10                     // this context's own scratch
    s.addi       s8, s5, #256                    // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s8, #0], s3
    s.st.d       [s8, #8], s1
    s.st.d       [s8, #16], s1
    s.movz       s1, #256
    s.st.d       [s8, #48], s1
    s.st.d       [s8, #56], s2
    s.st.d       [s8, #88], s6
    s.st.d       [s8, #104], s7
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #4
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s1, s2, s3
    s.movz       s3, #1
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
__rctx_program:
    s.cmp.lt     s7, s5, s2
    s.addi       s8, s2, #0
    s.sub        s9, s2, s7
    s.addi       s7, s2, #0
    s.xor        s10, s5, s9
    s.xor        s11, s9, s1
    s.sub        s12, s10, s9
    s.lshri      s13, s12, #2
    s.mov        s8, s12
    s.xor        s14, s13, s11
    s.sub        s13, s14, s11
    s.sub        s11, s3, s13
    s.min.s      s14, s11, s3
    s.cmp.lt     s11, s14, s2
    s.sub        s15, s2, s11
    s.xor        s11, s14, s15
    s.sub        s14, s11, s15
    s.cmp.eq     s11, s14, s3
    br.nz        s11, sdiv_done_1
    s.movz       s16, #0
    s.movz       s17, #31
    s.mov        s8, s16
    s.addi       s18, s17, #0
sdiv_2:
    s.lshr       s17, s12, s18
    s.shli       s19, s7, #1
    s.andi       s20, s17, #1
    s.shl        s17, s3, s18
    s.or         s21, s19, s20
    s.cmp.geu    s19, s21, s14
    s.sub        s20, s16, s19
    s.and        s19, s14, s20
    s.and        s22, s17, s20
    s.sub        s7, s21, s19
    s.or         s8, s8, s22
    s.subi       s18, s18, #1
    s.cmp.ge     s17, s18, s16
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.sub        s8, s10, s9
    s.xor        s10, s7, s9
    s.lshri      s7, s8, #2
    s.sub        s12, s10, s9
    s.muli       s10, s7, #4
    s.addi       s7, s2, #0
    s.add        s16, s13, s12
    s.addi       s12, s2, #0
    s.sub        s13, s8, s10
    s.xor        s8, s13, s9
    s.sub        s10, s8, s9
    s.cmp.lt     s8, s10, s2
    s.sub        s9, s2, s8
    s.xor        s8, s10, s9
    s.sub        s10, s8, s9
    s.mov        s7, s10
    br.nz        s11, sdiv_done_3
    s.movz       s8, #0
    s.movz       s11, #31
    s.mov        s7, s8
    s.addi       s13, s11, #0
    s.movz       s11, #1
sdiv_4:
    s.lshr       s17, s10, s13
    s.shli       s18, s12, #1
    s.andi       s19, s17, #1
    s.shl        s17, s11, s13
    s.or         s20, s18, s19
    s.cmp.geu    s18, s20, s14
    s.sub        s19, s8, s18
    s.and        s18, s14, s19
    s.and        s21, s17, s19
    s.sub        s12, s20, s18
    s.or         s7, s7, s21
    s.subi       s13, s13, #1
    s.cmp.ge     s17, s13, s8
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.xor        s8, s9, s15
    s.movz       s9, #16
    s.xor        s10, s7, s8
    s.movz       s7, #0
    s.sub        s11, s10, s8
    s.movz       s8, #8
    s.mul        s10, s11, s9
    s.addi       s11, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s12, s10, #63
for_5:
    s.cmp.ge     s13, s11, s8
    br.nz        s13, endfor_6
    s.mul        s13, s11, s9
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s14, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s17, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s13                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s17, s14
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s17, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s13                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s17, s14
    mb.wait      s14
gemm_pipe:
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s13
    s.add        s11, s11, s3
    s.cmp.ge     s15, s11, s8
    br.nz        s15, gemm_pipe_drain0
    s.mul        s15, s11, s9
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s18, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s18, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s18, s17
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s18, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s18, s17
    mb.wait      s17
    mb.wait      s13
    mb.arm       s15, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s15
    s.add        s11, s11, s3
    s.cmp.ge     s18, s11, s8
    br.nz        s18, gemm_pipe_drain1
    s.mul        s18, s11, s9
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s20, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s21, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s21, s19
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s21, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s21, s19
    mb.wait      s19
    mb.wait      s15
    br.nz        s20, gemm_pipe
gemm_pipe_drain0:
    s.movz       s8, #1
    mb.wait      s13
    br.nz        s8, endfor_6
gemm_pipe_drain1:
    mb.wait      s15
endfor_6:
    s.mul        s8, s16, s9
    s.add        s9, s7, s10                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v2, a0, s7
    s.add        s9, s7, s8                      // the tile origin
    s.movz       s7, #64
    s.muli       s8, s10, #2                     // a runtime tile origin, x2
    v.splat      v3, s9
    v.splat      v4, s3
    v.add        v5, v0, v1
    v.splat      v0, s7
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s7, s4, s8                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s8, #1
    @p3 v.st.h       [s7, #0], v1
    a.vread      v0, a0, s8
    s.addi       s8, s9, #1
    s.movz       s10, #2
    v.splat      v1, s8
    vf.cvt.f32.f16 v2, v0
    s.addi       s8, s9, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.splat      v0, s8
    s.movz       s8, #3
    s.addi       s11, s9, #3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    @p3 v.st.h       [s7, #0], v2
    a.vread      v0, a0, s10
    v.splat      v1, s11
    s.movz       s10, #4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s11, s9, #4
    s.movz       s12, #5
    v.splat      v0, s11
    s.addi       s11, s9, #5
    s.movz       s16, #6
    v.splat      v1, s11
    s.addi       s11, s9, #6
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v2
    v.splat      v2, s11
    s.movz       s8, #7
    s.addi       s11, s9, #7
    s.movz       s18, #8
    v.splat      v3, s11
    s.addi       s11, s9, #8
    v.splat      v5, s11
    s.movz       s11, #9
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s10, s9, #9
    v.splat      v0, s10
    s.movz       s10, #10
    @p4 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s12
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s12, s9, #10
    v.splat      v1, s12
    s.movz       s12, #11
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s16
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s16, s9, #11
    v.splat      v2, s16
    s.movz       s16, #12
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a0, s8
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s8, s9, #12
    v.splat      v3, s8
    s.movz       s8, #13
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a0, s18
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v5
    s.addi       s18, s9, #13
    v.splat      v5, s18
    s.movz       s18, #14
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s11, s9, #14
    s.addi       s20, s9, #15
    v.splat      v0, s11
    s.movz       s9, #15
    v.splat      v6, s20
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s12
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s8
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s18
    v.cmp.lt     p1, v6, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s7, #0], v1
    a.vread      v0, a0, s9
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s7, #0], v1
__rctx_next:
    s.addi       s7, s5, #2                      // the next program of this context: + 2
    s.cmp.lt     s8, s7, s6
    s.mov        s5, s7
    br.nz        s8, __rctx_program
    exit
