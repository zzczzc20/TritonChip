    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.add        s6, s3, s2
    s.movz       s7, #128
    s.cmp.lt     s8, s6, s4
    s.movz       s4, #0
    s.sub        s9, s5, s8
    s.movz       s5, #0
    s.cmp.lt     s8, s7, s4
    s.xor        s4, s6, s9
    s.sub        s6, s5, s8
    s.sub        s5, s4, s9
    s.ld.sw      s4, [s1, #40]                   // M: i32 at arg_base+40
    s.movz       s8, #15
    s.rdspecial  s10, pid.x
    s.add        s11, s4, s8
    s.movz       s8, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s11, s8
    s.rdspecial  s8, pid.y
    s.sub        s14, s12, s13
    s.movz       s12, #16
    s.xor        s13, s11, s14
    s.movz       s11, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.cmp.lt     s16, s12, s11
    s.lshri      s11, s15, #4
    s.sub        s17, s13, s16
    s.muli       s13, s11, #16
    s.xor        s16, s14, s17
    s.xor        s14, s12, s17
    s.xor        s18, s11, s16
    s.xor        s11, s7, s6
    s.ld.d       s19, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.sub        s20, s14, s17
    s.sub        s14, s15, s13
    s.ld.d       s13, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.lshri      s14, s5, #7
    s.sub        s15, s18, s16
    s.ld.d       s16, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.muli       s17, s14, #128
    s.sub        s18, s11, s6
    s.ld.d       s11, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.ld.d       s18, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s20, s9, s6
    s.sub        s6, s5, s17
    s.xor        s5, s14, s20
    s.ld.sw      s6, [s1, #56]                   // K: i32 at arg_base+56
    s.sub        s9, s5, s20
    s.mul        s5, s10, s9
    s.ld.sw      s10, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.ld.sw      s14, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.movz       s17, #8
    s.add        s20, s5, s8
    s.ld.sw      s5, [s1, #80]                   // stride_cm: i32 at arg_base+80
    s.mul        s1, s9, s17
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s1, s8
    s.cmp.lt     s8, s20, s9
    s.sub        s9, s21, s23
    s.sub        s21, s22, s8
    s.xor        s8, s1, s9
    s.xor        s22, s20, s21
    s.sub        s23, s8, s9
    s.movz       s8, #0
    s.movz       s24, #1
    s.sub        s25, s22, s21
    s.movz       s22, #0
    s.addi       s26, s8, #0
    s.cmp.eq     s8, s23, s24
    s.addi       s24, s22, #0
    s.mov        s26, s25
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s22, #31
    s.mov        s26, s8
    s.addi       s8, s22, #0
sdiv_2:
    s.lshr       s22, s25, s8
    s.shli       s27, s24, #1
    s.andi       s28, s22, #1
    s.movz       s22, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s23
    s.shl        s30, s27, s8
    s.sub        s27, s22, s28
    s.subi       s22, s8, #1
    s.and        s28, s23, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s26, s31
    s.mov        s24, s27
    s.mov        s26, s28
    s.mov        s8, s22
    s.movz       s22, #0
    s.cmp.ge     s27, s8, s22
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.xor        s8, s21, s9
    s.movz       s9, #0
    s.xor        s21, s26, s8
    s.movz       s22, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s1, s9
    s.sub        s9, s21, s8
    s.movz       s8, #0
    s.cmp.lt     s21, s20, s22
    s.sub        s22, s23, s24
    s.mul        s23, s9, s17
    s.sub        s9, s8, s21
    s.xor        s8, s1, s22
    s.xor        s1, s20, s9
    s.sub        s20, s8, s22
    s.movz       s8, #0
    s.movz       s21, #1
    s.sub        s22, s15, s23
    s.sub        s15, s1, s9
    s.movz       s1, #0
    s.addi       s24, s8, #0
    s.cmp.eq     s8, s20, s21
    s.min.s      s21, s22, s17
    s.addi       s17, s1, #0
    s.mov        s24, s15
    br.nz        s8, sdiv_done_3
    s.movz       s1, #0
    s.movz       s8, #31
    s.mov        s24, s1
    s.addi       s1, s8, #0
sdiv_4:
    s.lshr       s8, s15, s1
    s.shli       s22, s17, #1
    s.andi       s25, s8, #1
    s.movz       s8, #0
    s.or         s26, s22, s25
    s.movz       s22, #1
    s.cmp.geu    s25, s26, s20
    s.shl        s27, s22, s1
    s.sub        s22, s8, s25
    s.subi       s8, s1, #1
    s.and        s25, s20, s22
    s.and        s28, s27, s22
    s.sub        s22, s26, s25
    s.or         s25, s24, s28
    s.mov        s17, s22
    s.mov        s24, s25
    s.mov        s1, s8
    s.movz       s8, #0
    s.cmp.ge     s22, s1, s8
    br.nz        s22, sdiv_4
sdiv_done_3:
    s.xor        s1, s17, s9
    s.movz       s8, #0
    s.sub        s15, s1, s9
    s.movz       s1, #0
    s.movz       s9, #0
    s.cmp.lt     s17, s21, s8
    s.movz       s8, #0
    s.cmp.lt     s20, s15, s1
    s.sub        s1, s9, s17
    s.sub        s9, s8, s20
    s.xor        s8, s21, s1
    s.xor        s17, s15, s9
    s.sub        s20, s8, s1
    s.movz       s1, #0
    s.movz       s8, #1
    s.sub        s22, s17, s9
    s.movz       s17, #0
    s.addi       s24, s1, #0
    s.cmp.eq     s1, s20, s8
    s.addi       s8, s17, #0
    s.mov        s24, s22
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s24, s1
    s.addi       s1, s17, #0
sdiv_6:
    s.lshr       s17, s22, s1
    s.shli       s25, s8, #1
    s.andi       s26, s17, #1
    s.movz       s17, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s20
    s.shl        s28, s25, s1
    s.sub        s25, s17, s26
    s.subi       s17, s1, #1
    s.and        s26, s20, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s24, s29
    s.mov        s8, s25
    s.mov        s24, s26
    s.mov        s1, s17
    s.movz       s17, #0
    s.cmp.ge     s25, s1, s17
    br.nz        s25, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s17, #0
    s.movz       s20, #0
    s.cmp.lt     s22, s21, s1
    s.movz       s1, #0
    s.cmp.lt     s24, s15, s17
    s.sub        s17, s20, s22
    s.sub        s20, s1, s24
    s.xor        s1, s21, s17
    s.xor        s21, s8, s9
    s.xor        s8, s15, s20
    s.sub        s15, s1, s17
    s.movz       s1, #0
    s.movz       s22, #1
    s.sub        s24, s21, s9
    s.sub        s9, s8, s20
    s.movz       s8, #0
    s.addi       s21, s1, #0
    s.cmp.eq     s1, s15, s22
    s.add        s22, s23, s24
    s.addi       s23, s8, #0
    s.mov        s21, s9
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s8, #31
    s.mov        s21, s1
    s.addi       s1, s8, #0
sdiv_8:
    s.lshr       s8, s9, s1
    s.shli       s24, s23, #1
    s.andi       s25, s8, #1
    s.movz       s8, #0
    s.or         s26, s24, s25
    s.movz       s24, #1
    s.cmp.geu    s25, s26, s15
    s.shl        s27, s24, s1
    s.sub        s24, s8, s25
    s.subi       s8, s1, #1
    s.and        s25, s15, s24
    s.and        s28, s27, s24
    s.sub        s24, s26, s25
    s.or         s25, s21, s28
    s.mov        s23, s24
    s.mov        s21, s25
    s.mov        s1, s8
    s.movz       s8, #0
    s.cmp.ge     s24, s1, s8
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s1, s22, s12
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s8, s20, s17
    v.splat      v1, s4
    v.movi       v2, #0
    v.splat      v3, s1
    s.xor        s9, s21, s8
    v.add        v4, v3, v0
    v.sub        v0, v2, v1
    v.sub        v3, v2, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v1, v2
    s.sub        s15, s9, s8
    v.movi       v5, #1
    @p1 v.sel        v6, v3, v4
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.movz       s8, #31
idiv_9:
    v.splat      v4, s8
    v.shl        v7, v1, v5
    v.lshr       v8, v6, v4
    v.cmp.lt     p2, v1, v2
    v.and        v9, v8, v5
    v.shl        v8, v5, v4
    v.or         v4, v7, v9
    s.subi       s9, s8, #1
    v.cmp.geu    p3, v4, v3
    p.or         p4, p2, p3
    v.sub        v7, v4, v3
    @p4 v.sel        v9, v8, v2
    @p4 v.sel        v8, v7, v4
    v.or         v4, v0, v9
    v.mov        v1, v8
    v.mov        v0, v4
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s17, s8, s9
    br.nz        s17, idiv_9
    s.mul        s8, s15, s7
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s8
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v1
    v.add        v2, v3, v4
    v.add        v3, v5, v7
    v.add        v4, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s8
    v.splat      v11, s8
    v.splat      v12, s8
    v.splat      v13, s8
    v.splat      v14, s8
    v.splat      v15, s8
    v.splat      v16, s8
    @p1 v.sel        v17, v6, v1
    v.movi       v1, #0
    v.add        v6, v10, v2
    v.sub        v2, v1, v18
    v.sub        v10, v1, v0
    v.cmp.lt     p1, v18, v1
    v.cmp.lt     p2, v0, v1
    v.add        v19, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v2, v18
    @p2 v.sel        v2, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_10:
    v.splat      v18, s9
    v.shl        v22, v10, v20
    v.lshr       v23, v21, v18
    v.cmp.lt     p2, v10, v1
    v.and        v24, v23, v20
    v.shl        v23, v20, v18
    v.or         v18, v22, v24
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v18, v2
    p.or         p4, p2, p3
    v.sub        v22, v18, v2
    @p4 v.sel        v24, v23, v1
    @p4 v.sel        v23, v22, v18
    v.or         v18, v0, v24
    v.mov        v10, v23
    v.mov        v0, v18
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_10
    v.movi       v0, #0
    v.sub        v2, v1, v10
    v.sub        v1, v0, v6
    v.sub        v18, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v20, v2, v10
    v.movi       v2, #1
    @p2 v.sel        v10, v1, v6
    @p3 v.sel        v1, v18, v9
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_11:
    v.splat      v18, s9
    v.shl        v21, v9, v2
    v.lshr       v22, v10, v18
    v.cmp.lt     p1, v9, v0
    v.and        v23, v22, v2
    v.shl        v22, v2, v18
    v.or         v18, v21, v23
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v18, v1
    p.or         p4, p1, p3
    v.sub        v21, v18, v1
    @p4 v.sel        v23, v22, v0
    @p4 v.sel        v22, v21, v18
    v.or         v18, v6, v23
    v.mov        v9, v22
    v.mov        v6, v18
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_11
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.sub        v0, v1, v19
    v.sub        v6, v1, v11
    v.cmp.lt     p1, v19, v1
    v.cmp.lt     p3, v11, v1
    @p2 v.sel        v10, v2, v9
    v.movi       v2, #1
    @p1 v.sel        v9, v0, v19
    @p3 v.sel        v0, v6, v11
    v.movi       v6, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_12:
    v.splat      v18, s9
    v.shl        v19, v11, v2
    v.lshr       v21, v9, v18
    v.cmp.lt     p2, v11, v1
    v.and        v22, v21, v2
    v.shl        v21, v2, v18
    v.or         v18, v19, v22
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v18, v0
    p.or         p4, p2, p3
    v.sub        v19, v18, v0
    @p4 v.sel        v22, v21, v1
    @p4 v.sel        v21, v19, v18
    v.or         v18, v6, v22
    v.mov        v11, v21
    v.mov        v6, v18
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v11
    v.sub        v1, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v9, v2, v11
    v.movi       v2, #1
    @p2 v.sel        v11, v1, v3
    @p3 v.sel        v1, v6, v12
    v.movi       v3, #0
    v.movi       v6, #0
    s.movz       s9, #31
idiv_13:
    v.splat      v12, s9
    v.shl        v18, v6, v2
    v.lshr       v19, v11, v12
    v.cmp.lt     p1, v6, v0
    v.and        v21, v19, v2
    v.shl        v19, v2, v12
    v.or         v12, v18, v21
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v12, v1
    p.or         p4, p1, p3
    v.sub        v18, v12, v1
    @p4 v.sel        v21, v19, v0
    @p4 v.sel        v19, v18, v12
    v.or         v12, v3, v21
    v.mov        v6, v19
    v.mov        v3, v12
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.sub        v0, v1, v4
    v.sub        v3, v1, v13
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p3, v13, v1
    @p2 v.sel        v11, v2, v6
    v.movi       v2, #1
    @p1 v.sel        v6, v0, v4
    @p3 v.sel        v0, v3, v13
    v.movi       v3, #0
    v.movi       v4, #0
    s.movz       s9, #31
idiv_14:
    v.splat      v12, s9
    v.shl        v13, v4, v2
    v.lshr       v18, v6, v12
    v.cmp.lt     p2, v4, v1
    v.and        v19, v18, v2
    v.shl        v18, v2, v12
    v.or         v12, v13, v19
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v12, v0
    p.or         p4, p2, p3
    v.sub        v13, v12, v0
    @p4 v.sel        v19, v18, v1
    @p4 v.sel        v18, v13, v12
    v.or         v12, v3, v19
    v.mov        v4, v18
    v.mov        v3, v12
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v4
    v.sub        v1, v0, v5
    v.sub        v3, v0, v14
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v14, v0
    @p1 v.sel        v6, v2, v4
    v.movi       v2, #1
    @p2 v.sel        v4, v1, v5
    @p3 v.sel        v1, v3, v14
    v.movi       v3, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_15:
    v.splat      v12, s9
    v.shl        v13, v5, v2
    v.lshr       v14, v4, v12
    v.cmp.lt     p1, v5, v0
    v.and        v18, v14, v2
    v.shl        v14, v2, v12
    v.or         v12, v13, v18
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v12, v1
    p.or         p4, p1, p3
    v.sub        v13, v12, v1
    @p4 v.sel        v18, v14, v0
    @p4 v.sel        v14, v13, v12
    v.or         v12, v3, v18
    v.mov        v5, v14
    v.mov        v3, v12
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.sub        v0, v1, v7
    v.sub        v3, v1, v15
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v15, v1
    @p2 v.sel        v4, v2, v5
    v.movi       v2, #1
    @p1 v.sel        v5, v0, v7
    @p3 v.sel        v0, v3, v15
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s9, #31
idiv_16:
    v.splat      v12, s9
    v.shl        v13, v7, v2
    v.lshr       v14, v5, v12
    v.cmp.lt     p2, v7, v1
    v.and        v15, v14, v2
    v.shl        v14, v2, v12
    v.or         v12, v13, v15
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v12, v0
    p.or         p4, p2, p3
    v.sub        v13, v12, v0
    @p4 v.sel        v15, v14, v1
    @p4 v.sel        v14, v13, v12
    v.or         v12, v3, v15
    v.mov        v7, v14
    v.mov        v3, v12
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v7
    v.sub        v1, v0, v8
    v.sub        v3, v0, v16
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v16, v0
    @p1 v.sel        v5, v2, v7
    v.movi       v2, #1
    @p2 v.sel        v7, v1, v8
    @p3 v.sel        v1, v3, v16
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s9, #31
idiv_17:
    v.splat      v12, s9
    v.shl        v13, v8, v2
    v.lshr       v14, v7, v12
    v.cmp.lt     p1, v8, v0
    v.and        v15, v14, v2
    v.shl        v14, v2, v12
    v.or         v12, v13, v15
    s.subi       s15, s9, #1
    v.cmp.geu    p3, v12, v1
    p.or         p4, p1, p3
    v.sub        v13, v12, v1
    @p4 v.sel        v15, v14, v0
    @p4 v.sel        v14, v13, v12
    v.or         v12, v3, v15
    v.mov        v8, v14
    v.mov        v3, v12
    s.mov        s9, s15
    s.movz       s15, #0
    s.cmp.ge     s17, s9, s15
    br.nz        s17, idiv_17
    s.add        s9, s6, s2
    s.movz       s2, #0
    s.movz       s15, #0
    s.cmp.lt     s17, s9, s2
    s.movz       s2, #0
    s.sub        s20, s15, s17
    s.movz       s15, #0
    s.xor        s17, s9, s20
    s.cmp.lt     s9, s7, s2
    s.sub        s2, s17, s20
    s.sub        s17, s15, s9
    s.lshri      s9, s2, #7
    s.xor        s15, s20, s17
    s.muli       s20, s9, #128
    v.sub        v1, v0, v8
    s.xor        s21, s7, s17
    s.xor        s22, s9, s15
    s.movz       s9, #0
    s.movz       s23, #0
    s.movz       s24, #0
    @p2 v.sel        v0, v1, v8
    s.movz       s25, #32
    s.movz       s26, #48
    s.movz       s27, #64
    s.movz       s28, #80
    s.movz       s29, #96
    s.movz       s30, #112
    v.ld.gather.w v1, [s11, v17]                 // index is in elements (ISA sec 9.1)
    s.sub        s11, s21, s17
    s.sub        s11, s2, s20
    s.sub        s2, s22, s15
    s.movz       s11, #1
    s.addi       s15, s9, #0
    s.addi       s17, s23, #0
    s.addi       s20, s24, #0
    s.ld.w       s21, [s18, #0]                  // one element, not a vector
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s18, s15, s2
    br.nz        s18, endfor_19
    v.extract    s18, v20, #0
    s.mul        s22, s15, s7
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s18
    v.extract    s23, v10, #0
    v.add        v7, v3, v2
    v.splat      v3, s23
    v.sub        v8, v20, v7
    v.add        v7, v3, v2
    s.sub        s24, s6, s22
    s.movz       s22, #0
    s.movz       s31, #0
    v.reduce.or  s32, v8
    v.sub        v3, v10, v7
    s.add        s33, s9, s24
    s.movz       s34, #0
    s.cmp.eq     s35, s32, s22
    s.cmp.ge     s22, s18, s31
    s.movz       s31, #0
    s.movz       s32, #0
    v.reduce.or  s36, v3
    s.cmp.ge     s37, s33, s34
    s.and        s34, s35, s22
    s.cmp.eq     s22, s36, s31
    s.cmp.ge     s31, s23, s32
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s32, arg_base
    v.movi       v3, #0
    v.movi       v7, #0
    s.and        s35, s34, s37
    s.and        s34, s22, s31
    s.ld.d       s22, [s32, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.insert     v3, s35, #0
    v.insert     v7, s18, #0
    s.and        s18, s34, s37
    v.splat      v8, s14
    v.insert     v3, s18, #1
    v.splat      v12, s14
    v.splat      v13, s14
    v.splat      v14, s14
    v.splat      v15, s14
    v.splat      v16, s14
    v.splat      v18, s14
    v.splat      v19, s14
    v.mul        v21, v20, v8
    v.extract    s18, v9, #0
    v.insert     v7, s23, #1
    v.mul        v8, v10, v12
    v.splat      v12, s18
    v.mul        v22, v9, v13
    v.add        v13, v12, v2
    v.mul        v12, v11, v14
    v.sub        v14, v9, v13
    s.movz       s23, #0
    v.reduce.or  s31, v14
    s.cmp.eq     s32, s31, s23
    v.mul        v13, v6, v15
    s.movz       s23, #0
    v.mul        v14, v4, v16
    s.cmp.ge     s31, s18, s23
    v.mul        v15, v5, v18
    s.and        s23, s32, s31
    v.mul        v16, v0, v19
    v.extract    s31, v11, #0
    v.splat      v18, s31
    v.extract    s32, v6, #0
    v.add        v19, v18, v2
    v.splat      v18, s32
    v.extract    s34, v4, #0
    v.sub        v23, v11, v19
    v.add        v19, v18, v2
    v.splat      v18, s34
    s.movz       s35, #0
    s.movz       s36, #0
    v.sub        v24, v6, v19
    v.add        v19, v18, v2
    s.cmp.ge     s38, s31, s36
    v.sub        v18, v4, v19
    s.and        s36, s23, s37
    v.insert     v3, s36, #2
    v.extract    s23, v5, #0
    v.splat      v19, s23
    v.insert     v7, s18, #2
    v.reduce.or  s18, v23
    s.cmp.eq     s36, s18, s35
    s.movz       s18, #0
    v.add        v23, v19, v2
    s.and        s35, s36, s38
    s.movz       s36, #0
    v.sub        v19, v5, v23
    s.cmp.ge     s38, s32, s36
    s.and        s36, s35, s37
    v.insert     v3, s36, #3
    v.extract    s35, v0, #0
    v.splat      v23, s35
    v.insert     v7, s31, #3
    v.reduce.or  s31, v24
    s.cmp.eq     s36, s31, s18
    s.movz       s18, #0
    v.add        v24, v23, v2
    s.and        s31, s36, s38
    s.movz       s36, #0
    v.sub        v2, v0, v24
    s.cmp.ge     s38, s34, s36
    s.and        s36, s31, s37
    s.movz       s31, #0
    v.insert     v3, s36, #4
    v.reduce.or  s31, v18
    s.cmp.eq     s36, s31, s18
    s.movz       s18, #0
    s.and        s31, s36, s38
    s.movz       s36, #0
    v.insert     v7, s32, #4
    v.reduce.or  s32, v19
    s.cmp.eq     s38, s32, s18
    s.cmp.ge     s18, s23, s36
    s.movz       s32, #0
    s.and        s36, s31, s37
    s.and        s31, s38, s18
    s.movz       s18, #0
    v.insert     v3, s36, #5
    v.reduce.or  s36, v2
    s.cmp.eq     s38, s36, s32
    s.cmp.ge     s32, s35, s18
    v.insert     v7, s34, #5
    s.and        s18, s31, s37
    s.and        s31, s38, s32
    v.insert     v3, s18, #6
    v.insert     v7, s23, #6
    v.splat      v2, s10
    s.and        s18, s31, s37
    v.mul        v18, v17, v2
    s.add        s23, s13, s20
    v.extract    s31, v18, #0
    s.add        s32, s31, s17
    s.addi       s31, s22, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    .li       s34, #2147483647
    s.movz       s36, #1
    .li       s37, #137438953488
    s.add        s38, s19, s32
    v.insert     v3, s18, #7
    v.iota       v2                              // arange(0, VLEN)
    .li       s18, #7705171329024
    v.insert     v7, s35, #7
    s.movz       s32, #0
    s.st.d       [s31, #0], s23
    s.add        s23, s32, s24                   // the tile origin
    s.addi       s32, s22, #256
    v.splat      v19, s23
    s.addi       s23, s22, #768                  // TensorMap 1: the gathered fallback B tile
    v.cmp.lt     p1, v2, v19
    s.st.d       [s31, #8], s34
    s.movz       s34, #32
    s.movz       s35, #0
    s.st.d       [s31, #16], s33
    s.st.d       [s31, #48], s14
    s.st.d       [s31, #56], s36
    s.movz       s35, #16
    s.st.d       [s31, #88], s37
    s.movz       s36, #16
    s.st.d       [s31, #104], s18
    s.movz       s18, #1
    td.load      d0, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s31, #68719476768
    s.st.d       [s23, #0], s32
    .li       s32, #7705171329024
    s.st.d       [s23, #8], s34
    v.extract    s34, v18, #1
    s.add        s37, s34, s17
    s.st.d       [s23, #16], s35
    s.addi       s34, s22, #1024                 // 512 bytes of repack scratch
    s.add        s35, s19, s37
    s.st.d       [s23, #48], s36
    s.addi       s36, s34, #0
    s.st.d       [s23, #56], s18
    v.extract    s18, v18, #2
    s.add        s37, s18, s17
    s.st.d       [s23, #88], s31
    s.addi       s18, s34, #32
    s.add        s31, s19, s37
    s.st.d       [s23, #104], s32
    td.load      d1, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s38, #0]
    v.extract    s23, v18, #3
    s.add        s32, s23, s17
    s.addi       s23, s34, #64
    v.st.b       [s36, #0], v19
    s.add        s36, s19, s32
    v.extract    s32, v18, #4
    s.add        s37, s32, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s35, #0]
    s.addi       s32, s34, #96
    s.add        s35, s19, s37
    v.extract    s37, v18, #5
    v.st.b       [s18, #0], v19
    s.add        s18, s37, s17
    s.addi       s37, s34, #128
    s.add        s38, s19, s18
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s31, #0]
    v.extract    s18, v18, #6
    s.add        s31, s18, s17
    v.st.b       [s23, #0], v19
    s.addi       s18, s34, #160
    s.add        s23, s19, s31
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s36, #0]
    v.extract    s31, v18, #7
    s.add        s36, s31, s17
    v.st.b       [s32, #0], v19
    s.addi       s31, s34, #192
    s.add        s32, s19, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s35, #0]
    v.extract    s35, v18, #8
    s.add        s36, s35, s17
    v.st.b       [s37, #0], v19
    s.addi       s35, s34, #224
    s.add        s37, s19, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s38, #0]
    v.extract    s36, v18, #9
    s.add        s38, s36, s17
    v.st.b       [s18, #0], v19
    s.addi       s18, s34, #256
    s.add        s36, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s23, #0]
    v.extract    s23, v18, #10
    s.add        s38, s23, s17
    v.st.b       [s31, #0], v19
    s.addi       s23, s34, #288
    s.add        s31, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s32, #0]
    v.extract    s32, v18, #11
    s.add        s38, s32, s17
    v.st.b       [s35, #0], v19
    s.addi       s32, s34, #320
    s.add        s35, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s37, v18, #12
    s.add        s38, s37, s17
    v.st.b       [s18, #0], v19
    s.addi       s18, s34, #352
    s.add        s37, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s36, #0]
    v.extract    s36, v18, #13
    s.add        s38, s36, s17
    v.st.b       [s23, #0], v19
    s.addi       s23, s34, #384
    s.add        s36, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s31, #0]
    v.extract    s31, v18, #14
    s.add        s38, s31, s17
    v.st.b       [s32, #0], v19
    s.addi       s31, s34, #416
    s.add        s32, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s35, #0]
    v.extract    s35, v18, #15
    s.add        s38, s35, s17
    v.st.b       [s18, #0], v19
    s.movz       s18, #0
    s.add        s35, s19, s38
    s.add        s38, s18, s12                   // the tile origin
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s18, v18, #0
    s.add        s37, s18, s17
    v.splat      v23, s38
    v.st.b       [s23, #0], v19
    s.movz       s18, #0
    s.addi       s23, s34, #448
    s.add        s38, s18, s24                   // the tile origin
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s36, #0]
    s.addi       s18, s37, #16
    v.add        v24, v2, v23
    v.splat      v23, s38
    v.st.b       [s31, #0], v19
    v.extract    s31, v18, #1
    s.addi       s36, s34, #480
    s.add        s37, s19, s18
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s32, #0]
    s.add        s18, s31, s17
    v.cmp.lt     p2, v24, v23
    s.addi       s31, s18, #16
    v.st.b       [s23, #0], v19
    v.extract    s18, v18, #2
    s.addi       s23, s34, #16
    s.add        s32, s19, s31
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s35, #0]
    s.add        s31, s18, s17
    v.extract    s18, v18, #3
    s.addi       s35, s31, #16
    v.st.b       [s36, #0], v19
    s.addi       s31, s34, #48
    s.add        s36, s19, s35
    s.add        s35, s18, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    s.addi       s18, s35, #16
    v.extract    s35, v18, #4
    s.addi       s37, s34, #80
    v.st.b       [s23, #0], v19
    s.add        s23, s19, s18
    s.add        s18, s35, s17
    v.extract    s35, v18, #5
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s32, #0]
    s.addi       s32, s18, #16
    s.addi       s18, s34, #112
    s.add        s38, s19, s32
    v.st.b       [s31, #0], v19
    s.add        s31, s35, s17
    v.extract    s32, v18, #6
    s.addi       s35, s31, #16
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s36, #0]
    s.addi       s31, s34, #144
    s.add        s36, s19, s35
    s.add        s35, s32, s17
    v.st.b       [s37, #0], v19
    s.addi       s32, s35, #16
    v.extract    s35, v18, #7
    s.add        s37, s19, s32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s23, #0]
    s.addi       s23, s34, #176
    s.add        s32, s35, s17
    v.st.b       [s18, #0], v19
    s.addi       s18, s32, #16
    v.extract    s32, v18, #8
    s.add        s35, s19, s18
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    s.addi       s18, s34, #208
    s.add        s38, s32, s17
    v.st.b       [s31, #0], v19
    s.addi       s31, s38, #16
    v.extract    s32, v18, #9
    s.add        s38, s19, s31
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s36, #0]
    s.addi       s31, s34, #240
    s.add        s36, s32, s17
    v.st.b       [s23, #0], v19
    s.addi       s23, s36, #16
    v.extract    s32, v18, #10
    s.add        s36, s19, s23
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    s.addi       s23, s34, #272
    s.add        s37, s32, s17
    v.st.b       [s18, #0], v19
    s.addi       s18, s37, #16
    v.extract    s32, v18, #11
    s.add        s37, s19, s18
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    s.addi       s18, s34, #304
    s.add        s35, s32, s17
    v.st.b       [s31, #0], v19
    s.addi       s31, s35, #16
    v.extract    s32, v18, #12
    s.add        s35, s19, s31
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    s.addi       s31, s34, #336
    s.add        s38, s32, s17
    v.st.b       [s23, #0], v19
    s.addi       s23, s38, #16
    v.extract    s32, v18, #13
    s.add        s38, s19, s23
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s36, #0]
    s.addi       s23, s34, #368
    s.add        s36, s32, s17
    v.st.b       [s18, #0], v19
    s.addi       s18, s36, #16
    v.extract    s32, v18, #14
    s.add        s36, s19, s18
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    s.addi       s18, s34, #400
    s.add        s37, s32, s17
    v.st.b       [s31, #0], v19
    s.addi       s31, s37, #16
    v.extract    s32, v18, #15
    s.add        s37, s19, s31
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    s.addi       s31, s34, #432
    s.add        s35, s32, s17
    v.st.b       [s23, #0], v19
    s.addi       s23, s35, #16
    s.addi       s32, s34, #464
    s.add        s35, s19, s23
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    s.addi       s23, s34, #496
    v.st.b       [s18, #0], v19
    s.addi       s18, s34, #64
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s36, #0]
    s.addi       s36, s34, #128
    v.st.b       [s31, #0], v19
    s.addi       s31, s34, #192
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    s.addi       s37, s34, #256
    v.st.b       [s32, #0], v19
    s.addi       s32, s34, #320
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    s.addi       s35, s34, #384
    v.st.b       [s23, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s23, s34, #448
    v.ld.w       v19, [s34, #0]
    v.extract    s34, v3, #0
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s18, #0]
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s36, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s37, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s32, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s23, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_20
    s.movz       s18, #0
    s.add        s23, s13, s20
    s.addi       s31, s18, #0
    s.addi       s18, s22, #256
x8dot_row_21:
    s.addi       s32, s33, #0
    v.movi       v19, #0
    s.sub        s35, s32, s31
    s.add        s32, s23, s31
    v.splat      v23, s35
    s.shli       s35, s31, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s32, v21]            // index is in elements (ISA sec 9.1)
    s.add        s32, s18, s35
    s.addi       s35, s31, #1
    s.movz       s36, #32
    v.st.b       [s32, #0], v19
    fence.acq_rel.device
    s.mov        s31, s35
    s.cmp.lt     s32, s31, s36
    br.nz        s32, x8dot_row_21
x8dot_done_20:
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    s.movz       s31, #0
    s.movz       s32, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s34, v7, #0
    s.mov        s35, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s18            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s23
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_22
    s.movz       s32, #0
    s.add        s34, s13, s20
    s.addi       s35, s32, #0
    s.addi       s32, s22, #256
x8dot_row_23:
    s.addi       s36, s33, #0
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s34, s35
    v.splat      v23, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v8]             // index is in elements (ISA sec 9.1)
    s.add        s36, s32, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_23
x8dot_done_22:
    v.splat      v19, s31
    v.movi       v23, #0
    v.splat      v24, s31
    v.movi       v25, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    s.movz       s35, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s36, v7, #1
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_24
    s.movz       s35, #0
    s.add        s36, s13, s20
    s.addi       s37, s35, #0
    s.addi       s35, s22, #256
x8dot_row_25:
    s.addi       s38, s33, #0
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s36, s37
    v.splat      v23, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v22]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_25
x8dot_done_24:
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    s.movz       s36, #0
    s.movz       s37, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s38, v7, #2
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_26
    s.movz       s37, #0
    s.add        s38, s13, s20
    s.addi       s39, s37, #0
    s.addi       s37, s22, #256
x8dot_row_27:
    s.addi       s40, s33, #0
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s38, s39
    v.splat      v23, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v12]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_27
x8dot_done_26:
    v.splat      v19, s36
    v.movi       v23, #0
    v.splat      v24, s36
    v.movi       v25, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    s.movz       s39, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s40, v7, #3
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_28
    s.movz       s39, #0
    s.add        s40, s13, s20
    s.addi       s41, s39, #0
    s.addi       s39, s22, #256
x8dot_row_29:
    s.addi       s42, s33, #0
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v23, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v13]            // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_29
x8dot_done_28:
    v.splat      v19, s38
    v.movi       v23, #0
    v.splat      v24, s38
    v.movi       v25, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    s.movz       s41, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s42, v7, #4
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_30
    s.movz       s41, #0
    s.add        s42, s13, s20
    s.addi       s43, s41, #0
    s.addi       s41, s22, #256
x8dot_row_31:
    s.addi       s44, s33, #0
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v23, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v14]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_31
x8dot_done_30:
    v.splat      v19, s40
    v.movi       v23, #0
    v.splat      v24, s40
    v.movi       v25, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    s.movz       s43, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s44, v7, #5
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_32
    s.movz       s43, #0
    s.add        s44, s13, s20
    s.addi       s45, s43, #0
    s.addi       s43, s22, #256
x8dot_row_33:
    s.addi       s46, s33, #0
    v.movi       v19, #0
    s.sub        s47, s46, s45
    s.add        s46, s44, s45
    v.splat      v23, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v15]            // index is in elements (ISA sec 9.1)
    s.add        s46, s43, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_33
x8dot_done_32:
    v.splat      v19, s42
    v.movi       v23, #0
    v.splat      v24, s42
    v.movi       v25, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    s.movz       s45, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s46, v7, #6
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_34
    s.movz       s45, #0
    s.add        s46, s13, s20
    s.addi       s47, s45, #0
    s.addi       s45, s22, #256
x8dot_row_35:
    s.addi       s48, s33, #0
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s46, s47
    v.splat      v23, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v16]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_35
x8dot_done_34:
    s.movz       s45, #0
    v.extract    s46, v18, #0
    s.add        s47, s45, s25                   // the tile origin
    s.movz       s45, #0
    s.add        s48, s46, s17
    v.splat      v19, s44
    v.movi       v23, #0
    v.splat      v24, s44
    v.movi       v25, #0
    v.splat      v26, s47
    s.add        s44, s45, s24                   // the tile origin
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    s.movz       s49, #0
    s.addi       s50, s48, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s48, v7, #7
    v.add        v19, v2, v26
    v.splat      v23, s44
    v.extract    s44, v18, #1
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s47, s19, s50
    s.add        s48, s44, s17
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s46
    mb.wait      s46
    s.addi       s44, s22, #1536                 // 512 bytes of repack scratch
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s47, #0]
    s.addi       s47, s48, #32
    v.extract    s48, v18, #2
    s.addi       s49, s44, #0
    s.add        s50, s19, s47
    s.add        s47, s48, s17
    v.st.b       [s49, #0], v19
    s.addi       s48, s47, #32
    v.extract    s47, v18, #3
    s.addi       s49, s44, #32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s50, #0]
    s.add        s50, s19, s48
    s.add        s48, s47, s17
    v.extract    s47, v18, #4
    v.st.b       [s49, #0], v19
    s.addi       s49, s48, #32
    s.addi       s48, s44, #64
    s.add        s51, s19, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s50, #0]
    s.add        s49, s47, s17
    v.extract    s47, v18, #5
    s.addi       s50, s49, #32
    v.st.b       [s48, #0], v19
    s.addi       s48, s44, #96
    s.add        s49, s19, s50
    s.add        s50, s47, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.addi       s47, s50, #32
    v.extract    s50, v18, #6
    s.addi       s51, s44, #128
    v.st.b       [s48, #0], v19
    s.add        s48, s19, s47
    s.add        s47, s50, s17
    v.extract    s50, v18, #7
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s49, #0]
    s.addi       s49, s47, #32
    s.addi       s47, s44, #160
    s.add        s52, s19, s49
    v.st.b       [s51, #0], v19
    s.add        s49, s50, s17
    v.extract    s50, v18, #8
    s.addi       s51, s49, #32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s48, #0]
    s.addi       s48, s44, #192
    s.add        s49, s19, s51
    s.add        s51, s50, s17
    v.st.b       [s47, #0], v19
    s.addi       s47, s51, #32
    v.extract    s50, v18, #9
    s.addi       s51, s44, #224
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.add        s52, s19, s47
    s.add        s47, s50, s17
    v.extract    s50, v18, #10
    v.st.b       [s48, #0], v19
    s.addi       s48, s47, #32
    s.addi       s47, s44, #256
    s.add        s53, s19, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s49, #0]
    s.add        s48, s50, s17
    v.extract    s49, v18, #11
    s.addi       s50, s48, #32
    v.st.b       [s51, #0], v19
    s.addi       s48, s44, #288
    s.add        s51, s19, s50
    s.add        s50, s49, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s49, s50, #32
    v.extract    s50, v18, #12
    s.add        s52, s19, s49
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #320
    s.add        s49, s50, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s50, s49, #32
    v.extract    s49, v18, #13
    s.add        s53, s19, s50
    v.st.b       [s48, #0], v19
    s.addi       s48, s44, #352
    s.add        s50, s49, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.addi       s49, s50, #32
    v.extract    s50, v18, #14
    s.add        s51, s19, s49
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #384
    s.add        s49, s50, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s50, s49, #32
    v.extract    s49, v18, #15
    s.add        s52, s19, s50
    v.st.b       [s48, #0], v19
    s.addi       s48, s44, #416
    s.add        s50, s49, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.movz       s49, #0
    s.addi       s53, s50, #32
    s.add        s50, s49, s26                   // the tile origin
    v.st.b       [s47, #0], v19
    v.extract    s47, v18, #0
    s.add        s49, s19, s53
    s.add        s53, s47, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.movz       s47, #0
    v.splat      v23, s50
    s.addi       s50, s44, #448
    v.st.b       [s48, #0], v19
    s.add        s48, s47, s24                   // the tile origin
    s.addi       s47, s53, #48
    v.add        v19, v2, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v23, [s52, #0]
    v.splat      v24, s48
    v.extract    s48, v18, #1
    s.addi       s51, s44, #480
    v.st.b       [s50, #0], v23
    s.add        s50, s19, s47
    s.add        s47, s48, s17
    v.cmp.lt     p2, v19, v24
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s49, #0]
    s.addi       s48, s47, #48
    v.extract    s47, v18, #2
    s.addi       s49, s44, #16
    v.st.b       [s51, #0], v19
    s.add        s51, s19, s48
    s.add        s48, s47, s17
    v.extract    s47, v18, #3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s50, s48, #48
    s.addi       s48, s44, #48
    s.add        s52, s19, s50
    v.st.b       [s49, #0], v19
    s.add        s49, s47, s17
    v.extract    s47, v18, #4
    s.addi       s50, s49, #48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s49, s44, #80
    s.add        s51, s19, s50
    s.add        s50, s47, s17
    v.st.b       [s48, #0], v19
    s.addi       s47, s50, #48
    v.extract    s48, v18, #5
    s.addi       s50, s44, #112
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.add        s52, s19, s47
    s.add        s47, s48, s17
    v.extract    s48, v18, #6
    v.st.b       [s49, #0], v19
    s.addi       s49, s47, #48
    s.addi       s47, s44, #144
    s.add        s53, s19, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.add        s49, s48, s17
    v.extract    s48, v18, #7
    s.addi       s51, s49, #48
    v.st.b       [s50, #0], v19
    s.addi       s49, s44, #176
    s.add        s50, s19, s51
    s.add        s51, s48, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s48, s51, #48
    v.extract    s51, v18, #8
    s.add        s52, s19, s48
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #208
    s.add        s48, s51, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s51, s48, #48
    v.extract    s48, v18, #9
    s.add        s53, s19, s51
    v.st.b       [s49, #0], v19
    s.addi       s49, s44, #240
    s.add        s51, s48, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s48, s51, #48
    v.extract    s50, v18, #10
    s.add        s51, s19, s48
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #272
    s.add        s48, s50, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s50, s48, #48
    v.extract    s48, v18, #11
    s.add        s52, s19, s50
    v.st.b       [s49, #0], v19
    s.addi       s49, s44, #304
    s.add        s50, s48, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s48, s50, #48
    v.extract    s50, v18, #12
    s.add        s53, s19, s48
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #336
    s.add        s48, s50, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s50, s48, #48
    v.extract    s48, v18, #13
    s.add        s51, s19, s50
    v.st.b       [s49, #0], v19
    s.addi       s49, s44, #368
    s.add        s50, s48, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s48, s50, #48
    v.extract    s50, v18, #14
    s.add        s52, s19, s48
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #400
    s.add        s48, s50, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s50, s48, #48
    v.extract    s48, v18, #15
    s.add        s53, s19, s50
    v.st.b       [s49, #0], v19
    s.addi       s49, s44, #432
    s.add        s50, s48, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s48, s50, #48
    s.addi       s50, s44, #464
    s.add        s51, s19, s48
    v.st.b       [s47, #0], v19
    s.addi       s47, s44, #496
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s48, s44, #64
    v.st.b       [s49, #0], v19
    s.addi       s49, s44, #128
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s52, s44, #192
    v.st.b       [s50, #0], v19
    s.addi       s50, s44, #256
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s51, s44, #320
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s47, s44, #384
    v.ld.w       v19, [s44, #0]
    s.addi       s53, s44, #448
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    v.extract    s44, v3, #0
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s52, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s47, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_36
    s.movz       s47, #0
    s.add        s48, s13, s20
    s.addi       s49, s47, #0
    s.addi       s47, s48, #32
    s.addi       s48, s22, #256
x8dot_row_37:
    s.addi       s50, s33, #-32
    v.movi       v19, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s50, v21]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v19
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_37
x8dot_done_36:
    v.splat      v19, s44
    v.movi       v23, #0
    v.splat      v24, s44
    v.movi       v25, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    s.movz       s49, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s50, v7, #0
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_38
    s.movz       s49, #0
    s.add        s50, s13, s20
    s.addi       s51, s49, #0
    s.addi       s49, s50, #32
    s.addi       s50, s22, #256
x8dot_row_39:
    s.addi       s52, s33, #-32
    v.movi       v19, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v23, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v8]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_39
x8dot_done_38:
    v.splat      v19, s48
    v.movi       v23, #0
    v.splat      v24, s48
    v.movi       v25, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    s.movz       s51, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s52, v7, #1
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_40
    s.movz       s51, #0
    s.add        s52, s13, s20
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s22, #256
x8dot_row_41:
    s.addi       s54, s33, #-32
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v22]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_41
x8dot_done_40:
    v.splat      v19, s50
    v.movi       v23, #0
    v.splat      v24, s50
    v.movi       v25, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    s.movz       s53, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s54, v7, #2
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_42
    s.movz       s53, #0
    s.add        s54, s13, s20
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s22, #256
x8dot_row_43:
    s.addi       s56, s33, #-32
    v.movi       v19, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v23, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v12]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_43
x8dot_done_42:
    v.splat      v19, s52
    v.movi       v23, #0
    v.splat      v24, s52
    v.movi       v25, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    s.movz       s55, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s56, v7, #3
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_44
    s.movz       s55, #0
    s.add        s56, s13, s20
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s22, #256
x8dot_row_45:
    s.addi       s58, s33, #-32
    v.movi       v19, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v23, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s58, v13]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v19
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_45
x8dot_done_44:
    v.splat      v19, s54
    v.movi       v23, #0
    v.splat      v24, s54
    v.movi       v25, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    s.movz       s57, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s58, v7, #4
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s60, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s59, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s58                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_46
    s.movz       s57, #0
    s.add        s58, s13, s20
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s22, #256
x8dot_row_47:
    s.addi       s60, s33, #-32
    v.movi       v19, #0
    s.sub        s18, s60, s59
    s.add        s23, s57, s59
    v.splat      v23, s18
    s.shli       s18, s59, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s23, v14]            // index is in elements (ISA sec 9.1)
    s.add        s23, s58, s18
    s.addi       s18, s59, #1
    s.movz       s31, #32
    v.st.b       [s23, #0], v19
    fence.acq_rel.device
    s.mov        s59, s18
    s.cmp.lt     s18, s59, s31
    br.nz        s18, x8dot_row_47
x8dot_done_46:
    v.splat      v19, s56
    v.movi       v23, #0
    v.splat      v24, s56
    v.movi       v25, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    s.movz       s31, #0
    s.movz       s32, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s34, v7, #5
    s.mov        s35, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s18            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s23
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_48
    s.movz       s32, #0
    s.add        s34, s13, s20
    s.addi       s35, s32, #0
    s.addi       s32, s34, #32
    s.addi       s34, s22, #256
x8dot_row_49:
    s.addi       s36, s33, #-32
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s32, s35
    v.splat      v23, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v15]            // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_49
x8dot_done_48:
    v.splat      v19, s31
    v.movi       v23, #0
    v.splat      v24, s31
    v.movi       v25, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    s.movz       s35, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s36, v7, #6
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_50
    s.movz       s35, #0
    s.add        s36, s13, s20
    s.addi       s37, s35, #0
    s.addi       s35, s36, #32
    s.addi       s36, s22, #256
x8dot_row_51:
    s.addi       s38, s33, #-32
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v23, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v16]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_51
x8dot_done_50:
    s.movz       s35, #0
    v.extract    s36, v18, #0
    s.add        s37, s35, s27                   // the tile origin
    s.movz       s35, #0
    s.add        s38, s36, s17
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    v.splat      v26, s37
    s.add        s34, s35, s24                   // the tile origin
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s39, #32
    s.addi       s40, s38, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s38, v7, #7
    v.add        v19, v2, v26
    v.splat      v23, s34
    v.extract    s34, v18, #1
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s37, s19, s40
    s.add        s38, s34, s17
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s36
    mb.wait      s36
    s.addi       s34, s22, #2048                 // 512 bytes of repack scratch
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    s.addi       s37, s38, #64
    v.extract    s38, v18, #2
    s.addi       s39, s34, #0
    s.add        s40, s19, s37
    s.add        s37, s38, s17
    v.st.b       [s39, #0], v19
    s.addi       s38, s37, #64
    v.extract    s37, v18, #3
    s.addi       s39, s34, #32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s40, #0]
    s.add        s40, s19, s38
    s.add        s38, s37, s17
    v.extract    s37, v18, #4
    v.st.b       [s39, #0], v19
    s.addi       s39, s38, #64
    s.addi       s38, s34, #64
    s.add        s41, s19, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s40, #0]
    s.add        s39, s37, s17
    v.extract    s37, v18, #5
    s.addi       s40, s39, #64
    v.st.b       [s38, #0], v19
    s.addi       s38, s34, #96
    s.add        s39, s19, s40
    s.add        s40, s37, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.addi       s37, s40, #64
    v.extract    s40, v18, #6
    s.addi       s41, s34, #128
    v.st.b       [s38, #0], v19
    s.add        s38, s19, s37
    s.add        s37, s40, s17
    v.extract    s40, v18, #7
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s39, #0]
    s.addi       s39, s37, #64
    s.addi       s37, s34, #160
    s.add        s42, s19, s39
    v.st.b       [s41, #0], v19
    s.add        s39, s40, s17
    v.extract    s40, v18, #8
    s.addi       s41, s39, #64
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s38, #0]
    s.addi       s38, s34, #192
    s.add        s39, s19, s41
    s.add        s41, s40, s17
    v.st.b       [s37, #0], v19
    s.addi       s37, s41, #64
    v.extract    s40, v18, #9
    s.addi       s41, s34, #224
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.add        s42, s19, s37
    s.add        s37, s40, s17
    v.extract    s40, v18, #10
    v.st.b       [s38, #0], v19
    s.addi       s38, s37, #64
    s.addi       s37, s34, #256
    s.add        s43, s19, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s39, #0]
    s.add        s38, s40, s17
    v.extract    s39, v18, #11
    s.addi       s40, s38, #64
    v.st.b       [s41, #0], v19
    s.addi       s38, s34, #288
    s.add        s41, s19, s40
    s.add        s40, s39, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.addi       s39, s40, #64
    v.extract    s40, v18, #12
    s.add        s42, s19, s39
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #320
    s.add        s39, s40, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.addi       s40, s39, #64
    v.extract    s39, v18, #13
    s.add        s43, s19, s40
    v.st.b       [s38, #0], v19
    s.addi       s38, s34, #352
    s.add        s40, s39, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.addi       s39, s40, #64
    v.extract    s40, v18, #14
    s.add        s41, s19, s39
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #384
    s.add        s39, s40, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.addi       s40, s39, #64
    v.extract    s39, v18, #15
    s.add        s42, s19, s40
    v.st.b       [s38, #0], v19
    s.addi       s38, s34, #416
    s.add        s40, s39, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.movz       s39, #0
    s.addi       s43, s40, #64
    s.add        s40, s39, s28                   // the tile origin
    v.st.b       [s37, #0], v19
    v.extract    s37, v18, #0
    s.add        s39, s19, s43
    s.add        s43, s37, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.movz       s37, #0
    v.splat      v23, s40
    s.addi       s40, s34, #448
    v.st.b       [s38, #0], v19
    s.add        s38, s37, s24                   // the tile origin
    s.addi       s37, s43, #80
    v.add        v19, v2, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v23, [s42, #0]
    v.splat      v24, s38
    v.extract    s38, v18, #1
    s.addi       s41, s34, #480
    v.st.b       [s40, #0], v23
    s.add        s40, s19, s37
    s.add        s37, s38, s17
    v.cmp.lt     p2, v19, v24
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s39, #0]
    s.addi       s38, s37, #80
    v.extract    s37, v18, #2
    s.addi       s39, s34, #16
    v.st.b       [s41, #0], v19
    s.add        s41, s19, s38
    s.add        s38, s37, s17
    v.extract    s37, v18, #3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s40, s38, #80
    s.addi       s38, s34, #48
    s.add        s42, s19, s40
    v.st.b       [s39, #0], v19
    s.add        s39, s37, s17
    v.extract    s37, v18, #4
    s.addi       s40, s39, #80
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s39, s34, #80
    s.add        s41, s19, s40
    s.add        s40, s37, s17
    v.st.b       [s38, #0], v19
    s.addi       s37, s40, #80
    v.extract    s38, v18, #5
    s.addi       s40, s34, #112
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.add        s42, s19, s37
    s.add        s37, s38, s17
    v.extract    s38, v18, #6
    v.st.b       [s39, #0], v19
    s.addi       s39, s37, #80
    s.addi       s37, s34, #144
    s.add        s43, s19, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.add        s39, s38, s17
    v.extract    s38, v18, #7
    s.addi       s41, s39, #80
    v.st.b       [s40, #0], v19
    s.addi       s39, s34, #176
    s.add        s40, s19, s41
    s.add        s41, s38, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s38, s41, #80
    v.extract    s41, v18, #8
    s.add        s42, s19, s38
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #208
    s.add        s38, s41, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s41, s38, #80
    v.extract    s38, v18, #9
    s.add        s43, s19, s41
    v.st.b       [s39, #0], v19
    s.addi       s39, s34, #240
    s.add        s41, s38, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s38, s41, #80
    v.extract    s40, v18, #10
    s.add        s41, s19, s38
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #272
    s.add        s38, s40, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s40, s38, #80
    v.extract    s38, v18, #11
    s.add        s42, s19, s40
    v.st.b       [s39, #0], v19
    s.addi       s39, s34, #304
    s.add        s40, s38, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s38, s40, #80
    v.extract    s40, v18, #12
    s.add        s43, s19, s38
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #336
    s.add        s38, s40, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s40, s38, #80
    v.extract    s38, v18, #13
    s.add        s41, s19, s40
    v.st.b       [s39, #0], v19
    s.addi       s39, s34, #368
    s.add        s40, s38, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s38, s40, #80
    v.extract    s40, v18, #14
    s.add        s42, s19, s38
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #400
    s.add        s38, s40, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s40, s38, #80
    v.extract    s38, v18, #15
    s.add        s43, s19, s40
    v.st.b       [s39, #0], v19
    s.addi       s39, s34, #432
    s.add        s40, s38, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s38, s40, #80
    s.addi       s40, s34, #464
    s.add        s41, s19, s38
    v.st.b       [s37, #0], v19
    s.addi       s37, s34, #496
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s38, s34, #64
    v.st.b       [s39, #0], v19
    s.addi       s39, s34, #128
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s42, s34, #192
    v.st.b       [s40, #0], v19
    s.addi       s40, s34, #256
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s41, s34, #320
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s37, s34, #384
    v.ld.w       v19, [s34, #0]
    s.addi       s43, s34, #448
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s38, #0]
    v.extract    s34, v3, #0
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s39, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s42, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s40, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s41, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s37, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s43, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_52
    s.movz       s37, #0
    s.add        s38, s13, s20
    s.addi       s39, s37, #0
    s.addi       s37, s38, #64
    s.addi       s38, s22, #256
x8dot_row_53:
    s.addi       s40, s33, #-64
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v23, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v21]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_53
x8dot_done_52:
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    s.movz       s39, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s40, v7, #0
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_54
    s.movz       s39, #0
    s.add        s40, s13, s20
    s.addi       s41, s39, #0
    s.addi       s39, s40, #64
    s.addi       s40, s22, #256
x8dot_row_55:
    s.addi       s42, s33, #-64
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v23, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v8]             // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_55
x8dot_done_54:
    v.splat      v19, s38
    v.movi       v23, #0
    v.splat      v24, s38
    v.movi       v25, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    s.movz       s41, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s42, v7, #1
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_56
    s.movz       s41, #0
    s.add        s42, s13, s20
    s.addi       s43, s41, #0
    s.addi       s41, s42, #64
    s.addi       s42, s22, #256
x8dot_row_57:
    s.addi       s44, s33, #-64
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v23, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v22]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_57
x8dot_done_56:
    v.splat      v19, s40
    v.movi       v23, #0
    v.splat      v24, s40
    v.movi       v25, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    s.movz       s43, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s44, v7, #2
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_58
    s.movz       s43, #0
    s.add        s44, s13, s20
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s22, #256
x8dot_row_59:
    s.addi       s46, s33, #-64
    v.movi       v19, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v23, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v12]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_59
x8dot_done_58:
    v.splat      v19, s42
    v.movi       v23, #0
    v.splat      v24, s42
    v.movi       v25, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    s.movz       s45, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s46, v7, #3
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_60
    s.movz       s45, #0
    s.add        s46, s13, s20
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s22, #256
x8dot_row_61:
    s.addi       s48, s33, #-64
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v23, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v13]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_61
x8dot_done_60:
    v.splat      v19, s44
    v.movi       v23, #0
    v.splat      v24, s44
    v.movi       v25, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    s.movz       s47, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s48, v7, #4
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_62
    s.movz       s47, #0
    s.add        s48, s13, s20
    s.addi       s49, s47, #0
    s.addi       s47, s48, #64
    s.addi       s48, s22, #256
x8dot_row_63:
    s.addi       s50, s33, #-64
    v.movi       v19, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s50, v14]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v19
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_63
x8dot_done_62:
    v.splat      v19, s46
    v.movi       v23, #0
    v.splat      v24, s46
    v.movi       v25, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    s.movz       s49, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s50, v7, #5
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_64
    s.movz       s49, #0
    s.add        s50, s13, s20
    s.addi       s51, s49, #0
    s.addi       s49, s50, #64
    s.addi       s50, s22, #256
x8dot_row_65:
    s.addi       s52, s33, #-64
    v.movi       v19, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v23, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v15]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_65
x8dot_done_64:
    v.splat      v19, s48
    v.movi       v23, #0
    v.splat      v24, s48
    v.movi       v25, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    s.movz       s51, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s52, v7, #6
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_66
    s.movz       s51, #0
    s.add        s52, s13, s20
    s.addi       s53, s51, #0
    s.addi       s51, s52, #64
    s.addi       s52, s22, #256
x8dot_row_67:
    s.addi       s54, s33, #-64
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v16]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_67
x8dot_done_66:
    s.movz       s51, #0
    v.extract    s52, v18, #0
    s.add        s53, s51, s29                   // the tile origin
    s.movz       s51, #0
    s.add        s54, s52, s17
    v.splat      v19, s50
    v.movi       v23, #0
    v.splat      v24, s50
    v.movi       v25, #0
    v.splat      v26, s53
    s.add        s50, s51, s24                   // the tile origin
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    s.movz       s55, #64
    s.addi       s56, s54, #96
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    v.extract    s54, v7, #7
    v.add        v19, v2, v26
    v.splat      v23, s50
    v.extract    s50, v18, #1
    s.mov        s57, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s53, s19, s56
    s.add        s54, s50, s17
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s52
    mb.wait      s52
    s.addi       s50, s22, #2560                 // 512 bytes of repack scratch
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s53, s54, #96
    v.extract    s54, v18, #2
    s.addi       s55, s50, #0
    s.add        s56, s19, s53
    s.add        s53, s54, s17
    v.st.b       [s55, #0], v19
    s.addi       s54, s53, #96
    v.extract    s53, v18, #3
    s.addi       s55, s50, #32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s56, #0]
    s.add        s56, s19, s54
    s.add        s54, s53, s17
    v.extract    s53, v18, #4
    v.st.b       [s55, #0], v19
    s.addi       s55, s54, #96
    s.addi       s54, s50, #64
    s.add        s57, s19, s55
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s56, #0]
    s.add        s55, s53, s17
    v.extract    s53, v18, #5
    s.addi       s56, s55, #96
    v.st.b       [s54, #0], v19
    s.addi       s54, s50, #96
    s.add        s55, s19, s56
    s.add        s56, s53, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s57, #0]
    s.addi       s53, s56, #96
    v.extract    s56, v18, #6
    s.addi       s57, s50, #128
    v.st.b       [s54, #0], v19
    s.add        s54, s19, s53
    s.add        s53, s56, s17
    v.extract    s56, v18, #7
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s55, #0]
    s.addi       s55, s53, #96
    s.addi       s53, s50, #160
    s.add        s58, s19, s55
    v.st.b       [s57, #0], v19
    s.add        s55, s56, s17
    v.extract    s56, v18, #8
    s.addi       s57, s55, #96
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s54, #0]
    s.addi       s54, s50, #192
    s.add        s55, s19, s57
    s.add        s57, s56, s17
    v.st.b       [s53, #0], v19
    s.addi       s53, s57, #96
    v.extract    s56, v18, #9
    s.addi       s57, s50, #224
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.add        s58, s19, s53
    s.add        s53, s56, s17
    v.extract    s56, v18, #10
    v.st.b       [s54, #0], v19
    s.addi       s54, s53, #96
    s.addi       s53, s50, #256
    s.add        s59, s19, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s55, #0]
    s.add        s54, s56, s17
    v.extract    s55, v18, #11
    s.addi       s56, s54, #96
    v.st.b       [s57, #0], v19
    s.addi       s54, s50, #288
    s.add        s57, s19, s56
    s.add        s56, s55, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.addi       s55, s56, #96
    v.extract    s56, v18, #12
    s.add        s58, s19, s55
    v.st.b       [s53, #0], v19
    s.addi       s53, s50, #320
    s.add        s55, s56, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s59, #0]
    s.addi       s56, s55, #96
    v.extract    s55, v18, #13
    s.add        s59, s19, s56
    v.st.b       [s54, #0], v19
    s.addi       s54, s50, #352
    s.add        s56, s55, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s57, #0]
    s.addi       s55, s56, #96
    v.extract    s56, v18, #14
    s.add        s57, s19, s55
    v.st.b       [s53, #0], v19
    s.addi       s53, s50, #384
    s.add        s55, s56, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.addi       s56, s55, #96
    v.extract    s55, v18, #15
    s.add        s58, s19, s56
    v.st.b       [s54, #0], v19
    s.addi       s54, s50, #416
    s.add        s56, s55, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s59, #0]
    s.movz       s55, #0
    s.addi       s59, s56, #96
    s.add        s56, s55, s30                   // the tile origin
    v.st.b       [s53, #0], v19
    v.extract    s53, v18, #0
    s.add        s55, s19, s59
    s.add        s59, s53, s17
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s57, #0]
    s.movz       s53, #0
    v.splat      v23, s56
    s.addi       s56, s50, #448
    v.st.b       [s54, #0], v19
    s.add        s54, s53, s24                   // the tile origin
    s.addi       s24, s59, #112
    v.add        v19, v2, v23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s58, #0]
    v.splat      v23, s54
    v.extract    s53, v18, #1
    s.addi       s54, s50, #480
    v.st.b       [s56, #0], v2
    s.add        s56, s19, s24
    s.add        s24, s53, s17
    v.cmp.lt     p2, v19, v23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s55, #0]
    s.addi       s53, s24, #112
    v.extract    s24, v18, #2
    s.addi       s55, s50, #16
    v.st.b       [s54, #0], v2
    s.add        s54, s19, s53
    s.add        s53, s24, s17
    v.extract    s24, v18, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    s.addi       s56, s53, #112
    s.addi       s53, s50, #48
    s.add        s57, s19, s56
    v.st.b       [s55, #0], v2
    s.add        s55, s24, s17
    v.extract    s24, v18, #4
    s.addi       s56, s55, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s54, #0]
    s.addi       s54, s50, #80
    s.add        s55, s19, s56
    s.add        s56, s24, s17
    v.st.b       [s53, #0], v2
    s.addi       s24, s56, #112
    v.extract    s53, v18, #5
    s.addi       s56, s50, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    s.add        s57, s19, s24
    s.add        s24, s53, s17
    v.extract    s53, v18, #6
    v.st.b       [s54, #0], v2
    s.addi       s54, s24, #112
    s.addi       s24, s50, #144
    s.add        s58, s19, s54
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s55, #0]
    s.add        s54, s53, s17
    v.extract    s53, v18, #7
    s.addi       s55, s54, #112
    v.st.b       [s56, #0], v2
    s.addi       s54, s50, #176
    s.add        s56, s19, s55
    s.add        s55, s53, s17
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    s.addi       s53, s55, #112
    v.extract    s55, v18, #8
    s.addi       s57, s50, #208
    v.st.b       [s24, #0], v2
    s.add        s24, s19, s53
    s.add        s53, s55, s17
    v.extract    s55, v18, #9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    s.addi       s58, s53, #112
    s.addi       s53, s50, #240
    s.add        s59, s19, s58
    v.st.b       [s54, #0], v2
    s.add        s54, s55, s17
    v.extract    s55, v18, #10
    s.addi       s58, s54, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    s.addi       s54, s50, #272
    s.add        s56, s19, s58
    s.add        s58, s55, s17
    v.st.b       [s57, #0], v2
    s.addi       s55, s58, #112
    v.extract    s57, v18, #11
    s.add        s58, s19, s55
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s24, #0]
    s.addi       s24, s50, #304
    s.add        s55, s57, s17
    v.st.b       [s53, #0], v2
    s.addi       s53, s55, #112
    v.extract    s55, v18, #12
    s.add        s57, s19, s53
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    s.addi       s53, s50, #336
    s.add        s59, s55, s17
    v.st.b       [s54, #0], v2
    s.addi       s54, s59, #112
    v.extract    s55, v18, #13
    s.add        s59, s19, s54
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    s.addi       s54, s50, #368
    s.add        s56, s55, s17
    v.st.b       [s24, #0], v2
    s.addi       s24, s56, #112
    v.extract    s55, v18, #14
    s.add        s56, s19, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    s.addi       s24, s50, #400
    s.add        s58, s55, s17
    v.st.b       [s53, #0], v2
    s.addi       s53, s58, #112
    v.extract    s55, v18, #15
    s.add        s58, s19, s53
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    s.addi       s53, s50, #432
    s.add        s57, s55, s17
    v.st.b       [s54, #0], v2
    s.addi       s54, s57, #112
    s.addi       s55, s50, #464
    s.add        s57, s19, s54
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    s.addi       s54, s50, #496
    v.st.b       [s24, #0], v2
    s.addi       s24, s50, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    s.addi       s56, s50, #128
    v.st.b       [s53, #0], v2
    s.addi       s53, s50, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    s.addi       s58, s50, #256
    v.st.b       [s55, #0], v2
    s.addi       s55, s50, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    s.addi       s57, s50, #384
    v.st.b       [s54, #0], v2
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s54, s50, #448
    v.ld.w       v2, [s50, #0]
    v.extract    s50, v3, #0
    v.mov        v48, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s24, #0]
    v.mov        v49, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s56, #0]
    v.mov        v50, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s53, #0]
    v.mov        v51, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s58, #0]
    v.mov        v52, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s55, #0]
    v.mov        v53, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s57, #0]
    v.mov        v54, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s54, #0]
    v.mov        v55, v2                         // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_68
    s.movz       s24, #0
    s.add        s53, s13, s20
    s.addi       s54, s24, #0
    s.addi       s24, s53, #96
    s.addi       s53, s22, #256
x8dot_row_69:
    s.addi       s55, s33, #-96
    v.movi       v2, #0
    s.sub        s56, s55, s54
    s.add        s55, s24, s54
    v.splat      v18, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v18, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s55, v21]             // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v2
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_69
x8dot_done_68:
    v.splat      v2, s50
    v.movi       v18, #0
    v.splat      v19, s50
    v.movi       v21, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s53, #0
    s.movz       s54, #96
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v19, v21
    v.extract    s55, v7, #0
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_70
    s.movz       s54, #0
    s.add        s55, s13, s20
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s22, #256
x8dot_row_71:
    s.addi       s57, s33, #-96
    v.movi       v2, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v18, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v18, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s57, v8]              // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v2
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_71
x8dot_done_70:
    v.splat      v2, s53
    v.movi       v8, #0
    v.splat      v18, s53
    v.movi       v19, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    s.movz       s56, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v18, v19
    v.extract    s57, v7, #1
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_72
    s.movz       s56, #0
    s.add        s57, s13, s20
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s22, #256
x8dot_row_73:
    s.addi       s59, s33, #-96
    v.movi       v2, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v8, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v8, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s59, v22]             // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s18, #32
    v.st.b       [s59, #0], v2
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s23, s58, s18
    br.nz        s23, x8dot_row_73
x8dot_done_72:
    v.splat      v2, s55
    v.movi       v8, #0
    v.splat      v18, s55
    v.movi       v19, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    s.movz       s24, #0
    s.movz       s31, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v18, v19
    v.extract    s32, v7, #2
    s.mov        s34, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s18            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s23, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s23, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s24, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s23
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s24, x8dot_done_74
    s.movz       s31, #0
    s.add        s32, s13, s20
    s.addi       s34, s31, #0
    s.addi       s31, s32, #96
    s.addi       s32, s22, #256
x8dot_row_75:
    s.addi       s35, s33, #-96
    v.movi       v2, #0
    s.sub        s36, s35, s34
    s.add        s35, s31, s34
    v.splat      v8, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v8, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s35, v12]             // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v2
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_75
x8dot_done_74:
    v.splat      v2, s24
    v.movi       v8, #0
    v.splat      v12, s24
    v.movi       v18, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s32, #0
    s.movz       s34, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v12, v18
    v.extract    s35, v7, #3
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s31, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s32, x8dot_done_76
    s.movz       s34, #0
    s.add        s35, s13, s20
    s.addi       s36, s34, #0
    s.addi       s34, s35, #96
    s.addi       s35, s22, #256
x8dot_row_77:
    s.addi       s37, s33, #-96
    v.movi       v2, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v8, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v8, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s37, v13]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v2
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_77
x8dot_done_76:
    v.splat      v2, s32
    v.movi       v8, #0
    v.splat      v12, s32
    v.movi       v13, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v12, v13
    v.extract    s37, v7, #4
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_78
    s.movz       s36, #0
    s.add        s37, s13, s20
    s.addi       s38, s36, #0
    s.addi       s36, s37, #96
    s.addi       s37, s22, #256
x8dot_row_79:
    s.addi       s39, s33, #-96
    v.movi       v2, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v8, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v8, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s39, v14]             // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v2
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_79
x8dot_done_78:
    v.splat      v2, s35
    v.movi       v8, #0
    v.splat      v12, s35
    v.movi       v13, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v12, v13
    v.extract    s39, v7, #5
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_80
    s.movz       s38, #0
    s.add        s39, s13, s20
    s.addi       s40, s38, #0
    s.addi       s38, s39, #96
    s.addi       s39, s22, #256
x8dot_row_81:
    s.addi       s41, s33, #-96
    v.movi       v2, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v8, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v8, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s41, v15]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v2
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_81
x8dot_done_80:
    v.splat      v2, s37
    v.movi       v8, #0
    v.splat      v12, s37
    v.movi       v13, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    s.movz       s40, #96
    v.cmp.ne     p1, v2, v8
    v.cmp.eq     p2, v12, v13
    v.extract    s41, v7, #6
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_82
    s.movz       s40, #0
    s.add        s41, s13, s20
    s.addi       s42, s40, #0
    s.addi       s40, s41, #96
    s.addi       s41, s22, #256
x8dot_row_83:
    s.addi       s43, s33, #-96
    v.movi       v2, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v3, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s43, v16]             // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v2
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_83
x8dot_done_82:
    v.splat      v2, s39
    v.movi       v3, #0
    v.splat      v8, s39
    v.movi       v12, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    s.movz       s41, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v8, v12
    v.extract    s42, v7, #7
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s40, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    mb.wait      s39
    s.addi       s41, s22, #3072
    a.vread      v2, a8, s40
    s.movz       s40, #1
    v.st.w       [s41, #0], v2
    s.addi       s42, s41, #64
    a.vread      v2, a8, s40
    s.movz       s40, #2
    s.addi       s43, s41, #128
    s.movz       s44, #3
    s.addi       s45, s41, #192
    s.movz       s46, #4
    v.st.w       [s42, #0], v2
    a.vread      v2, a8, s40
    s.addi       s40, s41, #256
    s.movz       s42, #5
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #320
    s.movz       s44, #6
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #448
    s.movz       s42, #8
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #512
    s.movz       s44, #9
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #640
    s.movz       s42, #11
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #832
    s.movz       s42, #14
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #896
    s.movz       s44, #15
    s.addi       s47, s41, #960
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.movz       s41, #0
    s.addi       s45, s22, #4096
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.movz       s40, #1
    s.addi       s42, s45, #64
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.movz       s43, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a9, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a9, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a9, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a9, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.movz       s40, #0
    s.addi       s45, s22, #5120
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.movz       s42, #1
    s.addi       s43, s45, #64
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.movz       s41, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a10, s40
    s.movz       s40, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a10, s42
    s.movz       s42, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a10, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a10, s40
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a10, s42
    s.addi       s42, s45, #384
    s.movz       s46, #7
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #448
    s.movz       s43, #8
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #512
    s.movz       s44, #9
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.addi       s42, s45, #576
    s.movz       s46, #10
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.addi       s42, s45, #768
    s.movz       s46, #13
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #832
    s.movz       s43, #14
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.movz       s42, #0
    s.addi       s45, s22, #6144
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.movz       s41, #1
    s.addi       s43, s45, #64
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.movz       s40, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a11, s42
    s.movz       s42, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a11, s41
    s.movz       s41, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a11, s40
    s.addi       s40, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a11, s42
    s.addi       s42, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a11, s41
    s.addi       s41, s45, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #512
    s.movz       s44, #9
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.addi       s41, s45, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #640
    s.movz       s43, #11
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #704
    s.movz       s44, #12
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.addi       s41, s45, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.movz       s41, #0
    s.addi       s45, s22, #7168
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.movz       s40, #1
    s.addi       s43, s45, #64
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.movz       s42, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a12, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a12, s40
    s.movz       s40, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a12, s42
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a12, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a12, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.movz       s40, #0
    s.addi       s45, s22, #8192
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.movz       s42, #1
    s.addi       s43, s45, #64
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.movz       s41, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a13, s40
    s.movz       s40, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a13, s42
    s.movz       s42, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a13, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a13, s40
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a13, s42
    s.addi       s42, s45, #384
    s.movz       s46, #7
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #448
    s.movz       s43, #8
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #512
    s.movz       s44, #9
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.addi       s42, s45, #576
    s.movz       s46, #10
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.addi       s42, s45, #768
    s.movz       s46, #13
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #832
    s.movz       s43, #14
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.movz       s42, #0
    s.addi       s45, s22, #9216
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.movz       s41, #1
    s.addi       s43, s45, #64
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.movz       s40, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a14, s42
    s.movz       s42, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a14, s41
    s.movz       s41, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a14, s40
    s.addi       s40, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a14, s42
    s.addi       s42, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a14, s41
    s.addi       s41, s45, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #512
    s.movz       s44, #9
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.addi       s41, s45, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #640
    s.movz       s43, #11
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #704
    s.movz       s44, #12
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.addi       s41, s45, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.movz       s41, #0
    s.addi       s45, s22, #10240
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.movz       s40, #1
    s.addi       s43, s45, #64
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.movz       s42, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a15, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a15, s40
    s.movz       s40, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a15, s42
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a15, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a15, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.movz       s40, #0
    s.addi       s45, s22, #3072
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s22, #11264
    s.movz       s43, #1
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s22, #3136
    s.addi       s44, s42, #64
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a0, s40
    s.movz       s40, #2
    s.addi       s46, s22, #3200
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s42, #128
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a0, s43
    s.movz       s43, #3
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3264
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a0, s40
    s.addi       s40, s42, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3328
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a0, s43
    s.addi       s43, s42, #256
    s.movz       s45, #5
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3392
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.addi       s40, s42, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3456
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.addi       s43, s42, #384
    s.movz       s45, #7
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3520
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.addi       s40, s42, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3584
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.addi       s43, s42, #512
    s.movz       s45, #9
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3648
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.addi       s40, s42, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3712
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.addi       s43, s42, #640
    s.movz       s45, #11
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3776
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.addi       s40, s42, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3840
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.addi       s43, s42, #768
    s.movz       s45, #13
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #3904
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.addi       s40, s42, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #3968
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.addi       s43, s42, #896
    s.movz       s45, #15
    s.addi       s47, s42, #960
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s22, #4032
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a0, s44
    s.movz       s40, #0
    s.addi       s42, s22, #4096
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s22, #12288
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a0, s45
    s.movz       s43, #1
    s.addi       s45, s22, #4160
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s44, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a1, s40
    s.movz       s40, #2
    s.addi       s46, s22, #4224
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s44, #128
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a1, s43
    s.movz       s43, #3
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4288
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a1, s40
    s.addi       s40, s44, #192
    s.movz       s41, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4352
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #256
    s.movz       s43, #5
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4416
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.addi       s40, s44, #320
    s.movz       s41, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4480
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #384
    s.movz       s43, #7
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4544
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.addi       s40, s44, #448
    s.movz       s41, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4608
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #512
    s.movz       s43, #9
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4672
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.addi       s40, s44, #576
    s.movz       s41, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4736
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #640
    s.movz       s43, #11
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4800
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.addi       s40, s44, #704
    s.movz       s41, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4864
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #768
    s.movz       s43, #13
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s22, #4928
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.addi       s40, s44, #832
    s.movz       s41, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #4992
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.addi       s42, s44, #896
    s.movz       s43, #15
    s.addi       s47, s44, #960
    v.ld.w       v3, [s45, #0]
    s.addi       s44, s22, #5056
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a1, s41
    s.movz       s40, #0
    s.addi       s41, s22, #5120
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #13312
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a1, s43
    s.movz       s42, #1
    s.addi       s43, s22, #5184
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a2, s40
    s.movz       s40, #2
    s.addi       s46, s22, #5248
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a2, s42
    s.movz       s42, #3
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5312
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a2, s40
    s.addi       s40, s45, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #5376
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #256
    s.movz       s42, #5
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5440
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #5504
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #384
    s.movz       s42, #7
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5568
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.addi       s40, s45, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #5632
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #512
    s.movz       s42, #9
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5696
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.addi       s40, s45, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #5760
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #640
    s.movz       s42, #11
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5824
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #5888
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #768
    s.movz       s42, #13
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #5952
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.addi       s40, s45, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6016
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.addi       s41, s45, #896
    s.movz       s42, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #6080
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a2, s44
    s.movz       s40, #0
    s.addi       s44, s22, #6144
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #14336
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a2, s42
    s.movz       s41, #1
    s.addi       s42, s22, #6208
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a3, s40
    s.movz       s40, #2
    s.addi       s46, s22, #6272
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a3, s41
    s.movz       s41, #3
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6336
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a3, s40
    s.addi       s40, s45, #192
    s.movz       s43, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6400
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a3, s41
    s.addi       s41, s45, #256
    s.movz       s44, #5
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6464
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.addi       s40, s45, #320
    s.movz       s43, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6528
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.addi       s41, s45, #384
    s.movz       s44, #7
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6592
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6656
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6720
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.addi       s40, s45, #576
    s.movz       s43, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6784
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.addi       s41, s45, #640
    s.movz       s44, #11
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6848
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.addi       s40, s45, #704
    s.movz       s43, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #6912
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.addi       s41, s45, #768
    s.movz       s44, #13
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #6976
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7040
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #7104
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a3, s43
    s.movz       s40, #0
    s.addi       s43, s22, #7168
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #15360
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a3, s44
    s.movz       s41, #1
    s.addi       s44, s22, #7232
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a4, s40
    s.movz       s40, #2
    s.addi       s46, s22, #7296
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a4, s41
    s.movz       s41, #3
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #7360
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a4, s40
    s.addi       s40, s45, #192
    s.movz       s42, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7424
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a4, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #7488
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.addi       s40, s45, #320
    s.movz       s42, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7552
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.addi       s41, s45, #384
    s.movz       s43, #7
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #7616
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.addi       s40, s45, #448
    s.movz       s42, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7680
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.addi       s41, s45, #512
    s.movz       s43, #9
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #7744
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.addi       s40, s45, #576
    s.movz       s42, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7808
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #7872
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.addi       s40, s45, #704
    s.movz       s42, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #7936
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.addi       s41, s45, #768
    s.movz       s43, #13
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #8000
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.addi       s40, s45, #832
    s.movz       s42, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8064
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.addi       s41, s45, #896
    s.movz       s43, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #8128
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a4, s42
    s.movz       s40, #0
    s.addi       s42, s22, #8192
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #16384
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a4, s43
    s.movz       s41, #1
    s.addi       s43, s22, #8256
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a5, s40
    s.movz       s40, #2
    s.addi       s46, s22, #8320
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a5, s41
    s.movz       s41, #3
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #8384
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a5, s40
    s.addi       s40, s45, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8448
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a5, s41
    s.addi       s41, s45, #256
    s.movz       s42, #5
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #8512
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8576
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.addi       s41, s45, #384
    s.movz       s42, #7
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #8640
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.addi       s40, s45, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8704
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.addi       s41, s45, #512
    s.movz       s42, #9
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #8768
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.addi       s40, s45, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8832
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.addi       s41, s45, #640
    s.movz       s42, #11
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #8896
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #8960
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.addi       s41, s45, #768
    s.movz       s42, #13
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #9024
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.addi       s40, s45, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9088
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.addi       s41, s45, #896
    s.movz       s42, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s22, #9152
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a5, s44
    s.movz       s40, #0
    s.addi       s44, s22, #9216
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #17408
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a5, s42
    s.movz       s41, #1
    s.addi       s42, s22, #9280
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a6, s40
    s.movz       s40, #2
    s.addi       s46, s22, #9344
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a6, s41
    s.movz       s41, #3
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #9408
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a6, s40
    s.addi       s40, s45, #192
    s.movz       s43, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9472
    vf.add       v7, v2, v3
    v.st.w       [s44, #0], v7
    a.vread      v2, a6, s41
    s.addi       s41, s45, #256
    s.movz       s44, #5
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #9536
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.addi       s40, s45, #320
    s.movz       s43, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9600
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.addi       s41, s45, #384
    s.movz       s44, #7
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #9664
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9728
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #9792
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.addi       s40, s45, #576
    s.movz       s43, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9856
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.addi       s41, s45, #640
    s.movz       s44, #11
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #9920
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.addi       s40, s45, #704
    s.movz       s43, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #9984
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.addi       s41, s45, #768
    s.movz       s44, #13
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #10048
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #10112
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s22, #10176
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a6, s43
    s.movz       s40, #0
    s.addi       s43, s22, #10240
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s22, #18432
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a6, s44
    s.movz       s41, #1
    s.addi       s44, s22, #10304
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #64
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    a.vread      v2, a7, s40
    s.movz       s40, #2
    s.addi       s46, s22, #10368
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #128
    vf.add       v7, v2, v3
    v.st.w       [s45, #0], v7
    a.vread      v2, a7, s41
    s.movz       s41, #3
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #10432
    vf.add       v7, v2, v3
    v.st.w       [s42, #0], v7
    a.vread      v2, a7, s40
    s.addi       s40, s45, #192
    s.movz       s42, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #10496
    vf.add       v7, v2, v3
    v.st.w       [s43, #0], v7
    a.vread      v2, a7, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #10560
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s45, #320
    s.movz       s42, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #10624
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.addi       s41, s45, #384
    s.movz       s43, #7
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #10688
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s45, #448
    s.movz       s42, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #10752
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.addi       s41, s45, #512
    s.movz       s43, #9
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #10816
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s45, #576
    s.movz       s42, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #10880
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #10944
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s45, #704
    s.movz       s42, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #11008
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.addi       s41, s45, #768
    s.movz       s43, #13
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #11072
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s45, #832
    s.movz       s42, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s22, #11136
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.addi       s41, s45, #896
    s.movz       s43, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s22, #11200
    vf.add       v7, v2, v3
    v.st.w       [s40, #0], v7
    a.vread      v2, a7, s42
    s.addi       s40, s17, #128
    s.addi       s42, s20, #128
    s.addi       s45, s40, #0
    s.addi       s40, s42, #0
    v.ld.w       v3, [s46, #0]
    s.addi       s42, s22, #11264
    vf.add       v7, v2, v3
    v.st.w       [s41, #0], v7
    a.vread      v2, a7, s43
    s.movz       s41, #0
    s.addi       s43, s22, #11328
    v.ld.w       v3, [s44, #0]
    s.movz       s44, #1
    vf.add       v7, v2, v3
    v.st.w       [s47, #0], v7
    fence.acq_rel.device
    s.mov        s17, s45
    s.mov        s20, s40
    s.addi       s40, s22, #11392
    s.movz       s45, #2
    s.addi       s46, s22, #11456
    s.movz       s47, #3
    s.addi       s48, s22, #11520
    v.ld.w       v2, [s42, #0]
    s.movz       s42, #4
    a.vwrite     a0, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s41, s22, #11584
    s.movz       s43, #5
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #11648
    s.movz       s44, #6
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s45, s22, #11712
    s.movz       s46, #7
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s47, s22, #11776
    s.movz       s48, #8
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #11840
    s.movz       s42, #9
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #11904
    s.movz       s43, #10
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s44, s22, #11968
    s.movz       s45, #11
    a.vwrite     a0, s46, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s46, s22, #12032
    s.movz       s47, #12
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #12096
    s.movz       s48, #13
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #12160
    s.movz       s42, #14
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s43, s22, #12224
    s.movz       s44, #15
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s45, s22, #12288
    s.movz       s46, #0
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #12352
    s.movz       s47, #1
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #12416
    s.movz       s48, #2
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s42, s22, #12480
    s.movz       s43, #3
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s44, s22, #12544
    s.movz       s45, #4
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #12608
    s.movz       s46, #5
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #12672
    s.movz       s47, #6
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #12736
    s.movz       s48, #7
    a.vwrite     a1, s43, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s43, s22, #12800
    s.movz       s44, #8
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #12864
    s.movz       s45, #9
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #12928
    s.movz       s46, #10
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #12992
    s.movz       s47, #11
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #13056
    s.movz       s48, #12
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #13120
    s.movz       s44, #13
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #13184
    s.movz       s45, #14
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #13248
    s.movz       s46, #15
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #13312
    s.movz       s47, #0
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #13376
    s.movz       s48, #1
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #13440
    s.movz       s44, #2
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #13504
    s.movz       s45, #3
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #13568
    s.movz       s46, #4
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #13632
    s.movz       s47, #5
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #13696
    s.movz       s48, #6
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #13760
    s.movz       s44, #7
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #13824
    s.movz       s45, #8
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #13888
    s.movz       s46, #9
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #13952
    s.movz       s47, #10
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #14016
    s.movz       s48, #11
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #14080
    s.movz       s44, #12
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #14144
    s.movz       s45, #13
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #14208
    s.movz       s46, #14
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #14272
    s.movz       s47, #15
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #14336
    s.movz       s48, #0
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #14400
    s.movz       s44, #1
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #14464
    s.movz       s45, #2
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #14528
    s.movz       s46, #3
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #14592
    s.movz       s47, #4
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #14656
    s.movz       s48, #5
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #14720
    s.movz       s44, #6
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #14784
    s.movz       s45, #7
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #14848
    s.movz       s46, #8
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #14912
    s.movz       s47, #9
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #14976
    s.movz       s48, #10
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #15040
    s.movz       s44, #11
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #15104
    s.movz       s45, #12
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #15168
    s.movz       s46, #13
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #15232
    s.movz       s47, #14
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #15296
    s.movz       s48, #15
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #15360
    s.movz       s44, #0
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #15424
    s.movz       s45, #1
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #15488
    s.movz       s46, #2
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #15552
    s.movz       s47, #3
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #15616
    s.movz       s48, #4
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #15680
    s.movz       s44, #5
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #15744
    s.movz       s45, #6
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #15808
    s.movz       s46, #7
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #15872
    s.movz       s47, #8
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #15936
    s.movz       s48, #9
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #16000
    s.movz       s44, #10
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #16064
    s.movz       s45, #11
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #16128
    s.movz       s46, #12
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #16192
    s.movz       s47, #13
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #16256
    s.movz       s48, #14
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #16320
    s.movz       s44, #15
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #16384
    s.movz       s45, #0
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #16448
    s.movz       s46, #1
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #16512
    s.movz       s47, #2
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #16576
    s.movz       s48, #3
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #16640
    s.movz       s44, #4
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #16704
    s.movz       s45, #5
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #16768
    s.movz       s46, #6
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #16832
    s.movz       s47, #7
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #16896
    s.movz       s48, #8
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #16960
    s.movz       s44, #9
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #17024
    s.movz       s45, #10
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #17088
    s.movz       s46, #11
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #17152
    s.movz       s47, #12
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #17216
    s.movz       s48, #13
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #17280
    s.movz       s44, #14
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #17344
    s.movz       s45, #15
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #17408
    s.movz       s46, #0
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #17472
    s.movz       s47, #1
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #17536
    s.movz       s48, #2
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #17600
    s.movz       s44, #3
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #17664
    s.movz       s45, #4
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #17728
    s.movz       s46, #5
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #17792
    s.movz       s47, #6
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #17856
    s.movz       s48, #7
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #17920
    s.movz       s44, #8
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #17984
    s.movz       s45, #9
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #18048
    s.movz       s46, #10
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #18112
    s.movz       s47, #11
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #18176
    s.movz       s48, #12
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #18240
    s.movz       s44, #13
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #18304
    s.movz       s45, #14
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #18368
    s.movz       s46, #15
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #18432
    s.movz       s47, #0
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #18496
    s.movz       s48, #1
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #18560
    s.movz       s44, #2
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #18624
    s.movz       s45, #3
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #18688
    s.movz       s46, #4
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #18752
    s.movz       s47, #5
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #18816
    s.movz       s48, #6
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #18880
    s.movz       s44, #7
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #18944
    s.movz       s45, #8
    s.add        s49, s15, s11
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #19008
    s.movz       s46, #9
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #19072
    s.movz       s47, #10
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s22, #19136
    s.movz       s48, #11
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s22, #19200
    s.movz       s44, #12
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s22, #19264
    s.movz       s45, #13
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s22, #19328
    s.movz       s46, #14
    s.addi       s50, s22, #19392
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s42, #0]
    s.movz       s22, #15
    s.movz       s42, #1
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s41, #0]
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s40, #0]
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s50, #0]
    a.vwrite     a7, s22, v2
    s.mov        s15, s49
    br.nz        s42, for_18
endfor_19:
    s.movz       s2, #0
    v.extract    s6, v1, #0
    a.vread      v0, a0, s2
    v.splat      v2, s6
    s.mul        s2, s1, s5
    vf.mul       v3, v0, v2
    s.movz       s6, #0
    v.splat      v0, s21
    s.muli       s7, s8, #2
    s.muli       s9, s2, #2
    s.movz       s2, #0
    s.movz       s10, #0
    s.add        s11, s6, s8                     // the tile origin
    s.movz       s6, #0
    vf.mul       v2, v3, v0
    s.add        s12, s2, s1                     // the tile origin
    s.add        s1, s10, s4                     // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s11
    s.add        s2, s6, s3                      // the tile origin
    v.splat      v5, s12
    v.splat      v6, s1
    v.add        v7, v3, v4
    v.splat      v4, s2
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s9, s7
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.muli       s2, s5, #2
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s5, v1, #1
    @p3 v.st.h       [s4, #0], v8
    a.vread      v2, a0, s1
    v.splat      v4, s5
    s.muli       s1, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s4, s8, #16
    s.addi       s5, s8, #32
    s.addi       s6, s12, #1
    vf.mul       v2, v5, v0
    s.add        s10, s1, s9
    s.addi       s1, s8, #48
    v.splat      v4, s6
    vf.cvt.f32.bf16 v5, v2
    s.add        s6, s10, s7
    s.addi       s10, s8, #64
    v.cmp.lt     p1, v4, v6
    s.add        s11, s16, s6
    s.addi       s6, s8, #80
    p.and        p3, p1, p2
    s.addi       s13, s8, #96
    @p3 v.st.h       [s11, #0], v5
    s.addi       s11, s8, #112
    s.movz       s8, #2
    v.extract    s14, v1, #2
    a.vread      v2, a0, s8
    v.splat      v4, s14
    s.muli       s8, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #2
    s.movz       s15, #3
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #3
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #3
    s.movz       s15, #4
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #4
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #4
    s.movz       s15, #5
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #5
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #5
    s.movz       s15, #6
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #6
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #6
    s.movz       s15, #7
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #7
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #7
    s.movz       s15, #8
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #8
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #8
    s.movz       s15, #9
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #9
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #9
    s.movz       s15, #10
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #10
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #10
    s.movz       s15, #11
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #11
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #11
    s.movz       s15, #12
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #12
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #12
    s.movz       s15, #13
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #13
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #13
    s.movz       s15, #14
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #14
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #14
    s.movz       s15, #15
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s14, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #15
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s15
    v.splat      v4, s8
    s.muli       s8, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s14, s12, #15
    s.movz       s15, #0
    v.splat      v2, s14
    vf.mul       v4, v5, v0
    s.add        s14, s8, s9
    v.cmp.lt     p1, v2, v6
    s.add        s8, s14, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s8
    p.and        p3, p1, p2
    v.extract    s8, v1, #0
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s15
    v.splat      v4, s8
    s.movz       s7, #0
    vf.mul       v5, v2, v4
    s.muli       s8, s4, #2
    s.add        s14, s7, s4                     // the tile origin
    s.movz       s4, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s14
    s.add        s7, s4, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s7
    vf.cvt.f32.bf16 v8, v2
    s.add        s4, s9, s8
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    v.extract    s14, v1, #1
    @p3 v.st.h       [s7, #0], v8
    a.vread      v2, a1, s4
    v.splat      v4, s14
    s.muli       s4, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #1
    s.movz       s14, #2
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #2
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #2
    s.movz       s14, #3
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #3
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #3
    s.movz       s14, #4
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #4
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #4
    s.movz       s14, #5
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #5
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #5
    s.movz       s14, #6
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #6
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #6
    s.movz       s14, #7
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #7
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #7
    s.movz       s14, #8
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #8
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #8
    s.movz       s14, #9
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #9
    s.movz       s14, #10
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #10
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #10
    s.movz       s14, #11
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #11
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #11
    s.movz       s14, #12
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #12
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #12
    s.movz       s14, #13
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #13
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #13
    s.movz       s14, #14
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #14
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #14
    s.movz       s14, #15
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #15
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s14
    v.splat      v4, s4
    s.muli       s4, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s7, s12, #15
    s.movz       s14, #0
    v.splat      v2, s7
    vf.mul       v4, v5, v0
    s.add        s7, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s7, s8
    vf.cvt.f32.bf16 v2, v4
    s.add        s7, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #0
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a2, s14
    v.splat      v4, s4
    s.movz       s4, #0
    vf.mul       v5, v2, v4
    s.muli       s7, s5, #2
    s.add        s8, s4, s5                      // the tile origin
    s.movz       s4, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s8
    s.add        s5, s4, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v2
    s.add        s4, s9, s7
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    v.extract    s8, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v2, a2, s4
    v.splat      v4, s8
    s.muli       s4, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #1
    s.movz       s8, #2
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #2
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #2
    s.movz       s8, #3
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #3
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #3
    s.movz       s8, #4
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #4
    s.movz       s8, #5
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #5
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #5
    s.movz       s8, #6
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #6
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #6
    s.movz       s8, #7
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #7
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #7
    s.movz       s8, #8
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #8
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #8
    s.movz       s8, #9
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #9
    s.movz       s8, #10
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #10
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #10
    s.movz       s8, #11
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #11
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #11
    s.movz       s8, #12
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #12
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #12
    s.movz       s8, #13
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #13
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #13
    s.movz       s8, #14
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #14
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #14
    s.movz       s8, #15
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #15
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s8
    v.splat      v4, s4
    s.muli       s4, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #15
    s.movz       s8, #0
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s4, s9
    v.cmp.lt     p1, v2, v6
    s.add        s4, s5, s7
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    v.extract    s4, v1, #0
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a3, s8
    v.splat      v4, s4
    s.movz       s4, #0
    vf.mul       v5, v2, v4
    s.muli       s5, s1, #2
    s.add        s7, s4, s1                      // the tile origin
    s.movz       s1, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s7
    s.add        s4, s1, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s4
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s9, s5
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s7, v1, #1
    @p3 v.st.h       [s4, #0], v8
    a.vread      v2, a3, s1
    v.splat      v4, s7
    s.muli       s1, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #1
    s.movz       s7, #2
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #2
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #2
    s.movz       s7, #3
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #3
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #3
    s.movz       s7, #4
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #4
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #4
    s.movz       s7, #5
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #5
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #5
    s.movz       s7, #6
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #6
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #6
    s.movz       s7, #7
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #7
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #7
    s.movz       s7, #8
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #8
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #8
    s.movz       s7, #9
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #9
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #9
    s.movz       s7, #10
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #10
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #10
    s.movz       s7, #11
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #11
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #11
    s.movz       s7, #12
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #12
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #12
    s.movz       s7, #13
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #13
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #13
    s.movz       s7, #14
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #14
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #14
    s.movz       s7, #15
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #15
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s7
    v.splat      v4, s1
    s.muli       s1, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s4, s12, #15
    s.movz       s7, #0
    v.splat      v2, s4
    vf.mul       v4, v5, v0
    s.add        s4, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s4, s5
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #0
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.movz       s1, #0
    vf.mul       v5, v2, v4
    s.muli       s4, s10, #2
    s.add        s5, s1, s10                     // the tile origin
    s.movz       s1, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s5
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s9, s4
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s7, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v2, a4, s1
    v.splat      v4, s7
    s.muli       s1, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #1
    s.movz       s7, #2
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #2
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #2
    s.movz       s7, #3
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #3
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #3
    s.movz       s7, #4
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #4
    s.movz       s7, #5
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #5
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #5
    s.movz       s7, #6
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #6
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #6
    s.movz       s7, #7
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #7
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #7
    s.movz       s7, #8
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #8
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #8
    s.movz       s7, #9
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #9
    s.movz       s7, #10
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #10
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #10
    s.movz       s7, #11
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #11
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #11
    s.movz       s7, #12
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #12
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #12
    s.movz       s7, #13
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #13
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #13
    s.movz       s7, #14
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #14
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #14
    s.movz       s7, #15
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #15
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s7
    v.splat      v4, s1
    s.muli       s1, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #15
    s.movz       s7, #0
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #0
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a5, s7
    v.splat      v4, s1
    s.movz       s1, #0
    vf.mul       v5, v2, v4
    s.muli       s4, s6, #2
    s.add        s5, s1, s6                      // the tile origin
    s.movz       s1, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s5
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s9, s4
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s6, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v2, a5, s1
    v.splat      v4, s6
    s.muli       s1, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #1
    s.movz       s6, #2
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #2
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #2
    s.movz       s6, #3
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #3
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #3
    s.movz       s6, #4
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #4
    s.movz       s6, #5
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #5
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #5
    s.movz       s6, #6
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #6
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #6
    s.movz       s6, #7
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #7
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #7
    s.movz       s6, #8
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #8
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #8
    s.movz       s6, #9
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #9
    s.movz       s6, #10
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #10
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #10
    s.movz       s6, #11
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #11
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #11
    s.movz       s6, #12
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #12
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #12
    s.movz       s6, #13
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #13
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #13
    s.movz       s6, #14
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #14
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #14
    s.movz       s6, #15
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #15
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s6
    v.splat      v4, s1
    s.muli       s1, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #15
    s.movz       s6, #0
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #0
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.movz       s1, #0
    vf.mul       v5, v2, v4
    s.muli       s4, s13, #2
    s.add        s5, s1, s13                     // the tile origin
    s.movz       s1, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s5
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s9, s4
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s6, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v2, a6, s1
    v.splat      v4, s6
    s.muli       s1, s2, #1
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #1
    s.movz       s6, #2
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #2
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #2
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #2
    s.movz       s6, #3
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #3
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #3
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #3
    s.movz       s6, #4
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #4
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #4
    s.movz       s6, #5
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #5
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #5
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #5
    s.movz       s6, #6
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #6
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #6
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #6
    s.movz       s6, #7
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #7
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #7
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #7
    s.movz       s6, #8
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #8
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #8
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #8
    s.movz       s6, #9
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #9
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #9
    s.movz       s6, #10
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #10
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #10
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #10
    s.movz       s6, #11
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #11
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #11
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #11
    s.movz       s6, #12
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #12
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #12
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #12
    s.movz       s6, #13
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #13
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #13
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #13
    s.movz       s6, #14
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #14
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #14
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #14
    s.movz       s6, #15
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s5, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #15
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a6, s6
    v.splat      v4, s1
    s.muli       s1, s2, #15
    vf.mul       v5, v2, v4
    s.addi       s5, s12, #15
    s.movz       s6, #0
    v.splat      v2, s5
    vf.mul       v4, v5, v0
    s.add        s5, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s5, s4
    vf.cvt.f32.bf16 v2, v4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #0
    @p3 v.st.h       [s4, #0], v2
    a.vread      v2, a7, s6
    v.splat      v4, s1
    s.movz       s1, #0
    vf.mul       v5, v2, v4
    s.muli       s4, s11, #2
    s.add        s5, s1, s11                     // the tile origin
    s.movz       s1, #0
    vf.mul       v2, v5, v0
    v.splat      v4, s5
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v5, s12
    v.add        v7, v3, v4
    v.splat      v3, s5
    vf.cvt.f32.bf16 v4, v2
    s.add        s1, s9, s4
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s5, v1, #1
    @p3 v.st.h       [s3, #0], v4
    a.vread      v2, a7, s1
    v.splat      v3, s5
    s.muli       s1, s2, #1
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #1
    s.movz       s5, #2
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #2
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #2
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #2
    s.movz       s5, #3
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #3
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #3
    s.movz       s5, #4
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #4
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #4
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #4
    s.movz       s5, #5
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #5
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #5
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #5
    s.movz       s5, #6
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #6
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #6
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #6
    s.movz       s5, #7
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #7
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #7
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #7
    s.movz       s5, #8
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #8
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #8
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #8
    s.movz       s5, #9
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #9
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #9
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #9
    s.movz       s5, #10
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #10
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #10
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #10
    s.movz       s5, #11
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #11
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #11
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #11
    s.movz       s5, #12
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #12
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #12
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #12
    s.movz       s5, #13
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #13
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #13
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #13
    s.movz       s5, #14
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #14
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s5
    v.splat      v3, s1
    s.muli       s1, s2, #14
    vf.mul       v4, v2, v3
    s.addi       s3, s12, #14
    s.movz       s5, #15
    v.splat      v2, s3
    vf.mul       v3, v4, v0
    s.add        s3, s1, s9
    v.cmp.lt     p1, v2, v6
    s.add        s1, s3, s4
    vf.cvt.f32.bf16 v2, v3
    s.add        s3, s16, s1
    p.and        p3, p1, p2
    v.extract    s1, v1, #15
    @p3 v.st.h       [s3, #0], v2
    a.vread      v1, a7, s5
    v.splat      v2, s1
    s.muli       s1, s2, #15
    vf.mul       v3, v1, v2
    s.addi       s2, s12, #15
    v.splat      v1, s2
    vf.mul       v2, v3, v0
    s.add        s2, s1, s9
    v.cmp.lt     p1, v1, v6
    s.add        s1, s2, s4
    vf.cvt.f32.bf16 v0, v2
    s.add        s2, s16, s1
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v0
    exit
    exit
