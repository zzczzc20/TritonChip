source ~/tc_env/env.sh
cd /home/zhongchun/r40_tlw_predicate_20261017
python3 run_tests.py > runner.log 2>&1
echo $? > runner.exit
