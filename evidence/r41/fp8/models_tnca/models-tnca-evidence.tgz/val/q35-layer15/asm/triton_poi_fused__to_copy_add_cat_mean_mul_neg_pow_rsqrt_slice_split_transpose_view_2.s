    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s1, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v0, v2, v1
    s.movz       s3, #43520
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0
    v.movi       v1, #31
    v.sub        v4, v0, v3
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v4, #32
    v.and        v7, v6, v1
    v.movi       v1, #512
    v.sub        v6, v0, v7
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v8, v6, v7
    v.movi       v6, #0
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v7, #0
    v.sub        v9, v6, v3
    v.cmp.lt     p2, v3, v6
    v.sub        v10, v7, v5
    v.cmp.lt     p3, v5, v7
    @p3 v.sel        v11, v10, v5
    v.movi       v10, #15
    v.movi       v12, #16
    v.and        v13, v11, v10
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    @p2 v.sel        v10, v9, v3
    v.sub        v3, v7, v13
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.add        v9, v8, v4
    v.mul        v11, v5, v1
    v.movi       v14, #9
    @p3 v.sel        v15, v3, v13
    v.add        v3, v9, v11
    v.lshr       v13, v10, v14
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v10, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.sub        v3, v6, v13
    v.cmp.lt     p3, v4, v0
    @p2 v.sel        v14, v3, v13
    v.sub        v3, v0, v4
    v.sub        v0, v2, v4
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v13, [s2, v5]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v10
    v.cmp.lt     p2, v4, v2
    v.sub        v2, v7, v12
    v.cmp.lt     p4, v12, v7
    v.sub        v7, v6, v1
    @p3 v.sel        v10, v3, v4
    .li       s1, #1132462080
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v8, v11
    v.cmp.lt     p3, v1, v6
    v.rcp.approx v6, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s4, v9]              // index is in elements (ISA sec 9.1)
    @p2 v.sel        v9, v0, v4
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v9, v2, v12
    .li       s1, #1077936128
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s3, v10]             // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v10, v11
    @p3 v.sel        v11, v7, v1
    .li       s1, #1065353216
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #64
    vf.add       v11, v10, v1
    vf.cvt.bf16.f32 v10, v12
    v.mul        v12, v14, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s4, v8]               // index is in elements (ISA sec 9.1)
    v.add        v14, v8, v12
    v.movi       v8, #5440
    v.mul        v12, v15, v8
    vf.cvt.bf16.f32 v8, v7
    v.add        v7, v14, v12
    vf.add       v12, v8, v1
    vf.fms       v1, v3, v6, v0
    vf.fms       v0, v6, v1, v6
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v6
    vf.mul       v1, v13, v0                     // a/y: faithful quotient
    vf.fms       v6, v1, v3, v13
    vf.fms       v3, v6, v0, v1
    vf.neg       v0, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v3, v0, v1
    vf.add       v0, v3, v4
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v1, v1
    vf.mul       v4, v1, v9
    vf.fms       v6, v0, v3, v2
    vf.mul       v0, v4, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v2, v0, v1
    vf.mul       v0, v5, v2
    vf.mul       v1, v10, v2
    vf.mul       v2, v0, v11
    vf.mul       v0, v1, v12
    vf.neg       v1, v2
    vf.cvt.f32.bf16 v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s5, v7], v0
    @p1 v.st.scatter.h [s6, v7], v2
__rctx_next:
    exit
