#!/bin/bash
set -euo pipefail
source "$HOME/tc_env/env.sh"
ROOT="$HOME/r41-accept-p1-v2";OUT="$HOME/r41-accept-p1/rtl-fixed-v3"
mkdir -p "$OUT"
PY="$HOME/tc_env/torchenv/bin/python"
make -C "$ROOT" sim/build/tb_core_r39sw5x8.vvp PYTHON="$PY" > "$OUT/build.log" 2>&1
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm"
export TNCA_BACKEND=sim-file TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_HOST_TIMEOUT=1800 TNCA_DEADLINE=20000000
unset TNCA_ACTIVE_CORES
"$PY" -c "from tnca.device import prepare; prepare('core-vrf-sync-v5-x8')" > "$OUT/device-build.log" 2>&1
export TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p1/extensions" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
for dtype in float16 bfloat16; do
 for layout in contiguous strided; do
  flags=();if [ "$layout" = strided ]; then flags+=(--strided);fi
  "$PY" "$ROOT/tools/performance_harness/fragment_case.py" --out "$OUT/$dtype-$layout" --columns 32 --shapes 17x17x33 --dtype "$dtype" --bitwise --require-resident --cancel "${flags[@]}" > "$OUT/$dtype-$layout.log" 2>&1
 done
done
