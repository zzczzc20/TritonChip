#!/usr/bin/env python3
"""DP TLM broad-input gated norm with explicit precision casts and block cap 32."""
import json,sys,time
from pathlib import Path
import torch
from safetensors.torch import save_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
chat.L.use_tnca(str(tree));args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1']);start=time.monotonic();app=chat.ChatApplication(args);norm=app.model.model.language_model.layers[0].linear_attn.norm
G=torch.Generator().manual_seed(941012);x=torch.cat([(torch.randn((128,128),generator=G)*s).to(torch.bfloat16) for s in (0.0001,0.01,1.,10.)]);z=(torch.randn((512,128),generator=G)*2).to(torch.bfloat16)
with torch.no_grad():expected=norm(x,z).contiguous().clone()
stage,dev=chat.L.place(norm,'tnca','eager')
with torch.no_grad():got=stage(x.to(dev),z.to(dev)).detach().cpu().contiguous().clone()
if got.shape!=expected.shape or got.dtype!=expected.dtype:raise ValueError('shape or dtype mismatch')
bad=got.view(torch.int16)!=expected.view(torch.int16);d=(got.float()-expected.float()).abs();r={'schema':'r41-q35-gated-norm-random-tlm/1','scope':'nondefault precision casts, max block 32 and IEEE division, random finite operands, not board','seed':941012,'input_scales':[0.0001,0.01,1.,10.],'elements':got.numel(),'bit_mismatches':int(bad.sum()),'max_abs':float(d.max()),'first_mismatches':torch.nonzero(bad).tolist()[:10],'seconds':time.monotonic()-start}
out=h/'r41_q35_gate_random_precise_b32_ieee_20261101_diag';out.mkdir(exist_ok=False);save_file({'x':x,'z':z,'expected':expected,'got':got},str(out/'states.safetensors'));(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
