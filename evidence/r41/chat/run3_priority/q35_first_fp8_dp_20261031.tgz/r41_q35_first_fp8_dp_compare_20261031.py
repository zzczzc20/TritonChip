#!/usr/bin/env python3
"""CPU exact-vs-mma.dp emulation for real Qwen3.5 first-layer inputs."""
import json,sys,time
from pathlib import Path
import torch
from safetensors.torch import save_file
home=Path.home();tree=home/'r41_q35_multiturn_diag_20261031'
sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm'),str(tree/'tools/performance_harness')]
import chat
import fp8_blockwise_ref as ref
import fp8_block_reference as tref
prompt='My name is Alice. Please remember it and reply with one short sentence.'
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
app=chat.ChatApplication(args);chat.L.install_fp8_route('reference',dot='exact',scale_div='ieee')
inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
layer=app.model.model.language_model.layers[0]
if layer.block_type!='linear_attention':raise ValueError('unexpected layer type')
names=('linear_attn.in_proj_qkv','linear_attn.in_proj_z','mlp.gate_proj','mlp.up_proj');mods=dict(layer.named_modules()); captures={};handles=[]
for name in names:
 def hook(module,args,out,n=name):captures[n]=(args[0].detach()[:,-1:,:].cpu().contiguous().clone(),out.detach()[:,-1:,:].cpu().contiguous().clone())
 handles.append(mods[name].register_forward_hook(hook))
try:
 with torch.no_grad(): session=chat.Session(app.model,app.spec,'cpu',256,0);_,calls,_=session.prefill_prompt(inputs,None)
finally:
 for h in handles:h.remove()

def cmp(x,y):
 a,b=x.float(),y.float();d=(a-b).abs();return dict(elements=x.numel(),bit_mismatches=int((x.view(torch.int16)!=y.view(torch.int16)).sum()),max_abs=float(d.max()),rel_l2=float((a-b).norm()/b.norm().clamp_min(1e-30)))
tref.set_dot_mode('mma.dp');start=time.monotonic();rows=[];tensors={}
for i,name in enumerate(names):
 m=mods[name];x,y=captures[name];w=m.weight.detach().cpu();scale=m.weight_scale_inv.detach().cpu();block=list(m.block_size)
 dp=tref.block_dynamic(x,w,scale,block,torch.bfloat16,ieee=True)
 exact_ref=ref.w8a8_block_matmul(x,w,scale,block,dot='exact',scale_div='ieee')
 exact=ref.exact_w8a8(x,w,scale,block).to(torch.bfloat16)
 rows.append(dict(module=name,position=26,input_shape=list(x.shape),weight_shape=list(w.shape),block=block,hook_vs_reference=cmp(y,exact_ref),dp_vs_reference=cmp(dp,exact_ref),dp_vs_bf16_exact=cmp(dp,exact),reference_vs_bf16_exact=cmp(exact_ref,exact)))
 tensors[f'input_{i}']=x.contiguous();tensors[f'dp_{i}']=dp.contiguous();tensors[f'ref_{i}']=exact_ref.contiguous()
 print(json.dumps(rows[-1]),flush=True)
out=home/'r41_q35_first_fp8_dp_20261031';out.mkdir(exist_ok=False);save_file(tensors,str(out/'outputs.safetensors'))
r=dict(schema='r41-q35-first-fp8-dot-diagnostic/1',scope='CPU mathematical emulation of grouped four FP8 products vs exact reference; not TLM or board',prompt=prompt,input_ids=inputs['input_ids'].tolist(),model=app.spec.name,revision=app.spec.revision,layer=0,rows=rows,seconds=time.monotonic()-start)
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
