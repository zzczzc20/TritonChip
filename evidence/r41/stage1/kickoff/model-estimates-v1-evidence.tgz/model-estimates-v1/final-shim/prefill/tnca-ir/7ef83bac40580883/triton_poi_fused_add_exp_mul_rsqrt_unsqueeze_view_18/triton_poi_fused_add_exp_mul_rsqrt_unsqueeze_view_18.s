    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #7
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v6, v5, v4
    v.movi       v5, #63
    s.rdspecial  s1, arg_base
    v.sub        v7, v3, v4
    v.lshr       v8, v6, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v0, #0
    v.sub        v6, v2, v8
    v.movi       v9, #127
    v.sub        v10, v0, v4
    @p1 v.sel        v11, v6, v8
    v.cmp.lt     p1, v4, v0
    @p1 v.sel        v6, v10, v4
    v.sub        v8, v1, v11
    v.cmp.lt     p3, v11, v1
    v.and        v10, v6, v9
    @p3 v.sel        v6, v8, v11
    v.movi       v8, #128
    v.sub        v9, v0, v10
    v.and        v12, v6, v5
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v5, v7, v4
    v.sub        v6, v1, v12
    @p1 v.sel        v7, v9, v10
    v.movi       v9, #8192
    @p3 v.sel        v10, v6, v12
    v.movi       v6, #64
    v.sub        v12, v0, v8
    v.sub        v13, v2, v8
    v.sub        v14, v1, v6
    v.sub        v15, v3, v9
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v8, v0
    v.cmp.lt     p3, v8, v2
    @p1 v.sel        v0, v12, v8
    v.cmp.lt     p1, v6, v1
    @p3 v.sel        v0, v13, v8
    v.cmp.lt     p3, v9, v3
    @p1 v.sel        v0, v14, v6
    @p3 v.sel        v0, v15, v9
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.movi       v0, #13
    v.movi       v1, #0
    v.movi       v2, #0
    v.lshr       v6, v5, v0
    v.movi       v0, #15
    v.sub        v5, v2, v4
    v.sub        v12, v3, v6
    v.cmp.lt     p1, v4, v2
    @p1 v.sel        v3, v5, v4
    @p2 v.sel        v5, v12, v6
    v.movi       v6, #17
    v.movi       v12, #16
    v.sub        v13, v1, v5
    v.cmp.lt     p2, v5, v1
    v.lshr       v14, v3, v6
    @p2 v.sel        v3, v13, v5
    v.mul        v5, v10, v12
    v.sub        v6, v2, v14
    v.and        v13, v3, v0
    v.movi       v0, #1024
    @p1 v.sel        v3, v6, v14
    v.sub        v6, v1, v13
    .li       s1, #897988541
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v15, v3, v0
    @p2 v.sel        v0, v6, v13
    v.movi       v6, #2048
    .li       s1, #131072
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v16, v0, v5
    v.mul        v5, v0, v8
    v.mul        v8, v10, v6
    v.add        v6, v16, v15
    v.add        v10, v7, v5
    v.mul        v5, v3, v13
    v.ld.gather.w v7, [s2, v6]                   // index is in elements (ISA sec 9.1)
    v.add        v6, v10, v8
    v.movi       v8, #0
    v.movi       v10, #8191
    v.add        v15, v6, v5
    v.sub        v5, v8, v4
    v.cmp.lt     p1, v4, v8
    v.sub        v6, v1, v12
    @p1 v.sel        v16, v5, v4
    v.sub        v4, v2, v13
    v.cmp.lt     p2, v12, v1
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v5, v16, v10
    v.sub        v10, v8, v9
    v.cmp.lt     p3, v13, v2
    v.sub        v2, v8, v5
    @p2 v.sel        v16, v6, v12
    .li       s1, #3204448256
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v12, v7, v14
    v.ld.gather.w v7, [s3, v15]                  // index is in elements (ISA sec 9.1)
    .li       s1, #1035273459
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v15, v2, v5
    v.mul        v2, v3, v9
    v.rsqrt.approx v3, v12                       // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v9, v8
    v.add        v5, v15, v2
    @p3 v.sel        v2, v4, v13
    v.movi       v2, #16384
    @p1 v.sel        v4, v10, v9
    v.mul        v4, v0, v2
    v.add        v0, v5, v4
    v.ld.gather.w v2, [s4, v11]                  // index is in elements (ISA sec 9.1)
    vf.mul       v4, v3, v3
    vf.mul       v5, v3, v6
    vf.fms       v6, v12, v4, v1
    vf.mul       v1, v5, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v4, v1, v3
    vf.mul       v1, v7, v4
    vf.mul       v3, v1, v14
    vf.mul       v1, v3, v2
    v.st.scatter.w [s5, v0], v1
__rctx_next:
    exit
