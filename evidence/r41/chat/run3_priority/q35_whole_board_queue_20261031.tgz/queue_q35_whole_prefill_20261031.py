#!/usr/bin/env python3
"""Queue a whole-prefill Q35 multi-turn diagnostic after existing board jobs.

No image programming. The original 8-token attempt and quality scoring stay
unchanged; this preregistered one-prompt attempt is a separate reduced proof.
"""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys

WORK=Path.home()/'r41run3'
OLD=WORK/'runtime_nohost_v6_resume_20261031'
ROOT=WORK/'runtime_q35_whole_prefill_20261031'
OUT=WORK/'chat_q35_whole_prefill_20261031'
ORIG='r41-q35-segment-multiturn-20261031'
NAME='r41-q35-whole-prefill-multiturn-20261031'
PIDS=(1203557,1205212)
EXPECTED={'spec/r41/run3/board/'+ORIG+'.json':'52ead52160d842baf98b2ff7c3b732fa163f2ca1f54cd08dde5a5fa079dcf4ce',
          'tools/models/chat.py':'7121408bfa7189aad2a80dcb2bccce0a9ddce656fdf6b7eb9f7de46feec601ed',
          'tools/models/chat_quality.py':'cfaf18a5503c706f08d41323ff9b14ce90871ad3793ce3013849b0d924523eff'}


def derive(spec, registration, sha):
    spec=copy.deepcopy(spec);registration=copy.deepcopy(registration)
    if spec['id']!=ORIG or registration['id']!=ORIG or len(registration['experiments'])!=1:
        raise ValueError('unexpected original registration identity')
    row=registration['experiments'][0]
    if row['id']!=ORIG or row['sha256']!=sha or len(spec['steps'])!=1:
        raise ValueError('original manifest binding differs')
    argv=spec['steps'][0]['argv']
    if argv.count('--prefill-chunk')!=1 or argv[argv.index('--prefill-chunk')+1]!='8':
        raise ValueError('expected grouped prefill argument not found')
    if argv.count('--prompts')!=1 or argv[argv.index('--prompts')+1]!='multiturn':
        raise ValueError('unexpected quality prompt')
    argv[argv.index('--prefill-chunk')+1]='0'
    spec['id']=NAME
    spec['registration']['scope']=('Diagnostic: unchanged multi-turn prompt and CPU scoring, whole-prompt prefill '
       '(prefill-chunk 0) instead of registered 8-token chunks. Separate reduced proof; '
       'the prior grouped-prefill failure and the original timeout remain unchanged.')
    spec['chat_quality']['prefill']='Text is prefilled whole in this diagnostic; image turns remain whole.'
    registration['id']=NAME;row['id']=NAME;row['manifest']='spec/r41/run3/board/'+NAME+'.json'
    return spec,registration


def main():
    sys.path.insert(0,str(OLD/'tools/r41/run2_board'))
    import q35_timeout_recovery as recovery
    if ROOT.exists() or OUT.exists():raise FileExistsError('whole-prefill source or output already exists')
    for name,want in EXPECTED.items():
        if recovery.digest(OLD/name)!=want:raise ValueError('original source changed: '+name)
    OUT.mkdir();recovery.OUT=OUT
    try:
        subprocess.run(['cp','-a','--reflink=auto',str(OLD),str(ROOT)],check=True)
        for name,want in EXPECTED.items():
            if recovery.digest(ROOT/name)!=want:raise ValueError('copied source mismatch: '+name)
        origreg=WORK/'chat_nohost_v6_resume_20261031'/(ORIG+'-registration.json')
        reg=json.loads(origreg.read_text());source=ROOT/('spec/r41/run3/board/'+ORIG+'.json')
        spec,reg=derive(json.loads(source.read_text()),reg,EXPECTED['spec/r41/run3/board/'+ORIG+'.json'])
        manifest=ROOT/reg['experiments'][0]['manifest']
        with manifest.open('x') as f:json.dump(spec,f,indent=2);f.write('\n')
        reg['experiments'][0]['sha256']=recovery.digest(manifest)
        regpath=OUT/'registration.json'
        with regpath.open('x') as f:json.dump(reg,f,indent=2);f.write('\n')
        (OUT/'source-hashes.json').write_text(json.dumps(EXPECTED,indent=2)+'\n')
        recovery.record('waiting',predecessor_pids=PIDS,manifest_sha256=reg['experiments'][0]['sha256'],
                        registration_sha256=recovery.digest(regpath),scope='whole-prefill reduced quality diagnostic')
        for pid in PIDS:recovery.wait_pid(pid)
        for name,want in EXPECTED.items():
            if recovery.digest(ROOT/name)!=want:raise ValueError('source changed while waiting: '+name)
        if recovery.digest(manifest)!=reg['experiments'][0]['sha256']:
            raise ValueError('registered whole-prefill manifest changed while waiting')
        recovery.stage(ROOT,OUT/'multiturn',regpath,OUT/'stage.log')
        path=OUT/'multiturn'/NAME/'q35-quality/quality.json';data=json.loads(path.read_text())
        if data.get('status')!='pass' or data.get('reduced_proof') is not True or len(data.get('prompts',[]))!=1:
            raise ValueError('whole-prefill quality did not pass')
        recovery.check_prompt(data['prompts'][0])
        recovery.record('finished',quality=str(path),sha256=recovery.digest(path),
                        scope='separate whole-prefill reduced proof; grouped failure unchanged')
    except BaseException as exc:
        recovery.record('stopped',error=f'{type(exc).__name__}: {exc}');raise

if __name__=='__main__':main()
