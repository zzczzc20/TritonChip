#!/usr/bin/env bash
set -eu
mode=$1
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HOME="$HOME/flux-hf" HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR="$HOME/r41-p3/snapview"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=0 TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=3600 TNCA_X8_EQUAL_OUTPUT="$mode"
export TNCA_TLM_OUT="$HOME/r41_x8_equal_output_vl_l1_${mode}_tlm_20261101" TRITON_CACHE_DIR="$HOME/r41_x8_equal_output_vl_l1_${mode}_triton_20261101" TORCHINDUCTOR_CACHE_DIR="$HOME/r41_x8_equal_output_vl_l1_${mode}_inductor_20261101"
unset TNCA_CODE_CACHE_POLICY TNCA_EQUAL_ROWS TNCA_X8_SPILL_LANES TNCA_X8_PIPELINE
cd "$HOME/r41_current_x8_equal_output_20261101"
exec "$HOME/flux-venv/bin/python" -u tools/models/decode_profile.py --model vl --device tnca --tnca-tree "$PWD" --layers 1 --prompt "Say hi." --new-tokens 2 --bucket 64 --check-tokens 0 --out "$HOME/r41_x8_equal_output_vl_l1_${mode}_20261101"
