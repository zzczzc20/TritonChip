    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #1536
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #256
    s.movz       s8, #4
    .li       s9, #68719476752
    .li       s10, #2207613190144
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #1536
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #512
    s.movz       s16, #4
    .li       s17, #68719476752
    s.addi       s18, s12, #4096                 // the pointer's constant offset (4096 bytes)
    s.ld.d       s19, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    .li       s20, #2207613190144
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s22, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s23, #0
    s.st.d       [s7, #0], s18
    s.movz       s18, #8
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.cmp.lt     s24, s18, s6
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.sub        s6, s1, s24
    s.movz       s1, #3
    s.st.d       [s7, #48], s5
    s.movz       s5, #1
    s.st.d       [s7, #56], s8
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #0
    s.sub        s24, s23, s8
    s.movz       s8, #0
    s.st.d       [s7, #88], s9
    s.xor        s9, s4, s24
    s.sub        s23, s9, s24
    s.st.d       [s7, #104], s10
    s.lshri      s9, s23, #3
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s24, s6
    s.movz       s10, #0
    s.ld.d       s24, [s11, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s11, s24, s15                   // this context's own scratch
    s.xor        s15, s9, s7
    s.cmp.lt     s24, s4, s8
    s.sub        s8, s15, s7
    s.movz       s7, #0
    s.sub        s15, s1, s8
    s.muli       s1, s9, #8
    s.min.s      s9, s15, s5
    s.movz       s5, #0
    s.addi       s15, s11, #256                  // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.cmp.lt     s11, s9, s2
    s.sub        s2, s7, s24
    s.movz       s7, #1
    s.st.d       [s15, #0], s19
    s.sub        s19, s10, s11
    s.xor        s10, s4, s2
    s.xor        s11, s18, s6
    s.sub        s24, s23, s1
    s.movz       s1, #0
    s.sub        s23, s11, s6
    s.st.d       [s15, #8], s14
    s.xor        s6, s9, s19
    s.sub        s11, s10, s2
    s.st.d       [s15, #16], s3
    s.sub        s3, s6, s19
    s.addi       s6, s5, #0
    s.st.d       [s15, #48], s13
    s.cmp.eq     s5, s3, s7
    s.addi       s7, s1, #0
    s.st.d       [s15, #56], s16
    s.st.d       [s15, #88], s17
    s.st.d       [s15, #104], s20
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s6, s11
    br.nz        s5, sdiv_done_1
    s.movz       s1, #0
    s.movz       s5, #31
    s.mov        s6, s1
    s.addi       s1, s5, #0
sdiv_2:
    s.lshr       s5, s11, s1
    s.shli       s10, s7, #1
    s.andi       s13, s5, #1
    s.movz       s5, #0
    s.or         s14, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s14, s3
    s.shl        s15, s10, s1
    s.sub        s10, s5, s13
    s.subi       s5, s1, #1
    s.and        s13, s3, s10
    s.and        s16, s15, s10
    s.sub        s10, s14, s13
    s.or         s13, s6, s16
    s.mov        s7, s10
    s.mov        s6, s13
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s10, s1, s5
    br.nz        s10, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s1
    s.movz       s1, #0
    s.sub        s6, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s6
    s.movz       s4, #0
    s.sub        s10, s5, s6
    s.cmp.lt     s5, s9, s1
    s.lshri      s1, s10, #3
    s.movz       s11, #0
    s.muli       s13, s1, #8
    s.sub        s1, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s18, s11
    s.xor        s11, s9, s1
    s.sub        s9, s10, s13
    s.movz       s10, #0
    s.xor        s13, s9, s6
    s.xor        s9, s7, s2
    s.sub        s7, s13, s6
    s.sub        s6, s10, s5
    s.cmp.lt     s5, s7, s3
    s.sub        s3, s11, s1
    s.sub        s10, s4, s5
    s.movz       s4, #0
    s.xor        s5, s7, s10
    s.movz       s7, #1
    s.sub        s11, s9, s2
    s.xor        s2, s18, s6
    s.sub        s9, s5, s10
    s.movz       s5, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s7
    s.add        s7, s8, s11
    s.sub        s8, s2, s6
    s.addi       s2, s5, #0
    s.mov        s13, s9
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s5, #31
    s.mov        s13, s4
    s.addi       s4, s5, #0
sdiv_4:
    s.lshr       s5, s9, s4
    s.shli       s6, s2, #1
    s.andi       s8, s5, #1
    s.movz       s5, #0
    s.or         s11, s6, s8
    s.movz       s6, #1
    s.cmp.geu    s8, s11, s3
    s.shl        s14, s6, s4
    s.sub        s6, s5, s8
    s.subi       s5, s4, #1
    s.and        s8, s3, s6
    s.and        s15, s14, s6
    s.sub        s6, s11, s8
    s.or         s8, s13, s15
    s.mov        s2, s6
    s.mov        s13, s8
    s.mov        s4, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s4, s5
    br.nz        s6, sdiv_4
sdiv_done_3:
    s.movz       s2, #16
    .li       s3, #1431655766
    s.mul        s4, s7, s2
    s.rdspecial  s5, pid.z
    s.rdspecial  s6, npid.y
    s.xor        s8, s10, s1
    s.mul        s1, s5, s6
    s.mul        s5, s4, s3
    s.rdspecial  s3, pid.y
    s.xor        s6, s13, s8
    s.movz       s9, #31
    s.add        s10, s3, s1
    s.lshri      s1, s5, #32
    s.sub        s3, s6, s8
    s.sub        s5, s4, s1
    s.min.s      s6, s10, s9
    s.lshri      s8, s5, #1
    s.movz       s5, #4096
    s.add        s9, s1, s8
    s.mul        s1, s3, s2
    s.lshri      s2, s9, #5
    s.movz       s8, #2048
    s.muli       s9, s2, #48
    s.mul        s2, s6, s5
    s.mul        s5, s6, s8
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s6, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.sub        s11, s4, s9
    s.andi       s9, s1, #127
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s13, s6
    mb.wait      s6
    s.movz       s2, #0
    s.movz       s13, #0
    v.splat      v0, s7
    w.def        w1, #32, #16                    // v32..v47
    s.add        s7, s9, s5
    v.splat      v1, s13
    mb.arm       s5, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    v.splat      v2, s3
    v.splat      v3, s13
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.splat      v6, s1
    v.splat      v7, s11
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s9
    v.iota       v10                             // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s2                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s14, s5
    mb.wait      s5
    v.movi       v0, #0
    v.cmp.ge     p1, v2, v3
    v.extract    s2, v48, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.splat      v1, s2
    v.add        v2, v5, v4
    v.extract    s2, v48, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s2
    v.add        v3, v6, v4
    v.extract    s2, v48, #2
    v.extract    s7, v48, #3
    vf.fma       v3, v1, v33, v2
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v48, #4
    v.add        v4, v7, v8
    vf.fma       v4, v1, v34, v3
    v.splat      v1, s2
    v.extract    s2, v48, #5
    v.add        v3, v9, v10
    v.splat      v3, s2
    vf.fma       v5, v2, v35, v4
    v.extract    s2, v48, #6
    v.extract    s7, v48, #7
    v.splat      v2, s2
    v.splat      v4, s7
    vf.fma       v6, v1, v36, v5
    s.addi       s2, s12, #4096                  // &arg_A[1024] (a constant offset, x4)
    v.extract    s2, v48, #8
    v.extract    s7, v48, #9
    v.splat      v1, s2
    vf.fma       v5, v3, v37, v6
    v.splat      v3, s7
    v.extract    s2, v48, #10
    v.extract    s7, v48, #11
    v.splat      v6, s2
    vf.fma       v7, v2, v38, v5
    v.splat      v2, s7
    v.extract    s2, v48, #12
    v.extract    s7, v48, #13
    v.splat      v5, s2
    vf.fma       v8, v4, v39, v7
    v.splat      v4, s7
    v.extract    s2, v48, #14
    v.extract    s7, v48, #15
    v.splat      v7, s2
    vf.fma       v9, v1, v40, v8
    v.splat      v1, s7
    s.movz       s2, #1
    vf.fma       v8, v3, v41, v9
    vf.fma       v3, v6, v42, v8
    vf.fma       v6, v2, v43, v3
    vf.fma       v2, v5, v44, v6
    vf.fma       v3, v4, v45, v2
    vf.fma       v2, v7, v46, v3
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s3, v3
    v.extract    s3, v49, #0
    v.extract    s7, v49, #1
    v.splat      v1, s3
    v.splat      v2, s7
    v.extract    s3, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v49, #3
    v.extract    s7, v49, #4
    v.splat      v4, s3
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s3, v49, #5
    v.extract    s7, v49, #6
    v.splat      v3, s3
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s3, v49, #7
    v.extract    s7, v49, #8
    v.splat      v5, s3
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s3, v49, #9
    v.extract    s7, v49, #10
    v.splat      v6, s3
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s3, v49, #11
    v.extract    s7, v49, #12
    v.splat      v7, s3
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s3, v49, #13
    v.extract    s7, v49, #14
    v.splat      v8, s3
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s3, v49, #15
    s.movz       s7, #2
    v.splat      v9, s3
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s2, v1
    v.extract    s2, v50, #0
    v.extract    s3, v50, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v50, #3
    v.extract    s3, v50, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v50, #5
    v.extract    s3, v50, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v50, #7
    v.extract    s3, v50, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v50, #9
    v.extract    s3, v50, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v50, #11
    v.extract    s3, v50, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v50, #13
    v.extract    s3, v50, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v50, #15
    s.movz       s3, #3
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v51, #0
    v.extract    s7, v51, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v51, #3
    v.extract    s7, v51, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v51, #5
    v.extract    s7, v51, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v51, #7
    v.extract    s7, v51, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v51, #9
    v.extract    s7, v51, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v51, #11
    v.extract    s7, v51, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v51, #13
    v.extract    s7, v51, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v51, #15
    s.movz       s7, #4
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v52, #0
    v.extract    s3, v52, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v52, #3
    v.extract    s3, v52, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v52, #5
    v.extract    s3, v52, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v52, #7
    v.extract    s3, v52, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v52, #9
    v.extract    s3, v52, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v52, #11
    v.extract    s3, v52, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v52, #13
    v.extract    s3, v52, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v52, #15
    s.movz       s3, #5
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v53, #0
    v.extract    s7, v53, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v53, #3
    v.extract    s7, v53, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v53, #5
    v.extract    s7, v53, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v53, #7
    v.extract    s7, v53, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v53, #9
    v.extract    s7, v53, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v53, #11
    v.extract    s7, v53, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v53, #13
    v.extract    s7, v53, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v53, #15
    s.movz       s7, #6
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v54, #0
    v.extract    s3, v54, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v54, #3
    v.extract    s3, v54, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v54, #5
    v.extract    s3, v54, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v54, #7
    v.extract    s3, v54, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v54, #9
    v.extract    s3, v54, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v54, #11
    v.extract    s3, v54, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v54, #13
    v.extract    s3, v54, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v54, #15
    s.movz       s3, #7
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v55, #0
    v.extract    s7, v55, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v55, #3
    v.extract    s7, v55, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v55, #5
    v.extract    s7, v55, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v55, #7
    v.extract    s7, v55, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v55, #9
    v.extract    s7, v55, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v55, #11
    v.extract    s7, v55, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v55, #13
    v.extract    s7, v55, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v55, #15
    s.movz       s7, #8
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v56, #0
    v.extract    s3, v56, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v56, #3
    v.extract    s3, v56, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v56, #5
    v.extract    s3, v56, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v56, #7
    v.extract    s3, v56, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v56, #9
    v.extract    s3, v56, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v56, #11
    v.extract    s3, v56, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v56, #13
    v.extract    s3, v56, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v56, #15
    s.movz       s3, #9
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v57, #0
    v.extract    s7, v57, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v57, #3
    v.extract    s7, v57, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v57, #5
    v.extract    s7, v57, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v57, #7
    v.extract    s7, v57, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v57, #9
    v.extract    s7, v57, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v57, #11
    v.extract    s7, v57, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v57, #13
    v.extract    s7, v57, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v57, #15
    s.movz       s7, #10
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v58, #0
    v.extract    s3, v58, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v58, #3
    v.extract    s3, v58, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v58, #5
    v.extract    s3, v58, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v58, #7
    v.extract    s3, v58, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v58, #9
    v.extract    s3, v58, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v58, #11
    v.extract    s3, v58, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v58, #13
    v.extract    s3, v58, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v58, #15
    s.movz       s3, #11
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v59, #0
    v.extract    s7, v59, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v59, #3
    v.extract    s7, v59, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v59, #5
    v.extract    s7, v59, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v59, #7
    v.extract    s7, v59, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v59, #9
    v.extract    s7, v59, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v59, #11
    v.extract    s7, v59, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v59, #13
    v.extract    s7, v59, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v59, #15
    s.movz       s7, #12
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v60, #0
    v.extract    s3, v60, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v60, #3
    v.extract    s3, v60, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v60, #5
    v.extract    s3, v60, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v60, #7
    v.extract    s3, v60, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v60, #9
    v.extract    s3, v60, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v60, #11
    v.extract    s3, v60, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v60, #13
    v.extract    s3, v60, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v60, #15
    s.movz       s3, #13
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v61, #0
    v.extract    s7, v61, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v61, #3
    v.extract    s7, v61, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v61, #5
    v.extract    s7, v61, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s2, v61, #7
    v.extract    s7, v61, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s2, v61, #9
    v.extract    s7, v61, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s7
    v.extract    s2, v61, #11
    v.extract    s7, v61, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s7
    v.extract    s2, v61, #13
    v.extract    s7, v61, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s7
    v.extract    s2, v61, #15
    s.movz       s7, #14
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s2, v62, #0
    v.extract    s3, v62, #1
    v.splat      v1, s2
    v.splat      v2, s3
    v.extract    s2, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.extract    s2, v62, #3
    v.extract    s3, v62, #4
    v.splat      v4, s2
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s3
    v.extract    s2, v62, #5
    v.extract    s3, v62, #6
    v.splat      v3, s2
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s3
    v.extract    s2, v62, #7
    v.extract    s3, v62, #8
    v.splat      v5, s2
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s3
    v.extract    s2, v62, #9
    v.extract    s3, v62, #10
    v.splat      v6, s2
    vf.fma       v8, v2, v36, v7
    v.splat      v2, s3
    v.extract    s2, v62, #11
    v.extract    s3, v62, #12
    v.splat      v7, s2
    vf.fma       v9, v3, v37, v8
    v.splat      v3, s3
    v.extract    s2, v62, #13
    v.extract    s3, v62, #14
    v.splat      v8, s2
    vf.fma       v10, v1, v38, v9
    v.splat      v1, s3
    v.extract    s2, v62, #15
    s.movz       s3, #15
    v.splat      v9, s2
    vf.fma       v11, v5, v39, v10
    vf.fma       v5, v4, v40, v11
    vf.fma       v4, v6, v41, v5
    vf.fma       v5, v2, v42, v4
    vf.fma       v2, v7, v43, v5
    vf.fma       v4, v3, v44, v2
    vf.fma       v2, v8, v45, v4
    vf.fma       v3, v1, v46, v2
    vf.fma       v1, v9, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s2, v63, #0
    v.extract    s7, v63, #1
    v.splat      v1, s2
    v.splat      v2, s7
    v.extract    s2, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s2
    v.extract    s2, v63, #3
    v.extract    s7, v63, #4
    v.splat      v1, s2
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s7
    v.extract    s2, v63, #5
    v.extract    s7, v63, #6
    v.splat      v3, s2
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s7
    v.extract    s2, v63, #7
    v.extract    s7, v63, #8
    v.splat      v4, s2
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s7
    v.extract    s2, v63, #9
    v.extract    s7, v63, #10
    v.splat      v5, s2
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s7
    v.extract    s2, v63, #11
    v.extract    s7, v63, #12
    v.splat      v6, s2
    vf.fma       v8, v3, v37, v7
    v.splat      v3, s7
    v.extract    s2, v63, #13
    v.extract    s7, v63, #14
    v.splat      v7, s2
    vf.fma       v9, v0, v38, v8
    v.splat      v0, s7
    v.extract    s2, v63, #15
    s.movz       s7, #6144
    v.splat      v8, s2
    vf.fma       v10, v4, v39, v9
    s.movz       s2, #0
    s.mul        s9, s10, s7
    s.rdspecial  s11, arg_base
    s.rdspecial  s12, role_id
    vf.fma       v4, v1, v40, v10
    s.muli       s14, s4, #128                   // a runtime tile origin, x128
    s.add        s15, s2, s1                     // the tile origin
    s.movz       s2, #1536
    s.movz       s16, #32
    vf.fma       v1, v5, v41, v4
    s.add        s17, s15, s14                   // the tile origin
    v.iota       v4                              // arange(0, VLEN)
    s.add        s14, s17, s9                    // the tile origin
    s.mul        s15, s12, s2
    vf.fma       v5, v2, v42, v1
    v.splat      v1, s14
    v.splat      v2, s7
    v.movi       v9, #0
    v.add        v10, v4, v1
    vf.fma       v1, v6, v43, v5
    v.splat      v5, s10
    v.splat      v6, s16
    v.sub        v11, v9, v10
    v.sub        v12, v9, v2
    vf.fma       v13, v3, v44, v1
    s.movz       s2, #8192
    v.cmp.lt     p1, v10, v9
    v.cmp.lt     p2, v2, v9
    v.movi       v1, #0
    vf.fma       v3, v7, v45, v13
    v.cmp.lt     p3, v5, v6
    s.mul        s7, s10, s2
    v.splat      v5, s13
    v.movi       v6, #1
    vf.fma       v7, v0, v46, v3
    @p1 v.sel        v0, v11, v10
    @p2 v.sel        v3, v12, v2
    v.movi       v10, #0
    v.movi       v11, #0
    vf.fma       v12, v8, v47, v7
    s.movz       s2, #31
    a.vwrite     a0, s3, v12
    s.ld.d       s3, [s11, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s10, s3, s15                    // this context's own scratch
    s.addi       s3, s10, #512
idiv_6:
    v.splat      v7, s2
    v.shl        v8, v11, v6
    v.cmp.lt     p2, v11, v9
    v.lshr       v12, v0, v7
    v.shl        v13, v6, v7
    s.subi       s11, s2, #1
    v.and        v7, v12, v6
    s.movz       s12, #0
    v.or         v12, v8, v7
    v.cmp.geu    p4, v12, v3
    p.or         p5, p2, p4
    v.sub        v7, v12, v3
    @p5 v.sel        v8, v13, v9
    @p5 v.sel        v13, v7, v12
    v.or         v7, v10, v8
    v.mov        v11, v13
    v.mov        v10, v7
    s.mov        s2, s11
    s.cmp.ge     s11, s2, s12
    br.nz        s11, idiv_6
    v.sub        v0, v9, v11
    s.movz       s2, #0
    v.splat      v3, s8
    @p1 v.sel        v6, v0, v11
    s.add        s8, s2, s7                      // the tile origin
    s.addi       s2, s14, #128
    v.add        v0, v6, v3
    v.splat      v6, s8
    v.splat      v7, s2
    v.movi       v8, #0
    v.add        v9, v0, v6
    v.add        v0, v4, v7
    v.sub        v7, v8, v2
    v.add        v10, v5, v9
    v.sub        v9, v8, v0
    v.cmp.lt     p1, v0, v8
    v.cmp.lt     p2, v2, v8
    v.st.w       [s3, #0], v10
    s.addi       s2, s3, #64
    v.movi       v10, #1
    @p1 v.sel        v11, v9, v0
    @p2 v.sel        v0, v7, v2
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s7, #31
idiv_7:
    v.splat      v12, s7
    v.shl        v13, v9, v10
    v.cmp.lt     p2, v9, v8
    v.lshr       v14, v11, v12
    v.shl        v15, v10, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v10
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v0
    p.or         p5, p2, p4
    v.sub        v12, v14, v0
    @p5 v.sel        v13, v15, v8
    @p5 v.sel        v15, v12, v14
    v.or         v12, v7, v13
    v.mov        v9, v15
    v.mov        v7, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_7
    v.sub        v0, v8, v9
    s.addi       s7, s14, #256
    v.movi       v7, #0
    @p1 v.sel        v8, v0, v9
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #128
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_8:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_8
    v.sub        v0, v7, v10
    s.addi       s2, s14, #384
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #192
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_9:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_9
    v.sub        v0, v7, v10
    s.addi       s7, s14, #512
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #256
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_10:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_10
    v.sub        v0, v7, v10
    s.addi       s2, s14, #640
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #320
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_11
    v.sub        v0, v7, v10
    s.addi       s7, s14, #768
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #384
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_12:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_12
    v.sub        v0, v7, v10
    s.addi       s2, s14, #896
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #448
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_13
    v.sub        v0, v7, v10
    s.addi       s7, s14, #1024
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #512
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_14:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_14
    v.sub        v0, v7, v10
    s.addi       s2, s14, #1152
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #576
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_15
    v.sub        v0, v7, v10
    s.addi       s7, s14, #1280
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #640
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_16:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_16
    v.sub        v0, v7, v10
    s.addi       s2, s14, #1408
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #704
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_17
    v.sub        v0, v7, v10
    s.addi       s7, s14, #1536
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #768
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_18:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_18
    v.sub        v0, v7, v10
    s.addi       s2, s14, #1664
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #832
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_19:
    v.splat      v12, s7
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s7, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s11
    br.nz        s8, idiv_19
    v.sub        v0, v7, v10
    s.addi       s7, s14, #1792
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s7
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s7, s3, #896
    v.movi       v0, #1
    v.st.w       [s2, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s2, #31
idiv_20:
    v.splat      v12, s2
    v.shl        v13, v10, v0
    v.cmp.lt     p1, v10, v7
    v.lshr       v14, v11, v12
    v.shl        v15, v0, v12
    s.subi       s8, s2, #1
    v.and        v12, v14, v0
    s.movz       s11, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v8
    p.or         p5, p1, p4
    v.sub        v12, v14, v8
    @p5 v.sel        v13, v15, v7
    @p5 v.sel        v15, v12, v14
    v.or         v12, v9, v13
    v.mov        v10, v15
    v.mov        v9, v12
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s11
    br.nz        s8, idiv_20
    v.sub        v0, v7, v10
    s.addi       s2, s14, #1920
    v.movi       v7, #0
    @p2 v.sel        v8, v0, v10
    v.splat      v0, s2
    v.sub        v9, v7, v2
    v.add        v10, v8, v3
    v.add        v8, v4, v0
    v.cmp.lt     p1, v2, v7
    v.add        v0, v10, v6
    v.sub        v10, v7, v8
    v.cmp.lt     p2, v8, v7
    v.add        v11, v5, v0
    s.addi       s2, s3, #960
    v.movi       v0, #1
    v.st.w       [s7, #0], v11
    @p2 v.sel        v11, v10, v8
    @p1 v.sel        v8, v9, v2
    v.movi       v2, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_21:
    v.splat      v10, s3
    v.shl        v12, v9, v0
    v.cmp.lt     p1, v9, v7
    v.lshr       v13, v11, v10
    v.shl        v14, v0, v10
    s.subi       s7, s3, #1
    v.and        v10, v13, v0
    s.movz       s8, #0
    v.or         v13, v12, v10
    v.cmp.geu    p4, v13, v8
    p.or         p5, p1, p4
    v.sub        v10, v13, v8
    @p5 v.sel        v12, v14, v7
    @p5 v.sel        v14, v10, v13
    v.or         v10, v2, v12
    v.mov        v9, v14
    v.mov        v2, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s8
    br.nz        s7, idiv_21
    v.sub        v0, v7, v9
    s.addi       s3, s10, #512
    s.movz       s7, #0
    @p2 v.sel        v2, v0, v9
    s.add        s8, s7, s1                      // the tile origin
    s.movz       s7, #0
    v.add        v0, v2, v3
    v.splat      v2, s8
    s.add        s8, s7, s4                      // the tile origin
    v.add        v3, v0, v6
    s.movz       s7, #48
    s.movz       s11, #128
    v.add        v0, v5, v3
    v.splat      v3, s8
    v.splat      v5, s7
    v.st.w       [s2, #0], v0
    fence.acq_rel.device
    v.add        v0, v4, v2
    v.splat      v2, s11
    v.cmp.lt     p1, v3, v5
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    v.cmp.lt     p2, v0, v2
    p.and        p4, p1, p2
    s.addi       s7, s10, #576
    p.and        p1, p4, p3
    s.addi       s11, s8, #1
    s.movz       s12, #1
    v.splat      v0, s11
    s.addi       s11, s10, #640
    s.addi       s13, s8, #2
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    v.splat      v0, s13
    v.ld.w       v2, [s3, #0]
    p.and        p4, p5, p3
    s.movz       s3, #2
    s.addi       s13, s10, #704
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s2, v3
    v.ld.w       v0, [s7, #0]
    s.addi       s2, s8, #3
    s.movz       s7, #3
    v.splat      v2, s2
    s.addi       s2, s10, #768
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s12, v3
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #4
    s.movz       s12, #4
    v.splat      v2, s11
    s.addi       s11, s10, #832
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s3, v3
    v.ld.w       v0, [s13, #0]
    s.addi       s3, s8, #5
    s.movz       s13, #5
    v.splat      v2, s3
    s.addi       s3, s10, #896
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s7, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #6
    s.movz       s7, #6
    v.splat      v2, s2
    s.addi       s2, s10, #960
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s12, v3
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #7
    s.movz       s12, #7
    v.splat      v2, s11
    s.addi       s11, s10, #1024
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s13, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s8, #8
    s.movz       s13, #8
    v.splat      v2, s3
    s.addi       s3, s10, #1088
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s7, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #9
    s.movz       s7, #9
    v.splat      v2, s2
    s.addi       s2, s10, #1152
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s12, v3
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #10
    s.movz       s12, #10
    v.splat      v2, s11
    s.addi       s11, s10, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s13, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s8, #11
    s.movz       s13, #11
    v.splat      v2, s3
    s.addi       s3, s10, #1280
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s7, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #12
    s.movz       s7, #12
    v.splat      v2, s2
    s.addi       s2, s10, #1344
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s12, v3
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #13
    s.movz       s12, #13
    v.splat      v2, s11
    s.addi       s11, s10, #1408
    s.addi       s14, s10, #1472
    s.muli       s10, s1, #4                     // a runtime tile origin, x4
    s.muli       s1, s4, #512                    // a runtime tile origin, x512
    s.muli       s4, s9, #4                      // a runtime tile origin, x4
    s.add        s9, s22, s10                    // the tile origin
    s.addi       s10, s8, #14
    s.add        s15, s9, s1                     // the tile origin
    v.splat      v3, s10
    s.movz       s1, #14
    s.addi       s9, s8, #15
    s.add        s10, s15, s4                    // the tile origin
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    v.splat      v0, s9
    p.and        p4, p5, p3
    s.movz       s4, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v2, [s3, #0]
    s.movz       s3, #0
    v.splat      v4, s8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s21, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s7, v6
    v.ld.w       v2, [s2, #0]
    s.movz       s2, #1
    s.movz       s7, #1
    s.addi       s13, s8, #1
    v.splat      v3, s13
    s.addi       s13, s10, #512                  // row 1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s21, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s12, v6
    v.ld.w       v0, [s11, #0]
    s.movz       s11, #2
    s.movz       s12, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s1, v2
    v.ld.w       v0, [s14, #0]
    s.addi       s1, s8, #2
    s.addi       s14, s10, #1024                 // row 2
    v.splat      v2, s1
    s.movz       s1, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s21, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    s.movz       s15, #3
    p.and        p4, p5, p3
    a.vwrite     a1, s4, v4
    a.vread      v0, a1, s9
    a.vread      v3, a0, s3
    s.addi       s3, s8, #3
    s.addi       s4, s10, #1536                  // row 3
    vf.add       v4, v3, v1
    v.splat      v3, s3
    s.movz       s3, #4
    s.movz       s9, #4
    vf.sub       v6, v0, v4
    @p1 v.st.w       [s10, #0], v6
    a.vread      v0, a1, s2
    a.vread      v4, a0, s7
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v4, v1
    p.and        p1, p5, p3
    s.addi       s2, s8, #4
    s.addi       s7, s10, #2048                  // row 4
    v.splat      v4, s2
    vf.sub       v6, v0, v2
    s.movz       s2, #5
    @p4 v.st.w       [s13, #0], v6
    a.vread      v0, a1, s11
    a.vread      v2, a0, s12
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v2, v1
    p.and        p4, p5, p3
    s.movz       s11, #5
    s.addi       s12, s8, #5
    s.addi       s13, s10, #2560                 // row 5
    vf.sub       v2, v0, v3
    v.splat      v0, s12
    s.movz       s12, #6
    @p1 v.st.w       [s14, #0], v2
    a.vread      v2, a1, s1
    a.vread      v3, a0, s15
    v.cmp.lt     p1, v4, v5
    p.and        p5, p1, p2
    vf.add       v4, v3, v1
    p.and        p1, p5, p3
    s.movz       s1, #6
    s.addi       s14, s8, #6
    s.addi       s15, s10, #3072                 // row 6
    vf.sub       v3, v2, v4
    v.splat      v2, s14
    s.movz       s14, #7
    @p4 v.st.w       [s4, #0], v3
    a.vread      v3, a1, s3
    a.vread      v4, a0, s9
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    vf.add       v0, v4, v1
    p.and        p4, p5, p3
    s.movz       s3, #7
    s.addi       s4, s8, #7
    s.addi       s9, s10, #3584                  // row 7
    vf.sub       v4, v3, v0
    v.splat      v0, s4
    s.movz       s4, #8
    @p1 v.st.w       [s7, #0], v4
    a.vread      v3, a1, s2
    a.vread      v4, a0, s11
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v4, v1
    p.and        p1, p5, p3
    s.movz       s2, #8
    s.addi       s7, s8, #8
    s.addi       s11, s10, #4096                 // row 8
    vf.sub       v4, v3, v2
    v.splat      v2, s7
    s.movz       s7, #9
    @p4 v.st.w       [s13, #0], v4
    a.vread      v3, a1, s12
    a.vread      v4, a0, s1
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    vf.add       v0, v4, v1
    p.and        p4, p5, p3
    s.movz       s1, #9
    s.addi       s12, s8, #9
    s.addi       s13, s10, #4608                 // row 9
    vf.sub       v4, v3, v0
    v.splat      v0, s12
    s.movz       s12, #10
    @p1 v.st.w       [s15, #0], v4
    a.vread      v3, a1, s14
    a.vread      v4, a0, s3
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v4, v1
    p.and        p1, p5, p3
    s.movz       s3, #10
    s.addi       s14, s8, #10
    s.addi       s15, s10, #5120                 // row 10
    vf.sub       v4, v3, v2
    v.splat      v2, s14
    s.movz       s14, #11
    @p4 v.st.w       [s9, #0], v4
    a.vread      v3, a1, s4
    a.vread      v4, a0, s2
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    vf.add       v0, v4, v1
    p.and        p4, p5, p3
    s.movz       s2, #11
    s.addi       s4, s8, #11
    s.addi       s9, s10, #5632                  // row 11
    vf.sub       v4, v3, v0
    v.splat      v0, s4
    s.movz       s4, #12
    @p1 v.st.w       [s11, #0], v4
    a.vread      v3, a1, s7
    a.vread      v4, a0, s1
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v4, v1
    p.and        p1, p5, p3
    s.movz       s1, #12
    s.addi       s7, s8, #12
    s.addi       s11, s10, #6144                 // row 12
    vf.sub       v4, v3, v2
    v.splat      v2, s7
    s.movz       s7, #13
    @p4 v.st.w       [s13, #0], v4
    a.vread      v3, a1, s12
    a.vread      v4, a0, s3
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    vf.add       v0, v4, v1
    p.and        p4, p5, p3
    s.movz       s3, #13
    s.addi       s12, s8, #13
    s.addi       s13, s10, #6656                 // row 13
    vf.sub       v4, v3, v0
    v.splat      v0, s12
    s.movz       s12, #14
    @p1 v.st.w       [s15, #0], v4
    a.vread      v3, a1, s14
    a.vread      v4, a0, s2
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v4, v1
    p.and        p1, p5, p3
    s.movz       s2, #14
    s.addi       s14, s8, #14
    s.addi       s15, s10, #7168                 // row 14
    vf.sub       v4, v3, v2
    v.splat      v2, s14
    s.movz       s14, #15
    s.addi       s16, s8, #15
    s.addi       s8, s10, #7680                  // row 15
    @p4 v.st.w       [s9, #0], v4
    a.vread      v3, a1, s4
    a.vread      v4, a0, s1
    v.cmp.lt     p4, v0, v5
    p.and        p5, p4, p2
    vf.add       v0, v4, v1
    p.and        p4, p5, p3
    s.movz       s1, #15
    v.splat      v4, s16
    vf.sub       v6, v3, v0
    @p1 v.st.w       [s11, #0], v6
    a.vread      v0, a1, s7
    a.vread      v3, a0, s3
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.add       v2, v3, v1
    p.and        p1, p5, p3
    vf.sub       v3, v0, v2
    @p4 v.st.w       [s13, #0], v3
    a.vread      v0, a1, s12
    a.vread      v2, a0, s2
    v.cmp.lt     p4, v4, v5
    p.and        p5, p4, p2
    vf.add       v3, v2, v1
    p.and        p2, p5, p3
    vf.sub       v2, v0, v3
    @p1 v.st.w       [s15, #0], v2
    a.vread      v0, a1, s14
    a.vread      v2, a0, s1
    vf.add       v3, v2, v1
    vf.sub       v1, v0, v3
    @p2 v.st.w       [s8, #0], v1
__rctx_next:
    exit
