#!/bin/bash
# r41s2-int screens on the x86 Vivado host:
#   job 1: int kernel synthesis (attempt-3 image parameters)       | job 2: base tile 0 screen in SLR0 (calibration)
#   then:  int tile 1 screen in SLR1                                 |        int tile 0 screen in SLR0
set -u
R=$HOME/r41s2int; SRC=$R/src; SL=$R/slot.sh
V="vivado -mode batch -nojournal -nolog"
cd $R
echo "$(date -u +%FT%TZ) chain start" >> chain.log
$SL --min-gb 10 $R/kernel_synth.log -- $V -source $R/synth6.tcl -tclargs $SRC $SRC/evidence/r40/v2/convergence/attempt03/image.tcl $R/kernel_synth &
sleep 90
$SL --min-gb 8 $R/base_tile0_screen.log -- $V -source $SRC/flow/fpga/screen_r41_tile.tcl -tclargs $R/base_synth/synth.dcp 0 0 $R/base_tile0_screen &
wait %1
echo "$(date -u +%FT%TZ) kernel synth exit $?" >> chain.log
[ -f $R/kernel_synth/synth.dcp ] || { echo "$(date -u +%FT%TZ) no kernel synth.dcp" >> chain.log; exit 1; }
$SL --min-gb 8 $R/tile1_screen.log -- $V -source $SRC/flow/fpga/screen_r41_tile.tcl -tclargs $R/kernel_synth/synth.dcp 1 1 $R/tile1_screen &
sleep 120
$SL --min-gb 8 $R/tile0_screen.log -- $V -source $SRC/flow/fpga/screen_r41_tile.tcl -tclargs $R/kernel_synth/synth.dcp 0 0 $R/tile0_screen &
wait
echo "$(date -u +%FT%TZ) CHAIN-DONE" >> chain.log
