# AOT ID: ['39_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/wf/cwf3fyytsepzqobyowy4kolb4pi7hubedtt3qq7kxnscc3acbq4l.py
# Topologically Sorted Source Nodes: [getitem, to_2, freqs, f, getitem_2, f_1, getitem_6], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
# Source node to ATen node mapping:
#   f => cos
#   f_1 => sin
#   freqs => mul_2
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_6 => select_13, slice_9
#   to_2 => convert_element_type
# Graph fragment:
#   %arg2_1 : Tensor "i64[3, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %unsqueeze : Tensor "i64[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %mul_2 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg3_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul_2,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 60, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul_2,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 60, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   return %select_scatter_default,%select_scatter_default_1
triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3352}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 64
    x0 = (xindex % 64)
    x2 = xindex
    tmp24 = tl.load(in_ptr0 + (0))
    tmp25 = tl.broadcast_to(tmp24, [XBLOCK])
    tmp27 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp31 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 60, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.load(in_ptr0 + (1))
    tmp16 = tl.broadcast_to(tmp15, [XBLOCK])
    tmp17 = tl.where(tmp14, tmp16, 0)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp20 = tmp18 * tmp19
    tmp21 = tl_math.cos(tmp20)
    tmp22 = tl.full(tmp21.shape, 0.0, tmp21.dtype)
    tmp23 = tl.where(tmp14, tmp21, tmp22)
    tmp26 = tmp25.to(tl.float32)
    tmp28 = tmp26 * tmp27
    tmp29 = tl_math.cos(tmp28)
    tmp30 = tl.where(tmp14, tmp23, tmp29)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tmp32 * tmp27
    tmp34 = tl_math.cos(tmp33)
    tmp35 = tl.where(tmp2, tmp30, tmp34)
    tmp36 = tl_math.sin(tmp20)
    tmp37 = tl.full(tmp36.shape, 0.0, tmp36.dtype)
    tmp38 = tl.where(tmp14, tmp36, tmp37)
    tmp39 = tl_math.sin(tmp28)
    tmp40 = tl.where(tmp14, tmp38, tmp39)
    tmp41 = tl_math.sin(tmp33)
    tmp42 = tl.where(tmp2, tmp40, tmp41)
    tl.store(out_ptr0 + (x2), tmp35, xmask)
    tl.store(out_ptr1 + (x2), tmp42, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/a5/ca5j632m35suppu4vx62fouailoo634puztr3uvtzfykkvjimdlg.py
# Topologically Sorted Source Nodes: [pow_1, mean], Original ATen: [aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   pow_1 => pow_1
# Graph fragment:
#   %arg0_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %pow_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   return %buf2
triton_red_fused_mean_pow_1 = async_compile.triton('triton_red_fused_mean_pow_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_mean_pow_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 8192}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_mean_pow_1(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 128*x0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tmp0 * tmp0
        tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
        tmp4 = _tmp3 + tmp2
        _tmp3 = tl.where(r0_mask, tmp4, _tmp3)
    tmp3 = triton_helpers.promote_to_tensor(tl.sum(_tmp3, 0))
    tl.store(out_ptr0 + (x0), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ti/ctiip6sgo74rb62xrsy3k3gdbrjow6c3mqv2gfgeqfiwnsxjvi46.py
# Topologically Sorted Source Nodes: [pow_1, mean, add, rsqrt, mul, xn, q, getitem_9, neg, getitem_10, rot], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add => add
#   getitem_10 => slice_18
#   getitem_9 => slice_17
#   mean => mean
#   mul => mul
#   neg => neg
#   pow_1 => pow_1
#   q => permute
#   rot => cat
#   rsqrt => rsqrt
#   xn => mul_1
# Graph fragment:
#   %arg1_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf2 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf2]
#   %pow_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul), kwargs = {})
#   %permute : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_1, [0, 2, 1, 3]), kwargs = {})
#   %slice_17 : Tensor "f32[1, 16, 1, 64][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_17,), kwargs = {})
#   %slice_18 : Tensor "f32[1, 16, 1, 64][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_18], -1), kwargs = {})
#   return %neg,%buf4
triton_poi_fused_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_2 = async_compile.triton('triton_poi_fused_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 25152}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_2(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (64 + x0), xmask, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x1), xmask)
    tmp2 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr1 + (x0 + 128*x1), xmask)
    tmp3 = tl.full([1], 128.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = -tmp9
    tmp13 = tmp12 * tmp7
    tmp14 = tmp11 * tmp13
    tl.store(out_ptr0 + (x0 + 128*x1), tmp10, xmask)
    tl.store(out_ptr1 + (x0 + 128*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/73/c73hym2oztz7szuaf3ry4gadq67uea3xxtxkwdmait4jqgo26qve.py
# Topologically Sorted Source Nodes: [pow_1, mean, add, rsqrt, mul, xn, q, setitem_1, cat, cos_1, mul_3, setitem_3, cat_1, sin_1, mul_4, qe, matmul, transpose_1, mul_5], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten.view, aten.bmm]
# Source node to ATen node mapping:
#   add => add
#   cat => clone, expand, select_11, unsqueeze_1, view
#   cat_1 => clone_2, expand_1, select_23, unsqueeze_3, view_1
#   cos_1 => unsqueeze_2
#   matmul => bmm, view_2, view_3, view_4
#   mean => mean
#   mul => mul
#   mul_3 => mul_3
#   mul_4 => mul_4
#   mul_5 => mul_5
#   pow_1 => pow_1
#   q => permute
#   qe => add_1
#   rsqrt => rsqrt
#   setitem_1 => select_8, slice_7
#   setitem_3 => select_20, slice_15
#   sin_1 => unsqueeze_4
#   transpose_1 => permute_1
#   xn => mul_1
# Graph fragment:
#   %arg1_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf2 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf2]
#   %select_scatter_default : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %cat : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0" = PlaceHolder[target=cat]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %arg4_1 : Tensor "f32[1, 16, 144, 128][294912, 18432, 128, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %bmm : Tensor "f32[16, 1, 144][144, 144, 1]tnca:0" = PlaceHolder[target=bmm]
#   %pow_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul), kwargs = {})
#   %permute : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_1, [0, 2, 1, 3]), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_7 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_7, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view, 1), kwargs = {})
#   %mul_3 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute, %unsqueeze_2), kwargs = {})
#   %select_20 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_15 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_15, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_1 : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 1, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 128]), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_1, 1), kwargs = {})
#   %mul_4 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_4), kwargs = {})
#   %add_1 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_3, %mul_4), kwargs = {})
#   %view_2 : Tensor "f32[16, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [16, 1, 128]), kwargs = {})
#   %permute_1 : Tensor "f32[1, 16, 128, 144][294912, 18432, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg4_1, [0, 1, 3, 2]), kwargs = {})
#   %view_3 : Tensor "f32[16, 128, 144][18432, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [16, 128, 144]), kwargs = {})
#   %bmm : Tensor "f32[16, 1, 144][144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_2, %view_3), kwargs = {})
#   %view_4 : Tensor "f32[1, 16, 1, 144][2304, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 1, 144]), kwargs = {})
#   %mul_5 : Tensor "f32[1, 16, 1, 144][2304, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_4, 0.08838834764831845), kwargs = {})
#   return %bmm,%mul_5
triton_red_fused_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_red_fused_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 18432, 'r0_': 1198592}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2304
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 144
    tmp2 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x3 = xindex
    _tmp39 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_2 + 128*x1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp25 = tl.load(in_ptr3 + ((r0_2 % 64)), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp29 = tl.load(in_ptr4 + (r0_2 + 128*x1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp31 = tl.load(in_ptr5 + ((r0_2 % 64)), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp36 = tl.load(in_ptr6 + (r0_2 + 128*x3), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.full([1], 128.0, tl.float32)
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 1e-06, tl.float32)
        tmp6 = tmp4 + tmp5
        tmp7 = libdevice.rsqrt(tmp6)
        tmp8 = tmp1 * tmp7
        tmp9 = tmp0 * tmp8
        tmp10 = tl.full([1], 0, tl.int32)
        tmp11 = tmp10 == tmp10
        tmp12 = ((r0_2 % 64)).to(tl.int64)
        tmp13 = (tmp12).to(tl.int64)
        tmp14 = tl.full([1], 2, tl.int64)
        tmp15 = tmp13 >= tmp14
        tmp16 = tl.full([1], 60, tl.int64)
        tmp17 = tmp13 < tmp16
        tmp18 = ((((-2) + ((r0_2 % 64))) % 3)).to(tl.int64)
        tmp19 = (tmp18).to(tl.int64)
        tmp20 = tl.full([1], 0, tl.int64)
        tmp21 = tmp19 == tmp20
        tmp22 = tmp15 & tmp17
        tmp23 = tmp22 & tmp21
        tmp24 = tl.load(in_ptr3 + (tl.broadcast_to(130 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)), [R0_BLOCK])), r0_mask & tmp23, eviction_policy='evict_last', other=0.0)
        tmp26 = tl.where(tmp23, tmp24, tmp25)
        tmp27 = tl.where(tmp11, tmp26, tmp25)
        tmp28 = tmp9 * tmp27
        tmp30 = tl.load(in_ptr5 + (tl.broadcast_to(130 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)), [R0_BLOCK])), r0_mask & tmp23, eviction_policy='evict_last', other=0.0)
        tmp32 = tl.where(tmp23, tmp30, tmp31)
        tmp33 = tl.where(tmp11, tmp32, tmp31)
        tmp34 = tmp29 * tmp33
        tmp35 = tmp28 + tmp34
        tmp37 = tmp35 * tmp36
        tmp38 = tl.broadcast_to(tmp37, [R0_BLOCK])
        tmp40 = _tmp39 + tmp38
        _tmp39 = tl.where(r0_mask, tmp40, _tmp39)
    tmp39 = triton_helpers.promote_to_tensor(tl.sum(_tmp39, 0))
    tmp41 = tl.full([1], 0.08838834764831845, tl.float32)
    tmp42 = tmp39 * tmp41
    tl.store(in_out_ptr0 + (x3), tmp42, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        assert_size_stride_grouped((arg2_1, arg3_1), ((3, 1, 1), (64, )), ((1, 1, 1), (1, )), 'input')
        buf0 = empty_strided((3, 1, 1, 64), (64, 192, 192, 1), device='tnca', dtype=torch.float32)
        buf1 = empty_strided((3, 1, 1, 64), (64, 192, 192, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem, to_2, freqs, f, getitem_2, f_1, getitem_6], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_0.run(arg2_1, arg3_1, buf0, buf1, 192, stream=raw_stream0)
        del arg2_1
        del arg3_1
        assert_size_stride(arg0_1, (1, 1, 16, 128), (2048, 2048, 128, 1), 'input')
        buf2 = empty_strided((1, 1, 16, 1), (16, 16, 1, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [pow_1, mean], Original ATen: [aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_mean_pow_1.run(arg0_1, buf2, 16, 128, stream=raw_stream0)
        assert_size_stride(arg1_1, (128, ), (1, ), 'input')
        buf5 = empty_strided((1, 16, 1, 128), (2048, 128, 128, 1), device='tnca', dtype=torch.float32)
        buf3 = reinterpret_tensor(buf5, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf4 = reinterpret_tensor(buf5, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [pow_1, mean, add, rsqrt, mul, xn, q, getitem_9, neg, getitem_10, rot], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_2.run(arg1_1, arg0_1, buf2, buf3, buf4, 1024, stream=raw_stream0)
        assert_size_stride(arg4_1, (1, 16, 144, 128), (294912, 18432, 128, 1), 'input')
        buf6 = empty_strided((16, 1, 144), (144, 144, 1), device='tnca', dtype=torch.float32)
        buf7 = reinterpret_tensor(buf6, (1, 16, 1, 144), (2304, 144, 144, 1), 0); del buf6  # reuse
        # Topologically Sorted Source Nodes: [pow_1, mean, add, rsqrt, mul, xn, q, setitem_1, cat, cos_1, mul_3, setitem_3, cat_1, sin_1, mul_4, qe, matmul, transpose_1, mul_5], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten.view, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3.run(buf7, arg1_1, arg0_1, buf2, buf0, buf5, buf1, arg4_1, 2304, 128, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg4_1
        return (buf7, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 1, 16, 128), (2048, 2048, 128, 1), device='tnca:0', dtype=torch.float32)
    arg1_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((3, 1, 1), (1, 1, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg4_1 = rand_strided((1, 16, 144, 128), (294912, 18432, 128, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
