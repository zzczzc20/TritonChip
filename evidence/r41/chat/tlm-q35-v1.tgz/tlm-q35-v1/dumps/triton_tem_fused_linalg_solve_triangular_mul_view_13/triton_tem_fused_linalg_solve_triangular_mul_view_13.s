    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #1
    s.ld.d       s3, [s1, #16]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.sub        s1, s2, s4
    s.rdspecial  s5, arg_base
    s.movz       s6, #0
    s.min.s      s7, s1, s2
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s7, s6
    s.mul        s6, s1, s2
    s.ld.d       s1, [s5, #0]                    // arg_B: device_ptr64 at arg_base+0
    s.movz       s2, #0
    s.cmp.lt     s11, s4, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s11
    s.xor        s2, s7, s8
    s.add        s10, s3, s6                     // this context's own scratch
    s.movz       s3, #0
    s.movz       s6, #1
    s.xor        s11, s4, s9
    s.sub        s12, s2, s8
    s.addi       s2, s10, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s8, #2147483647
    .li       s10, #2147483647
    s.movz       s13, #64
    s.movz       s14, #4
    .li       s15, #68719476752
    s.sub        s16, s11, s9
    s.addi       s11, s3, #0
    s.cmp.eq     s3, s12, s6
    s.ld.d       s6, [s5, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s5, #0
    s.st.d       [s2, #0], s1
    .li       s1, #2207613190144
    s.st.d       [s2, #8], s8
    s.movz       s5, #0
    s.addi       s8, s5, #0
    s.st.d       [s2, #16], s10
    s.st.d       [s2, #48], s13
    s.st.d       [s2, #56], s14
    s.st.d       [s2, #88], s15
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d0, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s11, s16
    br.nz        s3, sdiv_done_1
    s.movz       s1, #0
    s.movz       s2, #31
    s.mov        s11, s1
    s.addi       s1, s2, #0
sdiv_2:
    s.lshr       s2, s16, s1
    s.shli       s3, s8, #1
    s.andi       s5, s2, #1
    s.movz       s2, #0
    s.or         s10, s3, s5
    s.movz       s3, #1
    s.cmp.geu    s5, s10, s12
    s.shl        s13, s3, s1
    s.sub        s3, s2, s5
    s.subi       s2, s1, #1
    s.and        s5, s12, s3
    s.and        s14, s13, s3
    s.sub        s3, s10, s5
    s.or         s5, s11, s14
    s.mov        s8, s3
    s.mov        s11, s5
    s.mov        s1, s2
    s.movz       s2, #0
    s.cmp.ge     s3, s1, s2
    br.nz        s3, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s10, s7, s1
    s.movz       s1, #0
    s.cmp.lt     s11, s2, s3
    s.sub        s3, s5, s10
    s.sub        s5, s1, s11
    s.xor        s1, s7, s3
    s.xor        s7, s8, s9
    s.xor        s8, s2, s5
    s.sub        s10, s1, s3
    s.movz       s1, #0
    s.movz       s11, #1
    s.sub        s12, s7, s9
    s.sub        s7, s8, s5
    s.movz       s8, #0
    s.addi       s9, s1, #0
    s.cmp.eq     s1, s10, s11
    s.add        s11, s4, s12
    s.addi       s4, s8, #0
    s.mov        s9, s7
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s8, #31
    s.mov        s9, s1
    s.addi       s1, s8, #0
sdiv_4:
    s.lshr       s8, s7, s1
    s.shli       s12, s4, #1
    s.andi       s13, s8, #1
    s.movz       s8, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s10
    s.shl        s15, s12, s1
    s.sub        s12, s8, s13
    s.subi       s8, s1, #1
    s.and        s13, s10, s12
    s.and        s16, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s9, s16
    s.mov        s4, s12
    s.mov        s9, s13
    s.mov        s1, s8
    s.movz       s8, #0
    s.cmp.ge     s12, s1, s8
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.rdspecial  s1, pid.z
    s.rdspecial  s4, npid.y
    s.xor        s7, s5, s3
    s.mul        s3, s1, s4
    s.rdspecial  s1, pid.y
    s.xor        s4, s9, s7
    s.movz       s5, #16
    s.movz       s8, #127
    s.add        s9, s1, s3
    s.sub        s1, s4, s7
    s.mul        s3, s11, s5
    s.min.s      s4, s9, s8
    s.movz       s7, #256
    s.mul        s8, s1, s5
    s.mul        s10, s4, s7
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s4, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.andi       s12, s3, #15
    s.andi       s13, s8, #15
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s14, s4
    mb.wait      s4
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #0
    s.add        s16, s13, s10
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d0, s17, s14
    mb.wait      s14
    v.extract    s10, v48, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    v.splat      v1, s10
    v.splat      v2, s11
    v.extract    s10, v48, #1
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s2
    v.splat      v4, s10
    v.splat      v5, s1
    v.splat      v6, s2
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v1
    vf.fma       v1, v4, v33, v3
    v.extract    s1, v48, #2
    v.splat      v2, s3
    v.splat      v3, s8
    v.splat      v4, s12
    v.cmp.ge     p1, v5, v6
    v.splat      v5, s1
    v.extract    s1, v48, #3
    v.add        v6, v2, v7
    vf.fma       v2, v5, v34, v1
    v.splat      v1, s1
    v.extract    s1, v48, #4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v3, v7
    vf.fma       v3, v1, v35, v2
    v.splat      v1, s1
    v.extract    s1, v48, #5
    v.splat      v2, s13
    v.iota       v6                              // arange(0, VLEN)
    vf.fma       v7, v1, v36, v3
    v.add        v1, v4, v5
    v.splat      v1, s1
    v.extract    s1, v48, #6
    v.add        v3, v2, v6
    vf.fma       v2, v1, v37, v7
    v.splat      v1, s1
    v.extract    s1, v48, #7
    v.extract    s2, v48, #8
    v.splat      v3, s1
    vf.fma       v4, v1, v38, v2
    v.splat      v1, s2
    v.extract    s1, v48, #9
    v.extract    s2, v48, #10
    v.splat      v2, s1
    vf.fma       v5, v3, v39, v4
    v.splat      v3, s2
    v.extract    s1, v48, #11
    v.extract    s2, v48, #12
    v.splat      v4, s1
    vf.fma       v6, v1, v40, v5
    v.splat      v1, s2
    v.extract    s1, v48, #13
    v.extract    s2, v48, #14
    v.splat      v5, s1
    vf.fma       v7, v2, v41, v6
    v.splat      v2, s2
    v.extract    s1, v48, #15
    s.movz       s2, #1
    v.splat      v6, s1
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v4, v43, v8
    vf.fma       v4, v1, v44, v3
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v6, v47, v3
    a.vwrite     a0, s15, v1
    v.extract    s1, v49, #0
    v.extract    s10, v49, #1
    v.splat      v1, s1
    v.splat      v2, s10
    v.extract    s1, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v49, #3
    v.extract    s10, v49, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s10
    v.extract    s1, v49, #5
    v.extract    s10, v49, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s10
    v.extract    s1, v49, #7
    v.extract    s10, v49, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s10
    v.extract    s1, v49, #9
    v.extract    s10, v49, #10
    v.extract    s11, v49, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v49, #12
    v.extract    s12, v49, #13
    v.extract    s13, v49, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s10
    v.extract    s10, v49, #15
    v.splat      v6, s11
    s.movz       s11, #2
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s10
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s2, v1
    v.extract    s1, v50, #0
    v.extract    s2, v50, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v50, #3
    v.extract    s2, v50, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v50, #5
    v.extract    s2, v50, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v50, #7
    v.extract    s2, v50, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v50, #9
    v.extract    s2, v50, #10
    v.extract    s10, v50, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v50, #12
    v.extract    s12, v50, #13
    v.extract    s13, v50, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v50, #15
    v.splat      v6, s10
    s.movz       s10, #3
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v51, #0
    v.extract    s2, v51, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v51, #3
    v.extract    s2, v51, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v51, #5
    v.extract    s2, v51, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v51, #7
    v.extract    s2, v51, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v51, #9
    v.extract    s2, v51, #10
    v.extract    s11, v51, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v51, #12
    v.extract    s12, v51, #13
    v.extract    s13, v51, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v51, #15
    v.splat      v6, s11
    s.movz       s11, #4
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v52, #0
    v.extract    s2, v52, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v52, #3
    v.extract    s2, v52, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v52, #5
    v.extract    s2, v52, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v52, #7
    v.extract    s2, v52, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v52, #9
    v.extract    s2, v52, #10
    v.extract    s10, v52, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v52, #12
    v.extract    s12, v52, #13
    v.extract    s13, v52, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v52, #15
    v.splat      v6, s10
    s.movz       s10, #5
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v53, #0
    v.extract    s2, v53, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v53, #3
    v.extract    s2, v53, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v53, #5
    v.extract    s2, v53, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v53, #7
    v.extract    s2, v53, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v53, #9
    v.extract    s2, v53, #10
    v.extract    s11, v53, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v53, #12
    v.extract    s12, v53, #13
    v.extract    s13, v53, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v53, #15
    v.splat      v6, s11
    s.movz       s11, #6
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v54, #0
    v.extract    s2, v54, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v54, #3
    v.extract    s2, v54, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v54, #5
    v.extract    s2, v54, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v54, #7
    v.extract    s2, v54, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v54, #9
    v.extract    s2, v54, #10
    v.extract    s10, v54, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v54, #12
    v.extract    s12, v54, #13
    v.extract    s13, v54, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v54, #15
    v.splat      v6, s10
    s.movz       s10, #7
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v55, #0
    v.extract    s2, v55, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v55, #3
    v.extract    s2, v55, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v55, #5
    v.extract    s2, v55, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v55, #7
    v.extract    s2, v55, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v55, #9
    v.extract    s2, v55, #10
    v.extract    s11, v55, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v55, #12
    v.extract    s12, v55, #13
    v.extract    s13, v55, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v55, #15
    v.splat      v6, s11
    s.movz       s11, #8
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v56, #0
    v.extract    s2, v56, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v56, #3
    v.extract    s2, v56, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v56, #5
    v.extract    s2, v56, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v56, #7
    v.extract    s2, v56, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v56, #9
    v.extract    s2, v56, #10
    v.extract    s10, v56, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v56, #12
    v.extract    s12, v56, #13
    v.extract    s13, v56, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v56, #15
    v.splat      v6, s10
    s.movz       s10, #9
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v57, #0
    v.extract    s2, v57, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v57, #3
    v.extract    s2, v57, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v57, #5
    v.extract    s2, v57, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v57, #7
    v.extract    s2, v57, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v57, #9
    v.extract    s2, v57, #10
    v.extract    s11, v57, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v57, #12
    v.extract    s12, v57, #13
    v.extract    s13, v57, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v57, #15
    v.splat      v6, s11
    s.movz       s11, #10
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v58, #0
    v.extract    s2, v58, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v58, #3
    v.extract    s2, v58, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v58, #5
    v.extract    s2, v58, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v58, #7
    v.extract    s2, v58, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v58, #9
    v.extract    s2, v58, #10
    v.extract    s10, v58, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v58, #12
    v.extract    s12, v58, #13
    v.extract    s13, v58, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v58, #15
    v.splat      v6, s10
    s.movz       s10, #11
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v59, #0
    v.extract    s2, v59, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v59, #3
    v.extract    s2, v59, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v59, #5
    v.extract    s2, v59, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v59, #7
    v.extract    s2, v59, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v59, #9
    v.extract    s2, v59, #10
    v.extract    s11, v59, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v59, #12
    v.extract    s12, v59, #13
    v.extract    s13, v59, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v59, #15
    v.splat      v6, s11
    s.movz       s11, #12
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v60, #0
    v.extract    s2, v60, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v60, #3
    v.extract    s2, v60, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v60, #5
    v.extract    s2, v60, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v60, #7
    v.extract    s2, v60, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v60, #9
    v.extract    s2, v60, #10
    v.extract    s10, v60, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v60, #12
    v.extract    s12, v60, #13
    v.extract    s13, v60, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v60, #15
    v.splat      v6, s10
    s.movz       s10, #13
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v61, #0
    v.extract    s2, v61, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v61, #3
    v.extract    s2, v61, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v61, #5
    v.extract    s2, v61, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v61, #7
    v.extract    s2, v61, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v61, #9
    v.extract    s2, v61, #10
    v.extract    s11, v61, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v61, #12
    v.extract    s12, v61, #13
    v.extract    s13, v61, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v61, #15
    v.splat      v6, s11
    s.movz       s11, #14
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s10, v1
    v.extract    s1, v62, #0
    v.extract    s2, v62, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v62, #3
    v.extract    s2, v62, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v62, #5
    v.extract    s2, v62, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v62, #7
    v.extract    s2, v62, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v62, #9
    v.extract    s2, v62, #10
    v.extract    s10, v62, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v62, #12
    v.extract    s12, v62, #13
    v.extract    s13, v62, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v62, #15
    v.splat      v6, s10
    s.movz       s10, #15
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s12
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s13
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v63, #0
    v.extract    s2, v63, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s1
    v.extract    s1, v63, #3
    v.extract    s2, v63, #4
    v.splat      v1, s1
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v63, #5
    v.extract    s2, v63, #6
    v.splat      v3, s1
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s2
    v.extract    s1, v63, #7
    v.extract    s2, v63, #8
    v.splat      v4, s1
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s2
    v.extract    s1, v63, #9
    v.extract    s2, v63, #10
    v.splat      v5, s1
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s2
    v.extract    s1, v63, #11
    v.extract    s2, v63, #12
    v.extract    s11, v63, #13
    vf.fma       v6, v3, v37, v7
    v.splat      v3, s1
    v.extract    s1, v63, #14
    v.extract    s12, v63, #15
    v.splat      v7, s2
    vf.fma       v8, v0, v38, v6
    v.splat      v0, s11
    s.mul        s2, s9, s7
    s.muli       s7, s8, #4                      // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s11, #0
    vf.fma       v6, v4, v39, v8
    v.splat      v4, s1
    s.movz       s1, #0
    s.muli       s13, s3, #64                    // a runtime tile origin, x64
    s.add        s15, s1, s3                     // the tile origin
    vf.fma       v8, v1, v40, v6
    v.splat      v1, s12
    s.movz       s1, #0
    s.movz       s3, #128
    s.add        s12, s1, s8                     // the tile origin
    vf.fma       v6, v5, v41, v8
    v.iota       v5                              // arange(0, VLEN)
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    s.add        s2, s6, s7                      // the tile origin
    vf.fma       v8, v2, v42, v6
    v.splat      v2, s12
    s.add        s6, s2, s13                     // the tile origin
    v.add        v6, v5, v2
    vf.fma       v2, v3, v43, v8
    v.movi       v3, #0
    v.splat      v5, s15
    s.add        s2, s6, s1                      // the tile origin
    s.movz       s1, #1
    vf.fma       v8, v7, v44, v2
    v.splat      v2, s5
    s.addi       s6, s15, #1
    s.addi       s7, s2, #64                     // row 1
    v.cmp.lt     p1, v5, v2
    vf.fma       v5, v0, v45, v8
    v.splat      v0, s5
    v.splat      v7, s9
    s.movz       s5, #2
    v.cmp.lt     p2, v6, v0
    vf.fma       v0, v4, v46, v5
    v.splat      v4, s3
    p.and        p3, p1, p2
    v.splat      v5, s6
    v.cmp.lt     p1, v7, v4
    vf.fma       v4, v1, v47, v0
    p.and        p4, p3, p1
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    s.addi       s3, s15, #2
    a.vwrite     a0, s10, v4
    a.vread      v0, a0, s11
    p.and        p3, p5, p1
    v.splat      v1, s3
    vf.add       v4, v0, v3
    s.addi       s3, s2, #128                    // row 2
    s.movz       s6, #3
    s.addi       s8, s15, #3
    s.addi       s9, s2, #192                    // row 3
    @p4 v.st.w       [s2, #0], v4
    a.vread      v0, a0, s1
    v.cmp.lt     p4, v1, v2
    p.and        p5, p4, p2
    vf.add       v1, v0, v3
    p.and        p4, p5, p1
    v.splat      v0, s8
    s.movz       s1, #4
    s.addi       s8, s15, #4
    s.addi       s10, s2, #256                   // row 4
    v.splat      v4, s8
    s.movz       s8, #5
    s.addi       s11, s15, #5
    s.addi       s12, s2, #320                   // row 5
    v.splat      v5, s11
    s.movz       s11, #6
    s.addi       s13, s15, #6
    @p3 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v2
    p.and        p5, p3, p2
    vf.add       v0, v1, v3
    p.and        p3, p5, p1
    v.splat      v1, s13
    s.addi       s5, s2, #384                    // row 6
    s.movz       s7, #7
    s.addi       s13, s15, #7
    v.splat      v6, s13
    s.addi       s13, s2, #448                   // row 7
    @p4 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p4, v4, v2
    p.and        p5, p4, p2
    vf.add       v4, v0, v3
    p.and        p4, p5, p1
    s.movz       s3, #8
    s.addi       s6, s15, #8
    v.splat      v0, s6
    s.addi       s6, s2, #512                    // row 8
    @p3 v.st.w       [s9, #0], v4
    a.vread      v4, a0, s1
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    vf.add       v5, v4, v3
    p.and        p3, p5, p1
    s.movz       s1, #9
    s.addi       s9, s15, #9
    v.splat      v4, s9
    s.addi       s9, s2, #576                    // row 9
    @p4 v.st.w       [s10, #0], v5
    a.vread      v5, a0, s8
    v.cmp.lt     p4, v1, v2
    p.and        p5, p4, p2
    vf.add       v1, v5, v3
    p.and        p4, p5, p1
    s.movz       s8, #10
    s.addi       s10, s15, #10
    v.splat      v5, s10
    s.addi       s10, s2, #640                   // row 10
    @p3 v.st.w       [s12, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v6, v2
    p.and        p5, p3, p2
    vf.add       v6, v1, v3
    p.and        p3, p5, p1
    s.movz       s11, #11
    s.addi       s12, s15, #11
    v.splat      v1, s12
    s.addi       s12, s2, #704                   // row 11
    @p4 v.st.w       [s5, #0], v6
    a.vread      v6, a0, s7
    v.cmp.lt     p4, v0, v2
    p.and        p5, p4, p2
    vf.add       v0, v6, v3
    p.and        p4, p5, p1
    s.movz       s5, #12
    s.addi       s7, s15, #12
    v.splat      v6, s7
    s.addi       s7, s2, #768                    // row 12
    @p3 v.st.w       [s13, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p3, v4, v2
    p.and        p5, p3, p2
    vf.add       v4, v0, v3
    p.and        p3, p5, p1
    s.movz       s3, #13
    s.addi       s13, s15, #13
    v.splat      v0, s13
    s.addi       s13, s2, #832                   // row 13
    @p4 v.st.w       [s6, #0], v4
    a.vread      v4, a0, s1
    v.cmp.lt     p4, v5, v2
    p.and        p5, p4, p2
    vf.add       v5, v4, v3
    p.and        p4, p5, p1
    s.movz       s1, #14
    s.addi       s6, s15, #14
    v.splat      v4, s6
    s.addi       s6, s2, #896                    // row 14
    @p3 v.st.w       [s9, #0], v5
    a.vread      v5, a0, s8
    v.cmp.lt     p3, v1, v2
    p.and        p5, p3, p2
    vf.add       v1, v5, v3
    p.and        p3, p5, p1
    s.movz       s8, #15
    s.addi       s9, s15, #15
    s.addi       s15, s2, #960                   // row 15
    v.splat      v5, s9
    @p4 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p4, v6, v2
    p.and        p5, p4, p2
    vf.add       v6, v1, v3
    p.and        p4, p5, p1
    @p3 v.st.w       [s12, #0], v6
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v2
    p.and        p5, p3, p2
    vf.add       v0, v1, v3
    p.and        p3, p5, p1
    @p4 v.st.w       [s7, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p4, v4, v2
    p.and        p5, p4, p2
    vf.add       v1, v0, v3
    p.and        p4, p5, p1
    @p3 v.st.w       [s13, #0], v1
    a.vread      v0, a0, s1
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    vf.add       v1, v0, v3
    p.and        p2, p5, p1
    @p4 v.st.w       [s6, #0], v1
    a.vread      v0, a0, s8
    vf.add       v1, v0, v3
    @p2 v.st.w       [s15, #0], v1
__rctx_next:
    exit
