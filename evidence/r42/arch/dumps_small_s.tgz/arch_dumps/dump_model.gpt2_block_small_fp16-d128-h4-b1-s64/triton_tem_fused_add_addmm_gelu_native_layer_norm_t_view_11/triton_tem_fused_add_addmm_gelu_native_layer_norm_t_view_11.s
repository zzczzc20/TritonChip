    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    s.st.d       [s6, #16], s1
    s.movz       s3, #256
    s.st.d       [s6, #48], s3
    s.movz       s7, #2
    s.st.d       [s6, #56], s7
    .li       s8, #68719476752
    s.st.d       [s6, #88], s8
    .li       s9, #8589934592
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s6, arg_base
    s.ld.d       s10, [s6, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s11, #512
    s.mul        s12, s6, s11
    s.add        s6, s10, s12                    // this context's own scratch
    s.addi       s10, s6, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s10, #0], s4
    s.st.d       [s10, #8], s1
    s.st.d       [s10, #16], s1
    s.st.d       [s10, #48], s3
    s.st.d       [s10, #56], s7
    s.st.d       [s10, #88], s8
    s.st.d       [s10, #104], s9
    fence.release.device
    td.load      d1, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #32
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s3
    s.sub        s1, s3, s4
    s.movz       s4, #4
    s.movz       s6, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
__rctx_program:
    s.cmp.lt     s9, s7, s3
    s.addi       s10, s3, #0
    s.sub        s11, s3, s9
    s.addi       s9, s3, #0
    s.xor        s12, s7, s11
    s.xor        s13, s11, s1
    s.sub        s14, s12, s11
    s.lshri      s15, s14, #5
    s.mov        s10, s14
    s.xor        s16, s15, s13
    s.sub        s15, s16, s13
    s.sub        s13, s4, s15
    s.min.s      s16, s13, s6
    s.cmp.lt     s13, s16, s3
    s.sub        s17, s3, s13
    s.xor        s13, s16, s17
    s.sub        s16, s13, s17
    s.cmp.eq     s13, s16, s6
    br.nz        s13, sdiv_done_1
    s.movz       s18, #0
    s.movz       s19, #31
    s.mov        s10, s18
    s.addi       s20, s19, #0
sdiv_2:
    s.lshr       s19, s14, s20
    s.shli       s21, s9, #1
    s.andi       s22, s19, #1
    s.shl        s19, s6, s20
    s.or         s23, s21, s22
    s.cmp.geu    s21, s23, s16
    s.sub        s22, s18, s21
    s.and        s21, s16, s22
    s.and        s24, s19, s22
    s.sub        s9, s23, s21
    s.or         s10, s10, s24
    s.subi       s20, s20, #1
    s.cmp.ge     s19, s20, s18
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.sub        s10, s12, s11
    s.xor        s12, s9, s11
    s.lshri      s9, s10, #5
    s.sub        s14, s12, s11
    s.muli       s12, s9, #32
    s.addi       s9, s3, #0
    s.add        s18, s15, s14
    s.addi       s14, s3, #0
    s.sub        s15, s10, s12
    s.xor        s10, s15, s11
    s.sub        s12, s10, s11
    s.cmp.lt     s10, s12, s3
    s.sub        s11, s3, s10
    s.xor        s10, s12, s11
    s.sub        s12, s10, s11
    s.mov        s9, s12
    br.nz        s13, sdiv_done_3
    s.movz       s10, #0
    s.movz       s13, #31
    s.mov        s9, s10
    s.addi       s15, s13, #0
    s.movz       s13, #1
sdiv_4:
    s.lshr       s19, s12, s15
    s.shli       s20, s14, #1
    s.andi       s21, s19, #1
    s.shl        s19, s13, s15
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s16
    s.sub        s21, s10, s20
    s.and        s20, s16, s21
    s.and        s23, s19, s21
    s.sub        s14, s22, s20
    s.or         s9, s9, s23
    s.subi       s15, s15, #1
    s.cmp.ge     s19, s15, s10
    br.nz        s19, sdiv_4
sdiv_done_3:
    s.xor        s10, s11, s17
    s.movz       s11, #16
    s.xor        s12, s9, s10
    s.mul        s9, s18, s11
    s.sub        s13, s12, s10
    s.movz       s10, #0
    s.mul        s12, s13, s11
    s.movz       s13, #8
    s.andi       s14, s9, #63
    s.addi       s15, s10, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s16, s12, #511
for_5:
    s.cmp.ge     s17, s15, s13
    br.nz        s17, endfor_6
    s.mul        s17, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s19, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s19, s18
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s19, s18
    mb.wait      s18
gemm_pipe:
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s19, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s17
    s.add        s15, s15, s6
    s.cmp.ge     s19, s15, s13
    br.nz        s19, gemm_pipe_drain0
    s.mul        s19, s15, s11
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s21, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s21, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s21, s20
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s21, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s21, s20
    mb.wait      s20
    mb.wait      s17
    mb.arm       s19, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s19
    s.add        s15, s15, s6
    s.cmp.ge     s21, s15, s13
    br.nz        s21, gemm_pipe_drain1
    s.mul        s21, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s22, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s24, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s24, s22
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s24, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s24, s22
    mb.wait      s22
    mb.wait      s19
    br.nz        s23, gemm_pipe
gemm_pipe_drain0:
    s.movz       s11, #1
    mb.wait      s17
    br.nz        s11, endfor_6
gemm_pipe_drain1:
    mb.wait      s19
endfor_6:
    s.add        s11, s10, s12                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.add        s11, s10, s9                    // the tile origin
    s.movz       s13, #64
    s.movz       s14, #512
    s.muli       s15, s12, #2                    // a runtime tile origin, x2
    v.splat      v2, s11
    v.splat      v3, s13
    v.add        v4, v0, v1
    v.splat      v0, s14
    v.cmp.lt     p1, v2, v3
    s.add        s12, s2, s15                    // the tile origin
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    a.vread      v0, a0, s10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    s.addi       s13, s11, #1
    s.movz       s14, #1
    v.splat      v2, s13
    s.addi       s13, s11, #2
    s.movz       s16, #2
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s13
    s.addi       s13, s11, #3
    s.movz       s21, #3
    v.cmp.lt     p1, v2, v3
    p.and        p5, p1, p2
    v.splat      v2, s13
    vf.cvt.f16.f32 v4, v1
    s.addi       s13, s11, #4
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p2
    v.splat      v1, s13
    vf.add       v2, v0, v4
    s.movz       s13, #4
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p2
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s10, v1
    a.vread      v0, a0, s14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #5
    s.movz       s24, #5
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p8, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s14, v1
    a.vread      v0, a0, s16
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #6
    s.movz       s25, #6
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p9, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s21
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #7
    s.movz       s26, #7
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p10, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s21, v1
    a.vread      v0, a0, s13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #8
    s.movz       s27, #8
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p11, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s13, v1
    a.vread      v0, a0, s24
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #9
    s.movz       s28, #9
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p12, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s24, v1
    a.vread      v0, a0, s25
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p9 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #10
    s.movz       s29, #10
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p13, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s25, v1
    a.vread      v0, a0, s26
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p10 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #11
    s.movz       s30, #11
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p14, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s26, v1
    a.vread      v0, a0, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p11 v.ld.h       v1, [s12, #0]
    s.addi       s23, s11, #12
    s.movz       s31, #12
    v.splat      v2, s23
    v.cmp.lt     p1, v2, v3
    p.and        p15, p1, p2
    p.ballot     s23, p15
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s27, v1
    a.vread      v0, a0, s28
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p12 v.ld.h       v1, [s12, #0]
    s.addi       s32, s11, #13
    s.movz       s33, #13
    v.splat      v2, s32
    v.cmp.lt     p1, v2, v3
    p.and        p15, p1, p2
    p.ballot     s32, p15
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s28, v1
    a.vread      v0, a0, s29
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p13 v.ld.h       v1, [s12, #0]
    s.addi       s34, s11, #14
    s.movz       s35, #14
    v.splat      v2, s34
    v.cmp.lt     p1, v2, v3
    p.and        p15, p1, p2
    p.ballot     s34, p15
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s29, v1
    a.vread      v0, a0, s30
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p14 v.ld.h       v1, [s12, #0]
    s.addi       s36, s11, #15
    s.movz       s11, #15
    v.splat      v2, s36
    v.cmp.lt     p1, v2, v3
    p.and        p15, p1, p2
    p.ballot     s36, p15
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s30, v1
    a.vread      v0, a0, s31
    p.frombits   p1, s23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    .li       s37, #1027024659
    v.splat      v2, s37                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s37, #1061962282
    v.splat      v3, s37                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s37, #1056964608
    v.splat      v4, s37                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v0, v5
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s31, v1
    a.vread      v0, a0, s33
    p.frombits   p1, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v0, v5
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s33, v1
    a.vread      v0, a0, s35
    p.frombits   p1, s34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v0, v5
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s35, v1
    a.vread      v0, a0, s11
    p.frombits   p1, s36
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v0, v5
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s11, v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    a.vread      v0, a1, s10
    a.vread      v1, a1, s10
    a.vread      v5, a1, s10
    a.vread      v6, a1, s10
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s14
    a.vread      v1, a1, s14
    a.vread      v5, a1, s14
    a.vread      v6, a1, s14
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s14, v0
    a.vread      v0, a1, s16
    a.vread      v1, a1, s16
    a.vread      v5, a1, s16
    a.vread      v6, a1, s16
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s16, v0
    a.vread      v0, a1, s21
    a.vread      v1, a1, s21
    a.vread      v5, a1, s21
    a.vread      v6, a1, s21
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s21, v0
    a.vread      v0, a1, s13
    a.vread      v1, a1, s13
    a.vread      v5, a1, s13
    a.vread      v6, a1, s13
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s13, v0
    a.vread      v0, a1, s24
    a.vread      v1, a1, s24
    a.vread      v5, a1, s24
    a.vread      v6, a1, s24
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s24, v0
    a.vread      v0, a1, s25
    a.vread      v1, a1, s25
    a.vread      v5, a1, s25
    a.vread      v6, a1, s25
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s25, v0
    a.vread      v0, a1, s26
    a.vread      v1, a1, s26
    a.vread      v5, a1, s26
    a.vread      v6, a1, s26
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s26, v0
    a.vread      v0, a1, s27
    a.vread      v1, a1, s27
    a.vread      v5, a1, s27
    a.vread      v6, a1, s27
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s27, v0
    a.vread      v0, a1, s28
    a.vread      v1, a1, s28
    a.vread      v5, a1, s28
    a.vread      v6, a1, s28
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s28, v0
    a.vread      v0, a1, s29
    a.vread      v1, a1, s29
    a.vread      v5, a1, s29
    a.vread      v6, a1, s29
    vf.mul       v7, v1, v5
    vf.mul       v1, v7, v6
    vf.mul       v5, v1, v2
    vf.add       v1, v0, v5
    vf.mul       v0, v1, v3
    a.vwrite     a2, s29, v0
    a.vread      v0, a1, s30
    a.vread      v1, a1, s30
    a.vread      v5, a1, s30
    a.vread      v6, a1, s30
    .li       s12, #3221225472
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v8, v1, v5
    vf.mul       v1, v8, v6
    vf.mul       v5, v1, v2
    .li       s12, #1069066811
    v.splat      v1, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v6, v0, v5
    vf.mul       v0, v6, v3
    a.vwrite     a2, s30, v0
    a.vread      v0, a1, s31
    a.vread      v5, a1, s31
    a.vread      v6, a1, s31
    a.vread      v8, a1, s31
    .li       s12, #1060205080
    v.splat      v9, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v10, v5, v6
    vf.mul       v5, v10, v8
    vf.mul       v6, v5, v2
    vf.add       v5, v0, v6
    vf.mul       v0, v5, v3
    a.vwrite     a2, s31, v0
    a.vread      v0, a1, s33
    a.vread      v5, a1, s33
    a.vread      v6, a1, s33
    a.vread      v8, a1, s33
    vf.mul       v10, v5, v6
    vf.mul       v5, v10, v8
    vf.mul       v6, v5, v2
    vf.add       v5, v0, v6
    vf.mul       v0, v5, v3
    a.vwrite     a2, s33, v0
    a.vread      v0, a1, s35
    a.vread      v5, a1, s35
    a.vread      v6, a1, s35
    a.vread      v8, a1, s35
    vf.mul       v10, v5, v6
    vf.mul       v5, v10, v8
    vf.mul       v6, v5, v2
    vf.add       v5, v0, v6
    vf.mul       v0, v5, v3
    a.vwrite     a2, s35, v0
    a.vread      v0, a1, s11
    a.vread      v5, a1, s11
    a.vread      v6, a1, s11
    a.vread      v8, a1, s11
    vf.mul       v10, v5, v6
    vf.mul       v5, v10, v8
    vf.mul       v6, v5, v2
    vf.add       v2, v0, v6
    vf.mul       v0, v2, v3
    a.vwrite     a2, s11, v0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    a.vread      v0, a2, s10
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s10, v0
    a.vread      v0, a2, s14
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s14, v0
    a.vread      v0, a2, s16
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s16, v0
    a.vread      v0, a2, s21
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s21, v0
    a.vread      v0, a2, s13
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s13, v0
    a.vread      v0, a2, s24
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s24, v0
    a.vread      v0, a2, s25
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s25, v0
    a.vread      v0, a2, s26
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s26, v0
    a.vread      v0, a2, s27
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s27, v0
    a.vread      v0, a2, s28
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s28, v0
    a.vread      v0, a2, s29
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    a.vwrite     a3, s29, v0
    a.vread      v0, a2, s30
    vf.abs       v2, v0
    vf.mul       v0, v2, v7
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v9
    vf.fma       v2, v3, v0, v3                  // 2**t * 2**d
    .li       s12, #1065353216
    v.splat      v0, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v5, v2, v3
    a.vwrite     a3, s30, v5
    a.vread      v2, a2, s31
    vf.abs       v3, v2
    vf.mul       v2, v3, v7
    vf.mul       v3, v2, v1
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v2, v1, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v6, v9
    vf.fma       v3, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v5
    a.vwrite     a3, s31, v2
    a.vread      v2, a2, s33
    vf.abs       v3, v2
    vf.mul       v2, v3, v7
    vf.mul       v3, v2, v1
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v2, v1, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v6, v9
    vf.fma       v3, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v5
    a.vwrite     a3, s33, v2
    a.vread      v2, a2, s35
    vf.abs       v3, v2
    vf.mul       v2, v3, v7
    vf.mul       v3, v2, v1
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v2, v1, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v6, v9
    vf.fma       v3, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v5
    a.vwrite     a3, s35, v2
    a.vread      v2, a2, s11
    vf.abs       v3, v2
    vf.mul       v2, v3, v7
    vf.mul       v3, v2, v1
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v2, v1, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v6, v9
    vf.fma       v2, v5, v1, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v5
    a.vwrite     a3, s11, v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    a.vread      v1, a3, s10
    a.vread      v2, a3, s10
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v2
    a.vread      v1, a3, s14
    a.vread      v2, a3, s14
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s14, v2
    a.vread      v1, a3, s16
    a.vread      v2, a3, s16
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s16, v2
    a.vread      v1, a3, s21
    a.vread      v2, a3, s21
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s21, v2
    a.vread      v1, a3, s13
    a.vread      v2, a3, s13
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s13, v2
    a.vread      v1, a3, s24
    a.vread      v2, a3, s24
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s24, v2
    a.vread      v1, a3, s25
    a.vread      v2, a3, s25
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s25, v2
    a.vread      v1, a3, s26
    a.vread      v2, a3, s26
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s26, v2
    a.vread      v1, a3, s27
    a.vread      v2, a3, s27
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s27, v2
    a.vread      v1, a3, s28
    a.vread      v2, a3, s28
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s28, v2
    a.vread      v1, a3, s29
    a.vread      v2, a3, s29
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s29, v2
    a.vread      v1, a3, s30
    a.vread      v2, a3, s30
    vf.sub       v3, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v2, v0
    vf.fms       v1, v2, v5, v2
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s30, v2
    a.vread      v1, a3, s31
    a.vread      v2, a3, s31
    v.movi       v3, #0
    vf.sub       v5, v0, v1
    vf.add       v1, v2, v0
    s.muli       s12, s9, #1024                  // a runtime tile origin, x1024
    s.add        s9, s5, s15                     // the tile origin
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    s.add        s15, s9, s12                    // the tile origin
    vf.fms       v6, v1, v2, v0
    vf.fms       v1, v2, v6, v2
    vf.neg       v6, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v1, v6, v2
    vf.mul       v2, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s31, v2
    a.vread      v1, a3, s33
    a.vread      v2, a3, s33
    vf.sub       v5, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v1, v2, v0
    vf.fms       v1, v2, v6, v2
    vf.neg       v6, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v1, v6, v2
    vf.mul       v2, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s33, v2
    a.vread      v1, a3, s35
    a.vread      v2, a3, s35
    vf.sub       v5, v0, v1
    vf.add       v1, v2, v0
    s.addi       s9, s15, #1024                  // row 1
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v1, v2, v0
    vf.fms       v1, v2, v6, v2
    vf.neg       v6, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v1, v6, v2
    vf.mul       v2, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s35, v2
    a.vread      v1, a3, s11
    a.vread      v2, a3, s11
    vf.sub       v5, v0, v1
    vf.add       v1, v2, v0
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    s.addi       s12, s15, #2048                 // row 2
    vf.fms       v6, v1, v2, v0
    vf.fms       v1, v2, v6, v2
    vf.neg       v6, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v1, v6, v2
    vf.mul       v2, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v1, a1, s10
    a.vread      v2, a2, s10
    a.vread      v5, a4, s10
    a.vread      v6, a4, s10
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s10, s15, #3072                 // row 3
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s15, #0], v2
    a.vread      v1, a1, s14
    a.vread      v2, a2, s14
    a.vread      v5, a4, s14
    a.vread      v6, a4, s14
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s14, s15, #4096                 // row 4
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s9, #0], v2
    a.vread      v1, a1, s16
    a.vread      v2, a2, s16
    a.vread      v5, a4, s16
    a.vread      v6, a4, s16
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s9, s15, #5120                  // row 5
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p5 v.st.h       [s12, #0], v2
    a.vread      v1, a1, s21
    a.vread      v2, a2, s21
    a.vread      v5, a4, s21
    a.vread      v6, a4, s21
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s12, s15, #6144                 // row 6
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p6 v.st.h       [s10, #0], v2
    a.vread      v1, a1, s13
    a.vread      v2, a2, s13
    a.vread      v5, a4, s13
    a.vread      v6, a4, s13
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s10, s15, #7168                 // row 7
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p7 v.st.h       [s14, #0], v2
    a.vread      v1, a1, s24
    a.vread      v2, a2, s24
    a.vread      v5, a4, s24
    a.vread      v6, a4, s24
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s13, s15, #8192                 // row 8
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p8 v.st.h       [s9, #0], v2
    a.vread      v1, a1, s25
    a.vread      v2, a2, s25
    a.vread      v5, a4, s25
    a.vread      v6, a4, s25
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s9, s15, #9216                  // row 9
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p9 v.st.h       [s12, #0], v2
    a.vread      v1, a1, s26
    a.vread      v2, a2, s26
    a.vread      v5, a4, s26
    a.vread      v6, a4, s26
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s12, s15, #10240                // row 10
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p10 v.st.h       [s10, #0], v2
    a.vread      v1, a1, s27
    a.vread      v2, a2, s27
    a.vread      v5, a4, s27
    a.vread      v6, a4, s27
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s10, s15, #11264                // row 11
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p11 v.st.h       [s13, #0], v2
    a.vread      v1, a1, s28
    a.vread      v2, a2, s28
    a.vread      v5, a4, s28
    a.vread      v6, a4, s28
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s13, s15, #12288                // row 12
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p12 v.st.h       [s9, #0], v2
    a.vread      v1, a1, s29
    a.vread      v2, a2, s29
    a.vread      v5, a4, s29
    a.vread      v6, a4, s29
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s9, s15, #13312                 // row 13
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p13 v.st.h       [s12, #0], v2
    a.vread      v1, a1, s30
    a.vread      v2, a2, s30
    a.vread      v5, a4, s30
    a.vread      v6, a4, s30
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s12, s15, #14336                // row 14
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    @p14 v.st.h       [s10, #0], v2
    a.vread      v1, a1, s31
    a.vread      v2, a2, s31
    a.vread      v5, a4, s31
    a.vread      v6, a4, s31
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    s.addi       s10, s15, #15360                // row 15
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    p.frombits   p1, s23
    @p1 v.st.h       [s13, #0], v2
    a.vread      v1, a1, s33
    a.vread      v2, a2, s33
    a.vread      v5, a4, s33
    a.vread      v6, a4, s33
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    p.frombits   p1, s32
    @p1 v.st.h       [s9, #0], v2
    a.vread      v1, a1, s35
    a.vread      v2, a2, s35
    a.vread      v5, a4, s35
    a.vread      v6, a4, s35
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v5, v1, v4
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v1, v5, v2
    vf.cvt.f32.f16 v2, v1
    p.frombits   p1, s34
    @p1 v.st.h       [s12, #0], v2
    a.vread      v1, a1, s11
    a.vread      v2, a2, s11
    a.vread      v5, a4, s11
    a.vread      v6, a4, s11
    vf.cmp.lt    p1, v2, v3
    vf.neg       v2, v5
    vf.mul       v3, v1, v4
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v0
    vf.mul       v0, v3, v2
    vf.cvt.f32.f16 v1, v0
    p.frombits   p1, s36
    @p1 v.st.h       [s10, #0], v1
__rctx_next:
    s.addi       s9, s7, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s9, s8
    s.mov        s7, s9
    br.nz        s10, __rctx_program
    exit
