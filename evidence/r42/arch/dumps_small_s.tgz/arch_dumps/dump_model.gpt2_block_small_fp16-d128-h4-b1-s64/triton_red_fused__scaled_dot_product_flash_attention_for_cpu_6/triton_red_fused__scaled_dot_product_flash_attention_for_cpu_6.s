    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #512
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #0
    s.movz       s2, #64
    s.movz       s6, #16
    s.movz       s7, #256
    s.movz       s8, #1
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
    s.ld.d       s10, [s4, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.add        s11, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // in_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.splat      v0, s8
    v.movi       v1, #0
    v.movi       v2, #63
    v.movi       v3, #-1
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    s.addi       s4, s1, #0
    @p1 v.sel        v5, v4, v0
    s.muli       s5, s8, #256
    v.movi       v4, #64
    v.and        v6, v5, v2
    s.muli       s11, s4, #4
    v.movi       v2, #0
    v.sub        v5, v1, v6
    v.splat      v7, s7
    v.sub        v8, v1, v4
    @p1 v.sel        v9, v5, v6
    .li       s12, #4286578688
    v.splat      v5, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.mul        v10, v9, v3
    s.add        s12, s3, s5
    v.cmp.lt     p1, v4, v1
    v.extract    s5, v10, #0
    v.cmp.ne     p2, v2, v1
    v.cmp.ge     p3, v0, v1
    v.cmp.lt     p4, v0, v7
    v.iota       v0                              // arange(0, VLEN)
    @p1 v.sel        v2, v8, v4
    p.mov        p1, p2
    v.mov        v6, v5
    p.and        p2, p3, p4
    v.splat      v2, s5
    v.movi       v3, #0
    v.movi       v7, #1
    s.add        s5, s12, s11
for_1:
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s5, #0]
    v.splat      v10, s4
    v.add        v11, v10, v0
    v.add        v10, v11, v2
    v.cmp.lt     p3, v11, v4
    p.not        p4, p3
    v.cmp.le     p3, v10, v1
    @p3 v.sel        v10, v3, v5
    p.and        p3, p4, p1
    vf.add       v11, v8, v10
    vf.cmp.eq    p4, v11, v5
    @p4 v.sel        v8, v7, v1
    vf.max       v6, v6, v11
    v.cmp.eq     p4, v8, v1
    @p4 v.sel        v8, v7, v1
    v.cmp.ne     p4, v8, v1
    p.or         p5, p1, p4
    p.or         p4, p5, p3
    p.mov        p3, p4
    p.mov        p1, p3
    s.addi       s5, s5, #64                     // the next iteration's address
    s.add        s4, s4, s6
    s.cmp.lt     s11, s4, s2
    br.nz        s11, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v2, #0
    vf.cmp.uo    p2, v6, v6
    vf.reduce.max.b v3, v6
    @p2 v.sel        v4, v1, v2
    .li       s4, #2143289344
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0
    v.reduce.or.b v8, v4
    s.mul        s4, s8, s2
    v.movi       v4, #-1
    v.cmp.ne     p2, v8, v2
    @p2 v.sel        v8, v6, v3
    s.addi       s5, s1, #0
    @p1 v.sel        v3, v1, v2
    vf.add       v1, v8, v7
    v.mul        v6, v9, v4
    s.muli       s11, s5, #4
    v.splat      v4, s8
    v.splat      v8, s7
    s.add        s13, s5, s4
    v.movi       v9, #0
    v.reduce.or  s14, v3
    v.extract    s15, v6, #0
    v.extract    s16, v1, #0
    s.shli       s17, s13, #2                    // element offset -> bytes (x4)
    v.cmp.ge     p1, v4, v2
    v.cmp.lt     p2, v4, v8
    v.splat      v1, s14
    v.mov        v9, v7
    p.and        p3, p1, p2
    v.splat      v3, s15
    v.splat      v4, s16
    .li       s13, #1069066811
    v.splat      v6, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #1060205080
    v.splat      v8, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s13, #1
    s.add        s13, s12, s11
    s.add        s11, s10, s17                   // &in_out_ptr0[...]
for_3:
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s13, #0]
    v.splat      v11, s5
    v.add        v12, v11, v0
    v.add        v11, v12, v3
    v.cmp.le     p1, v11, v2
    @p1 v.sel        v11, v7, v5
    vf.add       v12, v10, v11
    vf.sub       v10, v12, v4
    vf.mul       v11, v10, v6
    v.exp2.approx v12, v11                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v10, v6, v11               // the exact rounding error of x*log2(e)
    vf.mul       v10, v13, v8
    vf.fma       v11, v12, v10, v12              // 2**t * 2**d
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v10, v11, v12
    vf.add       v9, v9, v10
    v.st.w       [s11, #0], v10
    s.addi       s13, s13, #64                   // the next iteration's address
    s.addi       s11, s11, #64                   // the next iteration's address
    s.add        s5, s5, s6
    s.cmp.lt     s12, s5, s2
    br.nz        s12, for_3
endfor_4:
    vf.reduce.add.b v0, v9
    .li       s5, #1065353216
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    vf.add       v4, v0, v7
    v.movi       v0, #1
    v.cmp.eq     p1, v1, v3
    s.addi       s5, s1, #0
    @p1 v.sel        v1, v0, v3
    v.extract    s11, v4, #0
    s.muli       s12, s8, #256
    v.splat      v0, s11
    s.movz       s11, #256
    v.extract    s13, v1, #0
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    s.muli       s14, s5, #4
    v.splat      v4, s8
    v.splat      v5, s11
    s.add        s11, s5, s4
    v.splat      v6, s13
    s.add        s4, s10, s12
    s.shli       s12, s11, #2                    // element offset -> bytes (x4)
    v.cmp.ge     p1, v4, v3
    v.cmp.lt     p2, v4, v5
    p.and        p3, p1, p2
    v.cmp.ne     p1, v6, v3
    s.add        s11, s4, s14
    s.add        s4, s10, s12                    // &in_out_ptr0[...]
    vf.fms       v3, v0, v1, v2
    vf.fms       v0, v1, v3, v1
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v0, v2, v1
for_5:
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s11, #0]
    vf.mul       v2, v1, v0                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v1, v7, v2
    v.st.w       [s4, #0], v1
    s.addi       s11, s11, #64                   // the next iteration's address
    s.addi       s4, s4, #64                     // the next iteration's address
    s.add        s5, s5, s6
    s.cmp.lt     s12, s5, s2
    br.nz        s12, for_5
endfor_6:
__rctx_next:
    s.addi       s4, s8, #2                      // the next program of this context: + 2
    s.cmp.lt     s5, s4, s9
    s.mov        s8, s4
    br.nz        s5, __rctx_program
    exit
