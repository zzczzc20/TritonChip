    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    v.movi       v0, #0
    s.muli       s5, s4, #2
    s.muli       s6, s4, #2
    s.muli       s7, s4, #2
    s.muli       s8, s4, #2
    s.muli       s9, s4, #2
    v.movi       v1, #0
    s.rdspecial  s10, arg_base
    s.movz       s10, #128
    s.ld.d       s11, [s1, #8]                   // in_ptr0: device_ptr64 at arg_base+8
    s.movz       s12, #16
    s.movz       s13, #1
    s.add        s13, s3, s5
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.add        s14, s11, s6
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.add        s11, s5, s7
    s.ld.d       s5, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.add        s7, s6, s8
    s.ld.d       s6, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.add        s8, s5, s9
    s.ld.d       s5, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    v.mov        v1, v0
for_1:
    v.ld.h       v0, [s13, #0]
    v.ld.h       v2, [s14, #0]
    vf.cvt.f16.f32 v3, v0
    v.ld.h       v0, [s11, #0]
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v3, v4
    v.ld.h       v3, [s7, #0]
    vf.cvt.f16.f32 v4, v0
    vf.add       v0, v2, v4
    v.ld.h       v2, [s8, #0]
    vf.cvt.f16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f16.f32 v0, v2
    vf.add       v2, v3, v0
    vf.mul       v0, v2, v2
    vf.cvt.f32.f16 v3, v2
    vf.add       v1, v1, v0
    v.st.h       [s13, #0], v3
    s.addi       s13, s13, #32                   // the next iteration's address
    s.addi       s14, s14, #32                   // the next iteration's address
    s.addi       s11, s11, #32                   // the next iteration's address
    s.addi       s7, s7, #32                     // the next iteration's address
    s.addi       s8, s8, #32                     // the next iteration's address
    s.add        s4, s4, s12
    s.cmp.lt     s1, s4, s10
    br.nz        s1, for_1
endfor_2:
    .li       s1, #1124073472
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v3, v1
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0
    .li       s1, #925353388
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v3, v4
    .li       s1, #3204448256
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.addi       s1, s2, #0
    s.movz       s2, #1
    s.muli       s2, s1, #2
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    s.shli       s7, s1, #1                      // element offset -> bytes (x2)
    s.add        s8, s6, s4                      // &in_ptr4[...]
    s.add        s4, s5, s7                      // &out_ptr1[...]
    s.add        s5, s3, s2
    vf.fms       v4, v0, v1, v2
    vf.fms       v0, v1, v4, v1
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    vf.mul       v1, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v5
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v4, v1, v3
    vf.fms       v3, v0, v2, v6
    vf.mul       v0, v4, v3                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s2, v2, #0
    v.splat      v0, s2
for_3:
    v.ld.h       v1, [s5, #0]
    v.ld.h       v2, [s8, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    vf.cvt.f16.f32 v3, v2
    vf.mul       v2, v1, v3
    vf.cvt.f32.f16 v1, v2
    v.st.h       [s4, #0], v1
    s.addi       s5, s5, #32                     // the next iteration's address
    s.addi       s8, s8, #32                     // the next iteration's address
    s.addi       s4, s4, #32                     // the next iteration's address
    s.add        s1, s1, s12
    s.cmp.lt     s2, s1, s10
    br.nz        s2, for_3
endfor_4:
    exit
    exit
