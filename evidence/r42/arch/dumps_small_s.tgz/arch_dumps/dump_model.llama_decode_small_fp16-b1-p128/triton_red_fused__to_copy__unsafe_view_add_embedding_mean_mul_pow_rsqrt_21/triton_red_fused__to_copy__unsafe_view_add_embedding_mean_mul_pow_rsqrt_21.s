    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    v.movi       v1, #0
    s.movz       s3, #0
    v.iota       v2                              // arange(0, VLEN)
    s.rdspecial  s4, arg_base
    s.movz       s4, #128
    s.movz       s5, #16
    s.ld.d       s6, [s2, #0]                    // one element, not a vector
    s.lshri      s2, s6, #32
    s.ld.d       s7, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    v.movi       v3, #0
    s.addi       s8, s3, #0
    s.ld.d       s9, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    v.movi       v4, #0
    s.ld.d       s10, [s1, #24]                  // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s11, [s1, #32]                  // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s12, [s1, #40]                  // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s13, [s1, #48]                  // out_ptr1: device_ptr64 at arg_base+48
    v.insert     v0, s6, #0
    v.insert     v1, s2, #0
    v.insert     v0, s6, #1
    v.insert     v1, s2, #1
    v.insert     v0, s6, #2
    v.insert     v1, s2, #2
    v.insert     v0, s6, #3
    v.insert     v1, s2, #3
    v.insert     v0, s6, #4
    v.insert     v1, s2, #4
    v.insert     v0, s6, #5
    v.insert     v1, s2, #5
    v.insert     v0, s6, #6
    v.insert     v1, s2, #6
    v.insert     v0, s6, #7
    v.insert     v1, s2, #7
    v.insert     v0, s6, #8
    v.insert     v1, s2, #8
    v.insert     v0, s6, #9
    v.insert     v1, s2, #9
    v.insert     v0, s6, #10
    v.insert     v1, s2, #10
    v.insert     v0, s6, #11
    v.insert     v1, s2, #11
    v.insert     v0, s6, #12
    v.insert     v1, s2, #12
    v.insert     v0, s6, #13
    v.insert     v1, s2, #13
    v.insert     v0, s6, #14
    v.insert     v1, s2, #14
    v.insert     v0, s6, #15
    v.insert     v1, s2, #15
    v.mov        v4, v3
for_1:
    s.cmp.ge     s1, s8, s4
    br.nz        s1, endfor_2
    v.splat      v3, s8
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s8
    v.splat      v7, s8
    v.extract    s1, v1, #0
    s.muli       s2, s8, #2
    s.muli       s6, s8, #2
    s.muli       s14, s8, #2
    v.add        v8, v3, v5
    v.movi       v3, #0
    v.splat      v9, s4
    v.add        v10, v6, v5
    v.add        v6, v7, v5
    v.extract    s15, v0, #0
    s.shli       s16, s1, #32
    v.extract    s1, v1, #1
    s.or         s17, s15, s16
    v.cmp.ge     p1, v8, v3
    v.cmp.lt     p2, v8, v9
    v.cmp.ge     p3, v10, v3
    v.cmp.lt     p4, v10, v9
    v.movi       v5, #0
    v.extract    s15, v0, #1
    s.shli       s16, s1, #32
    s.add        s1, s7, s2
    p.and        p5, p1, p2
    v.cmp.ge     p1, v6, v3
    s.add        s2, s10, s6
    p.and        p2, p3, p4
    v.cmp.lt     p3, v6, v9
    s.add        s6, s11, s14
    p.and        p4, p1, p3
    s.cmp.ge     s14, s17, s3
    s.or         s17, s15, s16
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v6, [s1, #0]
    v.extract    s1, v0, #2
    s.cmp.ge     s15, s17, s3
    v.splat      v7, s8
    v.extract    s16, v1, #2
    v.movi       v8, #128
    v.add        v9, v7, v2
    s.shli       s17, s16, #32
    s.or         s16, s1, s17
    v.cmp.lt     p1, v9, v8
    v.extract    s1, v1, #3
    v.extract    s17, v0, #3
    s.shli       s18, s1, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v7, [s2, #0]
    s.cmp.ge     s1, s16, s3
    v.extract    s2, v1, #4
    s.or         s16, s17, s18
    v.extract    s17, v0, #4
    s.shli       s18, s2, #32
    s.cmp.ge     s2, s16, s3
    s.or         s16, s17, s18
    vf.cvt.f16.f32 v8, v6
    v.extract    s17, v1, #5
    s.cmp.ge     s18, s16, s3
    s.shli       s16, s17, #32
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s6, #0]
    v.insert     v5, s14, #0
    v.extract    s6, v0, #5
    v.extract    s14, v0, #6
    v.insert     v5, s15, #1
    s.or         s15, s6, s16
    vf.cvt.f16.f32 v10, v7
    v.insert     v5, s1, #2
    v.extract    s1, v1, #6
    s.cmp.ge     s6, s15, s3
    v.insert     v5, s2, #3
    s.shli       s2, s1, #32
    v.extract    s1, v1, #7
    v.insert     v5, s18, #4
    s.or         s15, s14, s2
    v.extract    s2, v0, #7
    v.insert     v5, s6, #5
    s.shli       s6, s1, #32
    s.cmp.ge     s1, s15, s3
    s.or         s14, s2, s6
    v.insert     v5, s1, #6
    vf.cvt.f16.f32 v7, v6
    v.extract    s1, v1, #8
    v.extract    s2, v0, #8
    s.shli       s6, s1, #32
    s.cmp.ge     s1, s14, s3
    v.extract    s14, v1, #9
    s.or         s15, s2, s6
    v.insert     v5, s1, #7
    v.extract    s1, v0, #9
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #10
    s.or         s15, s1, s2
    v.insert     v5, s6, #8
    v.extract    s1, v0, #10
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #11
    s.or         s15, s1, s2
    v.insert     v5, s6, #9
    v.extract    s1, v0, #11
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #12
    s.or         s15, s1, s2
    v.insert     v5, s6, #10
    v.extract    s1, v0, #12
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #13
    s.or         s15, s1, s2
    v.insert     v5, s6, #11
    v.extract    s1, v0, #13
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #14
    s.or         s15, s1, s2
    v.insert     v5, s6, #12
    v.extract    s1, v0, #14
    s.shli       s2, s14, #32
    s.cmp.ge     s6, s15, s3
    v.extract    s14, v1, #15
    v.extract    s15, v1, #0
    s.or         s16, s1, s2
    v.insert     v5, s6, #13
    v.extract    s1, v0, #15
    s.shli       s2, s14, #32
    v.extract    s6, v0, #0
    s.shli       s14, s15, #32
    s.cmp.ge     s15, s16, s3
    v.extract    s16, v1, #1
    s.or         s17, s1, s2
    s.or         s1, s6, s14
    s.movz       s2, #512
    v.insert     v5, s15, #14
    v.movi       v6, #0
    v.extract    s6, v0, #1
    s.shli       s14, s16, #32
    s.cmp.ge     s15, s17, s3
    s.cmp.lt     s16, s1, s2
    v.extract    s1, v1, #2
    s.or         s17, s6, s14
    v.insert     v5, s15, #15
    v.insert     v6, s16, #0
    v.extract    s6, v0, #2
    s.shli       s14, s1, #32
    s.cmp.lt     s1, s17, s2
    v.extract    s15, v1, #3
    s.or         s16, s6, s14
    v.insert     v6, s1, #1
    v.extract    s1, v0, #3
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #4
    s.or         s16, s1, s6
    v.insert     v6, s14, #2
    v.extract    s1, v0, #4
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #5
    s.or         s16, s1, s6
    v.insert     v6, s14, #3
    v.extract    s1, v0, #5
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #6
    s.or         s16, s1, s6
    v.insert     v6, s14, #4
    v.extract    s1, v0, #6
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #7
    s.or         s16, s1, s6
    v.insert     v6, s14, #5
    v.extract    s1, v0, #7
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.cmp.ne     p2, v5, v3
    v.extract    s15, v1, #8
    s.or         s16, s1, s6
    v.insert     v6, s14, #6
    v.extract    s1, v0, #8
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #9
    s.or         s16, s1, s6
    v.insert     v6, s14, #7
    v.extract    s1, v0, #9
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #10
    s.or         s16, s1, s6
    v.insert     v6, s14, #8
    v.extract    s1, v0, #10
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #11
    s.or         s16, s1, s6
    v.insert     v6, s14, #9
    v.extract    s1, v0, #11
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #12
    s.or         s16, s1, s6
    v.insert     v6, s14, #10
    v.extract    s1, v0, #12
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #13
    s.or         s16, s1, s6
    v.insert     v6, s14, #11
    v.extract    s1, v0, #13
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #14
    s.or         s16, s1, s6
    v.insert     v6, s14, #12
    v.extract    s1, v0, #14
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    v.extract    s15, v1, #15
    s.or         s16, s1, s6
    v.insert     v6, s14, #13
    v.extract    s1, v0, #15
    s.shli       s6, s15, #32
    s.cmp.lt     s14, s16, s2
    s.or         s15, s1, s6
    v.insert     v6, s14, #14
    s.cmp.lt     s1, s15, s2
    v.movi       v5, #1
    v.insert     v6, s1, #15
    v.cmp.ne     p3, v6, v3
    p.and        p4, p2, p3
    @p4 v.sel        v6, v3, v5
    v.reduce.or  s1, v6
    s.cmp.eq     s2, s1, s3
    br.nz        s2, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s1, v1, #0
    v.extract    s2, v0, #0
    s.shli       s6, s1, #32
    v.extract    s1, v1, #1
    s.or         s14, s2, s6
    s.movz       s2, #128
    v.extract    s6, v0, #1
    s.shli       s15, s1, #32
    s.mul        s1, s14, s2
    v.extract    s14, v1, #2
    s.or         s16, s6, s15
    v.extract    s6, v0, #2
    s.shli       s15, s14, #32
    s.mul        s14, s16, s2
    v.extract    s16, v1, #3
    v.movi       v3, #0
    v.movi       v5, #0
    s.or         s17, s6, s15
    s.lshri      s6, s1, #32
    v.extract    s15, v0, #3
    s.shli       s18, s16, #32
    s.mul        s16, s17, s2
    v.insert     v3, s1, #0
    v.extract    s1, v1, #4
    v.insert     v5, s6, #0
    s.or         s6, s15, s18
    s.lshri      s15, s14, #32
    v.extract    s17, v0, #4
    s.shli       s18, s1, #32
    s.mul        s1, s6, s2
    v.insert     v3, s14, #1
    v.extract    s6, v1, #5
    v.insert     v5, s15, #1
    s.or         s14, s17, s18
    s.lshri      s15, s16, #32
    v.extract    s17, v0, #5
    s.shli       s18, s6, #32
    s.mul        s6, s14, s2
    v.insert     v3, s16, #2
    v.extract    s14, v1, #6
    v.insert     v5, s15, #2
    s.or         s15, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #6
    s.shli       s18, s14, #32
    s.mul        s14, s15, s2
    v.insert     v3, s1, #3
    v.extract    s1, v1, #7
    v.insert     v5, s16, #3
    s.or         s15, s17, s18
    s.lshri      s16, s6, #32
    v.extract    s17, v0, #7
    s.shli       s18, s1, #32
    s.mul        s1, s15, s2
    v.insert     v3, s6, #4
    v.extract    s6, v1, #8
    v.insert     v5, s16, #4
    s.or         s15, s17, s18
    s.lshri      s16, s14, #32
    v.extract    s17, v0, #8
    s.shli       s18, s6, #32
    s.mul        s6, s15, s2
    v.insert     v3, s14, #5
    v.extract    s14, v1, #9
    v.insert     v5, s16, #5
    s.or         s15, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #9
    s.shli       s18, s14, #32
    s.mul        s14, s15, s2
    v.insert     v3, s1, #6
    v.extract    s1, v1, #10
    v.insert     v5, s16, #6
    s.or         s15, s17, s18
    s.lshri      s16, s6, #32
    v.extract    s17, v0, #10
    s.shli       s18, s1, #32
    s.mul        s1, s15, s2
    v.insert     v3, s6, #7
    v.extract    s6, v1, #11
    v.insert     v5, s16, #7
    s.or         s15, s17, s18
    s.lshri      s16, s14, #32
    v.extract    s17, v0, #11
    s.shli       s18, s6, #32
    s.mul        s6, s15, s2
    v.insert     v3, s14, #8
    v.extract    s14, v1, #12
    v.insert     v5, s16, #8
    s.or         s15, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #12
    s.shli       s18, s14, #32
    s.mul        s14, s15, s2
    v.insert     v3, s1, #9
    v.extract    s1, v1, #13
    v.insert     v5, s16, #9
    s.or         s15, s17, s18
    s.lshri      s16, s6, #32
    v.extract    s17, v0, #13
    s.shli       s18, s1, #32
    s.mul        s1, s15, s2
    v.insert     v3, s6, #10
    v.extract    s6, v1, #14
    v.insert     v5, s16, #10
    s.or         s15, s17, s18
    s.lshri      s16, s14, #32
    v.extract    s17, v0, #14
    s.shli       s18, s6, #32
    s.mul        s6, s15, s2
    v.insert     v3, s14, #11
    v.extract    s14, v1, #15
    v.insert     v5, s16, #11
    s.or         s15, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #15
    s.shli       s18, s14, #32
    s.mul        s14, s15, s2
    v.insert     v3, s1, #12
    v.insert     v5, s16, #12
    s.or         s1, s17, s18
    s.lshri      s15, s6, #32
    v.extract    s16, v9, #0
    s.mul        s17, s1, s2
    v.insert     v3, s6, #13
    v.insert     v5, s15, #13
    s.shli       s1, s16, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #1
    s.ashri      s15, s1, #32
    v.insert     v3, s14, #14
    v.insert     v5, s2, #14
    v.movi       v6, #0
    v.movi       v11, #0
    s.shli       s1, s6, #32
    s.lshri      s2, s17, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v9, #2
    s.ashri      s16, s1, #32
    v.insert     v3, s17, #15
    v.insert     v5, s2, #15
    v.insert     v6, s15, #0
    v.insert     v11, s6, #0
    s.shli       s1, s14, #32
    s.lshri      s2, s16, #32
    v.extract    s6, v9, #3
    s.ashri      s14, s1, #32
    v.insert     v6, s16, #1
    v.insert     v11, s2, #1
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #4
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #2
    v.insert     v11, s2, #2
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #5
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #3
    v.insert     v11, s2, #3
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #6
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #4
    v.insert     v11, s2, #4
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #7
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #5
    v.insert     v11, s2, #5
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #8
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #6
    v.insert     v11, s2, #6
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #9
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #7
    v.insert     v11, s2, #7
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #10
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #8
    v.insert     v11, s2, #8
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #11
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #9
    v.insert     v11, s2, #9
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #12
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #10
    v.insert     v11, s2, #10
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #13
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #11
    v.insert     v11, s2, #11
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    v.extract    s6, v9, #14
    s.ashri      s15, s1, #32
    v.insert     v6, s14, #12
    v.insert     v11, s2, #12
    s.shli       s1, s6, #32
    s.lshri      s2, s15, #32
    v.extract    s6, v9, #15
    s.ashri      s14, s1, #32
    v.insert     v6, s15, #13
    v.insert     v11, s2, #13
    s.shli       s1, s6, #32
    s.lshri      s2, s14, #32
    s.ashri      s6, s1, #32
    v.insert     v6, s14, #14
    v.insert     v11, s2, #14
    s.lshri      s1, s6, #32
    v.insert     v6, s6, #15
    v.insert     v11, s1, #15
    v.extract    s1, v5, #0
    v.extract    s2, v6, #0
    v.extract    s6, v11, #0
    v.extract    s14, v3, #0
    s.shli       s15, s6, #32
    s.shli       s6, s1, #32
    v.extract    s1, v11, #1
    v.extract    s16, v5, #1
    s.or         s17, s2, s15
    s.or         s2, s14, s6
    v.movi       v9, #0
    v.extract    s6, v6, #1
    s.shli       s14, s1, #32
    v.extract    s1, v3, #1
    s.shli       s15, s16, #32
    s.add        s16, s17, s2
    v.extract    s2, v11, #2
    v.extract    s17, v5, #2
    s.or         s18, s6, s14
    s.or         s6, s1, s15
    v.movi       v12, #0
    v.insert     v9, s16, #0
    v.extract    s1, v6, #2
    s.shli       s14, s2, #32
    v.extract    s2, v3, #2
    s.shli       s15, s17, #32
    s.lshri      s17, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v11, #3
    s.or         s18, s1, s14
    v.extract    s1, v5, #3
    s.or         s14, s2, s15
    v.insert     v12, s17, #0
    v.insert     v9, s16, #1
    v.extract    s2, v6, #3
    s.shli       s15, s6, #32
    v.extract    s6, v3, #3
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #4
    s.or         s18, s2, s15
    v.extract    s2, v5, #4
    s.or         s15, s6, s17
    v.insert     v12, s1, #1
    v.insert     v9, s16, #2
    v.extract    s1, v6, #4
    s.shli       s6, s14, #32
    v.extract    s14, v3, #4
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #5
    s.or         s18, s1, s6
    v.extract    s1, v5, #5
    s.or         s6, s14, s17
    v.insert     v12, s2, #2
    v.insert     v9, s16, #3
    v.extract    s2, v6, #5
    s.shli       s14, s15, #32
    v.extract    s15, v3, #5
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v11, #6
    s.or         s18, s2, s14
    v.extract    s2, v5, #6
    s.or         s14, s15, s17
    v.insert     v12, s1, #3
    v.insert     v9, s16, #4
    v.extract    s1, v6, #6
    s.shli       s15, s6, #32
    v.extract    s6, v3, #6
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #7
    s.or         s18, s1, s15
    v.extract    s1, v5, #7
    s.or         s15, s6, s17
    v.insert     v12, s2, #4
    v.insert     v9, s16, #5
    v.extract    s2, v6, #7
    s.shli       s6, s14, #32
    v.extract    s14, v3, #7
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #8
    s.or         s18, s2, s6
    v.extract    s2, v5, #8
    s.or         s6, s14, s17
    v.insert     v12, s1, #5
    v.insert     v9, s16, #6
    v.extract    s1, v6, #8
    s.shli       s14, s15, #32
    v.extract    s15, v3, #8
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v11, #9
    s.or         s18, s1, s14
    v.extract    s1, v5, #9
    s.or         s14, s15, s17
    v.insert     v12, s2, #6
    v.insert     v9, s16, #7
    v.extract    s2, v6, #9
    s.shli       s15, s6, #32
    v.extract    s6, v3, #9
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #10
    s.or         s18, s2, s15
    v.extract    s2, v5, #10
    s.or         s15, s6, s17
    v.insert     v12, s1, #7
    v.insert     v9, s16, #8
    v.extract    s1, v6, #10
    s.shli       s6, s14, #32
    v.extract    s14, v3, #10
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #11
    s.or         s18, s1, s6
    v.extract    s1, v5, #11
    s.or         s6, s14, s17
    v.insert     v12, s2, #8
    v.insert     v9, s16, #9
    v.extract    s2, v6, #11
    s.shli       s14, s15, #32
    v.extract    s15, v3, #11
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v11, #12
    s.or         s18, s2, s14
    v.extract    s2, v5, #12
    s.or         s14, s15, s17
    v.insert     v12, s1, #9
    v.insert     v9, s16, #10
    v.extract    s1, v6, #12
    s.shli       s15, s6, #32
    v.extract    s6, v3, #12
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #13
    s.or         s18, s1, s15
    v.extract    s1, v5, #13
    s.or         s15, s6, s17
    v.insert     v12, s2, #10
    v.insert     v9, s16, #11
    v.extract    s2, v6, #13
    s.shli       s6, s14, #32
    v.extract    s14, v3, #13
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #14
    s.or         s18, s2, s6
    v.extract    s2, v5, #14
    s.or         s6, s14, s17
    v.insert     v12, s1, #11
    v.insert     v9, s16, #12
    v.extract    s1, v6, #14
    s.shli       s14, s15, #32
    v.extract    s15, v3, #14
    s.shli       s17, s2, #32
    s.lshri      s2, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v11, #15
    s.or         s18, s1, s14
    v.extract    s1, v5, #15
    s.or         s14, s15, s17
    v.insert     v12, s2, #12
    v.insert     v9, s16, #13
    v.extract    s2, v6, #15
    s.shli       s15, s6, #32
    v.extract    s6, v3, #15
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    s.or         s14, s2, s15
    s.or         s2, s6, s17
    v.insert     v12, s1, #13
    v.insert     v9, s16, #14
    s.lshri      s1, s16, #32
    s.add        s6, s14, s2
    v.insert     v12, s1, #14
    v.insert     v9, s6, #15
    v.movi       v3, #31
    s.lshri      s1, s6, #32
    v.movi       v5, #1
    v.insert     v12, s1, #15
    v.ashr       v6, v9, v3
    v.movi       v3, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v12, v6
    @p2 v.sel        v6, v5, v3
    v.reduce.or  s2, v6
    s.cmp.eq     s6, s2, s1
    br.nz        s6, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s9, v9]               // index is in elements (ISA sec 9.1)
    s.shli       s1, s8, #1                      // element offset -> bytes (x2)
    s.add        s2, s7, s1                      // &in_out_ptr0[...]
    s.movz       s1, #1
    vf.cvt.f16.f32 v5, v3
    vf.add       v3, v5, v8
    vf.add       v5, v3, v10
    vf.add       v3, v5, v7
    vf.mul       v5, v3, v3
    vf.cvt.f32.f16 v6, v3
    vf.add       v3, v4, v5
    @p1 v.st.h       [s2, #0], v6
    @p1 v.sel        v4, v3, v4
    s.add        s8, s8, s5
    br.nz        s1, for_1
endfor_2:
    .li       s1, #1124073472
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v2, v4
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0
    .li       s1, #925353388
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v2, v4
    .li       s1, #3204448256
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.addi       s1, s3, #0
    s.movz       s2, #1
    s.muli       s2, s1, #2
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    s.shli       s6, s1, #1                      // element offset -> bytes (x2)
    s.add        s8, s12, s3                     // &in_ptr4[...]
    s.add        s3, s13, s6                     // &out_ptr1[...]
    s.add        s6, s7, s2
    vf.fms       v4, v0, v3, v1
    vf.fms       v0, v3, v4, v3
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    vf.mul       v1, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v5
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v1, v1
    vf.mul       v4, v1, v2
    vf.fms       v2, v0, v3, v6
    vf.mul       v0, v4, v2                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s2, v2, #0
    v.splat      v0, s2
for_5:
    v.ld.h       v1, [s6, #0]
    v.ld.h       v2, [s8, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    vf.cvt.f16.f32 v3, v2
    vf.mul       v2, v1, v3
    vf.cvt.f32.f16 v1, v2
    v.st.h       [s3, #0], v1
    s.addi       s6, s6, #32                     // the next iteration's address
    s.addi       s8, s8, #32                     // the next iteration's address
    s.addi       s3, s3, #32                     // the next iteration's address
    s.add        s1, s1, s5
    s.cmp.lt     s2, s1, s4
    br.nz        s2, for_5
endfor_6:
    exit
    exit
