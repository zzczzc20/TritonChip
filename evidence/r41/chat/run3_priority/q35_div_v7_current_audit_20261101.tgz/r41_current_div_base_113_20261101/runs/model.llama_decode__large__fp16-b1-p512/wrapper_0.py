# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/fl/cfliubtv4ljbfbegbvsb4hkuvrqhkazzuepkarjtfepnbegge3u2.py
# Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[128256, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 128256), "index out of bounds: 0 <= tmp1 < 128256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 128256), "index out of bounds: 0 <= tmp10 < 128256")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 2048*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 2048.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/7f/c7ftxzjnezd2x7jytcxrcyhahlyx7lmnje3ee5glyrcpdlukirgg.py
# Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg7_1 : Tensor "f16[2048, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg7_1]
#   %embedding : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 2048]), kwargs = {})
#   %permute : Tensor "f16[2048, 2048][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg7_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/sj/csjxqve5pt5zm2wj7oacdgebc5ebrnwv65loz6ygfwarkcu6w54q.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_3
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg8_1 : Tensor "f16[512, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg8_1]
#   %view_3 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 2048]), kwargs = {})
#   %permute_2 : Tensor "f16[2048, 512][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[1, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 512
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 512*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/hj/chjqmorr47242gcbkmuuvagyejpkudsqcfei4r2zhxa225ffncgj.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 2048]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 32, 64][2048, 2048, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 32, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 32, 1, 64][2048, 64, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 32, 1, 32][1024, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6144}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/66/c66y6eik6asimlaquswjimhpcve7ct4hldft7yluqc5zzuhdt5p3.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 2048]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 32, 64][2048, 2048, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 32, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 32, 1, 64][2048, 64, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 32, 1, 32][1024, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6144}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/gh/cghxqfmhum5sdjntvab777yetm2ukvxp6cundrc35won46utidoq.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 512]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 8, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 8, 1, 32][256, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_5 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/fd/cfdmcp6qfpceql2i2vfppfc75ro5n4assfyoqk6hbmje2smiggbo.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 512]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 8, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 8, 1, 32][256, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ry/cryt7mungmlu6fdwvt5mqjjnbplfrhiaqoa7ympjijsap5pz2c6f.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem => select
#   k => permute_3
#   k_1 => add_2
#   k_2 => cat_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   view_1 => view_5
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_4 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 512]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 8, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %select : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 0), kwargs = {})
#   %mul_4 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_2 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select, %add_2], 2), kwargs = {})
#   return %buf10
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ms/cmsxhtsh5bixu6efqs3xodfuxnowudm72jq7k4pmrac6xuwv2rwq.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
# Source node to ATen node mapping:
#   k => permute_3
#   k_1 => add_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   stack => cat_64
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %arg2_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat_1 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %arg3_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %add_2 : Tensor "f16[1, 8, 1, 64][262656, 32832, 64, 1]tnca:0" = PlaceHolder[target=add_2]
#   %view_4 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 512]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 8, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_64 : Tensor "f16[16, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_2, %add_9, %add_16, %add_23, %add_30, %add_37, %add_44, %add_51, %add_58, %add_65, %add_72, %add_79, %add_86, %add_93, %add_100, %add_107],), kwargs = {})
#   return %add_2,%buf507
triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8 = async_compile.triton('triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6400}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2), xmask).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp6, xmask)
    tl.store(out_ptr1 + (x2), tmp6, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/gm/cgmizvser5nqiqkfzoznthd7eo34nniy463giek4v3ku7uoulpfi.py
# Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_6 => unsqueeze
#   k_3 => clone, view_9
#   linear => view_1
#   mul => mul_2
#   mul_1 => mul_3
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_11, view_12
#   q => permute_1
#   q_1 => add_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm]
#   %arg2_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat : Tensor "f16[1, 32, 1, 64][2048, 64, 64, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg3_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %cat_2 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0" = PlaceHolder[target=cat_2]
#   %view_1 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 2048]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 32, 64][2048, 2048, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 32, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 32, 1, 64][2048, 64, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 32, 1, 64][2048, 64, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.3535533905932738), kwargs = {})
#   %view_11 : Tensor "f32[32, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [32, 1, 64]), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 8, 1, 513, 64][262656, 32832, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 8, 4, 513, 64][262656, 32832, 0, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 8, 4, 513, 64]), kwargs = {})
#   %clone : Tensor "f16[1, 8, 4, 513, 64][1050624, 131328, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 32, 513, 64][1050624, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 32, 513, 64]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 32, 513, 64][1050624, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 32, 64, 513][1050624, 32832, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 32, 64, 513][1050624, 32832, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.3535533905932738), kwargs = {})
#   %view_12 : Tensor "f32[32, 64, 513][32832, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [32, 64, 513]), kwargs = {})
#   %bmm : Tensor "f32[32, 1, 513][513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32768, 'r0_': 64},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131328, 'r0_': 533760}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16416
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 513
    x0 = (xindex % 513)
    _tmp15 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 64*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr2 + (r0_2 + 64*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr3 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr4 + (r0_2 + 64*x0 + 32832*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp0 * tmp1
        tmp5 = tmp3 * tmp4
        tmp6 = tmp2 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tl.full([1], 0.3535533905932738, tl.float32)
        tmp9 = tmp7 * tmp8
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp11 * tmp8
        tmp13 = tmp9 * tmp12
        tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp16 = _tmp15 + tmp14
        _tmp15 = tl.where(r0_mask, tmp16, _tmp15)
    tmp15 = triton_helpers.promote_to_tensor(tl.sum(_tmp15, 0))
    tl.store(out_ptr0 + (x3), tmp15, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/te/cteeo5vvek2drlgjvfmijbygu5zwnamfiwn7olopiot4qo3qkqwo.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => amax, any_1, eq, exp, logical_not, sub, sum_1, view_13
# Graph fragment:
#   %bmm : Tensor "f32[32, 1, 513][513, 513, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 32, 1, 513][16416, 513, 16416, 1]tnca:0" = PlaceHolder[target=exp]
#   %view_13 : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 32, 1, 513]), kwargs = {})
#   %eq : Tensor "b8[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%view_13, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%view_13, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%view_13, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 320, 'r0_': 196992}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10(in_ptr0, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 513
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp11 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 513*x0), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.full([1], float("-inf"), tl.float32)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2 == 0
        tmp4 = tmp3.to(tl.int64)
        tmp5 = (tmp4 != 0)
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 | tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
        tmp10 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp12 = tl.maximum(_tmp11, tmp10, tl.PropagateNan.ALL)
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp9 = _tmp7.to(tl.int8)
    tmp7 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp9, 0))
    tmp11 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp11, 0))
    tl.store(out_ptr0 + (x0), tmp7, None)
    _tmp17 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 513*x0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp13 - tmp11
        tmp15 = libdevice.exp(tmp14)
        tmp16 = tl.broadcast_to(tmp15, [R0_BLOCK])
        tmp18 = _tmp17 + tmp16
        _tmp17 = tl.where(r0_mask, tmp18, _tmp17)
        tl.store(out_ptr2 + (r0_1 + 513*x0), tmp15, r0_mask)
    tmp17 = triton_helpers.promote_to_tensor(tl.sum(_tmp17, 0))
    tl.store(out_ptr3 + (x0), tmp17, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/v6/cv6p3yvz5y6p5pc65gqptvj5cjfmvp2spehz5idexzijpt7nqtl2.py
# Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   getitem_1 => select_1
#   linear_2 => view_7
#   v => permute_5
#   v_1 => cat_3
#   view_2 => view_8
# Graph fragment:
#   %mm_2 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %select_1 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg5_1, 0, 0), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 512]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 8, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_1, %permute_5], 2), kwargs = {})
#   return %buf20
triton_poi_fused__unsafe_view_cat_select_transpose_view_11 = async_compile.triton('triton_poi_fused__unsafe_view_cat_select_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_select_transpose_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_select_transpose_view_11(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/uw/cuw4cjd6ekxxkyaztsae4pljw5tpa7deywskbtbizs2bhcojawyc.py
# Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_7 => unsqueeze_1
#   o => bmm_1, convert_element_type_10, convert_element_type_11, div, full_default, logical_not_1, view_14, view_15, view_16, where
#   v_2 => clone_1, view_10
# Graph fragment:
#   %any_1 : Tensor "b8[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 32, 1, 513][16416, 513, 16416, 1]tnca:0" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=sum_1]
#   %cat_3 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %bmm_1 : Tensor "f32[32, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %logical_not_1 : Tensor "b8[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 32, 1, 513], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where : Tensor "f32[1, 32, 1, 513][16416, 513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default, %div), kwargs = {})
#   %view_14 : Tensor "f32[32, 1, 513][513, 513, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [32, 1, 513]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 8, 1, 513, 64][262656, 32832, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_3, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 8, 4, 513, 64][262656, 32832, 0, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 8, 4, 513, 64]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 8, 4, 513, 64][1050624, 131328, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 32, 513, 64][1050624, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 32, 513, 64]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 32, 513, 64][1050624, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[32, 513, 64][32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [32, 513, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[32, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   %view_16 : Tensor "f32[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 32, 1, 64]), kwargs = {})
#   %convert_element_type_11 : Tensor "f16[1, 32, 1, 64][2048, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float16), kwargs = {})
#   return %bmm_1,%convert_element_type_11
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 1024},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 533504, 'r0_': 65664}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 513
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 64)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.load(in_ptr1 + (r0_2 + 513*x1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp7 = tl.load(in_ptr3 + (x0 + 64*r0_2 + 32832*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tmp11.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp13, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/x2/cx2zytogm5zjupo4blvjdvdizf3pb3byw6glm7ddtaof2r374slh.py
# Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   x => embedding
#   x_1 => add_3
#   y => add_4, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[128256, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %buf25 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf25]
#   %arg11_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %embedding : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 2048]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg11_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf25,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 128256), "index out of bounds: 0 <= tmp1 < 128256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 128256), "index out of bounds: 0 <= tmp12 < 128256")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 2048*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 2048.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp23 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/wa/cwasvczebsqtwn4qvo6qlnh34agd2m3y3lcmygxqfk3ujca35xla.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_20
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg12_1 : Tensor "f16[8192, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg12_1]
#   %view_20 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 2048]), kwargs = {})
#   %permute_11 : Tensor "f16[2048, 8192][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg12_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[1, 8192][8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_20, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_14 = async_compile.triton('triton_tem_fused_mm_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_14', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_14(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 8192
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 8192*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 8192*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ve/cvezwt7yuwxzpryc7c6wp4tr4qcgytafjixkug3nznrozrvsuwos.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => mm_5, permute_12, view_22, view_23
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg13_1 : Tensor "f16[8192, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg13_1]
#   %mm_4 : Tensor "f16[1, 8192][8192, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[1, 8192][8192, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %view_21 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 8192]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 2048]), kwargs = {})
#   %permute_12 : Tensor "f16[2048, 8192][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg13_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[1, 8192][8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_12), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 8192]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 8192
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 8192*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 8192*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/bo/cbowugawmlmjjuq5mkxgu4e6momatk5z6uz2hofaner4dsytjw7n.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => view_23
#   linear_6 => mm_6, permute_13, view_24
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0" = PlaceHolder[target=mul_10]
#   %arg14_1 : Tensor "f16[2048, 8192][8192, 1]tnca:0" = PlaceHolder[target=arg14_1]
#   %view_21 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 8192]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 8192]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 8192][8192, 8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   %view_24 : Tensor "f16[1, 8192][8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [1, 8192]), kwargs = {})
#   %permute_13 : Tensor "f16[8192, 2048][1, 8192]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg14_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 8192
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 8192

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 8192*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 8192*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/kz/ckzguislszeqtcqd6kby4d53nao3tkl7d6fb3x6cnaqrnk7cuqfg.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   linear_6 => view_25
#   rms_norm_2 => add_7, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[128256, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %buf31 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf31]
#   %arg15_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg15_1]
#   %embedding : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 2048]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 2048]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_6, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg15_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf31,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 128256), "index out of bounds: 0 <= tmp1 < 128256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 128256), "index out of bounds: 0 <= tmp14 < 128256")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 2048*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 2048.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/qv/cqvksqurjtsj3rinvld4g2yzkaqymlhtmobtevizbdc2s3jemw7o.py
# Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_7 => mm_7, permute_14, view_26
# Graph fragment:
#   %convert_element_type_26 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_26]
#   %arg16_1 : Tensor "f16[2048, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg16_1]
#   %view_26 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_26, [1, 2048]), kwargs = {})
#   %permute_14 : Tensor "f16[2048, 2048][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg16_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_26, %permute_14), kwargs = {})
#   return %mm_7
triton_tem_fused_mm_t_view_18 = async_compile.triton('triton_tem_fused_mm_t_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_18', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_18(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ea/ceaugyv3r73wunyi6rqlzb4itsx7tq3encdlpwyj5fpolmbj3eqx.py
# Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_8 => select_2
#   k_4 => permute_17
#   k_5 => add_9
#   k_6 => cat_6
#   linear_8 => view_30
#   mul_7 => mul_15
#   mul_8 => mul_16
#   view_4 => view_31
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_30 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 512]), kwargs = {})
#   %view_31 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_30, [1, 1, 8, 64]), kwargs = {})
#   %permute_17 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_31, [0, 2, 1, 3]), kwargs = {})
#   %select_2 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 1), kwargs = {})
#   %mul_15 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_17, %arg2_1), kwargs = {})
#   %mul_16 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_5, %arg3_1), kwargs = {})
#   %add_9 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_15, %mul_16), kwargs = {})
#   %cat_6 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_2, %add_9], 2), kwargs = {})
#   return %buf41
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (262144 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/xh/cxhf7xqtmnkr3qdxow4cz2bzeekx6gygpuudiazdpzpsg33k4ctd.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   h_1 => view_45
#   linear_6 => view_25
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
#   x_3 => add_10
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[128256, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_10]
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_10]
#   %buf57 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf57]
#   %arg20_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg20_1]
#   %embedding : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 2048]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 2048]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %view_45 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 1, 2048]), kwargs = {})
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6, %view_45), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_10,%buf57,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 32768}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 128256), "index out of bounds: 0 <= tmp1 < 128256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp22 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp26, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/me/cmewctmzgels3flqqrhledy6d4wwkpvkvp6e2wk3wnzkggqyxh2i.py
# Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_11 => mm_11, permute_25, view_46
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %convert_element_type_41 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_41]
#   %arg21_1 : Tensor "f16[8192, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg21_1]
#   %convert_element_type_40 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   %view_46 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_41, [1, 2048]), kwargs = {})
#   %permute_25 : Tensor "f16[2048, 8192][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg21_1, [1, 0]), kwargs = {})
#   %mm_11 : Tensor "f16[1, 8192][8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_46, %permute_25), kwargs = {})
#   return %mm_11
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 8192
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 8192*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 8192*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/mb/cmbzschumaaird3tnjqzvu6y5uyzliuclmv66irxpbza2q44rs2i.py
# Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_51
#   rms_norm_4 => add_14, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_13
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %buf63 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf63]
#   %arg24_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg24_1]
#   %view_51 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 2048]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg24_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf63,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/f2/cf2qzrfddvfxlbap6jxekpffgtlseqthpmyrc4lq3gzhfyplpysg.py
# Topologically Sorted Source Nodes: [linear_15, view_7, k_8, getitem_16, mul_12, mul_13, k_9, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_16 => select_4
#   k_10 => cat_10
#   k_8 => permute_31
#   k_9 => add_16
#   linear_15 => view_56
#   mul_12 => mul_26
#   mul_13 => mul_27
#   view_7 => view_57
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_56 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 512]), kwargs = {})
#   %view_57 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_56, [1, 1, 8, 64]), kwargs = {})
#   %permute_31 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_57, [0, 2, 1, 3]), kwargs = {})
#   %select_4 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 2), kwargs = {})
#   %mul_26 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_31, %arg2_1), kwargs = {})
#   %mul_27 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_9, %arg3_1), kwargs = {})
#   %add_16 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_26, %mul_27), kwargs = {})
#   %cat_10 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_4, %add_16], 2), kwargs = {})
#   return %buf73
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (524288 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/vt/cvt5h4y6dkgnm24rmfx5zyeqinmuzd5ej3rbjvhvx66milwl5nye.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   x_4 => add_13
#   x_5 => add_17
#   y_2 => add_18, convert_element_type_65, convert_element_type_66, mean_5, mul_30, mul_31, pow_6, rsqrt_5
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %buf88 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf88]
#   %arg29_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg29_1]
#   %view_51 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 2048]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 2048]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %convert_element_type_65 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_17, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_65, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [2], True), kwargs = {})
#   %add_18 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_5, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_18,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_65, %rsqrt_5), kwargs = {})
#   %mul_31 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_30, %arg29_1), kwargs = {})
#   %convert_element_type_66 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_31, torch.float16), kwargs = {})
#   return %buf88,%convert_element_type_66
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 24576}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ht/cht5bj2iuygxhr34wa2k2pxwfbrl4jdogx2gkwhdddupxsnoj7sr.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   linear_20 => view_77
#   rms_norm_6 => add_21, convert_element_type_75, convert_element_type_76, mean_6, mul_33, mul_34, pow_7, rsqrt_6
#   x_4 => add_13
#   x_5 => add_17
#   x_6 => add_20
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %buf94 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf94]
#   %arg33_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg33_1]
#   %view_51 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 2048]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 2048]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 2048]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_77), kwargs = {})
#   %convert_element_type_75 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_20, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_75, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [2], True), kwargs = {})
#   %add_21 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_6, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_21,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_75, %rsqrt_6), kwargs = {})
#   %mul_34 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_33, %arg33_1), kwargs = {})
#   %convert_element_type_76 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_34, torch.float16), kwargs = {})
#   return %buf94,%convert_element_type_76
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 28672}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 2048.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp25 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/lm/clmfsgv25r5oavfcw6ewiqra66gstl3he3orinxvumkc6bhrnjgb.py
# Topologically Sorted Source Nodes: [linear_22, view_10, k_12, getitem_24, mul_17, mul_18, k_13, k_14], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_24 => select_6
#   k_12 => permute_45
#   k_13 => add_23
#   k_14 => cat_14
#   linear_22 => view_82
#   mul_17 => mul_37
#   mul_18 => mul_38
#   view_10 => view_83
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_82 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_22, [1, 1, 512]), kwargs = {})
#   %view_83 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_82, [1, 1, 8, 64]), kwargs = {})
#   %permute_45 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_83, [0, 2, 1, 3]), kwargs = {})
#   %select_6 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 3), kwargs = {})
#   %mul_37 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_45, %arg2_1), kwargs = {})
#   %mul_38 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_13, %arg3_1), kwargs = {})
#   %add_23 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_37, %mul_38), kwargs = {})
#   %cat_14 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_6, %add_23], 2), kwargs = {})
#   return %buf104
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (786432 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/dw/cdwcjgkkrowcylgsf7hbncsl3azbsmz46hv6spyymfusetv2mz2p.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   h_3 => view_97
#   linear_13 => view_51
#   linear_20 => view_77
#   x_4 => add_13
#   x_5 => add_17
#   x_6 => add_20
#   x_7 => add_24
#   y_3 => add_25, convert_element_type_90, convert_element_type_91, mean_7, mul_41, mul_42, pow_8, rsqrt_7
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_24 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %add_24 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_24]
#   %buf120 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf120]
#   %arg38_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg38_1]
#   %view_51 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 2048]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 2048]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 2048]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_77), kwargs = {})
#   %view_97 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 2048]), kwargs = {})
#   %add_24 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_97), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_24, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [2], True), kwargs = {})
#   %add_25 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_7, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_25,), kwargs = {})
#   %mul_41 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_7), kwargs = {})
#   %mul_42 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_41, %arg38_1), kwargs = {})
#   %convert_element_type_91 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_42, torch.float16), kwargs = {})
#   return %add_24,%buf120,%convert_element_type_91
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 40960}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ik/ciks3a5jnoknjxtdtbxuqb6xl43pge4shiunmp5l25ij7gfmhg4y.py
# Topologically Sorted Source Nodes: [linear_29, view_13, k_16, getitem_32, mul_22, mul_23, k_17, k_18], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_32 => select_8
#   k_16 => permute_59
#   k_17 => add_30
#   k_18 => cat_18
#   linear_29 => view_108
#   mul_22 => mul_48
#   mul_23 => mul_49
#   view_13 => view_109
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_108 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_29, [1, 1, 512]), kwargs = {})
#   %view_109 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_108, [1, 1, 8, 64]), kwargs = {})
#   %permute_59 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_109, [0, 2, 1, 3]), kwargs = {})
#   %select_8 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 4), kwargs = {})
#   %mul_48 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_59, %arg2_1), kwargs = {})
#   %mul_49 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_17, %arg3_1), kwargs = {})
#   %add_30 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_48, %mul_49), kwargs = {})
#   %cat_18 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_8, %add_30], 2), kwargs = {})
#   return %buf136
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (1048576 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/uu/cuuayfaw2n22yvkgziezbv73upwuw4j25myba57adlwo5igtr4t7.py
# Topologically Sorted Source Nodes: [linear_36, view_16, k_20, getitem_40, mul_27, mul_28, k_21, k_22], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_40 => select_10
#   k_20 => permute_73
#   k_21 => add_37
#   k_22 => cat_22
#   linear_36 => view_134
#   mul_27 => mul_59
#   mul_28 => mul_60
#   view_16 => view_135
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_134 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_36, [1, 1, 512]), kwargs = {})
#   %view_135 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_134, [1, 1, 8, 64]), kwargs = {})
#   %permute_73 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_135, [0, 2, 1, 3]), kwargs = {})
#   %select_10 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 5), kwargs = {})
#   %mul_59 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_73, %arg2_1), kwargs = {})
#   %mul_60 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_21, %arg3_1), kwargs = {})
#   %add_37 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_59, %mul_60), kwargs = {})
#   %cat_22 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_10, %add_37], 2), kwargs = {})
#   return %buf167
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (1310720 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/bn/cbn66mu5j65ganirq5t5vahqerhestaxrccjys2zh7v2hgn4j5oq.py
# Topologically Sorted Source Nodes: [linear_43, view_19, k_24, getitem_48, mul_32, mul_33, k_25, k_26], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_48 => select_12
#   k_24 => permute_87
#   k_25 => add_44
#   k_26 => cat_26
#   linear_43 => view_160
#   mul_32 => mul_70
#   mul_33 => mul_71
#   view_19 => view_161
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_160 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_43, [1, 1, 512]), kwargs = {})
#   %view_161 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_160, [1, 1, 8, 64]), kwargs = {})
#   %permute_87 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_161, [0, 2, 1, 3]), kwargs = {})
#   %select_12 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 6), kwargs = {})
#   %mul_70 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_87, %arg2_1), kwargs = {})
#   %mul_71 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_25, %arg3_1), kwargs = {})
#   %add_44 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_70, %mul_71), kwargs = {})
#   %cat_26 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_12, %add_44], 2), kwargs = {})
#   return %buf199
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (1572864 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/ky/cky4nv3aywd5hkrbpcl3qwlgrwohxitexmushps5lljnmaxhmgui.py
# Topologically Sorted Source Nodes: [linear_50, view_22, k_28, getitem_56, mul_37, mul_38, k_29, k_30], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_56 => select_14
#   k_28 => permute_101
#   k_29 => add_51
#   k_30 => cat_30
#   linear_50 => view_186
#   mul_37 => mul_81
#   mul_38 => mul_82
#   view_22 => view_187
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_186 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_50, [1, 1, 512]), kwargs = {})
#   %view_187 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_186, [1, 1, 8, 64]), kwargs = {})
#   %permute_101 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_187, [0, 2, 1, 3]), kwargs = {})
#   %select_14 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 7), kwargs = {})
#   %mul_81 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_101, %arg2_1), kwargs = {})
#   %mul_82 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_29, %arg3_1), kwargs = {})
#   %add_51 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_81, %mul_82), kwargs = {})
#   %cat_30 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_14, %add_51], 2), kwargs = {})
#   return %buf230
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (1835008 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/yk/cykhtr5k7b3fvwivrl2ky4ilhwrtje4jdynpsw4knwsmlrektrog.py
# Topologically Sorted Source Nodes: [linear_57, view_25, k_32, getitem_64, mul_42, mul_43, k_33, k_34], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_64 => select_16
#   k_32 => permute_115
#   k_33 => add_58
#   k_34 => cat_34
#   linear_57 => view_212
#   mul_42 => mul_92
#   mul_43 => mul_93
#   view_25 => view_213
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_212 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_57, [1, 1, 512]), kwargs = {})
#   %view_213 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_212, [1, 1, 8, 64]), kwargs = {})
#   %permute_115 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_213, [0, 2, 1, 3]), kwargs = {})
#   %select_16 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 8), kwargs = {})
#   %mul_92 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_115, %arg2_1), kwargs = {})
#   %mul_93 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_33, %arg3_1), kwargs = {})
#   %add_58 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_92, %mul_93), kwargs = {})
#   %cat_34 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_16, %add_58], 2), kwargs = {})
#   return %buf262
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (2097152 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/e4/ce4migflr53sk54s3sczrxdmxd5z2kkqvfijpo5p5dasrnsi3wox.py
# Topologically Sorted Source Nodes: [linear_64, view_28, k_36, getitem_72, mul_47, mul_48, k_37, k_38], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_72 => select_18
#   k_36 => permute_129
#   k_37 => add_65
#   k_38 => cat_38
#   linear_64 => view_238
#   mul_47 => mul_103
#   mul_48 => mul_104
#   view_28 => view_239
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_238 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_64, [1, 1, 512]), kwargs = {})
#   %view_239 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_238, [1, 1, 8, 64]), kwargs = {})
#   %permute_129 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_239, [0, 2, 1, 3]), kwargs = {})
#   %select_18 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 9), kwargs = {})
#   %mul_103 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_129, %arg2_1), kwargs = {})
#   %mul_104 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_37, %arg3_1), kwargs = {})
#   %add_65 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_104), kwargs = {})
#   %cat_38 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_18, %add_65], 2), kwargs = {})
#   return %buf293
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (2359296 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/uv/cuvzo2qjmxmzjazy2qru6obyxhkvulxeyf4qzqnpgnlgv5hqeld3.py
# Topologically Sorted Source Nodes: [linear_71, view_31, k_40, getitem_80, mul_52, mul_53, k_41, k_42], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_80 => select_20
#   k_40 => permute_143
#   k_41 => add_72
#   k_42 => cat_42
#   linear_71 => view_264
#   mul_52 => mul_114
#   mul_53 => mul_115
#   view_31 => view_265
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_264 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_71, [1, 1, 512]), kwargs = {})
#   %view_265 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_264, [1, 1, 8, 64]), kwargs = {})
#   %permute_143 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_265, [0, 2, 1, 3]), kwargs = {})
#   %select_20 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 10), kwargs = {})
#   %mul_114 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_143, %arg2_1), kwargs = {})
#   %mul_115 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_41, %arg3_1), kwargs = {})
#   %add_72 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_114, %mul_115), kwargs = {})
#   %cat_42 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_20, %add_72], 2), kwargs = {})
#   return %buf325
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (2621440 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/bd/cbdwcmns6mt5iiszbuhkcd26w67fukzxocxg5z362pomyz67yuun.py
# Topologically Sorted Source Nodes: [linear_78, view_34, k_44, getitem_88, mul_57, mul_58, k_45, k_46], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_88 => select_22
#   k_44 => permute_157
#   k_45 => add_79
#   k_46 => cat_46
#   linear_78 => view_290
#   mul_57 => mul_125
#   mul_58 => mul_126
#   view_34 => view_291
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_290 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_78, [1, 1, 512]), kwargs = {})
#   %view_291 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_290, [1, 1, 8, 64]), kwargs = {})
#   %permute_157 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_291, [0, 2, 1, 3]), kwargs = {})
#   %select_22 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 11), kwargs = {})
#   %mul_125 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_157, %arg2_1), kwargs = {})
#   %mul_126 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_45, %arg3_1), kwargs = {})
#   %add_79 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_125, %mul_126), kwargs = {})
#   %cat_46 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_22, %add_79], 2), kwargs = {})
#   return %buf356
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (2883584 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/je/cjey4phxtfyd2kev3tzkjdq64q6fzowebdi6zzvrmcncftmzmzxw.py
# Topologically Sorted Source Nodes: [linear_85, view_37, k_48, getitem_96, mul_62, mul_63, k_49, k_50], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_96 => select_24
#   k_48 => permute_171
#   k_49 => add_86
#   k_50 => cat_50
#   linear_85 => view_316
#   mul_62 => mul_136
#   mul_63 => mul_137
#   view_37 => view_317
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_316 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_85, [1, 1, 512]), kwargs = {})
#   %view_317 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_316, [1, 1, 8, 64]), kwargs = {})
#   %permute_171 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_317, [0, 2, 1, 3]), kwargs = {})
#   %select_24 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 12), kwargs = {})
#   %mul_136 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_171, %arg2_1), kwargs = {})
#   %mul_137 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_49, %arg3_1), kwargs = {})
#   %add_86 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_136, %mul_137), kwargs = {})
#   %cat_50 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_24, %add_86], 2), kwargs = {})
#   return %buf388
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (3145728 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/bi/cbiotjxdlleurk5psr6oetoag7ho2xsttcmf2qd6mhxqpj23gl3t.py
# Topologically Sorted Source Nodes: [linear_92, view_40, k_52, getitem_104, mul_67, mul_68, k_53, k_54], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_104 => select_26
#   k_52 => permute_185
#   k_53 => add_93
#   k_54 => cat_54
#   linear_92 => view_342
#   mul_67 => mul_147
#   mul_68 => mul_148
#   view_40 => view_343
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_342 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_92, [1, 1, 512]), kwargs = {})
#   %view_343 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_342, [1, 1, 8, 64]), kwargs = {})
#   %permute_185 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_343, [0, 2, 1, 3]), kwargs = {})
#   %select_26 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 13), kwargs = {})
#   %mul_147 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_185, %arg2_1), kwargs = {})
#   %mul_148 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_53, %arg3_1), kwargs = {})
#   %add_93 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_147, %mul_148), kwargs = {})
#   %cat_54 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_26, %add_93], 2), kwargs = {})
#   return %buf419
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (3407872 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/2c/c2c66enl4ovuw4gxxrmd3x6d2vh7h6u4h2dnyupmp4nlnfheu2l3.py
# Topologically Sorted Source Nodes: [linear_99, view_43, k_56, getitem_112, mul_72, mul_73, k_57, k_58], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_112 => select_28
#   k_56 => permute_199
#   k_57 => add_100
#   k_58 => cat_58
#   linear_99 => view_368
#   mul_72 => mul_158
#   mul_73 => mul_159
#   view_43 => view_369
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_368 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_99, [1, 1, 512]), kwargs = {})
#   %view_369 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_368, [1, 1, 8, 64]), kwargs = {})
#   %permute_199 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_369, [0, 2, 1, 3]), kwargs = {})
#   %select_28 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 14), kwargs = {})
#   %mul_158 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_199, %arg2_1), kwargs = {})
#   %mul_159 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_57, %arg3_1), kwargs = {})
#   %add_100 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_158, %mul_159), kwargs = {})
#   %cat_58 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_28, %add_100], 2), kwargs = {})
#   return %buf451
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (3670016 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/oh/cohxmnzkd5ww35jp4x2xnougc5i3ekhrgovh7e3ycwlj77phopic.py
# Topologically Sorted Source Nodes: [linear_106, view_46, k_60, getitem_120, mul_77, mul_78, k_61, k_62], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_120 => select_30
#   k_60 => permute_213
#   k_61 => add_107
#   k_62 => cat_62
#   linear_106 => view_394
#   mul_77 => mul_169
#   mul_78 => mul_170
#   view_46 => view_395
# Graph fragment:
#   %arg4_1 : Tensor "f16[16, 1, 8, 512, 64][262144, 262144, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_394 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_106, [1, 1, 512]), kwargs = {})
#   %view_395 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_394, [1, 1, 8, 64]), kwargs = {})
#   %permute_213 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_395, [0, 2, 1, 3]), kwargs = {})
#   %select_30 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 15), kwargs = {})
#   %mul_169 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_213, %arg2_1), kwargs = {})
#   %mul_170 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_61, %arg3_1), kwargs = {})
#   %add_107 : Tensor "f16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_169, %mul_170), kwargs = {})
#   %cat_62 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_30, %add_107], 2), kwargs = {})
#   return %buf482
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    tmp0 = tl.load(in_ptr0 + (3932160 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/6w/c6w3nyrr5okvqaqlcmqrq3imohumouhyztec7j7ozdpgbokbxqbv.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, getitem_121, linear_107, view_47, v_45, v_46, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
# Source node to ATen node mapping:
#   getitem_121 => select_31
#   linear_100 => view_371
#   linear_107 => view_397
#   linear_16 => view_59
#   linear_2 => view_7
#   linear_23 => view_85
#   linear_30 => view_111
#   linear_37 => view_137
#   linear_44 => view_163
#   linear_51 => view_189
#   linear_58 => view_215
#   linear_65 => view_241
#   linear_72 => view_267
#   linear_79 => view_293
#   linear_86 => view_319
#   linear_9 => view_33
#   linear_93 => view_345
#   stack_1 => cat_65
#   v => permute_5
#   v_12 => permute_61
#   v_15 => permute_75
#   v_18 => permute_89
#   v_21 => permute_103
#   v_24 => permute_117
#   v_27 => permute_131
#   v_3 => permute_19
#   v_30 => permute_145
#   v_33 => permute_159
#   v_36 => permute_173
#   v_39 => permute_187
#   v_42 => permute_201
#   v_45 => permute_215
#   v_46 => cat_63
#   v_6 => permute_33
#   v_9 => permute_47
#   view_11 => view_86
#   view_14 => view_112
#   view_17 => view_138
#   view_2 => view_8
#   view_20 => view_164
#   view_23 => view_190
#   view_26 => view_216
#   view_29 => view_242
#   view_32 => view_268
#   view_35 => view_294
#   view_38 => view_320
#   view_41 => view_346
#   view_44 => view_372
#   view_47 => view_398
#   view_5 => view_34
#   view_8 => view_60
# Graph fragment:
#   %mm_107 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_107]
#   %view_7 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 512]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 8, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 512]), kwargs = {})
#   %view_34 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 1, 8, 64]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %view_59 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 512]), kwargs = {})
#   %view_60 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_59, [1, 1, 8, 64]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_60, [0, 2, 1, 3]), kwargs = {})
#   %view_85 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 512]), kwargs = {})
#   %view_86 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_85, [1, 1, 8, 64]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_86, [0, 2, 1, 3]), kwargs = {})
#   %view_111 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_30, [1, 1, 512]), kwargs = {})
#   %view_112 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_111, [1, 1, 8, 64]), kwargs = {})
#   %permute_61 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_112, [0, 2, 1, 3]), kwargs = {})
#   %view_137 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_37, [1, 1, 512]), kwargs = {})
#   %view_138 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_137, [1, 1, 8, 64]), kwargs = {})
#   %permute_75 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_138, [0, 2, 1, 3]), kwargs = {})
#   %view_163 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_44, [1, 1, 512]), kwargs = {})
#   %view_164 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_163, [1, 1, 8, 64]), kwargs = {})
#   %permute_89 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_164, [0, 2, 1, 3]), kwargs = {})
#   %view_189 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_51, [1, 1, 512]), kwargs = {})
#   %view_190 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_189, [1, 1, 8, 64]), kwargs = {})
#   %permute_103 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_190, [0, 2, 1, 3]), kwargs = {})
#   %view_215 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_58, [1, 1, 512]), kwargs = {})
#   %view_216 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_215, [1, 1, 8, 64]), kwargs = {})
#   %permute_117 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_216, [0, 2, 1, 3]), kwargs = {})
#   %view_241 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_65, [1, 1, 512]), kwargs = {})
#   %view_242 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_241, [1, 1, 8, 64]), kwargs = {})
#   %permute_131 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_242, [0, 2, 1, 3]), kwargs = {})
#   %view_267 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_72, [1, 1, 512]), kwargs = {})
#   %view_268 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_267, [1, 1, 8, 64]), kwargs = {})
#   %permute_145 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_268, [0, 2, 1, 3]), kwargs = {})
#   %view_293 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_79, [1, 1, 512]), kwargs = {})
#   %view_294 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_293, [1, 1, 8, 64]), kwargs = {})
#   %permute_159 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_294, [0, 2, 1, 3]), kwargs = {})
#   %view_319 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_86, [1, 1, 512]), kwargs = {})
#   %view_320 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_319, [1, 1, 8, 64]), kwargs = {})
#   %permute_173 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_320, [0, 2, 1, 3]), kwargs = {})
#   %view_345 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_93, [1, 1, 512]), kwargs = {})
#   %view_346 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_345, [1, 1, 8, 64]), kwargs = {})
#   %permute_187 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_346, [0, 2, 1, 3]), kwargs = {})
#   %view_371 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_100, [1, 1, 512]), kwargs = {})
#   %view_372 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_371, [1, 1, 8, 64]), kwargs = {})
#   %permute_201 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_372, [0, 2, 1, 3]), kwargs = {})
#   %select_31 : Tensor "f16[1, 8, 512, 64][262144, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg5_1, 0, 15), kwargs = {})
#   %view_397 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_107, [1, 1, 512]), kwargs = {})
#   %view_398 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_397, [1, 1, 8, 64]), kwargs = {})
#   %permute_215 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_398, [0, 2, 1, 3]), kwargs = {})
#   %cat_63 : Tensor "f16[1, 8, 513, 64][262656, 32832, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_31, %permute_215], 2), kwargs = {})
#   %cat_65 : Tensor "f16[16, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19, %permute_33, %permute_47, %permute_61, %permute_75, %permute_89, %permute_103, %permute_117, %permute_131, %permute_145, %permute_159, %permute_173, %permute_187, %permute_201, %permute_215],), kwargs = {})
#   return %buf492,%buf539
triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_40 = async_compile.triton('triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_40', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_40', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 5120}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_40(in_ptr0, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32832*x1), tmp0, xmask)
    tl.store(out_ptr1 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/he/chenrv52jcrfjy7yjbog5bni5hlfpoonndlhio3b2airpbs672cv.py
# Topologically Sorted Source Nodes: [linear_111, x_32, rms_norm_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_111 => view_415
#   rms_norm_32 => add_112, convert_element_type_400, convert_element_type_401, mean_32, mul_176, mul_177, pow_33, rsqrt_32
#   x_32 => add_111
# Graph fragment:
#   %add_108 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_108]
#   %mm_111 : Tensor "f16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_111]
#   %buf504 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf504]
#   %arg150_1 : Tensor "f16[2048][1]tnca:0" = PlaceHolder[target=arg150_1]
#   %view_415 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [1, 1, 2048]), kwargs = {})
#   %add_111 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_108, %view_415), kwargs = {})
#   %convert_element_type_400 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_111, torch.float32), kwargs = {})
#   %pow_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_400, 2), kwargs = {})
#   %mean_32 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_33, [2], True), kwargs = {})
#   %add_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_32, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_32 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_112,), kwargs = {})
#   %mul_176 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_400, %rsqrt_32), kwargs = {})
#   %mul_177 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_176, %arg150_1), kwargs = {})
#   %convert_element_type_401 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_177, torch.float16), kwargs = {})
#   return %buf504,%convert_element_type_401
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_41 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_41', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_41', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_41(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/hi/chipiilw47thvwsschkunmwylnvqc7n764oufqqnlnntvm4k77we.py
# Topologically Sorted Source Nodes: [linear_111, x_32, rms_norm_32, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_111 => view_415
#   linear_112 => mm_112, permute_224, view_416
#   rms_norm_32 => add_112, convert_element_type_400, convert_element_type_401, mean_32, mul_176, mul_177, pow_33, rsqrt_32
#   x_32 => add_111
# Graph fragment:
#   %convert_element_type_401 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_401]
#   %arg151_1 : Tensor "f16[128256, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg151_1]
#   %view_415 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [1, 1, 2048]), kwargs = {})
#   %add_111 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_108, %view_415), kwargs = {})
#   %convert_element_type_400 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_111, torch.float32), kwargs = {})
#   %pow_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_400, 2), kwargs = {})
#   %mean_32 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_33, [2], True), kwargs = {})
#   %add_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_32, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_32 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_112,), kwargs = {})
#   %mul_176 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_400, %rsqrt_32), kwargs = {})
#   %mul_177 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_176, %arg150_1), kwargs = {})
#   %convert_element_type_401 : Tensor "f16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_177, torch.float16), kwargs = {})
#   %view_416 : Tensor "f16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_401, [1, 2048]), kwargs = {})
#   %permute_224 : Tensor "f16[2048, 128256][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg151_1, [1, 0]), kwargs = {})
#   %mm_112 : Tensor "f16[1, 128256][128256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_416, %permute_224), kwargs = {})
#   return %mm_112
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_42 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_42', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_42', 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_42(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128256
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_current_div_base_113_20261101/runs/model.llama_decode__large__fp16-b1-p512/inductor_cache/hf/chfrm6gjnpl2dnuuqdfe6lng4rt4wy5bufdkc44dxmr7dtbavc4c.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
# Source node to ATen node mapping:
#   linear_100 => view_371
#   linear_107 => view_397
#   linear_16 => view_59
#   linear_2 => view_7
#   linear_23 => view_85
#   linear_30 => view_111
#   linear_37 => view_137
#   linear_44 => view_163
#   linear_51 => view_189
#   linear_58 => view_215
#   linear_65 => view_241
#   linear_72 => view_267
#   linear_79 => view_293
#   linear_86 => view_319
#   linear_9 => view_33
#   linear_93 => view_345
#   stack_1 => cat_65
#   v => permute_5
#   v_12 => permute_61
#   v_15 => permute_75
#   v_18 => permute_89
#   v_21 => permute_103
#   v_24 => permute_117
#   v_27 => permute_131
#   v_3 => permute_19
#   v_30 => permute_145
#   v_33 => permute_159
#   v_36 => permute_173
#   v_39 => permute_187
#   v_42 => permute_201
#   v_45 => permute_215
#   v_6 => permute_33
#   v_9 => permute_47
#   view_11 => view_86
#   view_14 => view_112
#   view_17 => view_138
#   view_2 => view_8
#   view_20 => view_164
#   view_23 => view_190
#   view_26 => view_216
#   view_29 => view_242
#   view_32 => view_268
#   view_35 => view_294
#   view_38 => view_320
#   view_41 => view_346
#   view_44 => view_372
#   view_47 => view_398
#   view_5 => view_34
#   view_8 => view_60
# Graph fragment:
#   %mm_2 : Tensor "f16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 512]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 8, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 512]), kwargs = {})
#   %view_34 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 1, 8, 64]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %view_59 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 512]), kwargs = {})
#   %view_60 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_59, [1, 1, 8, 64]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_60, [0, 2, 1, 3]), kwargs = {})
#   %view_85 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 512]), kwargs = {})
#   %view_86 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_85, [1, 1, 8, 64]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_86, [0, 2, 1, 3]), kwargs = {})
#   %view_111 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_30, [1, 1, 512]), kwargs = {})
#   %view_112 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_111, [1, 1, 8, 64]), kwargs = {})
#   %permute_61 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_112, [0, 2, 1, 3]), kwargs = {})
#   %view_137 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_37, [1, 1, 512]), kwargs = {})
#   %view_138 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_137, [1, 1, 8, 64]), kwargs = {})
#   %permute_75 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_138, [0, 2, 1, 3]), kwargs = {})
#   %view_163 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_44, [1, 1, 512]), kwargs = {})
#   %view_164 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_163, [1, 1, 8, 64]), kwargs = {})
#   %permute_89 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_164, [0, 2, 1, 3]), kwargs = {})
#   %view_189 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_51, [1, 1, 512]), kwargs = {})
#   %view_190 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_189, [1, 1, 8, 64]), kwargs = {})
#   %permute_103 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_190, [0, 2, 1, 3]), kwargs = {})
#   %view_215 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_58, [1, 1, 512]), kwargs = {})
#   %view_216 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_215, [1, 1, 8, 64]), kwargs = {})
#   %permute_117 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_216, [0, 2, 1, 3]), kwargs = {})
#   %view_241 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_65, [1, 1, 512]), kwargs = {})
#   %view_242 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_241, [1, 1, 8, 64]), kwargs = {})
#   %permute_131 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_242, [0, 2, 1, 3]), kwargs = {})
#   %view_267 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_72, [1, 1, 512]), kwargs = {})
#   %view_268 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_267, [1, 1, 8, 64]), kwargs = {})
#   %permute_145 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_268, [0, 2, 1, 3]), kwargs = {})
#   %view_293 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_79, [1, 1, 512]), kwargs = {})
#   %view_294 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_293, [1, 1, 8, 64]), kwargs = {})
#   %permute_159 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_294, [0, 2, 1, 3]), kwargs = {})
#   %view_319 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_86, [1, 1, 512]), kwargs = {})
#   %view_320 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_319, [1, 1, 8, 64]), kwargs = {})
#   %permute_173 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_320, [0, 2, 1, 3]), kwargs = {})
#   %view_345 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_93, [1, 1, 512]), kwargs = {})
#   %view_346 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_345, [1, 1, 8, 64]), kwargs = {})
#   %permute_187 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_346, [0, 2, 1, 3]), kwargs = {})
#   %view_371 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_100, [1, 1, 512]), kwargs = {})
#   %view_372 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_371, [1, 1, 8, 64]), kwargs = {})
#   %permute_201 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_372, [0, 2, 1, 3]), kwargs = {})
#   %view_397 : Tensor "f16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_107, [1, 1, 512]), kwargs = {})
#   %view_398 : Tensor "f16[1, 1, 8, 64][512, 512, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_397, [1, 1, 8, 64]), kwargs = {})
#   %permute_215 : Tensor "f16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_398, [0, 2, 1, 3]), kwargs = {})
#   %cat_65 : Tensor "f16[16, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19, %permute_33, %permute_47, %permute_61, %permute_75, %permute_89, %permute_103, %permute_117, %permute_131, %permute_145, %permute_159, %permute_173, %permute_187, %permute_201, %permute_215],), kwargs = {})
#   return %buf524
triton_poi_fused__unsafe_view_stack_transpose_view_43 = async_compile.triton('triton_poi_fused__unsafe_view_stack_transpose_view_43', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_stack_transpose_view_43', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': '1208D50BFD4C3317B29921A4309ECCE0DDAD0DD97AD7A15F9925508BF5279B49', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_stack_transpose_view_43(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp0, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg6_1), ((1, 1), (128256, 2048), (2048, )), ((1, 1), (2048, 1), (1, )), 'input')
        buf1 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg6_1, buf1, 1, 2048, stream=raw_stream0)
        del arg6_1
        assert_size_stride(arg7_1, (2048, 2048), (2048, 1), 'input')
        buf2 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg7_1, buf2, 128, 1, 1, stream=raw_stream0)
        del arg7_1
        assert_size_stride(arg8_1, (512, 2048), (2048, 1), 'input')
        buf3 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg8_1, buf3, 32, 1, 1, stream=raw_stream0)
        del arg8_1
        buf6 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf4 = reinterpret_tensor(buf6, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf2, buf4, 1024, stream=raw_stream0)
        buf5 = reinterpret_tensor(buf6, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf2, buf5, 1024, stream=raw_stream0)
        buf9 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf3, buf7, 256, stream=raw_stream0)
        del buf4
        del buf5
        buf8 = reinterpret_tensor(buf9, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf3, buf8, 256, stream=raw_stream0)
        assert_size_stride(arg4_1, (16, 1, 8, 512, 64), (262144, 262144, 32768, 64, 1), 'input')
        buf12 = empty_strided((1, 8, 513, 64), (262656, 32832, 64, 1), device='tnca', dtype=torch.float16)
        buf10 = reinterpret_tensor(buf12, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg4_1, buf10, 262144, stream=raw_stream0)
        del buf7
        del buf8
        assert_size_stride_grouped((arg2_1, arg3_1), ((1, 64), (1, 64)), ((64, 1), (64, 1)), 'input')
        buf11 = reinterpret_tensor(buf12, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf523 = empty_strided((16, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf507 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf3, arg2_1, buf9, arg3_1, buf11, buf507, 512, stream=raw_stream0)
        buf13 = empty_strided((32, 1, 513), (513, 513, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf2, arg2_1, buf6, arg3_1, buf12, buf13, 16416, 64, stream=raw_stream0)
        del buf10
        del buf11
        buf14 = empty_strided((1, 32, 1, 1), (32, 1, 32, 32), device='tnca', dtype=torch.bool)
        buf16 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf17 = empty_strided((1, 32, 1, 1), (32, 1, 32, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf13, buf14, buf16, buf17, 32, 513, stream=raw_stream0)
        del buf13
        assert_size_stride(arg9_1, (512, 2048), (2048, 1), 'input')
        buf18 = reinterpret_tensor(buf9, (1, 512), (512, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg9_1, buf18, 32, 1, 1, stream=raw_stream0)
        del arg9_1
        assert_size_stride(arg5_1, (16, 1, 8, 512, 64), (262144, 262144, 32768, 64, 1), 'input')
        buf21 = buf12; del buf12  # reuse
        buf19 = reinterpret_tensor(buf21, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg5_1, buf19, 262144, stream=raw_stream0)
        buf20 = reinterpret_tensor(buf21, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf18, buf20, 512, stream=raw_stream0)
        buf23 = reinterpret_tensor(buf1, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf14, buf16, buf17, buf21, buf23, 2048, 513, stream=raw_stream0)
        del buf19
        del buf20
        assert_size_stride(arg10_1, (2048, 2048), (2048, 1), 'input')
        buf24 = reinterpret_tensor(buf6, (1, 2048), (2048, 1), 0); del buf6  # reuse
        # Topologically Sorted Source Nodes: [o, transpose_3, o_1, h], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf23, arg10_1, buf24, 128, 1, 1, stream=raw_stream0)
        del arg10_1
        assert_size_stride(arg11_1, (2048, ), (1, ), 'input')
        buf26 = reinterpret_tensor(buf23, (1, 1, 2048), (2048, 2048, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13.run(arg1_1, arg0_1, buf24, arg11_1, buf26, 1, 2048, stream=raw_stream0)
        del arg11_1
        assert_size_stride(arg12_1, (8192, 2048), (2048, 1), 'input')
        buf27 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf26, arg12_1, buf27, 512, 1, 1, stream=raw_stream0)
        del arg12_1
        assert_size_stride(arg13_1, (8192, 2048), (2048, 1), 'input')
        buf29 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf26, arg13_1, buf27, buf29, 512, 1, 1, stream=raw_stream0)
        del arg13_1
        del buf27
        assert_size_stride(arg14_1, (2048, 8192), (8192, 1), 'input')
        buf30 = reinterpret_tensor(buf26, (1, 2048), (2048, 1), 0); del buf26  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf29, arg14_1, buf30, 128, 1, 1, stream=raw_stream0)
        del arg14_1
        assert_size_stride(arg15_1, (2048, ), (1, ), 'input')
        buf32 = reinterpret_tensor(buf2, (1, 1, 2048), (2048, 2048, 1), 0); del buf2  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg1_1, arg0_1, buf24, buf30, arg15_1, buf32, 1, 2048, stream=raw_stream0)
        del arg15_1
        assert_size_stride(arg16_1, (2048, 2048), (2048, 1), 'input')
        buf33 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf32, arg16_1, buf33, 128, 1, 1, stream=raw_stream0)
        del arg16_1
        assert_size_stride(arg17_1, (512, 2048), (2048, 1), 'input')
        buf34 = buf3; del buf3  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg17_1, buf34, 32, 1, 1, stream=raw_stream0)
        del arg17_1
        buf37 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf35 = reinterpret_tensor(buf37, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf33, buf35, 1024, stream=raw_stream0)
        buf36 = reinterpret_tensor(buf37, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2, cat_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf33, buf36, 1024, stream=raw_stream0)
        buf40 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf38 = reinterpret_tensor(buf40, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf34, buf38, 256, stream=raw_stream0)
        del buf35
        del buf36
        buf39 = reinterpret_tensor(buf40, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf34, buf39, 256, stream=raw_stream0)
        buf43 = buf21; del buf21  # reuse
        buf41 = reinterpret_tensor(buf43, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg4_1, buf41, 262144, stream=raw_stream0)
        del buf38
        del buf39
        buf42 = reinterpret_tensor(buf43, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf508 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 512)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, mul_7, mul_8, k_5, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf34, arg2_1, buf40, arg3_1, buf42, buf508, 512, stream=raw_stream0)
        buf44 = reinterpret_tensor(buf16, (32, 1, 513), (513, 513, 1), 0); del buf16  # reuse
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, mul_5, mul_6, q_3, o_2, getitem_14, expand_2, k_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf33, arg2_1, buf37, arg3_1, buf43, buf44, 16416, 64, stream=raw_stream0)
        del buf41
        del buf42
        buf45 = buf14; del buf14  # reuse
        buf47 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf48 = buf17; del buf17  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf44, buf45, buf47, buf48, 32, 513, stream=raw_stream0)
        del buf44
        assert_size_stride(arg18_1, (512, 2048), (2048, 1), 'input')
        buf49 = reinterpret_tensor(buf40, (1, 512), (512, 1), 0); del buf40  # reuse
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg18_1, buf49, 32, 1, 1, stream=raw_stream0)
        del arg18_1
        buf52 = buf43; del buf43  # reuse
        buf50 = reinterpret_tensor(buf52, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_9, linear_9, view_5, v_3, v_4], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg5_1, buf50, 262144, stream=raw_stream0)
        buf51 = reinterpret_tensor(buf52, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_9, linear_9, view_5, v_3, v_4], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf49, buf51, 512, stream=raw_stream0)
        buf54 = reinterpret_tensor(buf32, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf32  # reuse
        # Topologically Sorted Source Nodes: [o_2, getitem_15, expand_3, v_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf45, buf47, buf48, buf52, buf54, 2048, 513, stream=raw_stream0)
        del buf50
        del buf51
        assert_size_stride(arg19_1, (2048, 2048), (2048, 1), 'input')
        buf55 = reinterpret_tensor(buf37, (1, 2048), (2048, 1), 0); del buf37  # reuse
        # Topologically Sorted Source Nodes: [o_2, transpose_7, o_3, h_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf54, arg19_1, buf55, 128, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg20_1, (2048, ), (1, ), 'input')
        buf56 = reinterpret_tensor(buf24, (1, 1, 2048), (2048, 2048, 1), 0); del buf24  # reuse
        buf58 = reinterpret_tensor(buf54, (1, 1, 2048), (2048, 2048, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20.run(buf56, arg1_1, arg0_1, buf30, buf55, arg20_1, buf58, 1, 2048, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg20_1
        assert_size_stride(arg21_1, (8192, 2048), (2048, 1), 'input')
        buf59 = reinterpret_tensor(buf29, (1, 8192), (8192, 1), 0); del buf29  # reuse
        # Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf58, arg21_1, buf59, 512, 1, 1, stream=raw_stream0)
        del arg21_1
        assert_size_stride(arg22_1, (8192, 2048), (2048, 1), 'input')
        buf61 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf58, arg22_1, buf59, buf61, 512, 1, 1, stream=raw_stream0)
        del arg22_1
        del buf59
        assert_size_stride(arg23_1, (2048, 8192), (8192, 1), 'input')
        buf62 = reinterpret_tensor(buf58, (1, 2048), (2048, 1), 0); del buf58  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf61, arg23_1, buf62, 128, 1, 1, stream=raw_stream0)
        del arg23_1
        assert_size_stride(arg24_1, (2048, ), (1, ), 'input')
        buf64 = reinterpret_tensor(buf55, (1, 1, 2048), (2048, 2048, 1), 0); del buf55  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf56, buf62, arg24_1, buf64, 1, 2048, stream=raw_stream0)
        del arg24_1
        assert_size_stride(arg25_1, (2048, 2048), (2048, 1), 'input')
        buf65 = buf30; del buf30  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf64, arg25_1, buf65, 128, 1, 1, stream=raw_stream0)
        del arg25_1
        assert_size_stride(arg26_1, (512, 2048), (2048, 1), 'input')
        buf66 = buf34; del buf34  # reuse
        # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf64, arg26_1, buf66, 32, 1, 1, stream=raw_stream0)
        del arg26_1
        buf69 = reinterpret_tensor(buf33, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf33  # reuse
        buf67 = reinterpret_tensor(buf69, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf65, buf67, 1024, stream=raw_stream0)
        buf68 = reinterpret_tensor(buf69, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4, cat_8], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf65, buf68, 1024, stream=raw_stream0)
        buf72 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf70 = reinterpret_tensor(buf72, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, chunk_5, neg_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf66, buf70, 256, stream=raw_stream0)
        del buf67
        del buf68
        buf71 = reinterpret_tensor(buf72, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, chunk_5, neg_5, cat_9], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf66, buf71, 256, stream=raw_stream0)
        buf75 = buf52; del buf52  # reuse
        buf73 = reinterpret_tensor(buf75, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, getitem_16, mul_12, mul_13, k_9, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23.run(arg4_1, buf73, 262144, stream=raw_stream0)
        del buf70
        del buf71
        buf74 = reinterpret_tensor(buf75, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf509 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 1024)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, mul_12, mul_13, k_9, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf66, arg2_1, buf72, arg3_1, buf74, buf509, 512, stream=raw_stream0)
        buf76 = reinterpret_tensor(buf47, (32, 1, 513), (513, 513, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, mul_10, mul_11, q_5, o_4, getitem_22, expand_4, k_11], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf65, arg2_1, buf69, arg3_1, buf75, buf76, 16416, 64, stream=raw_stream0)
        del buf73
        del buf74
        buf77 = buf45; del buf45  # reuse
        buf79 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf80 = buf48; del buf48  # reuse
        # Topologically Sorted Source Nodes: [o_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf76, buf77, buf79, buf80, 32, 513, stream=raw_stream0)
        del buf76
        assert_size_stride(arg27_1, (512, 2048), (2048, 1), 'input')
        buf81 = reinterpret_tensor(buf72, (1, 512), (512, 1), 0); del buf72  # reuse
        # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf64, arg27_1, buf81, 32, 1, 1, stream=raw_stream0)
        del arg27_1
        buf84 = buf75; del buf75  # reuse
        buf82 = reinterpret_tensor(buf84, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_17, linear_16, view_8, v_6, v_7], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23.run(arg5_1, buf82, 262144, stream=raw_stream0)
        buf83 = reinterpret_tensor(buf84, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_17, linear_16, view_8, v_6, v_7], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf81, buf83, 512, stream=raw_stream0)
        buf86 = reinterpret_tensor(buf64, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf64  # reuse
        # Topologically Sorted Source Nodes: [o_4, getitem_23, expand_5, v_8], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf77, buf79, buf80, buf84, buf86, 2048, 513, stream=raw_stream0)
        del buf82
        del buf83
        assert_size_stride(arg28_1, (2048, 2048), (2048, 1), 'input')
        buf87 = reinterpret_tensor(buf69, (1, 2048), (2048, 1), 0); del buf69  # reuse
        # Topologically Sorted Source Nodes: [o_4, transpose_11, o_5, h_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf86, arg28_1, buf87, 128, 1, 1, stream=raw_stream0)
        del arg28_1
        assert_size_stride(arg29_1, (2048, ), (1, ), 'input')
        buf89 = reinterpret_tensor(buf86, (1, 1, 2048), (2048, 2048, 1), 0); del buf86  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf56, buf62, buf87, arg29_1, buf89, 1, 2048, stream=raw_stream0)
        del arg29_1
        assert_size_stride(arg30_1, (8192, 2048), (2048, 1), 'input')
        buf90 = reinterpret_tensor(buf61, (1, 8192), (8192, 1), 0); del buf61  # reuse
        # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf89, arg30_1, buf90, 512, 1, 1, stream=raw_stream0)
        del arg30_1
        assert_size_stride(arg31_1, (8192, 2048), (2048, 1), 'input')
        buf92 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf89, arg31_1, buf90, buf92, 512, 1, 1, stream=raw_stream0)
        del arg31_1
        del buf90
        assert_size_stride(arg32_1, (2048, 8192), (8192, 1), 'input')
        buf93 = reinterpret_tensor(buf89, (1, 2048), (2048, 1), 0); del buf89  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14, linear_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf92, arg32_1, buf93, 128, 1, 1, stream=raw_stream0)
        del arg32_1
        del buf92
        assert_size_stride(arg33_1, (2048, ), (1, ), 'input')
        buf95 = reinterpret_tensor(buf65, (1, 1, 2048), (2048, 2048, 1), 0); del buf65  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf56, buf62, buf87, buf93, arg33_1, buf95, 1, 2048, stream=raw_stream0)
        del arg33_1
        assert_size_stride(arg34_1, (2048, 2048), (2048, 1), 'input')
        buf96 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf95, arg34_1, buf96, 128, 1, 1, stream=raw_stream0)
        del arg34_1
        assert_size_stride(arg35_1, (512, 2048), (2048, 1), 'input')
        buf97 = buf66; del buf66  # reuse
        # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf95, arg35_1, buf97, 32, 1, 1, stream=raw_stream0)
        del arg35_1
        buf100 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf98 = reinterpret_tensor(buf100, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf96, buf98, 1024, stream=raw_stream0)
        buf99 = reinterpret_tensor(buf100, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6, cat_12], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf96, buf99, 1024, stream=raw_stream0)
        buf103 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf101 = reinterpret_tensor(buf103, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, chunk_7, neg_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf97, buf101, 256, stream=raw_stream0)
        del buf98
        del buf99
        buf102 = reinterpret_tensor(buf103, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, chunk_7, neg_7, cat_13], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf97, buf102, 256, stream=raw_stream0)
        buf106 = buf84; del buf84  # reuse
        buf104 = reinterpret_tensor(buf106, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, getitem_24, mul_17, mul_18, k_13, k_14], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26.run(arg4_1, buf104, 262144, stream=raw_stream0)
        del buf101
        del buf102
        buf105 = reinterpret_tensor(buf106, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf510 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 1536)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, mul_17, mul_18, k_13, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf97, arg2_1, buf103, arg3_1, buf105, buf510, 512, stream=raw_stream0)
        buf107 = reinterpret_tensor(buf79, (32, 1, 513), (513, 513, 1), 0); del buf79  # reuse
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, mul_15, mul_16, q_7, o_6, getitem_30, expand_6, k_15], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf96, arg2_1, buf100, arg3_1, buf106, buf107, 16416, 64, stream=raw_stream0)
        del buf100
        del buf104
        del buf105
        buf108 = buf77; del buf77  # reuse
        buf110 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf111 = buf80; del buf80  # reuse
        # Topologically Sorted Source Nodes: [o_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf107, buf108, buf110, buf111, 32, 513, stream=raw_stream0)
        del buf107
        assert_size_stride(arg36_1, (512, 2048), (2048, 1), 'input')
        buf112 = buf97; del buf97  # reuse
        # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf95, arg36_1, buf112, 32, 1, 1, stream=raw_stream0)
        del arg36_1
        buf115 = buf106; del buf106  # reuse
        buf113 = reinterpret_tensor(buf115, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_25, linear_23, view_11, v_9, v_10], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_26.run(arg5_1, buf113, 262144, stream=raw_stream0)
        buf114 = reinterpret_tensor(buf115, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_25, linear_23, view_11, v_9, v_10], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf112, buf114, 512, stream=raw_stream0)
        buf117 = reinterpret_tensor(buf95, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf95  # reuse
        # Topologically Sorted Source Nodes: [o_6, getitem_31, expand_7, v_11], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf108, buf110, buf111, buf115, buf117, 2048, 513, stream=raw_stream0)
        del buf113
        del buf114
        assert_size_stride(arg37_1, (2048, 2048), (2048, 1), 'input')
        buf118 = buf96; del buf96  # reuse
        # Topologically Sorted Source Nodes: [o_6, transpose_15, o_7, h_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf117, arg37_1, buf118, 128, 1, 1, stream=raw_stream0)
        del arg37_1
        assert_size_stride(arg38_1, (2048, ), (1, ), 'input')
        buf119 = buf56; del buf56  # reuse
        buf121 = reinterpret_tensor(buf117, (1, 1, 2048), (2048, 2048, 1), 0); del buf117  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf119, buf62, buf87, buf93, buf118, arg38_1, buf121, 1, 2048, stream=raw_stream0)
        del arg38_1
        del buf118
        assert_size_stride(arg39_1, (8192, 2048), (2048, 1), 'input')
        buf122 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_3, linear_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf121, arg39_1, buf122, 512, 1, 1, stream=raw_stream0)
        del arg39_1
        assert_size_stride(arg40_1, (8192, 2048), (2048, 1), 'input')
        buf124 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf121, arg40_1, buf122, buf124, 512, 1, 1, stream=raw_stream0)
        del arg40_1
        del buf122
        assert_size_stride(arg41_1, (2048, 8192), (8192, 1), 'input')
        buf125 = reinterpret_tensor(buf121, (1, 2048), (2048, 1), 0); del buf121  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19, linear_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf124, arg41_1, buf125, 128, 1, 1, stream=raw_stream0)
        del arg41_1
        assert_size_stride(arg42_1, (2048, ), (1, ), 'input')
        buf127 = reinterpret_tensor(buf93, (1, 1, 2048), (2048, 2048, 1), 0); del buf93  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf119, buf125, arg42_1, buf127, 1, 2048, stream=raw_stream0)
        del arg42_1
        assert_size_stride(arg43_1, (2048, 2048), (2048, 1), 'input')
        buf128 = buf87; del buf87  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf127, arg43_1, buf128, 128, 1, 1, stream=raw_stream0)
        del arg43_1
        assert_size_stride(arg44_1, (512, 2048), (2048, 1), 'input')
        buf129 = reinterpret_tensor(buf103, (1, 512), (512, 1), 0); del buf103  # reuse
        # Topologically Sorted Source Nodes: [linear_29], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf127, arg44_1, buf129, 32, 1, 1, stream=raw_stream0)
        del arg44_1
        buf132 = reinterpret_tensor(buf62, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf62  # reuse
        buf130 = reinterpret_tensor(buf132, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_28, view_12, q_8, chunk_8, neg_8], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf128, buf130, 1024, stream=raw_stream0)
        buf131 = reinterpret_tensor(buf132, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_28, view_12, q_8, chunk_8, neg_8, cat_16], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf128, buf131, 1024, stream=raw_stream0)
        buf135 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf133 = reinterpret_tensor(buf135, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_29, view_13, k_16, chunk_9, neg_9], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf129, buf133, 256, stream=raw_stream0)
        del buf130
        del buf131
        buf134 = reinterpret_tensor(buf135, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_29, view_13, k_16, chunk_9, neg_9, cat_17], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf129, buf134, 256, stream=raw_stream0)
        buf138 = buf115; del buf115  # reuse
        buf136 = reinterpret_tensor(buf138, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_29, view_13, k_16, getitem_32, mul_22, mul_23, k_17, k_18], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28.run(arg4_1, buf136, 262144, stream=raw_stream0)
        del buf133
        del buf134
        buf137 = reinterpret_tensor(buf138, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf511 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 2048)  # alias
        # Topologically Sorted Source Nodes: [linear_29, view_13, k_16, mul_22, mul_23, k_17, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf129, arg2_1, buf135, arg3_1, buf137, buf511, 512, stream=raw_stream0)
        buf139 = reinterpret_tensor(buf110, (32, 1, 513), (513, 513, 1), 0); del buf110  # reuse
        # Topologically Sorted Source Nodes: [linear_28, view_12, q_8, mul_20, mul_21, q_9, o_8, getitem_38, expand_8, k_19], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf128, arg2_1, buf132, arg3_1, buf138, buf139, 16416, 64, stream=raw_stream0)
        del buf136
        del buf137
        buf140 = buf108; del buf108  # reuse
        buf142 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf143 = buf111; del buf111  # reuse
        # Topologically Sorted Source Nodes: [o_8], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf139, buf140, buf142, buf143, 32, 513, stream=raw_stream0)
        del buf139
        assert_size_stride(arg45_1, (512, 2048), (2048, 1), 'input')
        buf144 = reinterpret_tensor(buf135, (1, 512), (512, 1), 0); del buf135  # reuse
        # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf127, arg45_1, buf144, 32, 1, 1, stream=raw_stream0)
        del arg45_1
        buf147 = buf138; del buf138  # reuse
        buf145 = reinterpret_tensor(buf147, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_33, linear_30, view_14, v_12, v_13], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_28.run(arg5_1, buf145, 262144, stream=raw_stream0)
        buf146 = reinterpret_tensor(buf147, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_33, linear_30, view_14, v_12, v_13], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf144, buf146, 512, stream=raw_stream0)
        buf149 = reinterpret_tensor(buf127, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf127  # reuse
        # Topologically Sorted Source Nodes: [o_8, getitem_39, expand_9, v_14], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf140, buf142, buf143, buf147, buf149, 2048, 513, stream=raw_stream0)
        del buf145
        del buf146
        assert_size_stride(arg46_1, (2048, 2048), (2048, 1), 'input')
        buf150 = reinterpret_tensor(buf132, (1, 2048), (2048, 1), 0); del buf132  # reuse
        # Topologically Sorted Source Nodes: [o_8, transpose_19, o_9, h_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf149, arg46_1, buf150, 128, 1, 1, stream=raw_stream0)
        del arg46_1
        assert_size_stride(arg47_1, (2048, ), (1, ), 'input')
        buf152 = reinterpret_tensor(buf149, (1, 1, 2048), (2048, 2048, 1), 0); del buf149  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, h_4, x_9, y_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf119, buf125, buf150, arg47_1, buf152, 1, 2048, stream=raw_stream0)
        del arg47_1
        assert_size_stride(arg48_1, (8192, 2048), (2048, 1), 'input')
        buf153 = reinterpret_tensor(buf124, (1, 8192), (8192, 1), 0); del buf124  # reuse
        # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf152, arg48_1, buf153, 512, 1, 1, stream=raw_stream0)
        del arg48_1
        assert_size_stride(arg49_1, (8192, 2048), (2048, 1), 'input')
        buf155 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_24], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf152, arg49_1, buf153, buf155, 512, 1, 1, stream=raw_stream0)
        del arg49_1
        del buf153
        assert_size_stride(arg50_1, (2048, 8192), (8192, 1), 'input')
        buf156 = reinterpret_tensor(buf152, (1, 2048), (2048, 1), 0); del buf152  # reuse
        # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_24, linear_34], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf155, arg50_1, buf156, 128, 1, 1, stream=raw_stream0)
        del arg50_1
        del buf155
        assert_size_stride(arg51_1, (2048, ), (1, ), 'input')
        buf158 = reinterpret_tensor(buf128, (1, 1, 2048), (2048, 2048, 1), 0); del buf128  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, h_4, x_9, linear_34, x_10, rms_norm_10], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf119, buf125, buf150, buf156, arg51_1, buf158, 1, 2048, stream=raw_stream0)
        del arg51_1
        assert_size_stride(arg52_1, (2048, 2048), (2048, 1), 'input')
        buf159 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_35], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf158, arg52_1, buf159, 128, 1, 1, stream=raw_stream0)
        del arg52_1
        assert_size_stride(arg53_1, (512, 2048), (2048, 1), 'input')
        buf160 = buf129; del buf129  # reuse
        # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf158, arg53_1, buf160, 32, 1, 1, stream=raw_stream0)
        del arg53_1
        buf163 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf161 = reinterpret_tensor(buf163, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_35, view_15, q_10, chunk_10, neg_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf159, buf161, 1024, stream=raw_stream0)
        buf162 = reinterpret_tensor(buf163, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_35, view_15, q_10, chunk_10, neg_10, cat_20], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf159, buf162, 1024, stream=raw_stream0)
        buf166 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf164 = reinterpret_tensor(buf166, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_36, view_16, k_20, chunk_11, neg_11], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf160, buf164, 256, stream=raw_stream0)
        del buf161
        del buf162
        buf165 = reinterpret_tensor(buf166, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_36, view_16, k_20, chunk_11, neg_11, cat_21], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf160, buf165, 256, stream=raw_stream0)
        buf169 = buf147; del buf147  # reuse
        buf167 = reinterpret_tensor(buf169, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_36, view_16, k_20, getitem_40, mul_27, mul_28, k_21, k_22], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29.run(arg4_1, buf167, 262144, stream=raw_stream0)
        del buf164
        del buf165
        buf168 = reinterpret_tensor(buf169, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf512 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 2560)  # alias
        # Topologically Sorted Source Nodes: [linear_36, view_16, k_20, mul_27, mul_28, k_21, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf160, arg2_1, buf166, arg3_1, buf168, buf512, 512, stream=raw_stream0)
        buf170 = reinterpret_tensor(buf142, (32, 1, 513), (513, 513, 1), 0); del buf142  # reuse
        # Topologically Sorted Source Nodes: [linear_35, view_15, q_10, mul_25, mul_26, q_11, o_10, getitem_46, expand_10, k_23], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf159, arg2_1, buf163, arg3_1, buf169, buf170, 16416, 64, stream=raw_stream0)
        del buf167
        del buf168
        buf171 = buf140; del buf140  # reuse
        buf173 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf174 = buf143; del buf143  # reuse
        # Topologically Sorted Source Nodes: [o_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf170, buf171, buf173, buf174, 32, 513, stream=raw_stream0)
        del buf170
        assert_size_stride(arg54_1, (512, 2048), (2048, 1), 'input')
        buf175 = reinterpret_tensor(buf166, (1, 512), (512, 1), 0); del buf166  # reuse
        # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf158, arg54_1, buf175, 32, 1, 1, stream=raw_stream0)
        del arg54_1
        buf178 = buf169; del buf169  # reuse
        buf176 = reinterpret_tensor(buf178, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_41, linear_37, view_17, v_15, v_16], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_29.run(arg5_1, buf176, 262144, stream=raw_stream0)
        buf177 = reinterpret_tensor(buf178, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_41, linear_37, view_17, v_15, v_16], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf175, buf177, 512, stream=raw_stream0)
        buf180 = reinterpret_tensor(buf158, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf158  # reuse
        # Topologically Sorted Source Nodes: [o_10, getitem_47, expand_11, v_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf171, buf173, buf174, buf178, buf180, 2048, 513, stream=raw_stream0)
        del buf176
        del buf177
        assert_size_stride(arg55_1, (2048, 2048), (2048, 1), 'input')
        buf181 = reinterpret_tensor(buf163, (1, 2048), (2048, 1), 0); del buf163  # reuse
        # Topologically Sorted Source Nodes: [o_10, transpose_23, o_11, h_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf180, arg55_1, buf181, 128, 1, 1, stream=raw_stream0)
        del arg55_1
        assert_size_stride(arg56_1, (2048, ), (1, ), 'input')
        buf182 = buf119; del buf119  # reuse
        buf184 = reinterpret_tensor(buf180, (1, 1, 2048), (2048, 2048, 1), 0); del buf180  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, h_4, x_9, linear_34, x_10, h_5, x_11, y_5], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf182, buf125, buf150, buf156, buf181, arg56_1, buf184, 1, 2048, stream=raw_stream0)
        del arg56_1
        assert_size_stride(arg57_1, (8192, 2048), (2048, 1), 'input')
        buf185 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_5, linear_39], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf184, arg57_1, buf185, 512, 1, 1, stream=raw_stream0)
        del arg57_1
        assert_size_stride(arg58_1, (8192, 2048), (2048, 1), 'input')
        buf187 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_29], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf184, arg58_1, buf185, buf187, 512, 1, 1, stream=raw_stream0)
        del arg58_1
        del buf185
        assert_size_stride(arg59_1, (2048, 8192), (8192, 1), 'input')
        buf188 = reinterpret_tensor(buf184, (1, 2048), (2048, 1), 0); del buf184  # reuse
        # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_29, linear_41], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf187, arg59_1, buf188, 128, 1, 1, stream=raw_stream0)
        del arg59_1
        del buf187
        assert_size_stride(arg60_1, (2048, ), (1, ), 'input')
        buf190 = reinterpret_tensor(buf181, (1, 1, 2048), (2048, 2048, 1), 0); del buf181  # reuse
        # Topologically Sorted Source Nodes: [linear_41, x_12, rms_norm_12], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf182, buf188, arg60_1, buf190, 1, 2048, stream=raw_stream0)
        del arg60_1
        assert_size_stride(arg61_1, (2048, 2048), (2048, 1), 'input')
        buf191 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [linear_41, x_12, rms_norm_12, linear_42], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf190, arg61_1, buf191, 128, 1, 1, stream=raw_stream0)
        del arg61_1
        assert_size_stride(arg62_1, (512, 2048), (2048, 1), 'input')
        buf192 = buf160; del buf160  # reuse
        # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf190, arg62_1, buf192, 32, 1, 1, stream=raw_stream0)
        del arg62_1
        buf195 = reinterpret_tensor(buf150, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf150  # reuse
        buf193 = reinterpret_tensor(buf195, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_42, view_18, q_12, chunk_12, neg_12], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf191, buf193, 1024, stream=raw_stream0)
        buf194 = reinterpret_tensor(buf195, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_42, view_18, q_12, chunk_12, neg_12, cat_24], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf191, buf194, 1024, stream=raw_stream0)
        buf198 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf196 = reinterpret_tensor(buf198, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_43, view_19, k_24, chunk_13, neg_13], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf192, buf196, 256, stream=raw_stream0)
        del buf193
        del buf194
        buf197 = reinterpret_tensor(buf198, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_43, view_19, k_24, chunk_13, neg_13, cat_25], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf192, buf197, 256, stream=raw_stream0)
        buf201 = buf178; del buf178  # reuse
        buf199 = reinterpret_tensor(buf201, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_43, view_19, k_24, getitem_48, mul_32, mul_33, k_25, k_26], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30.run(arg4_1, buf199, 262144, stream=raw_stream0)
        del buf196
        del buf197
        buf200 = reinterpret_tensor(buf201, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf513 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 3072)  # alias
        # Topologically Sorted Source Nodes: [linear_43, view_19, k_24, mul_32, mul_33, k_25, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf192, arg2_1, buf198, arg3_1, buf200, buf513, 512, stream=raw_stream0)
        buf202 = reinterpret_tensor(buf173, (32, 1, 513), (513, 513, 1), 0); del buf173  # reuse
        # Topologically Sorted Source Nodes: [linear_42, view_18, q_12, mul_30, mul_31, q_13, o_12, getitem_54, expand_12, k_27], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf191, arg2_1, buf195, arg3_1, buf201, buf202, 16416, 64, stream=raw_stream0)
        del buf199
        del buf200
        buf203 = buf171; del buf171  # reuse
        buf205 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf206 = buf174; del buf174  # reuse
        # Topologically Sorted Source Nodes: [o_12], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf202, buf203, buf205, buf206, 32, 513, stream=raw_stream0)
        del buf202
        assert_size_stride(arg63_1, (512, 2048), (2048, 1), 'input')
        buf207 = reinterpret_tensor(buf198, (1, 512), (512, 1), 0); del buf198  # reuse
        # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf190, arg63_1, buf207, 32, 1, 1, stream=raw_stream0)
        del arg63_1
        buf210 = buf201; del buf201  # reuse
        buf208 = reinterpret_tensor(buf210, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_49, linear_44, view_20, v_18, v_19], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_30.run(arg5_1, buf208, 262144, stream=raw_stream0)
        buf209 = reinterpret_tensor(buf210, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_49, linear_44, view_20, v_18, v_19], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf207, buf209, 512, stream=raw_stream0)
        buf212 = reinterpret_tensor(buf190, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf190  # reuse
        # Topologically Sorted Source Nodes: [o_12, getitem_55, expand_13, v_20], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf203, buf205, buf206, buf210, buf212, 2048, 513, stream=raw_stream0)
        del buf208
        del buf209
        assert_size_stride(arg64_1, (2048, 2048), (2048, 1), 'input')
        buf213 = reinterpret_tensor(buf195, (1, 2048), (2048, 1), 0); del buf195  # reuse
        # Topologically Sorted Source Nodes: [o_12, transpose_27, o_13, h_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf212, arg64_1, buf213, 128, 1, 1, stream=raw_stream0)
        del arg64_1
        assert_size_stride(arg65_1, (2048, ), (1, ), 'input')
        buf215 = reinterpret_tensor(buf212, (1, 1, 2048), (2048, 2048, 1), 0); del buf212  # reuse
        # Topologically Sorted Source Nodes: [linear_41, x_12, h_6, x_13, y_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf182, buf188, buf213, arg65_1, buf215, 1, 2048, stream=raw_stream0)
        del arg65_1
        assert_size_stride(arg66_1, (8192, 2048), (2048, 1), 'input')
        buf216 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_46], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf215, arg66_1, buf216, 512, 1, 1, stream=raw_stream0)
        del arg66_1
        assert_size_stride(arg67_1, (8192, 2048), (2048, 1), 'input')
        buf218 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_34], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf215, arg67_1, buf216, buf218, 512, 1, 1, stream=raw_stream0)
        del arg67_1
        del buf216
        assert_size_stride(arg68_1, (2048, 8192), (8192, 1), 'input')
        buf219 = reinterpret_tensor(buf215, (1, 2048), (2048, 1), 0); del buf215  # reuse
        # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_34, linear_48], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf218, arg68_1, buf219, 128, 1, 1, stream=raw_stream0)
        del arg68_1
        del buf218
        assert_size_stride(arg69_1, (2048, ), (1, ), 'input')
        buf221 = reinterpret_tensor(buf191, (1, 1, 2048), (2048, 2048, 1), 0); del buf191  # reuse
        # Topologically Sorted Source Nodes: [linear_41, x_12, h_6, x_13, linear_48, x_14, rms_norm_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf182, buf188, buf213, buf219, arg69_1, buf221, 1, 2048, stream=raw_stream0)
        del arg69_1
        assert_size_stride(arg70_1, (2048, 2048), (2048, 1), 'input')
        buf222 = buf125; del buf125  # reuse
        # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf221, arg70_1, buf222, 128, 1, 1, stream=raw_stream0)
        del arg70_1
        assert_size_stride(arg71_1, (512, 2048), (2048, 1), 'input')
        buf223 = buf192; del buf192  # reuse
        # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf221, arg71_1, buf223, 32, 1, 1, stream=raw_stream0)
        del arg71_1
        buf226 = reinterpret_tensor(buf159, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf159  # reuse
        buf224 = reinterpret_tensor(buf226, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_49, view_21, q_14, chunk_14, neg_14], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf222, buf224, 1024, stream=raw_stream0)
        buf225 = reinterpret_tensor(buf226, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_49, view_21, q_14, chunk_14, neg_14, cat_28], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf222, buf225, 1024, stream=raw_stream0)
        buf229 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf227 = reinterpret_tensor(buf229, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_50, view_22, k_28, chunk_15, neg_15], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf223, buf227, 256, stream=raw_stream0)
        del buf224
        del buf225
        buf228 = reinterpret_tensor(buf229, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_50, view_22, k_28, chunk_15, neg_15, cat_29], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf223, buf228, 256, stream=raw_stream0)
        buf232 = buf210; del buf210  # reuse
        buf230 = reinterpret_tensor(buf232, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_50, view_22, k_28, getitem_56, mul_37, mul_38, k_29, k_30], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31.run(arg4_1, buf230, 262144, stream=raw_stream0)
        del buf227
        del buf228
        buf231 = reinterpret_tensor(buf232, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf514 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 3584)  # alias
        # Topologically Sorted Source Nodes: [linear_50, view_22, k_28, mul_37, mul_38, k_29, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf223, arg2_1, buf229, arg3_1, buf231, buf514, 512, stream=raw_stream0)
        buf233 = reinterpret_tensor(buf205, (32, 1, 513), (513, 513, 1), 0); del buf205  # reuse
        # Topologically Sorted Source Nodes: [linear_49, view_21, q_14, mul_35, mul_36, q_15, o_14, getitem_62, expand_14, k_31], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf222, arg2_1, buf226, arg3_1, buf232, buf233, 16416, 64, stream=raw_stream0)
        del buf230
        del buf231
        buf234 = buf203; del buf203  # reuse
        buf236 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf237 = buf206; del buf206  # reuse
        # Topologically Sorted Source Nodes: [o_14], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf233, buf234, buf236, buf237, 32, 513, stream=raw_stream0)
        del buf233
        assert_size_stride(arg72_1, (512, 2048), (2048, 1), 'input')
        buf238 = reinterpret_tensor(buf229, (1, 512), (512, 1), 0); del buf229  # reuse
        # Topologically Sorted Source Nodes: [linear_51], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf221, arg72_1, buf238, 32, 1, 1, stream=raw_stream0)
        del arg72_1
        buf241 = buf232; del buf232  # reuse
        buf239 = reinterpret_tensor(buf241, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_57, linear_51, view_23, v_21, v_22], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_31.run(arg5_1, buf239, 262144, stream=raw_stream0)
        buf240 = reinterpret_tensor(buf241, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_57, linear_51, view_23, v_21, v_22], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf238, buf240, 512, stream=raw_stream0)
        buf243 = reinterpret_tensor(buf221, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf221  # reuse
        # Topologically Sorted Source Nodes: [o_14, getitem_63, expand_15, v_23], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf234, buf236, buf237, buf241, buf243, 2048, 513, stream=raw_stream0)
        del buf239
        del buf240
        assert_size_stride(arg73_1, (2048, 2048), (2048, 1), 'input')
        buf244 = reinterpret_tensor(buf226, (1, 2048), (2048, 1), 0); del buf226  # reuse
        # Topologically Sorted Source Nodes: [o_14, transpose_31, o_15, h_7], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf243, arg73_1, buf244, 128, 1, 1, stream=raw_stream0)
        del arg73_1
        assert_size_stride(arg74_1, (2048, ), (1, ), 'input')
        buf245 = buf182; del buf182  # reuse
        buf247 = reinterpret_tensor(buf243, (1, 1, 2048), (2048, 2048, 1), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [linear_41, x_12, h_6, x_13, linear_48, x_14, h_7, x_15, y_7], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf245, buf188, buf213, buf219, buf244, arg74_1, buf247, 1, 2048, stream=raw_stream0)
        del arg74_1
        assert_size_stride(arg75_1, (8192, 2048), (2048, 1), 'input')
        buf248 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_7, linear_53], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf247, arg75_1, buf248, 512, 1, 1, stream=raw_stream0)
        del arg75_1
        assert_size_stride(arg76_1, (8192, 2048), (2048, 1), 'input')
        buf250 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_39], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf247, arg76_1, buf248, buf250, 512, 1, 1, stream=raw_stream0)
        del arg76_1
        del buf248
        assert_size_stride(arg77_1, (2048, 8192), (8192, 1), 'input')
        buf251 = reinterpret_tensor(buf247, (1, 2048), (2048, 1), 0); del buf247  # reuse
        # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_39, linear_55], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf250, arg77_1, buf251, 128, 1, 1, stream=raw_stream0)
        del arg77_1
        del buf250
        assert_size_stride(arg78_1, (2048, ), (1, ), 'input')
        buf253 = reinterpret_tensor(buf244, (1, 1, 2048), (2048, 2048, 1), 0); del buf244  # reuse
        # Topologically Sorted Source Nodes: [linear_55, x_16, rms_norm_16], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf245, buf251, arg78_1, buf253, 1, 2048, stream=raw_stream0)
        del arg78_1
        assert_size_stride(arg79_1, (2048, 2048), (2048, 1), 'input')
        buf254 = buf219; del buf219  # reuse
        # Topologically Sorted Source Nodes: [linear_55, x_16, rms_norm_16, linear_56], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf253, arg79_1, buf254, 128, 1, 1, stream=raw_stream0)
        del arg79_1
        assert_size_stride(arg80_1, (512, 2048), (2048, 1), 'input')
        buf255 = buf223; del buf223  # reuse
        # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf253, arg80_1, buf255, 32, 1, 1, stream=raw_stream0)
        del arg80_1
        buf258 = reinterpret_tensor(buf213, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf213  # reuse
        buf256 = reinterpret_tensor(buf258, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_56, view_24, q_16, chunk_16, neg_16], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf254, buf256, 1024, stream=raw_stream0)
        buf257 = reinterpret_tensor(buf258, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_56, view_24, q_16, chunk_16, neg_16, cat_32], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf254, buf257, 1024, stream=raw_stream0)
        buf261 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf259 = reinterpret_tensor(buf261, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_57, view_25, k_32, chunk_17, neg_17], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf255, buf259, 256, stream=raw_stream0)
        del buf256
        del buf257
        buf260 = reinterpret_tensor(buf261, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_57, view_25, k_32, chunk_17, neg_17, cat_33], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf255, buf260, 256, stream=raw_stream0)
        buf264 = buf241; del buf241  # reuse
        buf262 = reinterpret_tensor(buf264, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_57, view_25, k_32, getitem_64, mul_42, mul_43, k_33, k_34], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32.run(arg4_1, buf262, 262144, stream=raw_stream0)
        del buf259
        del buf260
        buf263 = reinterpret_tensor(buf264, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf515 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 4096)  # alias
        # Topologically Sorted Source Nodes: [linear_57, view_25, k_32, mul_42, mul_43, k_33, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf255, arg2_1, buf261, arg3_1, buf263, buf515, 512, stream=raw_stream0)
        buf265 = reinterpret_tensor(buf236, (32, 1, 513), (513, 513, 1), 0); del buf236  # reuse
        # Topologically Sorted Source Nodes: [linear_56, view_24, q_16, mul_40, mul_41, q_17, o_16, getitem_70, expand_16, k_35], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf254, arg2_1, buf258, arg3_1, buf264, buf265, 16416, 64, stream=raw_stream0)
        del buf262
        del buf263
        buf266 = buf234; del buf234  # reuse
        buf268 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf269 = buf237; del buf237  # reuse
        # Topologically Sorted Source Nodes: [o_16], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf265, buf266, buf268, buf269, 32, 513, stream=raw_stream0)
        del buf265
        assert_size_stride(arg81_1, (512, 2048), (2048, 1), 'input')
        buf270 = reinterpret_tensor(buf261, (1, 512), (512, 1), 0); del buf261  # reuse
        # Topologically Sorted Source Nodes: [linear_58], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf253, arg81_1, buf270, 32, 1, 1, stream=raw_stream0)
        del arg81_1
        buf273 = buf264; del buf264  # reuse
        buf271 = reinterpret_tensor(buf273, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_65, linear_58, view_26, v_24, v_25], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_32.run(arg5_1, buf271, 262144, stream=raw_stream0)
        buf272 = reinterpret_tensor(buf273, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_65, linear_58, view_26, v_24, v_25], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf270, buf272, 512, stream=raw_stream0)
        buf275 = reinterpret_tensor(buf253, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf253  # reuse
        # Topologically Sorted Source Nodes: [o_16, getitem_71, expand_17, v_26], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf266, buf268, buf269, buf273, buf275, 2048, 513, stream=raw_stream0)
        del buf271
        del buf272
        assert_size_stride(arg82_1, (2048, 2048), (2048, 1), 'input')
        buf276 = reinterpret_tensor(buf258, (1, 2048), (2048, 1), 0); del buf258  # reuse
        # Topologically Sorted Source Nodes: [o_16, transpose_35, o_17, h_8], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf275, arg82_1, buf276, 128, 1, 1, stream=raw_stream0)
        del arg82_1
        assert_size_stride(arg83_1, (2048, ), (1, ), 'input')
        buf278 = reinterpret_tensor(buf275, (1, 1, 2048), (2048, 2048, 1), 0); del buf275  # reuse
        # Topologically Sorted Source Nodes: [linear_55, x_16, h_8, x_17, y_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf245, buf251, buf276, arg83_1, buf278, 1, 2048, stream=raw_stream0)
        del arg83_1
        assert_size_stride(arg84_1, (8192, 2048), (2048, 1), 'input')
        buf279 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf278, arg84_1, buf279, 512, 1, 1, stream=raw_stream0)
        del arg84_1
        assert_size_stride(arg85_1, (8192, 2048), (2048, 1), 'input')
        buf281 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_44], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf278, arg85_1, buf279, buf281, 512, 1, 1, stream=raw_stream0)
        del arg85_1
        del buf279
        assert_size_stride(arg86_1, (2048, 8192), (8192, 1), 'input')
        buf282 = reinterpret_tensor(buf278, (1, 2048), (2048, 1), 0); del buf278  # reuse
        # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_44, linear_62], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf281, arg86_1, buf282, 128, 1, 1, stream=raw_stream0)
        del arg86_1
        del buf281
        assert_size_stride(arg87_1, (2048, ), (1, ), 'input')
        buf284 = reinterpret_tensor(buf254, (1, 1, 2048), (2048, 2048, 1), 0); del buf254  # reuse
        # Topologically Sorted Source Nodes: [linear_55, x_16, h_8, x_17, linear_62, x_18, rms_norm_18], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf245, buf251, buf276, buf282, arg87_1, buf284, 1, 2048, stream=raw_stream0)
        del arg87_1
        assert_size_stride(arg88_1, (2048, 2048), (2048, 1), 'input')
        buf285 = buf188; del buf188  # reuse
        # Topologically Sorted Source Nodes: [linear_63], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf284, arg88_1, buf285, 128, 1, 1, stream=raw_stream0)
        del arg88_1
        assert_size_stride(arg89_1, (512, 2048), (2048, 1), 'input')
        buf286 = buf255; del buf255  # reuse
        # Topologically Sorted Source Nodes: [linear_64], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf284, arg89_1, buf286, 32, 1, 1, stream=raw_stream0)
        del arg89_1
        buf289 = reinterpret_tensor(buf222, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf222  # reuse
        buf287 = reinterpret_tensor(buf289, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_63, view_27, q_18, chunk_18, neg_18], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf285, buf287, 1024, stream=raw_stream0)
        buf288 = reinterpret_tensor(buf289, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_63, view_27, q_18, chunk_18, neg_18, cat_36], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf285, buf288, 1024, stream=raw_stream0)
        buf292 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf290 = reinterpret_tensor(buf292, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_64, view_28, k_36, chunk_19, neg_19], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf286, buf290, 256, stream=raw_stream0)
        del buf287
        del buf288
        buf291 = reinterpret_tensor(buf292, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_64, view_28, k_36, chunk_19, neg_19, cat_37], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf286, buf291, 256, stream=raw_stream0)
        buf295 = buf273; del buf273  # reuse
        buf293 = reinterpret_tensor(buf295, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_64, view_28, k_36, getitem_72, mul_47, mul_48, k_37, k_38], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33.run(arg4_1, buf293, 262144, stream=raw_stream0)
        del buf290
        del buf291
        buf294 = reinterpret_tensor(buf295, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf516 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 4608)  # alias
        # Topologically Sorted Source Nodes: [linear_64, view_28, k_36, mul_47, mul_48, k_37, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf286, arg2_1, buf292, arg3_1, buf294, buf516, 512, stream=raw_stream0)
        del buf286
        buf296 = reinterpret_tensor(buf268, (32, 1, 513), (513, 513, 1), 0); del buf268  # reuse
        # Topologically Sorted Source Nodes: [linear_63, view_27, q_18, mul_45, mul_46, q_19, o_18, getitem_78, expand_18, k_39], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf285, arg2_1, buf289, arg3_1, buf295, buf296, 16416, 64, stream=raw_stream0)
        del buf285
        del buf293
        del buf294
        buf297 = buf266; del buf266  # reuse
        buf299 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf300 = buf269; del buf269  # reuse
        # Topologically Sorted Source Nodes: [o_18], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf296, buf297, buf299, buf300, 32, 513, stream=raw_stream0)
        del buf296
        assert_size_stride(arg90_1, (512, 2048), (2048, 1), 'input')
        buf301 = reinterpret_tensor(buf292, (1, 512), (512, 1), 0); del buf292  # reuse
        # Topologically Sorted Source Nodes: [linear_65], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf284, arg90_1, buf301, 32, 1, 1, stream=raw_stream0)
        del arg90_1
        buf304 = buf295; del buf295  # reuse
        buf302 = reinterpret_tensor(buf304, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_73, linear_65, view_29, v_27, v_28], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_33.run(arg5_1, buf302, 262144, stream=raw_stream0)
        buf303 = reinterpret_tensor(buf304, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_73, linear_65, view_29, v_27, v_28], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf301, buf303, 512, stream=raw_stream0)
        buf306 = reinterpret_tensor(buf284, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf284  # reuse
        # Topologically Sorted Source Nodes: [o_18, getitem_79, expand_19, v_29], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf297, buf299, buf300, buf304, buf306, 2048, 513, stream=raw_stream0)
        del buf302
        del buf303
        assert_size_stride(arg91_1, (2048, 2048), (2048, 1), 'input')
        buf307 = reinterpret_tensor(buf289, (1, 2048), (2048, 1), 0); del buf289  # reuse
        # Topologically Sorted Source Nodes: [o_18, transpose_39, o_19, h_9], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf306, arg91_1, buf307, 128, 1, 1, stream=raw_stream0)
        del arg91_1
        assert_size_stride(arg92_1, (2048, ), (1, ), 'input')
        buf308 = buf245; del buf245  # reuse
        buf310 = reinterpret_tensor(buf306, (1, 1, 2048), (2048, 2048, 1), 0); del buf306  # reuse
        # Topologically Sorted Source Nodes: [linear_55, x_16, h_8, x_17, linear_62, x_18, h_9, x_19, y_9], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf308, buf251, buf276, buf282, buf307, arg92_1, buf310, 1, 2048, stream=raw_stream0)
        del arg92_1
        assert_size_stride(arg93_1, (8192, 2048), (2048, 1), 'input')
        buf311 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_9, linear_67], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf310, arg93_1, buf311, 512, 1, 1, stream=raw_stream0)
        del arg93_1
        assert_size_stride(arg94_1, (8192, 2048), (2048, 1), 'input')
        buf313 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_49], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf310, arg94_1, buf311, buf313, 512, 1, 1, stream=raw_stream0)
        del arg94_1
        del buf311
        assert_size_stride(arg95_1, (2048, 8192), (8192, 1), 'input')
        buf314 = reinterpret_tensor(buf310, (1, 2048), (2048, 1), 0); del buf310  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_49, linear_69], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf313, arg95_1, buf314, 128, 1, 1, stream=raw_stream0)
        del arg95_1
        del buf313
        assert_size_stride(arg96_1, (2048, ), (1, ), 'input')
        buf316 = reinterpret_tensor(buf307, (1, 1, 2048), (2048, 2048, 1), 0); del buf307  # reuse
        # Topologically Sorted Source Nodes: [linear_69, x_20, rms_norm_20], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf308, buf314, arg96_1, buf316, 1, 2048, stream=raw_stream0)
        del arg96_1
        assert_size_stride(arg97_1, (2048, 2048), (2048, 1), 'input')
        buf317 = buf282; del buf282  # reuse
        # Topologically Sorted Source Nodes: [linear_69, x_20, rms_norm_20, linear_70], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf316, arg97_1, buf317, 128, 1, 1, stream=raw_stream0)
        del arg97_1
        assert_size_stride(arg98_1, (512, 2048), (2048, 1), 'input')
        buf318 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_71], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf316, arg98_1, buf318, 32, 1, 1, stream=raw_stream0)
        del arg98_1
        buf321 = reinterpret_tensor(buf276, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf276  # reuse
        buf319 = reinterpret_tensor(buf321, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_70, view_30, q_20, chunk_20, neg_20], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf317, buf319, 1024, stream=raw_stream0)
        buf320 = reinterpret_tensor(buf321, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_70, view_30, q_20, chunk_20, neg_20, cat_40], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf317, buf320, 1024, stream=raw_stream0)
        buf324 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf322 = reinterpret_tensor(buf324, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_71, view_31, k_40, chunk_21, neg_21], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf318, buf322, 256, stream=raw_stream0)
        del buf319
        del buf320
        buf323 = reinterpret_tensor(buf324, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_71, view_31, k_40, chunk_21, neg_21, cat_41], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf318, buf323, 256, stream=raw_stream0)
        buf327 = buf304; del buf304  # reuse
        buf325 = reinterpret_tensor(buf327, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_71, view_31, k_40, getitem_80, mul_52, mul_53, k_41, k_42], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34.run(arg4_1, buf325, 262144, stream=raw_stream0)
        del buf322
        del buf323
        buf326 = reinterpret_tensor(buf327, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf517 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 5120)  # alias
        # Topologically Sorted Source Nodes: [linear_71, view_31, k_40, mul_52, mul_53, k_41, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf318, arg2_1, buf324, arg3_1, buf326, buf517, 512, stream=raw_stream0)
        buf328 = reinterpret_tensor(buf299, (32, 1, 513), (513, 513, 1), 0); del buf299  # reuse
        # Topologically Sorted Source Nodes: [linear_70, view_30, q_20, mul_50, mul_51, q_21, o_20, getitem_86, expand_20, k_43], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf317, arg2_1, buf321, arg3_1, buf327, buf328, 16416, 64, stream=raw_stream0)
        del buf325
        del buf326
        buf329 = buf297; del buf297  # reuse
        buf331 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf332 = buf300; del buf300  # reuse
        # Topologically Sorted Source Nodes: [o_20], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf328, buf329, buf331, buf332, 32, 513, stream=raw_stream0)
        del buf328
        assert_size_stride(arg99_1, (512, 2048), (2048, 1), 'input')
        buf333 = reinterpret_tensor(buf324, (1, 512), (512, 1), 0); del buf324  # reuse
        # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf316, arg99_1, buf333, 32, 1, 1, stream=raw_stream0)
        del arg99_1
        buf336 = buf327; del buf327  # reuse
        buf334 = reinterpret_tensor(buf336, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_81, linear_72, view_32, v_30, v_31], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_34.run(arg5_1, buf334, 262144, stream=raw_stream0)
        buf335 = reinterpret_tensor(buf336, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_81, linear_72, view_32, v_30, v_31], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf333, buf335, 512, stream=raw_stream0)
        buf338 = reinterpret_tensor(buf316, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf316  # reuse
        # Topologically Sorted Source Nodes: [o_20, getitem_87, expand_21, v_32], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf329, buf331, buf332, buf336, buf338, 2048, 513, stream=raw_stream0)
        del buf331
        del buf334
        del buf335
        assert_size_stride(arg100_1, (2048, 2048), (2048, 1), 'input')
        buf339 = reinterpret_tensor(buf321, (1, 2048), (2048, 1), 0); del buf321  # reuse
        # Topologically Sorted Source Nodes: [o_20, transpose_43, o_21, h_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf338, arg100_1, buf339, 128, 1, 1, stream=raw_stream0)
        del arg100_1
        assert_size_stride(arg101_1, (2048, ), (1, ), 'input')
        buf341 = reinterpret_tensor(buf338, (1, 1, 2048), (2048, 2048, 1), 0); del buf338  # reuse
        # Topologically Sorted Source Nodes: [linear_69, x_20, h_10, x_21, y_10], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf308, buf314, buf339, arg101_1, buf341, 1, 2048, stream=raw_stream0)
        del arg101_1
        assert_size_stride(arg102_1, (8192, 2048), (2048, 1), 'input')
        buf342 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf341, arg102_1, buf342, 512, 1, 1, stream=raw_stream0)
        del arg102_1
        assert_size_stride(arg103_1, (8192, 2048), (2048, 1), 'input')
        buf344 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_54], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf341, arg103_1, buf342, buf344, 512, 1, 1, stream=raw_stream0)
        del arg103_1
        del buf342
        assert_size_stride(arg104_1, (2048, 8192), (8192, 1), 'input')
        buf345 = reinterpret_tensor(buf341, (1, 2048), (2048, 1), 0); del buf341  # reuse
        # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_54, linear_76], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf344, arg104_1, buf345, 128, 1, 1, stream=raw_stream0)
        del arg104_1
        del buf344
        assert_size_stride(arg105_1, (2048, ), (1, ), 'input')
        buf347 = reinterpret_tensor(buf317, (1, 1, 2048), (2048, 2048, 1), 0); del buf317  # reuse
        # Topologically Sorted Source Nodes: [linear_69, x_20, h_10, x_21, linear_76, x_22, rms_norm_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf308, buf314, buf339, buf345, arg105_1, buf347, 1, 2048, stream=raw_stream0)
        del arg105_1
        assert_size_stride(arg106_1, (2048, 2048), (2048, 1), 'input')
        buf348 = buf251; del buf251  # reuse
        # Topologically Sorted Source Nodes: [linear_77], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf347, arg106_1, buf348, 128, 1, 1, stream=raw_stream0)
        del arg106_1
        assert_size_stride(arg107_1, (512, 2048), (2048, 1), 'input')
        buf349 = buf318; del buf318  # reuse
        # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf347, arg107_1, buf349, 32, 1, 1, stream=raw_stream0)
        del arg107_1
        buf352 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf350 = reinterpret_tensor(buf352, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_77, view_33, q_22, chunk_22, neg_22], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf348, buf350, 1024, stream=raw_stream0)
        buf351 = reinterpret_tensor(buf352, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_77, view_33, q_22, chunk_22, neg_22, cat_44], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf348, buf351, 1024, stream=raw_stream0)
        buf355 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf353 = reinterpret_tensor(buf355, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_78, view_34, k_44, chunk_23, neg_23], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf349, buf353, 256, stream=raw_stream0)
        del buf350
        del buf351
        buf354 = reinterpret_tensor(buf355, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_78, view_34, k_44, chunk_23, neg_23, cat_45], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf349, buf354, 256, stream=raw_stream0)
        buf358 = buf336; del buf336  # reuse
        buf356 = reinterpret_tensor(buf358, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_78, view_34, k_44, getitem_88, mul_57, mul_58, k_45, k_46], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35.run(arg4_1, buf356, 262144, stream=raw_stream0)
        del buf353
        del buf354
        buf357 = reinterpret_tensor(buf358, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf518 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 5632)  # alias
        # Topologically Sorted Source Nodes: [linear_78, view_34, k_44, mul_57, mul_58, k_45, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf349, arg2_1, buf355, arg3_1, buf357, buf518, 512, stream=raw_stream0)
        del buf349
        buf359 = empty_strided((32, 1, 513), (513, 513, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_77, view_33, q_22, mul_55, mul_56, q_23, o_22, getitem_94, expand_22, k_47], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf348, arg2_1, buf352, arg3_1, buf358, buf359, 16416, 64, stream=raw_stream0)
        del buf348
        del buf356
        del buf357
        buf360 = buf329; del buf329  # reuse
        buf362 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf363 = buf332; del buf332  # reuse
        # Topologically Sorted Source Nodes: [o_22], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf359, buf360, buf362, buf363, 32, 513, stream=raw_stream0)
        del buf359
        assert_size_stride(arg108_1, (512, 2048), (2048, 1), 'input')
        buf364 = reinterpret_tensor(buf355, (1, 512), (512, 1), 0); del buf355  # reuse
        # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf347, arg108_1, buf364, 32, 1, 1, stream=raw_stream0)
        del arg108_1
        buf367 = buf358; del buf358  # reuse
        buf365 = reinterpret_tensor(buf367, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_89, linear_79, view_35, v_33, v_34], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_35.run(arg5_1, buf365, 262144, stream=raw_stream0)
        buf366 = reinterpret_tensor(buf367, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_89, linear_79, view_35, v_33, v_34], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf364, buf366, 512, stream=raw_stream0)
        buf369 = reinterpret_tensor(buf347, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf347  # reuse
        # Topologically Sorted Source Nodes: [o_22, getitem_95, expand_23, v_35], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf360, buf362, buf363, buf367, buf369, 2048, 513, stream=raw_stream0)
        del buf365
        del buf366
        assert_size_stride(arg109_1, (2048, 2048), (2048, 1), 'input')
        buf370 = reinterpret_tensor(buf352, (1, 2048), (2048, 1), 0); del buf352  # reuse
        # Topologically Sorted Source Nodes: [o_22, transpose_47, o_23, h_11], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf369, arg109_1, buf370, 128, 1, 1, stream=raw_stream0)
        del arg109_1
        assert_size_stride(arg110_1, (2048, ), (1, ), 'input')
        buf371 = buf308; del buf308  # reuse
        buf373 = reinterpret_tensor(buf369, (1, 1, 2048), (2048, 2048, 1), 0); del buf369  # reuse
        # Topologically Sorted Source Nodes: [linear_69, x_20, h_10, x_21, linear_76, x_22, h_11, x_23, y_11], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf371, buf314, buf339, buf345, buf370, arg110_1, buf373, 1, 2048, stream=raw_stream0)
        del arg110_1
        del buf314
        assert_size_stride(arg111_1, (8192, 2048), (2048, 1), 'input')
        buf374 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_11, linear_81], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf373, arg111_1, buf374, 512, 1, 1, stream=raw_stream0)
        del arg111_1
        assert_size_stride(arg112_1, (8192, 2048), (2048, 1), 'input')
        buf376 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_59], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf373, arg112_1, buf374, buf376, 512, 1, 1, stream=raw_stream0)
        del arg112_1
        del buf374
        assert_size_stride(arg113_1, (2048, 8192), (8192, 1), 'input')
        buf377 = reinterpret_tensor(buf373, (1, 2048), (2048, 1), 0); del buf373  # reuse
        # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_59, linear_83], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf376, arg113_1, buf377, 128, 1, 1, stream=raw_stream0)
        del arg113_1
        del buf376
        assert_size_stride(arg114_1, (2048, ), (1, ), 'input')
        buf379 = reinterpret_tensor(buf370, (1, 1, 2048), (2048, 2048, 1), 0); del buf370  # reuse
        # Topologically Sorted Source Nodes: [linear_83, x_24, rms_norm_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf371, buf377, arg114_1, buf379, 1, 2048, stream=raw_stream0)
        del arg114_1
        assert_size_stride(arg115_1, (2048, 2048), (2048, 1), 'input')
        buf380 = buf345; del buf345  # reuse
        # Topologically Sorted Source Nodes: [linear_83, x_24, rms_norm_24, linear_84], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf379, arg115_1, buf380, 128, 1, 1, stream=raw_stream0)
        del arg115_1
        assert_size_stride(arg116_1, (512, 2048), (2048, 1), 'input')
        buf381 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf379, arg116_1, buf381, 32, 1, 1, stream=raw_stream0)
        del arg116_1
        buf384 = reinterpret_tensor(buf339, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf339  # reuse
        buf382 = reinterpret_tensor(buf384, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_84, view_36, q_24, chunk_24, neg_24], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf380, buf382, 1024, stream=raw_stream0)
        buf383 = reinterpret_tensor(buf384, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_84, view_36, q_24, chunk_24, neg_24, cat_48], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf380, buf383, 1024, stream=raw_stream0)
        buf387 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf385 = reinterpret_tensor(buf387, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_85, view_37, k_48, chunk_25, neg_25], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf381, buf385, 256, stream=raw_stream0)
        del buf382
        del buf383
        buf386 = reinterpret_tensor(buf387, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_85, view_37, k_48, chunk_25, neg_25, cat_49], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf381, buf386, 256, stream=raw_stream0)
        buf390 = buf367; del buf367  # reuse
        buf388 = reinterpret_tensor(buf390, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_85, view_37, k_48, getitem_96, mul_62, mul_63, k_49, k_50], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36.run(arg4_1, buf388, 262144, stream=raw_stream0)
        del buf385
        del buf386
        buf389 = reinterpret_tensor(buf390, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf519 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 6144)  # alias
        # Topologically Sorted Source Nodes: [linear_85, view_37, k_48, mul_62, mul_63, k_49, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf381, arg2_1, buf387, arg3_1, buf389, buf519, 512, stream=raw_stream0)
        buf391 = reinterpret_tensor(buf362, (32, 1, 513), (513, 513, 1), 0); del buf362  # reuse
        # Topologically Sorted Source Nodes: [linear_84, view_36, q_24, mul_60, mul_61, q_25, o_24, getitem_102, expand_24, k_51], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf380, arg2_1, buf384, arg3_1, buf390, buf391, 16416, 64, stream=raw_stream0)
        del buf388
        del buf389
        buf392 = buf360; del buf360  # reuse
        buf394 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf395 = buf363; del buf363  # reuse
        # Topologically Sorted Source Nodes: [o_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf391, buf392, buf394, buf395, 32, 513, stream=raw_stream0)
        del buf391
        assert_size_stride(arg117_1, (512, 2048), (2048, 1), 'input')
        buf396 = reinterpret_tensor(buf387, (1, 512), (512, 1), 0); del buf387  # reuse
        # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf379, arg117_1, buf396, 32, 1, 1, stream=raw_stream0)
        del arg117_1
        buf399 = buf390; del buf390  # reuse
        buf397 = reinterpret_tensor(buf399, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_97, linear_86, view_38, v_36, v_37], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_36.run(arg5_1, buf397, 262144, stream=raw_stream0)
        buf398 = reinterpret_tensor(buf399, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_97, linear_86, view_38, v_36, v_37], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf396, buf398, 512, stream=raw_stream0)
        buf401 = reinterpret_tensor(buf379, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf379  # reuse
        # Topologically Sorted Source Nodes: [o_24, getitem_103, expand_25, v_38], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf392, buf394, buf395, buf399, buf401, 2048, 513, stream=raw_stream0)
        del buf394
        del buf397
        del buf398
        assert_size_stride(arg118_1, (2048, 2048), (2048, 1), 'input')
        buf402 = reinterpret_tensor(buf384, (1, 2048), (2048, 1), 0); del buf384  # reuse
        # Topologically Sorted Source Nodes: [o_24, transpose_51, o_25, h_12], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf401, arg118_1, buf402, 128, 1, 1, stream=raw_stream0)
        del arg118_1
        assert_size_stride(arg119_1, (2048, ), (1, ), 'input')
        buf404 = reinterpret_tensor(buf401, (1, 1, 2048), (2048, 2048, 1), 0); del buf401  # reuse
        # Topologically Sorted Source Nodes: [linear_83, x_24, h_12, x_25, y_12], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf371, buf377, buf402, arg119_1, buf404, 1, 2048, stream=raw_stream0)
        del arg119_1
        assert_size_stride(arg120_1, (8192, 2048), (2048, 1), 'input')
        buf405 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf404, arg120_1, buf405, 512, 1, 1, stream=raw_stream0)
        del arg120_1
        assert_size_stride(arg121_1, (8192, 2048), (2048, 1), 'input')
        buf407 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_64], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf404, arg121_1, buf405, buf407, 512, 1, 1, stream=raw_stream0)
        del arg121_1
        del buf405
        assert_size_stride(arg122_1, (2048, 8192), (8192, 1), 'input')
        buf408 = reinterpret_tensor(buf404, (1, 2048), (2048, 1), 0); del buf404  # reuse
        # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_64, linear_90], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf407, arg122_1, buf408, 128, 1, 1, stream=raw_stream0)
        del arg122_1
        del buf407
        assert_size_stride(arg123_1, (2048, ), (1, ), 'input')
        buf410 = reinterpret_tensor(buf380, (1, 1, 2048), (2048, 2048, 1), 0); del buf380  # reuse
        # Topologically Sorted Source Nodes: [linear_83, x_24, h_12, x_25, linear_90, x_26, rms_norm_26], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf371, buf377, buf402, buf408, arg123_1, buf410, 1, 2048, stream=raw_stream0)
        del arg123_1
        assert_size_stride(arg124_1, (2048, 2048), (2048, 1), 'input')
        buf411 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf410, arg124_1, buf411, 128, 1, 1, stream=raw_stream0)
        del arg124_1
        assert_size_stride(arg125_1, (512, 2048), (2048, 1), 'input')
        buf412 = buf381; del buf381  # reuse
        # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf410, arg125_1, buf412, 32, 1, 1, stream=raw_stream0)
        del arg125_1
        buf415 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf413 = reinterpret_tensor(buf415, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_91, view_39, q_26, chunk_26, neg_26], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf411, buf413, 1024, stream=raw_stream0)
        buf414 = reinterpret_tensor(buf415, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_91, view_39, q_26, chunk_26, neg_26, cat_52], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf411, buf414, 1024, stream=raw_stream0)
        buf418 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf416 = reinterpret_tensor(buf418, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_92, view_40, k_52, chunk_27, neg_27], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf412, buf416, 256, stream=raw_stream0)
        del buf413
        del buf414
        buf417 = reinterpret_tensor(buf418, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_92, view_40, k_52, chunk_27, neg_27, cat_53], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf412, buf417, 256, stream=raw_stream0)
        buf421 = buf399; del buf399  # reuse
        buf419 = reinterpret_tensor(buf421, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_92, view_40, k_52, getitem_104, mul_67, mul_68, k_53, k_54], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37.run(arg4_1, buf419, 262144, stream=raw_stream0)
        del buf416
        del buf417
        buf420 = reinterpret_tensor(buf421, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf520 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 6656)  # alias
        # Topologically Sorted Source Nodes: [linear_92, view_40, k_52, mul_67, mul_68, k_53, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf412, arg2_1, buf418, arg3_1, buf420, buf520, 512, stream=raw_stream0)
        del buf412
        buf422 = empty_strided((32, 1, 513), (513, 513, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_91, view_39, q_26, mul_65, mul_66, q_27, o_26, getitem_110, expand_26, k_55], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf411, arg2_1, buf415, arg3_1, buf421, buf422, 16416, 64, stream=raw_stream0)
        del buf411
        del buf415
        del buf419
        del buf420
        buf423 = buf392; del buf392  # reuse
        buf425 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf426 = buf395; del buf395  # reuse
        # Topologically Sorted Source Nodes: [o_26], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf422, buf423, buf425, buf426, 32, 513, stream=raw_stream0)
        del buf422
        assert_size_stride(arg126_1, (512, 2048), (2048, 1), 'input')
        buf427 = reinterpret_tensor(buf418, (1, 512), (512, 1), 0); del buf418  # reuse
        # Topologically Sorted Source Nodes: [linear_93], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf410, arg126_1, buf427, 32, 1, 1, stream=raw_stream0)
        del arg126_1
        buf430 = buf421; del buf421  # reuse
        buf428 = reinterpret_tensor(buf430, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_105, linear_93, view_41, v_39, v_40], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_37.run(arg5_1, buf428, 262144, stream=raw_stream0)
        buf429 = reinterpret_tensor(buf430, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_105, linear_93, view_41, v_39, v_40], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf427, buf429, 512, stream=raw_stream0)
        buf432 = reinterpret_tensor(buf410, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf410  # reuse
        # Topologically Sorted Source Nodes: [o_26, getitem_111, expand_27, v_41], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf423, buf425, buf426, buf430, buf432, 2048, 513, stream=raw_stream0)
        del buf425
        del buf428
        del buf429
        assert_size_stride(arg127_1, (2048, 2048), (2048, 1), 'input')
        buf433 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_26, transpose_55, o_27, h_13], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf432, arg127_1, buf433, 128, 1, 1, stream=raw_stream0)
        del arg127_1
        assert_size_stride(arg128_1, (2048, ), (1, ), 'input')
        buf434 = buf371; del buf371  # reuse
        buf436 = reinterpret_tensor(buf432, (1, 1, 2048), (2048, 2048, 1), 0); del buf432  # reuse
        # Topologically Sorted Source Nodes: [linear_83, x_24, h_12, x_25, linear_90, x_26, h_13, x_27, y_13], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf434, buf377, buf402, buf408, buf433, arg128_1, buf436, 1, 2048, stream=raw_stream0)
        del arg128_1
        del buf377
        assert_size_stride(arg129_1, (8192, 2048), (2048, 1), 'input')
        buf437 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_13, linear_95], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf436, arg129_1, buf437, 512, 1, 1, stream=raw_stream0)
        del arg129_1
        assert_size_stride(arg130_1, (8192, 2048), (2048, 1), 'input')
        buf439 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_69], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf436, arg130_1, buf437, buf439, 512, 1, 1, stream=raw_stream0)
        del arg130_1
        del buf437
        assert_size_stride(arg131_1, (2048, 8192), (8192, 1), 'input')
        buf440 = reinterpret_tensor(buf436, (1, 2048), (2048, 1), 0); del buf436  # reuse
        # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_69, linear_97], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf439, arg131_1, buf440, 128, 1, 1, stream=raw_stream0)
        del arg131_1
        del buf439
        assert_size_stride(arg132_1, (2048, ), (1, ), 'input')
        buf442 = reinterpret_tensor(buf433, (1, 1, 2048), (2048, 2048, 1), 0); del buf433  # reuse
        # Topologically Sorted Source Nodes: [linear_97, x_28, rms_norm_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf434, buf440, arg132_1, buf442, 1, 2048, stream=raw_stream0)
        del arg132_1
        assert_size_stride(arg133_1, (2048, 2048), (2048, 1), 'input')
        buf443 = buf408; del buf408  # reuse
        # Topologically Sorted Source Nodes: [linear_97, x_28, rms_norm_28, linear_98], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf442, arg133_1, buf443, 128, 1, 1, stream=raw_stream0)
        del arg133_1
        assert_size_stride(arg134_1, (512, 2048), (2048, 1), 'input')
        buf444 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_99], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf442, arg134_1, buf444, 32, 1, 1, stream=raw_stream0)
        del arg134_1
        buf447 = reinterpret_tensor(buf402, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf402  # reuse
        buf445 = reinterpret_tensor(buf447, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_98, view_42, q_28, chunk_28, neg_28], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf443, buf445, 1024, stream=raw_stream0)
        buf446 = reinterpret_tensor(buf447, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_98, view_42, q_28, chunk_28, neg_28, cat_56], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf443, buf446, 1024, stream=raw_stream0)
        buf450 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf448 = reinterpret_tensor(buf450, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_99, view_43, k_56, chunk_29, neg_29], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf444, buf448, 256, stream=raw_stream0)
        del buf445
        del buf446
        buf449 = reinterpret_tensor(buf450, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_99, view_43, k_56, chunk_29, neg_29, cat_57], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf444, buf449, 256, stream=raw_stream0)
        buf453 = buf430; del buf430  # reuse
        buf451 = reinterpret_tensor(buf453, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_99, view_43, k_56, getitem_112, mul_72, mul_73, k_57, k_58], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38.run(arg4_1, buf451, 262144, stream=raw_stream0)
        del buf448
        del buf449
        buf452 = reinterpret_tensor(buf453, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf521 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 7168)  # alias
        # Topologically Sorted Source Nodes: [linear_99, view_43, k_56, mul_72, mul_73, k_57, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf444, arg2_1, buf450, arg3_1, buf452, buf521, 512, stream=raw_stream0)
        buf454 = empty_strided((32, 1, 513), (513, 513, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_98, view_42, q_28, mul_70, mul_71, q_29, o_28, getitem_118, expand_28, k_59], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf443, arg2_1, buf447, arg3_1, buf453, buf454, 16416, 64, stream=raw_stream0)
        del buf443
        del buf451
        del buf452
        buf455 = buf423; del buf423  # reuse
        buf457 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf458 = buf426; del buf426  # reuse
        # Topologically Sorted Source Nodes: [o_28], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf454, buf455, buf457, buf458, 32, 513, stream=raw_stream0)
        del buf454
        assert_size_stride(arg135_1, (512, 2048), (2048, 1), 'input')
        buf459 = reinterpret_tensor(buf450, (1, 512), (512, 1), 0); del buf450  # reuse
        # Topologically Sorted Source Nodes: [linear_100], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf442, arg135_1, buf459, 32, 1, 1, stream=raw_stream0)
        del arg135_1
        buf462 = buf453; del buf453  # reuse
        buf460 = reinterpret_tensor(buf462, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_113, linear_100, view_44, v_42, v_43], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_38.run(arg5_1, buf460, 262144, stream=raw_stream0)
        buf461 = reinterpret_tensor(buf462, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        # Topologically Sorted Source Nodes: [getitem_113, linear_100, view_44, v_42, v_43], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf459, buf461, 512, stream=raw_stream0)
        buf464 = reinterpret_tensor(buf442, (1, 32, 1, 64), (2048, 64, 64, 1), 0); del buf442  # reuse
        # Topologically Sorted Source Nodes: [o_28, getitem_119, expand_29, v_44], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf455, buf457, buf458, buf462, buf464, 2048, 513, stream=raw_stream0)
        del buf457
        del buf460
        del buf461
        assert_size_stride(arg136_1, (2048, 2048), (2048, 1), 'input')
        buf465 = reinterpret_tensor(buf447, (1, 2048), (2048, 1), 0); del buf447  # reuse
        # Topologically Sorted Source Nodes: [o_28, transpose_59, o_29, h_14], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf464, arg136_1, buf465, 128, 1, 1, stream=raw_stream0)
        del arg136_1
        assert_size_stride(arg137_1, (2048, ), (1, ), 'input')
        buf467 = reinterpret_tensor(buf464, (1, 1, 2048), (2048, 2048, 1), 0); del buf464  # reuse
        # Topologically Sorted Source Nodes: [linear_97, x_28, h_14, x_29, y_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf434, buf440, buf465, arg137_1, buf467, 1, 2048, stream=raw_stream0)
        del arg137_1
        assert_size_stride(arg138_1, (8192, 2048), (2048, 1), 'input')
        buf468 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf467, arg138_1, buf468, 512, 1, 1, stream=raw_stream0)
        del arg138_1
        assert_size_stride(arg139_1, (8192, 2048), (2048, 1), 'input')
        buf470 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_74], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf467, arg139_1, buf468, buf470, 512, 1, 1, stream=raw_stream0)
        del arg139_1
        del buf468
        assert_size_stride(arg140_1, (2048, 8192), (8192, 1), 'input')
        buf471 = reinterpret_tensor(buf467, (1, 2048), (2048, 1), 0); del buf467  # reuse
        # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_74, linear_104], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf470, arg140_1, buf471, 128, 1, 1, stream=raw_stream0)
        del arg140_1
        assert_size_stride(arg141_1, (2048, ), (1, ), 'input')
        buf473 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_97, x_28, h_14, x_29, linear_104, x_30, rms_norm_30], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf434, buf440, buf465, buf471, arg141_1, buf473, 1, 2048, stream=raw_stream0)
        del arg141_1
        assert_size_stride(arg142_1, (2048, 2048), (2048, 1), 'input')
        buf474 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_105], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf473, arg142_1, buf474, 128, 1, 1, stream=raw_stream0)
        del arg142_1
        assert_size_stride(arg143_1, (512, 2048), (2048, 1), 'input')
        buf475 = buf444; del buf444  # reuse
        # Topologically Sorted Source Nodes: [linear_106], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf473, arg143_1, buf475, 32, 1, 1, stream=raw_stream0)
        del arg143_1
        buf478 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf476 = reinterpret_tensor(buf478, (1, 32, 1, 32), (2048, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_105, view_45, q_30, chunk_30, neg_30], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf474, buf476, 1024, stream=raw_stream0)
        buf477 = reinterpret_tensor(buf478, (1, 32, 1, 32), (2048, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_105, view_45, q_30, chunk_30, neg_30, cat_60], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf474, buf477, 1024, stream=raw_stream0)
        buf481 = empty_strided((1, 8, 1, 64), (512, 64, 64, 1), device='tnca', dtype=torch.float16)
        buf479 = reinterpret_tensor(buf481, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_106, view_46, k_60, chunk_31, neg_31], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf475, buf479, 256, stream=raw_stream0)
        del buf476
        del buf477
        buf480 = reinterpret_tensor(buf481, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_106, view_46, k_60, chunk_31, neg_31, cat_61], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf475, buf480, 256, stream=raw_stream0)
        buf484 = buf462; del buf462  # reuse
        buf482 = reinterpret_tensor(buf484, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_106, view_46, k_60, getitem_120, mul_77, mul_78, k_61, k_62], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39.run(arg4_1, buf482, 262144, stream=raw_stream0)
        del arg4_1
        del buf479
        del buf480
        buf483 = reinterpret_tensor(buf484, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf522 = reinterpret_tensor(buf523, (1, 8, 1, 64), (512, 64, 64, 1), 7680)  # alias
        # Topologically Sorted Source Nodes: [linear_106, view_46, k_60, mul_77, mul_78, k_61, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf475, arg2_1, buf481, arg3_1, buf483, buf522, 512, stream=raw_stream0)
        del buf475
        buf485 = empty_strided((32, 1, 513), (513, 513, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_105, view_45, q_30, mul_75, mul_76, q_31, o_30, getitem_126, expand_30, k_63], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf474, arg2_1, buf478, arg3_1, buf484, buf485, 16416, 64, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del buf474
        del buf478
        del buf482
        del buf483
        buf486 = buf455; del buf455  # reuse
        buf488 = empty_strided((1, 32, 1, 513), (16416, 513, 16416, 1), device='tnca', dtype=torch.float32)
        buf489 = buf458; del buf458  # reuse
        # Topologically Sorted Source Nodes: [o_30], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf485, buf486, buf488, buf489, 32, 513, stream=raw_stream0)
        del buf485
        assert_size_stride(arg144_1, (512, 2048), (2048, 1), 'input')
        buf490 = reinterpret_tensor(buf481, (1, 512), (512, 1), 0); del buf481  # reuse
        # Topologically Sorted Source Nodes: [linear_107], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf473, arg144_1, buf490, 32, 1, 1, stream=raw_stream0)
        del arg144_1
        del buf473
        buf493 = buf484; del buf484  # reuse
        buf491 = reinterpret_tensor(buf493, (1, 8, 512, 64), (262656, 32832, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_121, linear_107, view_47, v_45, v_46], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_39.run(arg5_1, buf491, 262144, stream=raw_stream0)
        del arg5_1
        buf492 = reinterpret_tensor(buf493, (1, 8, 1, 64), (262656, 32832, 64, 1), 32768)  # alias
        buf540 = reinterpret_tensor(buf470, (16, 8, 1, 64), (512, 64, 64, 1), 0); del buf470  # reuse
        buf539 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 7680)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, getitem_121, linear_107, view_47, v_45, v_46, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_40.run(buf490, buf492, buf539, 512, stream=raw_stream0)
        del buf490
        buf495 = empty_strided((1, 32, 1, 64), (2048, 64, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_30, getitem_127, expand_31, v_47], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf486, buf488, buf489, buf493, buf495, 2048, 513, stream=raw_stream0)
        del buf486
        del buf488
        del buf489
        del buf491
        del buf492
        del buf493
        assert_size_stride(arg145_1, (2048, 2048), (2048, 1), 'input')
        buf496 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_30, transpose_63, o_31, h_15], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf495, arg145_1, buf496, 128, 1, 1, stream=raw_stream0)
        del arg145_1
        assert_size_stride(arg146_1, (2048, ), (1, ), 'input')
        buf497 = buf434; del buf434  # reuse
        buf499 = reinterpret_tensor(buf495, (1, 1, 2048), (2048, 2048, 1), 0); del buf495  # reuse
        # Topologically Sorted Source Nodes: [linear_97, x_28, h_14, x_29, linear_104, x_30, h_15, x_31, y_15], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf497, buf440, buf465, buf471, buf496, arg146_1, buf499, 1, 2048, stream=raw_stream0)
        del arg146_1
        del buf440
        del buf465
        del buf471
        del buf496
        assert_size_stride(arg147_1, (8192, 2048), (2048, 1), 'input')
        buf500 = empty_strided((1, 8192), (8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_15, linear_109], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf499, arg147_1, buf500, 512, 1, 1, stream=raw_stream0)
        del arg147_1
        assert_size_stride(arg148_1, (8192, 2048), (2048, 1), 'input')
        buf502 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_79], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf499, arg148_1, buf500, buf502, 512, 1, 1, stream=raw_stream0)
        del arg148_1
        del buf500
        assert_size_stride(arg149_1, (2048, 8192), (8192, 1), 'input')
        buf503 = reinterpret_tensor(buf499, (1, 2048), (2048, 1), 0); del buf499  # reuse
        # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_79, linear_111], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf502, arg149_1, buf503, 128, 1, 1, stream=raw_stream0)
        del arg149_1
        del buf502
        assert_size_stride(arg150_1, (2048, ), (1, ), 'input')
        buf505 = buf497; del buf497  # reuse
        # Topologically Sorted Source Nodes: [linear_111, x_32, rms_norm_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_41.run(buf505, buf503, arg150_1, 1, 2048, stream=raw_stream0)
        del arg150_1
        del buf503
        assert_size_stride(arg151_1, (128256, 2048), (2048, 1), 'input')
        buf506 = empty_strided((1, 128256), (128256, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_111, x_32, rms_norm_32, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_42.run(buf505, arg151_1, buf506, 8016, 1, 1, stream=raw_stream0)
        del arg151_1
        del buf505
        buf524 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf18, buf524, 512, stream=raw_stream0)
        del buf18
        buf525 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 512)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf49, buf525, 512, stream=raw_stream0)
        del buf49
        buf526 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 1024)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf81, buf526, 512, stream=raw_stream0)
        del buf81
        buf527 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 1536)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf112, buf527, 512, stream=raw_stream0)
        del buf112
        buf528 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 2048)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf144, buf528, 512, stream=raw_stream0)
        del buf144
        buf529 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 2560)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf175, buf529, 512, stream=raw_stream0)
        del buf175
        buf530 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 3072)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf207, buf530, 512, stream=raw_stream0)
        del buf207
        buf531 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 3584)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf238, buf531, 512, stream=raw_stream0)
        del buf238
        buf532 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 4096)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf270, buf532, 512, stream=raw_stream0)
        del buf270
        buf533 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 4608)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf301, buf533, 512, stream=raw_stream0)
        del buf301
        buf534 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 5120)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf333, buf534, 512, stream=raw_stream0)
        del buf333
        buf535 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 5632)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf364, buf535, 512, stream=raw_stream0)
        del buf364
        buf536 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 6144)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf396, buf536, 512, stream=raw_stream0)
        del buf396
        buf537 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 6656)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf427, buf537, 512, stream=raw_stream0)
        del buf427
        buf538 = reinterpret_tensor(buf540, (1, 8, 1, 64), (512, 64, 64, 1), 7168)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, linear_30, view_14, v_12, linear_37, view_17, v_15, linear_44, view_20, v_18, linear_51, view_23, v_21, linear_58, view_26, v_24, linear_65, view_29, v_27, linear_72, view_32, v_30, linear_79, view_35, v_33, linear_86, view_38, v_36, linear_93, view_41, v_39, linear_100, view_44, v_42, linear_107, view_47, v_45, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_43.run(buf459, buf538, 512, stream=raw_stream0)
        del buf459
        return (reinterpret_tensor(buf506, (1, 1, 128256), (128256, 128256, 1), 0), reinterpret_tensor(buf523, (16, 1, 8, 1, 64), (512, 512, 64, 64, 1), 0), reinterpret_tensor(buf540, (16, 1, 8, 1, 64), (512, 512, 64, 64, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((128256, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg3_1 = rand_strided((1, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg4_1 = rand_strided((16, 1, 8, 512, 64), (262144, 262144, 32768, 64, 1), device='tnca:0', dtype=torch.float16)
    arg5_1 = rand_strided((16, 1, 8, 512, 64), (262144, 262144, 32768, 64, 1), device='tnca:0', dtype=torch.float16)
    arg6_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg7_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg8_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg9_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg10_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg11_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg12_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg13_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg14_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg15_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg16_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg17_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg18_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg19_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg20_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg21_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg22_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg23_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg24_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg25_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg26_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg27_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg28_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg29_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg30_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg31_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg32_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg33_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg34_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg35_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg36_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg37_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg38_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg39_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg40_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg41_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg42_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg43_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg44_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg45_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg46_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg47_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg48_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg49_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg50_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg51_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg52_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg53_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg54_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg55_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg56_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg57_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg58_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg59_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg60_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg61_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg62_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg63_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg64_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg65_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg66_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg67_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg68_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg69_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg70_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg71_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg72_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg73_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg74_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg75_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg76_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg77_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg78_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg79_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg80_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg81_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg82_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg83_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg84_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg85_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg86_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg87_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg88_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg89_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg90_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg91_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg92_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg93_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg94_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg95_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg96_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg97_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg98_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg99_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg100_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg101_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg102_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg103_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg104_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg105_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg106_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg107_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg108_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg109_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg110_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg111_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg112_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg113_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg114_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg115_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg116_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg117_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg118_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg119_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg120_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg121_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg122_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg123_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg124_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg125_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg126_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg127_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg128_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg129_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg130_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg131_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg132_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg133_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg134_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg135_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg136_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg137_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg138_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg139_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg140_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg141_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg142_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg143_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg144_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg145_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg146_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg147_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg148_1 = rand_strided((8192, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    arg149_1 = rand_strided((2048, 8192), (8192, 1), device='tnca:0', dtype=torch.float16)
    arg150_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg151_1 = rand_strided((128256, 2048), (2048, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
