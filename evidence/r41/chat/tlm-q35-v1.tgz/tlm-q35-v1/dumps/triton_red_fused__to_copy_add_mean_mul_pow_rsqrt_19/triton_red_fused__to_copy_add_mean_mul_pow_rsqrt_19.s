    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr2: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr3: device_ptr64 at arg_base+40
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s2
    s.movz       s9, #2560
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #1103806595072
    s.st.d       [s1, #104], s9
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s8, #0
    s.st.d       [s1, #0], s3
    s.movz       s8, #2560
    s.st.d       [s1, #8], s8
    s.movz       s8, #2
    s.st.d       [s1, #48], s8
    s.movz       s8, #16
    s.st.d       [s1, #88], s8
    .li       s8, #1103806595072
    s.st.d       [s1, #104], s8
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #2560
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #2560
    s.movz       s12, #2560
    s.muli       s13, s10, #2
    s.muli       s14, s10, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s11
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s12
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.add        s11, s2, s13
    p.and        p5, p1, p2
    s.add        s12, s3, s14
    p.and        p1, p3, p4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s11, #0]
    v.splat      v3, s10
    v.movi       v4, #2560
    v.movi       v5, #0
    v.add        v6, v3, v0
    s.add        s11, s10, s9
    s.movz       s13, #1
    v.cmp.lt     p2, v6, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s12, #0]
    vf.cvt.bf16.f32 v4, v1
    vf.cvt.bf16.f32 v1, v3
    vf.add       v3, v4, v1
    vf.mul       v1, v3, v3
    vf.add       v3, v2, v1
    @p2 v.sel        v1, v3, v2
    v.mov        v5, v1
    v.mov        v2, v5
    s.mov        s10, s11
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s10, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_4
    .li       s1, #1159725056
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v4, s10
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s10
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s1, #2560
    s.movz       s11, #2560
    s.muli       s12, s10, #2
    s.muli       s13, s10, #2
    v.add        v9, v4, v6
    v.movi       v4, #0
    v.splat      v6, s1
    v.add        v10, v7, v8
    v.movi       v7, #0
    v.cmp.ge     p1, v9, v4
    v.splat      v4, s11
    v.cmp.lt     p2, v9, v6
    v.cmp.ge     p3, v10, v7
    v.cmp.lt     p4, v10, v4
    v.splat      v4, s10
    s.add        s1, s2, s12
    p.and        p5, p1, p2
    s.add        s11, s3, s13
    p.and        p1, p3, p4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v6, [s1, #0]
    v.add        v7, v4, v0
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #2560
    s.shli       s1, s10, #1                     // element offset -> bytes (x2)
    vf.fms       v9, v1, v5, v2
    s.add        s12, s4, s1                     // &in_ptr2[...]
    v.cmp.lt     p2, v7, v8
    .li       s13, #1077936128
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #3204448256
    v.splat      v7, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v5, v9, v5
    .li       s13, #1065353216
    v.splat      v9, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s11, #0]
    vf.neg       v11, v8                         // Newton step: r0*(2 - x*r0)
    vf.cvt.bf16.f32 v8, v6
    s.add        s11, s5, s1                     // &out_ptr1[...]
    s.add        s13, s6, s1                     // &out_ptr2[...]
    s.add        s14, s7, s1                     // &out_ptr3[...]
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v6, v11, v5
    s.add        s1, s10, s9
    s.movz       s15, #1
    vf.mul       v5, v3, v6                      // a/y: faithful quotient
    vf.cvt.bf16.f32 v11, v10
    vf.fms       v10, v5, v1, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    vf.add       v12, v8, v11
    vf.fms       v8, v10, v6, v5
    vf.neg       v6, v8                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v8, v6, v5
    vf.cvt.bf16.f32 v5, v1
    vf.add       v1, v8, v4
    vf.add       v4, v5, v9
    v.rsqrt.approx v5, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v5, v5
    vf.mul       v8, v5, v7
    vf.fms       v7, v1, v6, v2
    vf.mul       v1, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v5
    v.extract    s12, v2, #0
    v.splat      v1, s12
    vf.mul       v2, v12, v1
    vf.mul       v1, v2, v4
    vf.cvt.f32.bf16 v2, v1
    @p2 v.st.h       [s11, #0], v2
    @p2 v.st.h       [s13, #0], v2
    @p2 v.st.h       [s14, #0], v2
    s.mov        s10, s1
    br.nz        s15, for_3
endfor_4:
    exit
    exit
