    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #6208
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #16
    s.rdspecial  s2, pid.y
    s.movz       s6, #4096
    s.mul        s7, s2, s1
    s.movz       s2, #0
    s.movz       s8, #144
    s.movz       s8, #9
    s.add        s9, s3, s5                      // this context's own scratch
    s.ld.d       s3, [s4, #0]                    // arg_X: device_ptr64 at arg_base+0
    s.addi       s5, s9, #0
    s.addi       s10, s9, #1024
    s.addi       s11, s5, #64
    s.addi       s12, s5, #128
    s.addi       s13, s5, #192
    s.addi       s14, s5, #256
    s.addi       s15, s5, #320
    s.addi       s16, s5, #384
    s.addi       s17, s5, #448
    s.addi       s18, s5, #512
    s.ld.d       s19, [s4, #8]                   // arg_W: device_ptr64 at arg_base+8
    s.addi       s20, s5, #576
    s.addi       s21, s5, #640
    s.addi       s22, s5, #704
    s.addi       s23, s5, #768
    s.addi       s24, s5, #832
    s.addi       s25, s5, #896
    s.addi       s26, s5, #960
    s.movz       s27, #1
    s.rdspecial  s28, role_id
    s.rdspecial  s29, npid.x
    s.ld.d       s30, [s4, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s31, [s4, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s32, [s4, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s33, [s4, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s34, [s4, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s35, [s4, #56]                  // out_ptr1: device_ptr64 at arg_base+56
__rctx_program:
    s.mul        s4, s28, s1
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #4
    v.movi       v3, #0
    v.splat      v4, s4
    v.movi       v5, #4
    v.movi       v6, #0
    v.add        v7, v4, v0
    v.movi       v4, #0
    v.movi       v8, #15
    v.sub        v9, v1, v7
    v.cmp.lt     p1, v7, v1
    v.sub        v10, v6, v7
    @p1 v.sel        v11, v9, v7
    v.cmp.lt     p2, v7, v6
    @p2 v.sel        v9, v10, v7
    v.lshr       v7, v11, v2
    v.movi       v2, #15
    v.movi       v10, #16
    v.sub        v11, v1, v7
    v.splat      v12, s7
    v.and        v13, v9, v8
    @p1 v.sel        v8, v11, v7
    v.sub        v7, v6, v10
    v.sub        v9, v6, v13
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p3, v8, v4
    v.movi       v11, #1
    v.add        v11, v12, v0
    @p2 v.sel        v12, v9, v13
    v.sub        v9, v3, v8
    v.cmp.lt     p2, v10, v6
    v.movi       v6, #4096
    @p1 v.sel        v13, v9, v8
    @p2 v.sel        v9, v7, v10
    v.sub        v7, v4, v8
    v.lshr       v9, v13, v5
    v.splat      v5, s2
    @p3 v.sel        v13, v7, v8
    v.sub        v7, v3, v9
    v.cmp.lt     p2, v10, v1
    v.and        v8, v13, v2
    @p1 v.sel        v2, v7, v9
    v.sub        v7, v1, v10
    v.sub        v1, v4, v10
    v.mul        v9, v2, v6
    v.sub        v6, v4, v8
    v.cmp.lt     p1, v10, v4
    v.extract    s4, v9, #0
    v.extract    s36, v9, #1
    v.splat      v4, s4
    v.movi       v13, #1
    v.extract    s4, v9, #2
    v.extract    s37, v9, #3
    v.add        v13, v5, v4
    @p2 v.sel        v4, v7, v10
    v.extract    s38, v9, #4
    v.splat      v4, s36
    v.cmp.lt     p2, v10, v3
    v.sub        v7, v3, v10
    v.add        v3, v5, v4
    v.movi       v4, #1
    v.extract    s36, v9, #5
    v.extract    s39, v9, #6
    @p1 v.sel        v4, v1, v10
    v.splat      v1, s4
    v.extract    s4, v9, #7
    @p3 v.sel        v4, v6, v8
    v.splat      v6, s37
    v.add        v8, v5, v1
    v.movi       v1, #1
    v.extract    s37, v9, #8
    v.add        v1, v5, v6
    @p2 v.sel        v6, v7, v10
    v.splat      v6, s38
    v.extract    s38, v9, #9
    v.st.w       [s5, #0], v13
    v.splat      v7, s36
    v.extract    s36, v9, #10
    v.add        v13, v5, v6
    v.add        v6, v5, v7
    v.st.w       [s11, #0], v3
    v.splat      v3, s39
    v.extract    s39, v9, #11
    v.add        v7, v5, v3
    v.st.w       [s12, #0], v8
    v.splat      v3, s4
    v.extract    s4, v9, #12
    v.add        v8, v5, v3
    v.st.w       [s13, #0], v1
    v.movi       v1, #144
    v.mul        v3, v11, v1
    v.st.w       [s14, #0], v13
    v.splat      v1, s37
    v.extract    s37, v9, #13
    v.add        v13, v5, v1
    v.st.w       [s15, #0], v6
    v.splat      v1, s38
    v.extract    s38, v9, #14
    v.add        v6, v5, v1
    v.st.w       [s16, #0], v7
    v.splat      v1, s36
    v.extract    s36, v9, #15
    v.splat      v7, s39
    v.add        v9, v5, v1
    s.addi       s39, s2, #0
    v.add        v1, v5, v7
    v.st.w       [s17, #0], v8
    v.splat      v7, s4
    v.add        v8, v5, v7
    v.st.w       [s18, #0], v13
    v.splat      v7, s37
    v.add        v13, v5, v7
    v.st.w       [s20, #0], v6
    v.splat      v6, s38
    v.add        v7, v5, v6
    v.st.w       [s21, #0], v9
    v.splat      v6, s36
    v.add        v9, v5, v6
    v.splat      v5, s2
    v.add        v6, v5, v3
    v.st.w       [s22, #0], v1
    v.st.w       [s23, #0], v8
    v.st.w       [s24, #0], v13
    v.st.w       [s25, #0], v7
    v.st.w       [s26, #0], v9
    fence.acq_rel.device
    v.st.w       [s10, #0], v6
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s4, s39, s8
    br.nz        s4, endfor_2
    s.movz       s4, #0
    .li       s36, #1431655766
    s.cmp.lt     s37, s39, s4
    s.cmp.lt     s38, s39, s4
    s.sub        s40, s4, s37
    s.sub        s37, s4, s38
    s.xor        s38, s39, s40
    s.xor        s41, s39, s37
    s.sub        s42, s38, s40
    s.sub        s38, s41, s37
    s.mul        s41, s42, s36
    s.mul        s43, s38, s36
    s.movz       s36, #3
    s.addi       s44, s9, #0
    s.cmp.lt     s45, s36, s4
    s.lshri      s46, s41, #32
    s.lshri      s41, s43, #32
    s.sub        s43, s42, s46
    s.sub        s47, s38, s41
    s.lshri      s48, s43, #1
    s.lshri      s43, s47, #1
    s.add        s47, s46, s48
    s.sub        s46, s4, s45
    s.lshri      s4, s47, #1
    s.add        s45, s41, s43
    s.muli       s41, s4, #3
    s.lshri      s4, s45, #1
    s.xor        s43, s37, s46
    v.ld.w       v1, [s44, #0]
    s.xor        s37, s4, s43
    s.sub        s44, s42, s41
    s.sub        s41, s37, s43
    s.xor        s37, s44, s40
    s.sub        s42, s41, s27
    s.sub        s43, s37, s40
    v.splat      v3, s42
    s.sub        s37, s43, s27
    v.movi       v5, #256
    v.splat      v6, s37
    v.add        v7, v3, v4
    v.iota       v3                              // arange(0, VLEN)
    v.add        v8, v6, v12
    v.mul        v6, v7, v5
    s.addi       s37, s9, #1088
    v.mul        v5, v8, v10
    v.extract    s40, v6, #0
    s.muli       s42, s4, #3
    v.extract    s4, v5, #0
    v.splat      v9, s40
    v.splat      v13, s4
    s.xor        s4, s36, s46
    s.sub        s40, s38, s42
    v.add        v14, v9, v13
    s.sub        s38, s4, s46
    s.addi       s4, s9, #64
    v.add        v9, v14, v3
    v.extract    s38, v6, #1
    v.extract    s40, v5, #1
    v.add        v13, v1, v9
    v.splat      v1, s38
    v.splat      v9, s40
    v.st.w       [s37, #0], v13
    s.addi       s38, s37, #64
    v.add        v13, v1, v9
    s.addi       s40, s9, #128
    v.extract    s42, v6, #2
    v.add        v1, v13, v3
    v.extract    s44, v5, #2
    v.splat      v9, s42
    v.splat      v13, s44
    s.addi       s42, s37, #128
    s.addi       s44, s9, #192
    v.add        v14, v9, v13
    v.extract    s45, v6, #3
    v.extract    s46, v5, #3
    v.add        v9, v14, v3
    v.splat      v13, s45
    v.splat      v14, s46
    s.addi       s45, s37, #192
    v.ld.w       v15, [s4, #0]
    v.add        v16, v13, v14
    s.movz       s4, #256
    s.addi       s4, s9, #256
    v.add        v13, v16, v3
    v.extract    s46, v6, #4
    v.extract    s47, v5, #4
    v.splat      v14, s46
    v.splat      v16, s47
    s.addi       s46, s37, #256
    s.addi       s47, s9, #320
    v.add        v17, v14, v16
    v.add        v14, v17, v3
    v.add        v16, v15, v1
    v.st.w       [s38, #0], v16
    v.extract    s38, v6, #5
    v.splat      v1, s38
    v.extract    s38, v5, #5
    v.splat      v15, s38
    s.addi       s38, s37, #320
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s40, #0]
    s.addi       s40, s9, #384
    v.add        v16, v15, v9
    v.st.w       [s42, #0], v16
    v.extract    s42, v6, #6
    v.splat      v9, s42
    v.extract    s42, v5, #6
    v.splat      v15, s42
    s.addi       s42, s37, #384
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s44, #0]
    s.addi       s44, s9, #448
    v.add        v16, v15, v13
    v.st.w       [s45, #0], v16
    v.extract    s45, v6, #7
    v.splat      v13, s45
    v.extract    s45, v5, #7
    v.splat      v15, s45
    s.addi       s45, s37, #448
    v.add        v16, v13, v15
    v.add        v13, v16, v3
    v.ld.w       v15, [s4, #0]
    s.addi       s4, s9, #512
    v.add        v16, v15, v14
    v.st.w       [s46, #0], v16
    v.extract    s46, v6, #8
    v.splat      v14, s46
    v.extract    s46, v5, #8
    v.splat      v15, s46
    s.addi       s46, s37, #512
    v.add        v16, v14, v15
    v.add        v14, v16, v3
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s9, #576
    v.add        v16, v15, v1
    v.st.w       [s38, #0], v16
    v.extract    s38, v6, #9
    v.splat      v1, s38
    v.extract    s38, v5, #9
    v.splat      v15, s38
    s.addi       s38, s37, #576
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s40, #0]
    s.addi       s40, s9, #640
    v.add        v16, v15, v9
    v.st.w       [s42, #0], v16
    v.extract    s42, v6, #10
    v.splat      v9, s42
    v.extract    s42, v5, #10
    v.splat      v15, s42
    s.addi       s42, s37, #640
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s44, #0]
    s.addi       s44, s9, #704
    v.add        v16, v15, v13
    v.st.w       [s45, #0], v16
    v.extract    s45, v6, #11
    v.splat      v13, s45
    v.extract    s45, v5, #11
    v.splat      v15, s45
    s.addi       s45, s37, #704
    v.add        v16, v13, v15
    v.add        v13, v16, v3
    v.ld.w       v15, [s4, #0]
    s.addi       s4, s9, #768
    v.add        v16, v15, v14
    v.st.w       [s46, #0], v16
    v.extract    s46, v6, #12
    v.splat      v14, s46
    v.extract    s46, v5, #12
    v.splat      v15, s46
    s.addi       s46, s37, #768
    v.add        v16, v14, v15
    v.add        v14, v16, v3
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s9, #832
    v.add        v16, v15, v1
    v.st.w       [s38, #0], v16
    v.extract    s38, v6, #13
    v.splat      v1, s38
    v.extract    s38, v5, #13
    v.splat      v15, s38
    s.addi       s38, s37, #832
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s40, #0]
    s.addi       s40, s9, #896
    v.add        v16, v15, v9
    v.st.w       [s42, #0], v16
    v.extract    s42, v6, #14
    v.splat      v9, s42
    v.extract    s42, v5, #14
    v.splat      v15, s42
    s.addi       s42, s37, #896
    s.addi       s48, s37, #960
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s44, #0]
    s.addi       s37, s9, #960
    v.movi       v16, #1
    v.add        v17, v15, v13
    v.cmp.lt     p1, v2, v16
    v.st.w       [s45, #0], v17
    v.extract    s44, v6, #15
    v.movi       v6, #0
    v.splat      v13, s44
    v.extract    s44, v5, #15
    v.cmp.ge     p2, v7, v6
    v.splat      v5, s44
    @p1 v.sel        v15, v16, v6
    v.add        v17, v13, v5
    v.add        v5, v17, v3
    v.ld.w       v13, [s4, #0]
    v.movi       v17, #1
    v.movi       v18, #0
    @p2 v.sel        v19, v16, v6
    v.cmp.lt     p1, v7, v10
    @p1 v.sel        v7, v17, v18
    v.cmp.ge     p1, v8, v6
    @p1 v.sel        v6, v17, v18
    v.add        v16, v13, v14
    v.cmp.lt     p1, v8, v10
    v.st.w       [s46, #0], v16
    @p1 v.sel        v8, v17, v18
    v.cmp.lt     p1, v0, v10
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    v.ld.w       v13, [s47, #0]
    s.addi       s44, s9, #1088
    v.extract    s45, v15, #0
    v.extract    s46, v19, #0
    v.splat      v14, s45
    v.movi       v16, #0
    v.cmp.ne     p2, v14, v16
    v.add        v14, v13, v1
    v.splat      v1, s46
    v.st.w       [s38, #0], v14
    v.extract    s38, v7, #0
    v.cmp.ne     p3, v1, v16
    p.and        p4, p2, p3
    v.ld.w       v1, [s40, #0]
    v.splat      v13, s38
    v.movi       v14, #0
    v.extract    s38, v6, #0
    v.splat      v16, s38
    v.cmp.ne     p2, v13, v14
    p.and        p3, p4, p2
    v.cmp.ne     p2, v16, v14
    v.add        v13, v1, v9
    p.and        p4, p3, p2
    v.st.w       [s42, #0], v13
    v.extract    s38, v8, #0
    v.movi       v1, #0
    v.splat      v9, s38
    v.ld.w       v13, [s37, #0]
    v.cmp.ne     p2, v9, v1
    p.and        p3, p4, p2
    s.addi       s37, s9, #1152
    p.and        p2, p3, p1
    s.movz       s38, #1
    v.add        v1, v13, v5
    v.st.w       [s48, #0], v1
    fence.acq_rel.device
    v.extract    s40, v15, #1
    v.extract    s42, v19, #1
    v.splat      v1, s40
    v.movi       v5, #0
    v.splat      v9, s42
    v.extract    s40, v7, #1
    v.movi       v13, #0
    v.splat      v14, s40
    v.extract    s40, v6, #1
    v.cmp.ne     p3, v1, v5
    v.cmp.ne     p4, v9, v5
    p.and        p5, p3, p4
    v.splat      v1, s40
    v.extract    s40, v8, #1
    v.cmp.ne     p3, v14, v13
    p.and        p4, p5, p3
    v.ld.w       v5, [s44, #0]
    v.splat      v9, s40
    v.movi       v14, #0
    v.cmp.ne     p3, v1, v13
    p.and        p5, p4, p3
    v.cmp.ne     p3, v9, v14
    p.and        p4, p5, p3
    s.addi       s40, s9, #1216
    p.and        p3, p4, p1
    v.extract    s42, v15, #2
    v.extract    s44, v19, #2
    v.splat      v1, s42
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s42, v7, #2
    v.movi       v14, #0
    v.splat      v16, s42
    v.extract    s42, v6, #2
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s42
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s42, #2
    a.vwrite     a1, s4, v17
    v.ld.w       v1, [s37, #0]
    v.extract    s4, v8, #2
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1280
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s37, v15, #3
    p.and        p2, p4, p1
    v.extract    s44, v19, #3
    v.splat      v5, s37
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s37, v7, #3
    v.movi       v14, #0
    v.splat      v16, s37
    v.extract    s37, v6, #3
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s37
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s37, #3
    a.vwrite     a1, s38, v17
    v.ld.w       v1, [s40, #0]
    v.extract    s38, v8, #3
    v.movi       v5, #0
    v.splat      v9, s38
    p.and        p5, p4, p3
    s.addi       s38, s9, #1344
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s40, v15, #4
    p.and        p3, p4, p1
    v.extract    s44, v19, #4
    v.splat      v5, s40
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s40, v7, #4
    v.movi       v14, #0
    v.splat      v16, s40
    v.extract    s40, v6, #4
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s40
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s40, #4
    a.vwrite     a1, s42, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #4
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1408
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s42, v15, #5
    p.and        p2, p4, p1
    v.extract    s44, v19, #5
    v.splat      v5, s42
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s42, v7, #5
    v.movi       v14, #0
    v.splat      v16, s42
    v.extract    s42, v6, #5
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s42
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s42, #5
    a.vwrite     a1, s37, v17
    v.ld.w       v1, [s38, #0]
    v.extract    s37, v8, #5
    v.movi       v5, #0
    v.splat      v9, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1472
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s38, v15, #6
    p.and        p3, p4, p1
    v.extract    s44, v19, #6
    v.splat      v5, s38
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s38, v7, #6
    v.movi       v14, #0
    v.splat      v16, s38
    v.extract    s38, v6, #6
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s38
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s38, #6
    a.vwrite     a1, s40, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #6
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1536
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s40, v15, #7
    p.and        p2, p4, p1
    v.extract    s44, v19, #7
    v.splat      v5, s40
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s40, v7, #7
    v.movi       v14, #0
    v.splat      v16, s40
    v.extract    s40, v6, #7
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s40
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s40, #7
    a.vwrite     a1, s42, v17
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #7
    v.movi       v5, #0
    v.splat      v9, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1600
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s42, v15, #8
    p.and        p3, p4, p1
    v.extract    s44, v19, #8
    v.splat      v5, s42
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s42, v7, #8
    v.movi       v14, #0
    v.splat      v16, s42
    v.extract    s42, v6, #8
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s42
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s42, #8
    a.vwrite     a1, s38, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #8
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1664
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s38, v15, #9
    p.and        p2, p4, p1
    v.extract    s44, v19, #9
    v.splat      v5, s38
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s38, v7, #9
    v.movi       v14, #0
    v.splat      v16, s38
    v.extract    s38, v6, #9
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s38
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s38, #9
    a.vwrite     a1, s40, v17
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #9
    v.movi       v5, #0
    v.splat      v9, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1728
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s40, v15, #10
    p.and        p3, p4, p1
    v.extract    s44, v19, #10
    v.splat      v5, s40
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s40, v7, #10
    v.movi       v14, #0
    v.splat      v16, s40
    v.extract    s40, v6, #10
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s40
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s40, #10
    a.vwrite     a1, s42, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #10
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1792
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s42, v15, #11
    p.and        p2, p4, p1
    v.extract    s44, v19, #11
    v.splat      v5, s42
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s42, v7, #11
    v.movi       v14, #0
    v.splat      v16, s42
    v.extract    s42, v6, #11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s42
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s42, #11
    a.vwrite     a1, s38, v17
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #11
    v.movi       v5, #0
    v.splat      v9, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1856
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s38, v15, #12
    p.and        p3, p4, p1
    v.extract    s44, v19, #12
    v.splat      v5, s38
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s38, v7, #12
    v.movi       v14, #0
    v.splat      v16, s38
    v.extract    s38, v6, #12
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s38
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s38, #12
    a.vwrite     a1, s40, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #12
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #1920
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s40, v15, #13
    p.and        p2, p4, p1
    v.extract    s44, v19, #13
    v.splat      v5, s40
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s40, v7, #13
    v.movi       v14, #0
    v.splat      v16, s40
    v.extract    s40, v6, #13
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s40
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s40, #13
    a.vwrite     a1, s42, v17
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #13
    v.movi       v5, #0
    v.splat      v9, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1984
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s42, v15, #14
    p.and        p3, p4, p1
    v.extract    s44, v19, #14
    v.splat      v5, s42
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s42, v7, #14
    v.movi       v14, #0
    v.splat      v16, s42
    v.extract    s42, v6, #14
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s42
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s42, #14
    a.vwrite     a1, s38, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #14
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s9, #2048
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s38, v15, #15
    p.and        p2, p4, p1
    v.extract    s44, v19, #15
    v.splat      v5, s38
    v.movi       v9, #0
    v.splat      v13, s44
    v.extract    s38, v7, #15
    v.movi       v7, #0
    v.splat      v14, s38
    v.extract    s38, v6, #15
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s38
    v.cmp.ne     p3, v14, v7
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v7
    s.movz       s38, #15
    a.vwrite     a1, s40, v6
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #15
    v.movi       v5, #0
    v.splat      v6, s37
    p.and        p5, p4, p3
    s.addi       s37, s9, #1024
    v.cmp.ne     p3, v6, v5
    p.and        p4, p5, p3
    s.movz       s40, #48
    p.and        p3, p4, p1
    s.mul        s44, s41, s40
    s.mul        s40, s43, s1
    s.movz       s41, #0
    s.addi       s43, s9, #2112
    s.add        s45, s41, s44                   // the tile origin
    s.addi       s41, s43, #64
    s.add        s44, s45, s40                   // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.splat      v1, s44
    s.addi       s40, s44, #1
    s.addi       s45, s43, #128
    v.splat      v6, s40
    a.vwrite     a1, s42, v5
    v.ld.w       v5, [s4, #0]
    s.addi       s4, s44, #2
    s.addi       s40, s44, #3
    v.splat      v7, s4
    v.splat      v8, s40
    s.addi       s4, s43, #192
    s.addi       s40, s44, #4
    s.addi       s42, s43, #256
    v.splat      v9, s40
    s.addi       s40, s44, #5
    s.addi       s46, s43, #320
    v.splat      v13, s40
    s.addi       s40, s44, #6
    s.addi       s47, s43, #384
    v.splat      v14, s40
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v15, [s3, v5]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s38, v15
    v.ld.w       v5, [s37, #0]
    s.addi       s38, s44, #7
    s.addi       s40, s43, #448
    v.splat      v15, s38
    s.addi       s38, s44, #8
    v.splat      v16, s38
    s.addi       s38, s43, #512
    v.add        v17, v5, v1
    v.st.w       [s43, #0], v17
    v.ld.w       v1, [s37, #0]
    v.add        v5, v1, v6
    v.st.w       [s41, #0], v5
    s.addi       s41, s9, #1024
    v.ld.w       v1, [s37, #0]
    v.add        v5, v1, v7
    v.st.w       [s45, #0], v5
    s.addi       s45, s44, #9
    v.splat      v1, s45
    s.addi       s45, s43, #576
    v.ld.w       v5, [s37, #0]
    v.add        v6, v5, v8
    v.st.w       [s4, #0], v6
    s.addi       s4, s44, #10
    v.splat      v5, s4
    s.addi       s4, s43, #640
    v.ld.w       v6, [s37, #0]
    v.add        v7, v6, v9
    v.st.w       [s42, #0], v7
    s.addi       s42, s44, #11
    v.splat      v6, s42
    s.addi       s42, s43, #704
    v.ld.w       v7, [s37, #0]
    v.add        v8, v7, v13
    v.st.w       [s46, #0], v8
    s.addi       s46, s44, #12
    v.splat      v7, s46
    s.addi       s46, s43, #768
    v.ld.w       v8, [s37, #0]
    v.add        v9, v8, v14
    v.st.w       [s47, #0], v9
    s.addi       s47, s44, #13
    v.splat      v8, s47
    s.addi       s47, s43, #832
    v.ld.w       v9, [s37, #0]
    v.add        v13, v9, v15
    v.st.w       [s40, #0], v13
    s.addi       s40, s44, #14
    s.addi       s48, s44, #15
    v.splat      v9, s40
    s.addi       s40, s43, #896
    v.splat      v13, s48
    s.addi       s44, s43, #960
    v.ld.w       v14, [s37, #0]
    s.addi       s37, s9, #2112
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s43, #0
    v.add        v15, v14, v16
    v.st.w       [s38, #0], v15
    v.splat      v14, s2
    v.splat      v15, s1
    v.cmp.lt     p1, v14, v15
    v.ld.w       v14, [s41, #0]
    s.add        s38, s43, s7                    // the tile origin
    v.splat      v16, s38
    v.add        v17, v3, v16
    v.add        v3, v14, v1
    v.cmp.lt     p2, v17, v15
    v.st.w       [s45, #0], v3
    p.and        p3, p1, p2
    v.ld.w       v1, [s41, #0]
    s.addi       s38, s9, #2176
    s.movz       s45, #1
    v.add        v3, v1, v5
    v.st.w       [s4, #0], v3
    v.splat      v1, s27
    v.cmp.lt     p1, v1, v15
    v.ld.w       v1, [s41, #0]
    p.and        p4, p1, p2
    v.add        v3, v1, v6
    s.movz       s4, #2
    v.st.w       [s42, #0], v3
    s.addi       s42, s9, #2240
    v.ld.w       v1, [s41, #0]
    v.splat      v3, s4
    v.cmp.lt     p1, v3, v15
    p.and        p5, p1, p2
    v.add        v3, v1, v7
    v.st.w       [s46, #0], v3
    s.movz       s46, #3
    v.ld.w       v1, [s41, #0]
    v.splat      v3, s36
    s.addi       s36, s9, #2304
    v.add        v5, v1, v8
    v.st.w       [s47, #0], v5
    v.ld.w       v1, [s41, #0]
    s.addi       s47, s9, #2368
    v.add        v5, v1, v9
    v.st.w       [s40, #0], v5
    s.movz       s40, #4
    v.splat      v1, s40
    v.ld.w       v5, [s41, #0]
    v.add        v6, v5, v13
    s.movz       s41, #5
    v.st.w       [s44, #0], v6
    fence.acq_rel.device
    s.addi       s44, s9, #2432
    v.splat      v5, s41
    v.ld.w       v6, [s37, #0]
    s.addi       s37, s9, #2496
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s19, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s43, v7
    v.ld.w       v3, [s38, #0]
    s.movz       s38, #6
    s.addi       s43, s9, #2560
    v.splat      v6, s38
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s19, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s45, v7
    v.ld.w       v1, [s42, #0]
    s.movz       s42, #7
    s.addi       s45, s9, #2624
    v.splat      v3, s42
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s4, v7
    v.ld.w       v1, [s36, #0]
    s.movz       s4, #8
    s.addi       s36, s9, #2688
    v.splat      v5, s4
    v.splat      v7, s8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s46, v8
    v.ld.w       v1, [s47, #0]
    s.movz       s46, #9
    s.addi       s47, s9, #2752
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s40, v6
    v.ld.w       v1, [s44, #0]
    s.movz       s40, #10
    s.addi       s44, s9, #2816
    v.splat      v3, s40
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s41, v6
    v.ld.w       v1, [s37, #0]
    s.movz       s37, #11
    s.addi       s41, s9, #2880
    v.splat      v5, s37
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s38, v6
    v.ld.w       v1, [s43, #0]
    s.movz       s38, #12
    s.addi       s43, s9, #2944
    v.splat      v6, s38
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s42, v7
    v.ld.w       v1, [s45, #0]
    s.movz       s42, #13
    s.addi       s45, s9, #3008
    v.splat      v3, s42
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s4, v7
    v.ld.w       v1, [s36, #0]
    s.movz       s4, #14
    s.addi       s36, s9, #3072
    v.splat      v5, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s46, v7
    v.ld.w       v1, [s47, #0]
    s.movz       s46, #15
    s.movz       s47, #0
    v.splat      v6, s46
    v.movi       v7, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s40, v8
    v.ld.w       v1, [s44, #0]
    v.movi       v3, #0
    s.movz       s40, #1
    s.movz       s44, #2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s37, v8
    v.ld.w       v1, [s41, #0]
    s.movz       s37, #3
    v.movi       v5, #1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s38, v8
    v.ld.w       v1, [s43, #0]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s19, v1]              // index is in elements (ISA sec 9.1)
    v.movi       v1, #2
    a.vwrite     a2, s42, v6
    v.ld.w       v6, [s45, #0]
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s19, v6]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s4, v8
    v.ld.w       v6, [s36, #0]
    v.movi       v8, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s19, v6]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s46, v9
    a.vread      v6, a1, s47
    a.vread      v9, a1, s40
    a.vread      v13, a1, s44
    a.vread      v14, a1, s37
    a.vread      v15, a2, s47
    v.permute    v16, v6, v3
    a.vread      v17, a2, s40
    v.permute    v18, v6, v5
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s44
    v.permute    v21, v6, v1
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v5
    a.vread      v19, a2, s37
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    s.movz       s4, #4
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v1
    s.movz       s36, #5
    v.permute    v23, v14, v3
    vf.fma       v3, v18, v20, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v23, v15, v7
    v.permute    v15, v6, v21
    vf.fma       v23, v15, v18, v16
    v.permute    v15, v13, v5
    s.movz       s4, #6
    v.permute    v16, v14, v5
    vf.fma       v5, v15, v17, v22
    v.movi       v15, #5
    vf.fma       v22, v16, v17, v24
    v.permute    v16, v9, v8
    a.vread      v17, a2, s36
    vf.fma       v24, v16, v19, v3
    v.permute    v3, v6, v15
    vf.fma       v16, v3, v17, v23
    v.permute    v3, v13, v1
    v.permute    v23, v14, v1
    s.movz       s36, #7
    vf.fma       v1, v3, v20, v5
    v.movi       v3, #6
    vf.fma       v5, v23, v20, v22
    v.permute    v20, v9, v21
    a.vread      v22, a2, s4
    vf.fma       v23, v20, v18, v24
    v.permute    v20, v6, v3
    vf.fma       v24, v20, v22, v16
    v.permute    v16, v13, v8
    v.permute    v20, v14, v8
    s.movz       s4, #8
    vf.fma       v8, v16, v19, v1
    v.movi       v1, #7
    vf.fma       v16, v20, v19, v5
    v.permute    v5, v9, v15
    a.vread      v19, a2, s36
    vf.fma       v20, v5, v17, v23
    v.permute    v5, v6, v1
    vf.fma       v23, v5, v19, v24
    v.permute    v5, v13, v21
    v.permute    v24, v14, v21
    s.movz       s36, #9
    vf.fma       v21, v5, v18, v8
    v.movi       v5, #8
    vf.fma       v8, v24, v18, v16
    v.permute    v16, v9, v3
    a.vread      v18, a2, s4
    vf.fma       v24, v16, v22, v20
    v.permute    v16, v6, v5
    vf.fma       v20, v16, v18, v23
    v.permute    v16, v13, v15
    v.permute    v23, v14, v15
    s.movz       s4, #10
    vf.fma       v15, v16, v17, v21
    v.movi       v16, #9
    vf.fma       v21, v23, v17, v8
    v.permute    v8, v9, v1
    a.vread      v17, a2, s36
    vf.fma       v23, v8, v19, v24
    v.permute    v8, v6, v16
    vf.fma       v24, v8, v17, v20
    v.permute    v8, v13, v3
    v.permute    v20, v14, v3
    s.movz       s36, #11
    vf.fma       v3, v8, v22, v15
    v.movi       v8, #10
    vf.fma       v15, v20, v22, v21
    v.permute    v20, v9, v5
    a.vread      v21, a2, s4
    vf.fma       v22, v20, v18, v23
    v.permute    v20, v6, v8
    vf.fma       v23, v20, v21, v24
    v.permute    v20, v13, v1
    v.permute    v24, v14, v1
    s.movz       s4, #12
    vf.fma       v1, v20, v19, v3
    v.movi       v3, #11
    vf.fma       v20, v24, v19, v15
    v.permute    v15, v9, v16
    a.vread      v19, a2, s36
    vf.fma       v24, v15, v17, v22
    v.permute    v15, v6, v3
    vf.fma       v22, v15, v19, v23
    v.permute    v15, v13, v5
    v.permute    v23, v14, v5
    s.movz       s36, #13
    vf.fma       v5, v15, v18, v1
    v.movi       v1, #12
    vf.fma       v15, v23, v18, v20
    v.permute    v18, v9, v8
    a.vread      v20, a2, s4
    vf.fma       v23, v18, v21, v24
    v.permute    v18, v6, v1
    vf.fma       v24, v18, v20, v22
    v.permute    v18, v13, v16
    v.permute    v22, v14, v16
    s.movz       s4, #14
    vf.fma       v16, v18, v17, v5
    v.movi       v5, #13
    vf.fma       v18, v22, v17, v15
    v.permute    v15, v9, v3
    a.vread      v17, a2, s36
    vf.fma       v22, v15, v19, v23
    v.permute    v15, v6, v5
    vf.fma       v23, v15, v17, v24
    v.permute    v15, v13, v8
    v.permute    v24, v14, v8
    s.movz       s36, #15
    vf.fma       v8, v15, v21, v16
    v.movi       v15, #14
    vf.fma       v16, v24, v21, v18
    v.permute    v18, v9, v1
    a.vread      v21, a2, s4
    vf.fma       v24, v18, v20, v22
    v.permute    v18, v6, v15
    vf.fma       v22, v18, v21, v23
    v.permute    v18, v13, v3
    v.permute    v23, v14, v3
    s.movz       s4, #0
    vf.fma       v3, v18, v19, v8
    v.movi       v8, #15
    vf.fma       v18, v23, v19, v16
    v.permute    v16, v9, v5
    a.vread      v19, a2, s36
    v.permute    v23, v6, v8
    vf.fma       v6, v16, v17, v24
    v.permute    v16, v13, v1
    vf.fma       v24, v23, v19, v22
    v.permute    v22, v9, v15
    vf.fma       v23, v16, v20, v3
    a.vread      v3, a0, s4
    vf.fma       v16, v22, v21, v6
    v.permute    v6, v13, v5
    v.permute    v22, v9, v8
    vf.add       v9, v3, v24
    v.permute    v3, v14, v1
    vf.fma       v1, v6, v17, v23
    v.permute    v6, v13, v15
    vf.fma       v23, v22, v19, v16
    s.movz       s36, #1
    vf.fma       v16, v3, v20, v18
    a.vwrite     a0, s4, v9
    a.vread      v3, a0, s36
    v.permute    v9, v14, v5
    vf.fma       v5, v6, v21, v1
    v.permute    v1, v13, v8
    vf.add       v6, v3, v23
    vf.fma       v3, v9, v17, v16
    v.permute    v9, v14, v15
    vf.fma       v13, v1, v19, v5
    s.movz       s37, #2
    a.vwrite     a0, s36, v6
    a.vread      v1, a0, s37
    vf.fma       v5, v9, v21, v3
    v.permute    v3, v14, v8
    vf.add       v6, v1, v13
    s.movz       s38, #3
    s.movz       s40, #4
    vf.fma       v1, v3, v19, v5
    v.movi       v3, #0
    a.vwrite     a0, s37, v6
    a.vread      v5, a0, s38
    s.movz       s41, #5
    s.movz       s42, #6
    vf.add       v6, v5, v1
    s.movz       s43, #7
    v.movi       v1, #1
    v.movi       v5, #2
    v.movi       v8, #3
    a.vwrite     a0, s38, v6
    a.vread      v6, a1, s40
    a.vread      v9, a1, s41
    a.vread      v13, a1, s42
    a.vread      v14, a1, s43
    a.vread      v15, a2, s4
    v.permute    v16, v6, v3
    a.vread      v17, a2, s36
    v.permute    v18, v6, v1
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s37
    v.permute    v21, v6, v5
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v1
    a.vread      v19, a2, s38
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    v.permute    v22, v14, v3
    vf.fma       v3, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v5
    vf.fma       v23, v22, v15, v7
    a.vread      v15, a2, s40
    vf.fma       v22, v18, v20, v24
    v.permute    v18, v6, v21
    s.movz       s4, #6
    vf.fma       v24, v18, v15, v16
    v.permute    v16, v13, v1
    v.permute    v18, v14, v1
    vf.fma       v1, v16, v17, v3
    v.movi       v3, #5
    vf.fma       v16, v18, v17, v23
    v.permute    v17, v9, v8
    a.vread      v18, a2, s41
    s.movz       s36, #7
    vf.fma       v23, v17, v19, v22
    v.permute    v17, v6, v3
    vf.fma       v22, v17, v18, v24
    v.permute    v17, v13, v5
    v.permute    v24, v14, v5
    vf.fma       v5, v17, v20, v1
    v.movi       v1, #6
    vf.fma       v17, v24, v20, v16
    v.permute    v16, v9, v21
    a.vread      v20, a2, s4
    vf.fma       v24, v16, v15, v23
    v.permute    v16, v6, v1
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v13, v8
    s.movz       s4, #8
    v.permute    v22, v14, v8
    vf.fma       v8, v16, v19, v5
    v.movi       v5, #7
    vf.fma       v16, v22, v19, v17
    v.permute    v17, v9, v3
    a.vread      v19, a2, s36
    vf.fma       v22, v17, v18, v24
    v.permute    v17, v6, v5
    vf.fma       v24, v17, v19, v23
    v.permute    v17, v13, v21
    v.permute    v23, v14, v21
    s.movz       s36, #9
    vf.fma       v21, v17, v15, v8
    v.movi       v8, #8
    vf.fma       v17, v23, v15, v16
    v.permute    v15, v9, v1
    a.vread      v16, a2, s4
    vf.fma       v23, v15, v20, v22
    v.permute    v15, v6, v8
    vf.fma       v22, v15, v16, v24
    v.permute    v15, v13, v3
    v.permute    v24, v14, v3
    s.movz       s4, #10
    vf.fma       v3, v15, v18, v21
    v.movi       v15, #9
    vf.fma       v21, v24, v18, v17
    v.permute    v17, v9, v5
    a.vread      v18, a2, s36
    vf.fma       v24, v17, v19, v23
    v.permute    v17, v6, v15
    vf.fma       v23, v17, v18, v22
    v.permute    v17, v13, v1
    v.permute    v22, v14, v1
    s.movz       s36, #11
    vf.fma       v1, v17, v20, v3
    v.movi       v3, #10
    vf.fma       v17, v22, v20, v21
    v.permute    v20, v9, v8
    a.vread      v21, a2, s4
    vf.fma       v22, v20, v16, v24
    v.permute    v20, v6, v3
    vf.fma       v24, v20, v21, v23
    v.permute    v20, v13, v5
    v.permute    v23, v14, v5
    s.movz       s4, #12
    vf.fma       v5, v20, v19, v1
    v.movi       v1, #11
    vf.fma       v20, v23, v19, v17
    v.permute    v17, v9, v15
    a.vread      v19, a2, s36
    vf.fma       v23, v17, v18, v22
    v.permute    v17, v6, v1
    vf.fma       v22, v17, v19, v24
    v.permute    v17, v13, v8
    v.permute    v24, v14, v8
    s.movz       s36, #13
    vf.fma       v8, v17, v16, v5
    v.movi       v5, #12
    vf.fma       v17, v24, v16, v20
    v.permute    v16, v9, v3
    a.vread      v20, a2, s4
    vf.fma       v24, v16, v21, v23
    v.permute    v16, v6, v5
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v13, v15
    v.permute    v22, v14, v15
    s.movz       s4, #14
    vf.fma       v15, v16, v18, v8
    v.movi       v8, #13
    vf.fma       v16, v22, v18, v17
    v.permute    v17, v9, v1
    a.vread      v18, a2, s36
    vf.fma       v22, v17, v19, v24
    v.permute    v17, v6, v8
    vf.fma       v24, v17, v18, v23
    v.permute    v17, v13, v3
    v.permute    v23, v14, v3
    s.movz       s36, #15
    vf.fma       v3, v17, v21, v15
    v.movi       v15, #14
    vf.fma       v17, v23, v21, v16
    v.permute    v16, v9, v5
    a.vread      v21, a2, s4
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v6, v15
    vf.fma       v22, v16, v21, v24
    v.permute    v16, v13, v1
    v.permute    v24, v14, v1
    s.movz       s4, #4
    vf.fma       v1, v16, v19, v3
    v.movi       v3, #15
    vf.fma       v16, v24, v19, v17
    v.permute    v17, v9, v8
    a.vread      v19, a2, s36
    v.permute    v24, v6, v3
    vf.fma       v6, v17, v18, v23
    v.permute    v17, v13, v5
    vf.fma       v23, v24, v19, v22
    v.permute    v22, v9, v15
    vf.fma       v24, v17, v20, v1
    a.vread      v1, a0, s4
    vf.fma       v17, v22, v21, v6
    v.permute    v6, v13, v8
    v.permute    v22, v9, v3
    vf.add       v9, v1, v23
    v.permute    v1, v14, v5
    vf.fma       v5, v6, v18, v24
    v.permute    v6, v13, v15
    vf.fma       v23, v22, v19, v17
    s.movz       s36, #5
    vf.fma       v17, v1, v20, v16
    a.vwrite     a0, s4, v9
    a.vread      v1, a0, s36
    v.permute    v9, v14, v8
    vf.fma       v8, v6, v21, v5
    v.permute    v5, v13, v3
    vf.add       v6, v1, v23
    vf.fma       v1, v9, v18, v17
    v.permute    v9, v14, v15
    vf.fma       v13, v5, v19, v8
    s.movz       s4, #6
    a.vwrite     a0, s36, v6
    a.vread      v5, a0, s4
    vf.fma       v6, v9, v21, v1
    v.permute    v1, v14, v3
    vf.add       v3, v5, v13
    s.movz       s36, #7
    s.movz       s37, #8
    vf.fma       v5, v1, v19, v6
    v.movi       v1, #0
    a.vwrite     a0, s4, v3
    a.vread      v3, a0, s36
    s.movz       s4, #9
    s.movz       s38, #10
    vf.add       v6, v3, v5
    s.movz       s40, #11
    s.movz       s41, #0
    v.movi       v3, #1
    s.movz       s42, #1
    a.vwrite     a0, s36, v6
    a.vread      v5, a1, s37
    a.vread      v6, a1, s4
    a.vread      v8, a1, s38
    a.vread      v9, a1, s40
    a.vread      v13, a2, s41
    v.permute    v14, v5, v1
    a.vread      v15, a2, s42
    v.permute    v16, v5, v3
    vf.fma       v17, v14, v13, v7
    v.movi       v14, #2
    v.permute    v18, v6, v1
    s.movz       s4, #2
    v.permute    v19, v5, v14
    vf.fma       v20, v16, v15, v17
    a.vread      v16, a2, s4
    vf.fma       v17, v18, v13, v7
    v.movi       v18, #3
    v.permute    v21, v6, v3
    vf.fma       v22, v19, v16, v20
    s.movz       s4, #3
    v.permute    v19, v5, v18
    a.vread      v20, a2, s4
    v.permute    v23, v8, v1
    vf.fma       v24, v21, v15, v17
    v.movi       v17, #4
    vf.fma       v21, v19, v20, v22
    v.permute    v19, v6, v14
    s.movz       s4, #4
    vf.fma       v22, v23, v13, v7
    vf.fma       v23, v19, v16, v24
    a.vread      v19, a2, s4
    v.permute    v24, v9, v1
    s.movz       s4, #5
    vf.fma       v1, v24, v13, v7
    v.permute    v13, v5, v17
    vf.fma       v24, v13, v19, v21
    v.permute    v13, v8, v3
    v.permute    v21, v9, v3
    s.movz       s36, #6
    vf.fma       v3, v13, v15, v22
    v.movi       v13, #5
    vf.fma       v22, v21, v15, v1
    v.permute    v1, v6, v18
    a.vread      v15, a2, s4
    vf.fma       v21, v1, v20, v23
    v.permute    v1, v5, v13
    vf.fma       v23, v1, v15, v24
    v.permute    v1, v8, v14
    v.permute    v24, v9, v14
    s.movz       s4, #7
    vf.fma       v14, v1, v16, v3
    v.movi       v1, #6
    vf.fma       v3, v24, v16, v22
    v.permute    v16, v6, v17
    a.vread      v22, a2, s36
    vf.fma       v24, v16, v19, v21
    v.permute    v16, v5, v1
    vf.fma       v21, v16, v22, v23
    v.permute    v16, v8, v18
    v.permute    v23, v9, v18
    s.movz       s36, #8
    vf.fma       v18, v16, v20, v14
    v.movi       v14, #7
    vf.fma       v16, v23, v20, v3
    v.permute    v3, v6, v13
    a.vread      v20, a2, s4
    vf.fma       v23, v3, v15, v24
    v.permute    v3, v5, v14
    vf.fma       v24, v3, v20, v21
    v.permute    v3, v8, v17
    v.permute    v21, v9, v17
    s.movz       s4, #9
    vf.fma       v17, v3, v19, v18
    v.movi       v3, #8
    vf.fma       v18, v21, v19, v16
    v.permute    v16, v6, v1
    a.vread      v19, a2, s36
    vf.fma       v21, v16, v22, v23
    v.permute    v16, v5, v3
    vf.fma       v23, v16, v19, v24
    v.permute    v16, v8, v13
    v.permute    v24, v9, v13
    s.movz       s36, #10
    vf.fma       v13, v16, v15, v17
    v.movi       v16, #9
    vf.fma       v17, v24, v15, v18
    v.permute    v15, v6, v14
    a.vread      v18, a2, s4
    vf.fma       v24, v15, v20, v21
    v.permute    v15, v5, v16
    vf.fma       v21, v15, v18, v23
    v.permute    v15, v8, v1
    v.permute    v23, v9, v1
    s.movz       s4, #11
    vf.fma       v1, v15, v22, v13
    v.movi       v13, #10
    vf.fma       v15, v23, v22, v17
    v.permute    v17, v6, v3
    a.vread      v22, a2, s36
    vf.fma       v23, v17, v19, v24
    v.permute    v17, v5, v13
    vf.fma       v24, v17, v22, v21
    v.permute    v17, v8, v14
    v.permute    v21, v9, v14
    s.movz       s36, #12
    vf.fma       v14, v17, v20, v1
    v.movi       v1, #11
    vf.fma       v17, v21, v20, v15
    v.permute    v15, v6, v16
    a.vread      v20, a2, s4
    vf.fma       v21, v15, v18, v23
    v.permute    v15, v5, v1
    vf.fma       v23, v15, v20, v24
    v.permute    v15, v8, v3
    v.permute    v24, v9, v3
    s.movz       s4, #13
    vf.fma       v3, v15, v19, v14
    v.movi       v14, #12
    vf.fma       v15, v24, v19, v17
    v.permute    v17, v6, v13
    a.vread      v19, a2, s36
    vf.fma       v24, v17, v22, v21
    v.permute    v17, v5, v14
    vf.fma       v21, v17, v19, v23
    v.permute    v17, v8, v16
    v.permute    v23, v9, v16
    s.movz       s37, #14
    vf.fma       v16, v17, v18, v3
    v.movi       v3, #13
    vf.fma       v17, v23, v18, v15
    v.permute    v15, v6, v1
    a.vread      v18, a2, s4
    vf.fma       v23, v15, v20, v24
    v.permute    v15, v5, v3
    vf.fma       v24, v15, v18, v21
    v.permute    v15, v8, v13
    v.permute    v21, v9, v13
    s.movz       s38, #15
    vf.fma       v13, v15, v22, v16
    v.movi       v15, #14
    vf.fma       v16, v21, v22, v17
    v.permute    v17, v6, v14
    a.vread      v21, a2, s37
    vf.fma       v22, v17, v19, v23
    v.permute    v17, v5, v15
    vf.fma       v23, v17, v21, v24
    v.permute    v17, v8, v1
    v.permute    v24, v9, v1
    s.movz       s40, #8
    vf.fma       v1, v17, v20, v13
    v.movi       v13, #15
    vf.fma       v17, v24, v20, v16
    v.permute    v16, v6, v3
    a.vread      v20, a2, s38
    v.permute    v24, v5, v13
    vf.fma       v5, v16, v18, v22
    v.permute    v16, v8, v14
    vf.fma       v22, v24, v20, v23
    v.permute    v23, v6, v15
    vf.fma       v24, v16, v19, v1
    a.vread      v1, a0, s40
    vf.fma       v16, v23, v21, v5
    v.permute    v5, v8, v3
    v.permute    v23, v6, v13
    vf.add       v6, v1, v22
    v.permute    v1, v9, v14
    vf.fma       v14, v5, v18, v24
    v.permute    v5, v8, v15
    vf.fma       v22, v23, v20, v16
    s.movz       s41, #9
    vf.fma       v16, v1, v19, v17
    a.vwrite     a0, s40, v6
    a.vread      v1, a0, s41
    v.permute    v6, v9, v3
    vf.fma       v3, v5, v21, v14
    v.permute    v5, v8, v13
    vf.add       v8, v1, v22
    vf.fma       v1, v6, v18, v16
    v.permute    v6, v9, v15
    vf.fma       v14, v5, v20, v3
    s.movz       s40, #10
    a.vwrite     a0, s41, v8
    a.vread      v3, a0, s40
    vf.fma       v5, v6, v21, v1
    v.permute    v1, v9, v13
    vf.add       v6, v3, v14
    s.movz       s41, #11
    v.movi       v3, #0
    vf.fma       v8, v1, v20, v5
    s.movz       s42, #0
    a.vwrite     a0, s40, v6
    a.vread      v1, a0, s41
    v.movi       v5, #1
    s.movz       s40, #1
    vf.add       v6, v1, v8
    v.movi       v1, #2
    s.movz       s43, #2
    v.movi       v8, #3
    s.movz       s44, #3
    a.vwrite     a0, s41, v6
    a.vread      v6, a1, s36
    a.vread      v9, a1, s4
    a.vread      v13, a1, s37
    a.vread      v14, a1, s38
    a.vread      v15, a2, s42
    v.permute    v16, v6, v3
    a.vread      v17, a2, s40
    v.permute    v18, v6, v5
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s43
    v.permute    v21, v6, v1
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v5
    a.vread      v19, a2, s44
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    s.movz       s4, #4
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v1
    v.permute    v23, v14, v3
    s.movz       s36, #5
    vf.fma       v3, v18, v20, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v23, v15, v7
    v.permute    v7, v6, v21
    v.permute    v15, v13, v5
    v.permute    v23, v14, v5
    vf.fma       v5, v7, v18, v16
    v.movi       v7, #5
    vf.fma       v16, v15, v17, v22
    v.permute    v15, v9, v8
    s.movz       s4, #6
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s36
    v.permute    v23, v6, v7
    vf.fma       v24, v15, v19, v3
    v.permute    v3, v13, v1
    vf.fma       v15, v23, v17, v5
    v.movi       v5, #6
    vf.fma       v23, v3, v20, v16
    v.permute    v3, v9, v21
    v.permute    v16, v14, v1
    s.movz       s36, #7
    vf.fma       v1, v3, v18, v24
    a.vread      v3, a2, s4
    vf.fma       v24, v16, v20, v22
    v.permute    v16, v6, v5
    v.permute    v20, v13, v8
    v.permute    v22, v14, v8
    vf.fma       v8, v16, v3, v15
    v.movi       v15, #7
    vf.fma       v16, v20, v19, v23
    v.permute    v20, v9, v7
    s.movz       s4, #8
    vf.fma       v23, v22, v19, v24
    a.vread      v19, a2, s36
    v.permute    v22, v6, v15
    vf.fma       v24, v20, v17, v1
    v.permute    v1, v13, v21
    vf.fma       v20, v22, v19, v8
    v.movi       v8, #8
    vf.fma       v22, v1, v18, v16
    v.permute    v1, v9, v5
    v.permute    v16, v14, v21
    s.movz       s36, #9
    vf.fma       v21, v1, v3, v24
    a.vread      v1, a2, s4
    vf.fma       v24, v16, v18, v23
    v.permute    v16, v6, v8
    v.permute    v18, v13, v7
    v.permute    v23, v14, v7
    vf.fma       v7, v16, v1, v20
    v.movi       v16, #9
    vf.fma       v20, v18, v17, v22
    v.permute    v18, v9, v15
    s.movz       s4, #10
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s36
    v.permute    v23, v6, v16
    vf.fma       v24, v18, v19, v21
    v.permute    v18, v13, v5
    vf.fma       v21, v23, v17, v7
    v.movi       v7, #10
    vf.fma       v23, v18, v3, v20
    v.permute    v18, v9, v8
    v.permute    v20, v14, v5
    s.movz       s36, #11
    vf.fma       v5, v18, v1, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v20, v3, v22
    v.permute    v3, v6, v7
    v.permute    v20, v13, v15
    v.permute    v22, v14, v15
    vf.fma       v15, v3, v18, v21
    v.movi       v3, #11
    vf.fma       v21, v20, v19, v23
    v.permute    v20, v9, v16
    s.movz       s4, #12
    vf.fma       v23, v22, v19, v24
    a.vread      v19, a2, s36
    v.permute    v22, v6, v3
    vf.fma       v24, v20, v17, v5
    v.permute    v5, v13, v8
    vf.fma       v20, v22, v19, v15
    v.movi       v15, #12
    vf.fma       v22, v5, v1, v21
    v.permute    v5, v9, v7
    v.permute    v21, v14, v8
    s.movz       s36, #13
    vf.fma       v8, v5, v18, v24
    a.vread      v5, a2, s4
    vf.fma       v24, v21, v1, v23
    v.permute    v1, v6, v15
    v.permute    v21, v13, v16
    v.permute    v23, v14, v16
    vf.fma       v16, v1, v5, v20
    v.movi       v1, #13
    vf.fma       v20, v21, v17, v22
    v.permute    v21, v9, v3
    s.movz       s37, #14
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s36
    v.permute    v23, v6, v1
    vf.fma       v24, v21, v19, v8
    v.permute    v8, v13, v7
    vf.fma       v21, v23, v17, v16
    v.movi       v16, #14
    vf.fma       v23, v8, v18, v20
    v.permute    v8, v9, v15
    v.permute    v20, v14, v7
    s.movz       s38, #15
    vf.fma       v7, v8, v5, v24
    a.vread      v8, a2, s37
    vf.fma       v24, v20, v18, v22
    v.permute    v18, v6, v16
    v.permute    v20, v13, v3
    v.permute    v22, v14, v3
    vf.fma       v3, v18, v8, v21
    v.movi       v18, #15
    vf.fma       v21, v20, v19, v23
    v.permute    v20, v9, v1
    v.permute    v23, v6, v18
    vf.fma       v6, v22, v19, v24
    a.vread      v19, a2, s38
    v.permute    v22, v13, v15
    vf.fma       v24, v20, v17, v7
    v.permute    v7, v9, v16
    vf.fma       v20, v23, v19, v3
    vf.fma       v3, v22, v5, v21
    a.vread      v21, a0, s4
    v.permute    v22, v13, v1
    vf.fma       v23, v7, v8, v24
    v.permute    v7, v9, v18
    vf.add       v9, v21, v20
    v.permute    v20, v14, v15
    vf.fma       v15, v22, v17, v3
    v.permute    v3, v13, v16
    vf.fma       v21, v7, v19, v23
    vf.fma       v7, v20, v5, v6
    a.vwrite     a0, s4, v9
    a.vread      v5, a0, s36
    v.permute    v6, v14, v1
    vf.fma       v1, v3, v8, v15
    v.permute    v3, v13, v18
    vf.add       v9, v5, v21
    vf.fma       v5, v6, v17, v7
    v.permute    v6, v14, v16
    vf.fma       v7, v3, v19, v1
    v.permute    v1, v14, v18
    a.vwrite     a0, s36, v9
    a.vread      v3, a0, s37
    vf.fma       v9, v6, v8, v5
    s.add        s4, s39, s27
    vf.add       v5, v3, v7
    s.movz       s36, #1
    vf.fma       v3, v1, v19, v9
    a.vwrite     a0, s37, v5
    a.vread      v1, a0, s38
    vf.add       v5, v1, v3
    a.vwrite     a0, s38, v5
    s.mov        s39, s4
    br.nz        s36, for_1
endfor_2:
    v.movi       v0, #1
    v.cmp.lt     p1, v2, v0
    v.movi       v1, #0
    @p1 v.sel        v3, v0, v1
    v.cmp.lt     p1, v4, v10
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v12, v10
    v.movi       v0, #1
    @p1 v.sel        v6, v0, v1
    v.cmp.lt     p1, v11, v10
    s.addi       s4, s9, #3136
    v.extract    s36, v12, #0
    v.splat      v0, s36
    v.extract    s36, v4, #0
    v.splat      v1, s36
    v.splat      v7, s1
    v.mul        v8, v1, v7
    v.add        v1, v0, v8
    s.movz       s36, #0
    s.muli       s37, s7, #256                   // a runtime tile origin, x256
    s.add        s38, s36, s37                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s36, #256
    v.splat      v8, s36
    v.mul        v9, v0, v8
    v.splat      v0, s38
    v.add        v8, v9, v0
    v.add        v0, v1, v8
    v.extract    s36, v2, #0
    v.splat      v1, s36
    v.splat      v9, s6
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s4, #0], v1
    s.addi       s36, s4, #64
    v.extract    s37, v12, #1
    v.splat      v0, s37
    v.extract    s37, v4, #1
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #1
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #128
    v.extract    s37, v12, #2
    v.splat      v0, s37
    v.extract    s37, v4, #2
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #2
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #192
    v.extract    s37, v12, #3
    v.splat      v0, s37
    v.extract    s37, v4, #3
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #3
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #256
    v.extract    s37, v12, #4
    v.splat      v0, s37
    v.extract    s37, v4, #4
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #4
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #320
    v.extract    s37, v12, #5
    v.splat      v0, s37
    v.extract    s37, v4, #5
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #5
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #384
    v.extract    s37, v12, #6
    v.splat      v0, s37
    v.extract    s37, v4, #6
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #6
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #448
    v.extract    s37, v12, #7
    v.splat      v0, s37
    v.extract    s37, v4, #7
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #7
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #512
    v.extract    s37, v12, #8
    v.splat      v0, s37
    v.extract    s37, v4, #8
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #8
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #576
    v.extract    s37, v12, #9
    v.splat      v0, s37
    v.extract    s37, v4, #9
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #9
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #640
    v.extract    s37, v12, #10
    v.splat      v0, s37
    v.extract    s37, v4, #10
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #10
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #704
    v.extract    s37, v12, #11
    v.splat      v0, s37
    v.extract    s37, v4, #11
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #11
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #768
    v.extract    s37, v12, #12
    v.splat      v0, s37
    v.extract    s37, v4, #12
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #12
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #832
    v.extract    s37, v12, #13
    v.splat      v0, s37
    v.extract    s37, v4, #13
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #13
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #896
    v.extract    s37, v12, #14
    v.splat      v0, s37
    v.extract    s37, v4, #14
    v.splat      v1, s37
    v.mul        v10, v1, v7
    v.add        v1, v0, v10
    v.add        v0, v1, v8
    v.extract    s37, v2, #14
    v.splat      v1, s37
    v.mul        v10, v1, v9
    v.add        v1, v0, v10
    v.st.w       [s36, #0], v1
    s.addi       s36, s4, #960
    v.extract    s4, v12, #15
    v.splat      v0, s4
    v.extract    s4, v4, #15
    v.splat      v1, s4
    v.mul        v4, v1, v7
    v.add        v1, v0, v4
    v.add        v0, v1, v8
    v.extract    s4, v2, #15
    v.splat      v1, s4
    v.mul        v2, v1, v9
    v.add        v1, v0, v2
    v.st.w       [s36, #0], v1
    fence.acq_rel.device
    s.muli       s4, s7, #4                      // a runtime tile origin, x4
    s.add        s36, s30, s4                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s37, s31, s4                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s38, s32, s4                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s39, s33, s4                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s4, s9, #4160
    v.splat      v0, s2
    s.addi       s40, s9, #3136
    v.ld.w       v1, [s40, #0]
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s40, s4, #64
    s.addi       s41, s9, #3200
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #128
    s.addi       s41, s9, #3264
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #192
    s.addi       s41, s9, #3328
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #256
    s.addi       s41, s9, #3392
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #320
    s.addi       s41, s9, #3456
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #384
    s.addi       s41, s9, #3520
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #448
    s.addi       s41, s9, #3584
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #512
    s.addi       s41, s9, #3648
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #576
    s.addi       s41, s9, #3712
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #640
    s.addi       s41, s9, #3776
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #704
    s.addi       s41, s9, #3840
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #768
    s.addi       s41, s9, #3904
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #832
    s.addi       s41, s9, #3968
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #896
    s.addi       s41, s9, #4032
    v.ld.w       v1, [s41, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    s.addi       s40, s4, #960
    s.addi       s4, s9, #4096
    v.ld.w       v1, [s4, #0]
    v.add        v2, v0, v1
    v.st.w       [s40, #0], v2
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.addi       s40, s9, #4160
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #0
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #0
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #0
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #1
    s.addi       s40, s9, #4224
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #1
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #1
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #1
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #2
    s.addi       s40, s9, #4288
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #2
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #2
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #2
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #3
    s.addi       s40, s9, #4352
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #3
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #3
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #3
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #4
    s.addi       s40, s9, #4416
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #4
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #4
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #4
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #5
    s.addi       s40, s9, #4480
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #5
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #5
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #5
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #6
    s.addi       s40, s9, #4544
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #6
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #6
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #6
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #7
    s.addi       s40, s9, #4608
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #7
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #7
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #7
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #8
    s.addi       s40, s9, #4672
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #8
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #8
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #8
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #9
    s.addi       s40, s9, #4736
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #9
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #9
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #9
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #10
    s.addi       s40, s9, #4800
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #10
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #10
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #10
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #11
    s.addi       s40, s9, #4864
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #11
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #11
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #11
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #12
    s.addi       s40, s9, #4928
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #12
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #12
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #12
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #13
    s.addi       s40, s9, #4992
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #13
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #13
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #13
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #14
    s.addi       s40, s9, #5056
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #14
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #14
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #14
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    s.movz       s4, #15
    s.addi       s40, s9, #5120
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v3, #15
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.extract    s40, v5, #15
    v.splat      v1, s40
    v.cmp.ne     p3, v1, v2
    p.and        p4, p2, p3
    v.extract    s40, v6, #15
    v.splat      v1, s40
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s34, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s4, v1
    .li       s4, #925353388
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.addi       s4, s9, #5184
    v.splat      v2, s2
    s.addi       s40, s9, #3136
    v.ld.w       v4, [s40, #0]
    v.add        v7, v2, v4
    v.st.w       [s4, #0], v7
    s.addi       s40, s4, #64
    s.addi       s41, s9, #3200
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #128
    s.addi       s41, s9, #3264
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #192
    s.addi       s41, s9, #3328
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #256
    s.addi       s41, s9, #3392
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #320
    s.addi       s41, s9, #3456
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #384
    s.addi       s41, s9, #3520
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #448
    s.addi       s41, s9, #3584
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #512
    s.addi       s41, s9, #3648
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #576
    s.addi       s41, s9, #3712
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #640
    s.addi       s41, s9, #3776
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #704
    s.addi       s41, s9, #3840
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #768
    s.addi       s41, s9, #3904
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #832
    s.addi       s41, s9, #3968
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #896
    s.addi       s41, s9, #4032
    v.ld.w       v4, [s41, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    s.addi       s40, s4, #960
    s.addi       s4, s9, #4096
    v.ld.w       v4, [s4, #0]
    v.add        v7, v2, v4
    v.st.w       [s40, #0], v7
    fence.acq_rel.device
    s.movz       s4, #0
    a.vread      v2, a0, s4
    v.extract    s4, v3, #0
    v.splat      v4, s4
    v.movi       v7, #0
    v.cmp.ne     p2, v4, v7
    v.extract    s40, v5, #0
    v.splat      v4, s40
    v.cmp.ne     p3, v4, v7
    p.and        p4, p2, p3
    v.extract    s41, v6, #0
    v.splat      v4, s41
    v.movi       v7, #0
    v.cmp.ne     p2, v4, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s36, #0]
    vf.sub       v8, v2, v4
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v7
    v.splat      v2, s40
    v.movi       v4, #0
    v.cmp.ne     p3, v2, v4
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v4, v2, v0
    v.rsqrt.approx v2, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v2, v2
    .li       s42, #1077936128
    v.splat      v9, s42                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v10, v4, v7, v9
    .li       s42, #3204448256
    v.splat      v4, s42                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v2, v4
    vf.mul       v11, v7, v10                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v7, v11, v2
    vf.mul       v2, v8, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #0
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5184
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #0
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #0
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #0
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #1
    a.vread      v2, a0, s4
    v.extract    s4, v3, #1
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #1
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #1
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #1
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5248
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #1
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #1
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #1
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #2
    a.vread      v2, a0, s4
    v.extract    s4, v3, #2
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #2
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #2
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #2
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5312
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #2
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #2
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #2
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #3
    a.vread      v2, a0, s4
    v.extract    s4, v3, #3
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #3
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #3
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5376
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #3
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #3
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #3
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #4
    a.vread      v2, a0, s4
    v.extract    s4, v3, #4
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #4
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #4
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #4
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5440
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #4
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #4
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #4
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #5
    a.vread      v2, a0, s4
    v.extract    s4, v3, #5
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #5
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #5
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #5
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5504
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #5
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #5
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #5
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #6
    a.vread      v2, a0, s4
    v.extract    s4, v3, #6
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #6
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #6
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #6
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5568
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #6
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #6
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #6
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #7
    a.vread      v2, a0, s4
    v.extract    s4, v3, #7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #7
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #7
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #7
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5632
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #7
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #7
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #7
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #8
    a.vread      v2, a0, s4
    v.extract    s4, v3, #8
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #8
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #8
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5696
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #8
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #8
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #8
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #9
    a.vread      v2, a0, s4
    v.extract    s4, v3, #9
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #9
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #9
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #9
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5760
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #9
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #9
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #9
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #10
    a.vread      v2, a0, s4
    v.extract    s4, v3, #10
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #10
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #10
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #10
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5824
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #10
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #10
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #10
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #11
    a.vread      v2, a0, s4
    v.extract    s4, v3, #11
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #11
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #11
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #11
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5888
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #11
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #11
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #11
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #12
    a.vread      v2, a0, s4
    v.extract    s4, v3, #12
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #12
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #12
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #12
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #5952
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #12
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #12
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #12
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #13
    a.vread      v2, a0, s4
    v.extract    s4, v3, #13
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #13
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #13
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #13
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #6016
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #13
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #13
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #13
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #14
    a.vread      v2, a0, s4
    v.extract    s4, v3, #14
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #14
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #14
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v2, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.fms       v11, v7, v8, v9
    vf.mul       v7, v2, v4
    vf.mul       v8, v7, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v10, v7
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s38, #0]
    vf.mul       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s39, #0]
    vf.add       v7, v10, v2
    s.movz       s4, #14
    a.vread      v2, a3, s4
    vf.add       v8, v7, v2
    vf.max.prop  v2, v8, v1
    s.addi       s4, s9, #6080
    v.ld.w       v7, [s4, #0]
    v.extract    s4, v3, #14
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    v.extract    s4, v5, #14
    v.splat      v8, s4
    v.cmp.ne     p3, v8, v10
    p.and        p4, p2, p3
    v.extract    s4, v6, #14
    v.splat      v8, s4
    v.movi       v10, #0
    v.cmp.ne     p2, v8, v10
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v7], v2
    s.movz       s4, #15
    a.vread      v2, a0, s4
    v.extract    s4, v3, #15
    v.splat      v7, s4
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s40, v5, #15
    v.splat      v7, s40
    v.cmp.ne     p3, v7, v8
    p.and        p4, p2, p3
    v.extract    s41, v6, #15
    v.splat      v7, s41
    v.movi       v8, #0
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s36, #0]
    vf.sub       v10, v2, v7
    v.splat      v2, s4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s40
    v.movi       v7, #0
    v.cmp.ne     p3, v2, v7
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s37, #0]
    vf.add       v7, v2, v0
    v.rsqrt.approx v0, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v0, v0
    vf.fms       v8, v7, v2, v9
    vf.mul       v2, v0, v4
    vf.mul       v4, v2, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v2, v4, v0
    vf.mul       v0, v10, v2
    v.splat      v2, s4
    v.movi       v4, #0
    v.cmp.ne     p2, v2, v4
    v.splat      v2, s40
    v.cmp.ne     p3, v2, v4
    p.and        p4, p2, p3
    v.splat      v2, s41
    v.movi       v4, #0
    v.cmp.ne     p2, v2, v4
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s38, #0]
    vf.mul       v7, v0, v2
    v.splat      v0, s4
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s40
    v.movi       v2, #0
    v.cmp.ne     p3, v0, v2
    p.and        p4, p2, p3
    v.splat      v0, s41
    v.cmp.ne     p2, v0, v2
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s39, #0]
    vf.add       v2, v7, v0
    s.movz       s4, #15
    a.vread      v0, a3, s4
    vf.add       v4, v2, v0
    vf.max.prop  v0, v4, v1
    s.addi       s4, s9, #6144
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v3, #15
    v.splat      v2, s4
    v.movi       v3, #0
    v.cmp.ne     p2, v2, v3
    v.extract    s4, v5, #15
    v.splat      v2, s4
    v.cmp.ne     p3, v2, v3
    p.and        p4, p2, p3
    v.extract    s4, v6, #15
    v.splat      v2, s4
    v.movi       v3, #0
    v.cmp.ne     p2, v2, v3
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s35, v1], v0
__rctx_next:
    s.addi       s4, s28, #2                     // the next program of this context: + 2
    s.cmp.lt     s36, s4, s29
    s.mov        s28, s4
    br.nz        s36, __rctx_program
    exit
