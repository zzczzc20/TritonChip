    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s1, arg_base
    v.movi       v1, #256
    s.ld.d       s3, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s4, #2
    v.splat      v2, s2
    s.movz       s5, #2
    s.movz       s6, #2
    v.add        v3, v2, v0
    s.movz       s7, #2
    s.movz       s8, #2
    v.cmp.lt     p1, v3, v1
    s.movz       s9, #2
    s.movz       s10, #2
    s.ld.d       s11, [s1, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s12, #2
    s.movz       s13, #2
    s.movz       s14, #2
    s.movz       s15, #2
    s.movz       s16, #2
    s.movz       s17, #2
    s.movz       s18, #2
    s.movz       s19, #2
    s.movz       s20, #2
    s.movz       s21, #30
    s.ld.d       s22, [s1, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v0, #0
    s.movz       s23, #30
    s.movz       s24, #30
    s.movz       s25, #30
    s.movz       s26, #30
    s.movz       s27, #30
    s.movz       s28, #30
    s.movz       s29, #30
    s.movz       s30, #30
    s.movz       s31, #30
    s.ld.d       s32, [s1, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s33, #30
    s.movz       s34, #30
    s.movz       s35, #30
    s.movz       s36, #30
    s.movz       s37, #30
    s.movz       s38, #30
    v.movi       v2, #64
    s.movz       s39, #256
    .li       s39, #-2
    v.movi       v4, #1
    s.ld.d       s39, [s1, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v2, v0
    s.ld.d       s40, [s1, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    v.sub        v4, v0, v3
    s.ld.d       s41, [s1, #48]                  // out_ptr0: device_ptr64 at arg_base+48
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v7, #31
    v.sub        v8, v5, v3
    v.sub        v9, v6, v3
    v.cmp.lt     p4, v3, v5
    @p4 v.sel        v10, v8, v3
    v.cmp.lt     p5, v3, v6
    @p5 v.sel        v8, v9, v3
    v.movi       v9, #6
    v.and        v11, v10, v7
    @p2 v.sel        v7, v4, v3
    v.movi       v3, #63
    v.lshr       v4, v8, v9
    v.sub        v8, v5, v11
    v.and        v9, v7, v3
    v.sub        v3, v6, v4
    @p4 v.sel        v7, v8, v11
    v.sub        v8, v0, v9
    @p5 v.sel        v10, v3, v4
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    @p2 v.sel        v3, v8, v9
    v.mul        v4, v10, v1
    s.add        s2, s3, s1                      // &in_ptr4[...]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s22, v10]             // index is in elements (ISA sec 9.1)
    v.add        v8, v3, v4
    .li       s1, #1132462080
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #32
    v.rcp.approx v11, v4                         // ISA 8.8: <= 2**-22 relative
    v.sub        v12, v0, v2
    v.sub        v0, v6, v2
    v.sub        v13, v5, v10
    v.cmp.lt     p2, v2, v6
    v.cmp.lt     p4, v10, v5
    @p3 v.sel        v5, v12, v2
    v.movi       v5, #1
    .li       s1, #897988541
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v6, v0, v2
    .li       s1, #1077936128
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s11, v8]              // index is in elements (ISA sec 9.1)
    @p4 v.sel        v12, v13, v10
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s32, v3]             // index is in elements (ISA sec 9.1)
    vf.fms       v13, v4, v11, v9
    vf.cvt.bf16.f32 v9, v6
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v14, v11, v13, v11
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v14, [s39, v7]             // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v15, v12
    v.extract    s1, v7, #0
    v.extract    s3, v7, #1
    s.shli       s11, s1, #32
    v.movi       v12, #0
    s.ashri      s1, s11, #32
    v.movi       v16, #0
    s.shli       s11, s3, #32
    s.lshri      s3, s1, #32
    v.extract    s22, v7, #2
    s.ashri      s32, s11, #32
    s.shli       s11, s22, #32
    s.lshri      s22, s32, #32
    vf.cmp.o     p2, v13, v13
    @p2 v.sel        v17, v13, v11
    vf.add       v11, v15, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s2, #0]
    s.ashri      s2, s11, #32
    vf.mul       v13, v1, v17                    // a/y: faithful quotient
    vf.fms       v15, v13, v4, v1
    vf.fms       v1, v15, v17, v13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s40, v7]              // index is in elements (ISA sec 9.1)
    v.insert     v12, s1, #0
    v.insert     v16, s3, #0
    vf.neg       v15, v1                         // a/y: one correction to the IEEE quotient
    v.insert     v12, s32, #1
    v.insert     v16, s22, #1
    vf.cvt.bf16.f32 v1, v6
    v.extract    s1, v7, #3
    s.lshri      s3, s2, #32
    s.shli       s11, s1, #32
    v.extract    s1, v7, #4
    s.ashri      s22, s11, #32
    v.insert     v12, s2, #2
    v.insert     v16, s3, #2
    s.shli       s2, s1, #32
    s.lshri      s1, s22, #32
    s.ashri      s3, s2, #32
    v.insert     v12, s22, #3
    v.insert     v16, s1, #3
    s.lshri      s1, s3, #32
    v.insert     v12, s3, #4
    vf.cmp.o     p2, v15, v15
    v.insert     v16, s1, #4
    @p2 v.sel        v6, v15, v13
    v.extract    s1, v7, #5
    s.shli       s2, s1, #32
    vf.add       v13, v6, v5
    s.ashri      s1, s2, #32
    v.rsqrt.approx v5, v13                       // ISA 8.8: <= 2**-22 relative
    v.insert     v12, s1, #5
    vf.mul       v6, v5, v5
    s.lshri      s2, s1, #32
    vf.mul       v15, v5, v2
    v.insert     v16, s2, #5
    vf.fms       v2, v13, v6, v0
    v.extract    s1, v7, #6
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    vf.mul       v0, v15, v2                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.insert     v12, s1, #6
    vf.cmp.o     p2, v0, v0
    s.lshri      s2, s1, #32
    @p2 v.sel        v2, v0, v5
    v.insert     v16, s2, #6
    vf.mul       v0, v9, v2
    v.extract    s1, v7, #7
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    vf.mul       v2, v0, v11
    v.extract    s2, v7, #8
    s.lshri      s3, s1, #32
    s.shli       s11, s2, #32
    v.extract    s2, v7, #9
    s.ashri      s22, s11, #32
    v.insert     v12, s1, #7
    v.insert     v16, s3, #7
    s.shli       s1, s2, #32
    s.lshri      s2, s22, #32
    v.extract    s3, v7, #10
    s.ashri      s11, s1, #32
    v.insert     v12, s22, #8
    v.insert     v16, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s11, #32
    v.extract    s3, v7, #11
    s.ashri      s22, s1, #32
    v.insert     v12, s11, #9
    v.insert     v16, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s22, #32
    v.extract    s3, v7, #12
    s.ashri      s11, s1, #32
    v.insert     v12, s22, #10
    v.insert     v16, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s11, #32
    v.extract    s3, v7, #13
    s.ashri      s22, s1, #32
    v.insert     v12, s11, #11
    v.insert     v16, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s22, #32
    v.extract    s3, v7, #14
    s.ashri      s11, s1, #32
    v.insert     v12, s22, #12
    v.insert     v16, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s11, #32
    v.extract    s3, v7, #15
    s.ashri      s22, s1, #32
    v.insert     v12, s11, #13
    v.insert     v16, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s22, #32
    s.ashri      s3, s1, #32
    v.insert     v12, s22, #14
    v.insert     v16, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v12, s3, #15
    v.insert     v16, s1, #15
    v.movi       v0, #0
    v.extract    s1, v12, #0
    v.extract    s2, v16, #0
    v.extract    s3, v16, #1
    s.shli       s11, s2, #32
    v.extract    s2, v12, #1
    s.or         s22, s1, s11
    s.shli       s1, s3, #32
    s.cmp.ge     s3, s22, s4
    v.extract    s4, v16, #2
    s.or         s11, s2, s1
    v.insert     v0, s3, #0
    v.extract    s1, v12, #2
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s11, s5
    v.extract    s4, v16, #3
    s.or         s5, s1, s2
    v.insert     v0, s3, #1
    v.extract    s1, v12, #3
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s6
    v.extract    s4, v16, #4
    s.or         s5, s1, s2
    v.insert     v0, s3, #2
    v.extract    s1, v12, #4
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s7
    v.extract    s4, v16, #5
    s.or         s5, s1, s2
    v.insert     v0, s3, #3
    v.extract    s1, v12, #5
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s8
    v.extract    s4, v16, #6
    s.or         s5, s1, s2
    v.insert     v0, s3, #4
    v.extract    s1, v12, #6
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s9
    v.extract    s4, v16, #7
    s.or         s5, s1, s2
    v.insert     v0, s3, #5
    v.extract    s1, v12, #7
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s10
    v.extract    s4, v16, #8
    s.or         s5, s1, s2
    v.insert     v0, s3, #6
    v.extract    s1, v12, #8
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s12
    v.extract    s4, v16, #9
    s.or         s5, s1, s2
    v.insert     v0, s3, #7
    v.extract    s1, v12, #9
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s13
    v.extract    s4, v16, #10
    s.or         s5, s1, s2
    v.insert     v0, s3, #8
    v.extract    s1, v12, #10
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s14
    v.extract    s4, v16, #11
    s.or         s5, s1, s2
    v.insert     v0, s3, #9
    v.extract    s1, v12, #11
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s15
    v.extract    s4, v16, #12
    s.or         s5, s1, s2
    v.insert     v0, s3, #10
    v.extract    s1, v12, #12
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s16
    v.extract    s4, v16, #13
    s.or         s5, s1, s2
    v.insert     v0, s3, #11
    v.extract    s1, v12, #13
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s17
    v.extract    s4, v16, #14
    s.or         s5, s1, s2
    v.insert     v0, s3, #12
    v.extract    s1, v12, #14
    s.shli       s2, s4, #32
    s.cmp.ge     s3, s5, s18
    v.extract    s4, v16, #15
    v.extract    s5, v16, #0
    s.or         s6, s1, s2
    v.insert     v0, s3, #13
    v.extract    s1, v12, #15
    s.shli       s2, s4, #32
    v.extract    s3, v12, #0
    s.shli       s4, s5, #32
    s.cmp.ge     s5, s6, s19
    v.extract    s6, v16, #1
    s.or         s7, s1, s2
    s.or         s1, s3, s4
    v.insert     v0, s5, #14
    v.movi       v5, #0
    v.extract    s2, v12, #1
    s.shli       s3, s6, #32
    s.cmp.ge     s4, s7, s20
    s.cmp.lt     s5, s1, s21
    v.extract    s1, v16, #2
    s.or         s6, s2, s3
    v.insert     v0, s4, #15
    v.insert     v5, s5, #0
    v.extract    s2, v12, #2
    s.shli       s3, s1, #32
    s.cmp.lt     s1, s6, s23
    v.extract    s4, v16, #3
    s.or         s5, s2, s3
    v.insert     v5, s1, #1
    v.extract    s1, v12, #3
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s24
    v.extract    s4, v16, #4
    s.or         s5, s1, s2
    v.insert     v5, s3, #2
    v.extract    s1, v12, #4
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s25
    v.extract    s4, v16, #5
    s.or         s5, s1, s2
    v.insert     v5, s3, #3
    v.extract    s1, v12, #5
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s26
    v.extract    s4, v16, #6
    s.or         s5, s1, s2
    v.insert     v5, s3, #4
    v.extract    s1, v12, #6
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s27
    v.extract    s4, v16, #7
    s.or         s5, s1, s2
    v.insert     v5, s3, #5
    v.extract    s1, v12, #7
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s28
    v.movi       v6, #0
    s.or         s4, s1, s2
    v.insert     v5, s3, #6
    v.cmp.ne     p2, v0, v6
    v.extract    s1, v16, #8
    v.extract    s2, v12, #8
    s.shli       s3, s1, #32
    s.cmp.lt     s1, s4, s29
    v.extract    s4, v16, #9
    s.or         s5, s2, s3
    v.insert     v5, s1, #7
    v.extract    s1, v12, #9
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s30
    v.extract    s4, v16, #10
    s.or         s5, s1, s2
    v.insert     v5, s3, #8
    v.extract    s1, v12, #10
    s.shli       s2, s4, #32
    v.movi       v0, #0
    s.cmp.lt     s3, s5, s31
    v.extract    s4, v16, #11
    s.or         s5, s1, s2
    v.insert     v5, s3, #9
    v.extract    s1, v12, #11
    s.shli       s2, s4, #32
    v.sub        v6, v0, v3
    s.cmp.lt     s3, s5, s33
    v.extract    s4, v16, #12
    s.or         s5, s1, s2
    v.cmp.lt     p3, v3, v0
    v.insert     v5, s3, #10
    v.extract    s1, v12, #12
    s.shli       s2, s4, #32
    @p3 v.sel        v7, v6, v3
    v.movi       v3, #31
    s.cmp.lt     s3, s5, s34
    v.extract    s4, v16, #13
    s.or         s5, s1, s2
    v.insert     v5, s3, #11
    v.extract    s1, v12, #13
    s.shli       s2, s4, #32
    v.and        v6, v7, v3
    s.cmp.lt     s3, s5, s35
    v.extract    s4, v16, #14
    s.or         s5, s1, s2
    v.insert     v5, s3, #12
    v.extract    s1, v12, #14
    s.shli       s2, s4, #32
    v.sub        v3, v0, v6
    s.cmp.lt     s3, s5, s36
    v.extract    s4, v16, #15
    s.or         s5, s1, s2
    v.insert     v5, s3, #13
    v.extract    s1, v12, #15
    s.shli       s2, s4, #32
    @p3 v.sel        v7, v3, v6
    v.movi       v3, #-2
    s.cmp.lt     s3, s5, s37
    s.or         s4, s1, s2
    v.insert     v5, s3, #14
    v.add        v6, v7, v3
    v.movi       v3, #3
    v.movi       v7, #0
    s.cmp.lt     s1, s4, s38
    v.movi       v9, #0
    v.insert     v5, s1, #15
    v.sub        v11, v0, v10
    v.sub        v12, v7, v6
    v.sub        v13, v7, v3
    v.cmp.lt     p3, v10, v0
    v.cmp.lt     p4, v6, v7
    v.cmp.lt     p5, v3, v7
    v.cmp.ne     p6, v5, v9
    v.movi       v0, #1
    @p3 v.sel        v0, v11, v10
    v.movi       v0, #1
    @p4 v.sel        v5, v12, v6
    @p5 v.sel        v9, v13, v3
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v12, s1
    v.shl        v13, v11, v0
    v.cmp.lt     p3, v11, v7
    v.lshr       v15, v5, v12
    v.shl        v16, v0, v12
    s.subi       s2, s1, #1
    v.and        v12, v15, v0
    s.movz       s3, #0
    v.or         v15, v13, v12
    v.cmp.geu    p5, v15, v9
    p.or         p7, p3, p5
    v.sub        v12, v15, v9
    @p7 v.sel        v13, v16, v7
    @p7 v.sel        v16, v12, v15
    v.or         v12, v10, v13
    v.mov        v11, v16
    v.mov        v10, v12
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_1
    v.sub        v0, v7, v11
    v.movi       v5, #0
    v.movi       v7, #0
    @p4 v.sel        v9, v0, v11
    v.extract    s1, v9, #0
    v.extract    s2, v9, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    v.extract    s3, v9, #2
    s.lshri      s4, s2, #32
    s.ashri      s5, s1, #32
    v.insert     v5, s2, #0
    v.insert     v7, s4, #0
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #3
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #1
    v.insert     v7, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #4
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #2
    v.insert     v7, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #5
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #3
    v.insert     v7, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #6
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #4
    v.insert     v7, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #7
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #5
    v.insert     v7, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #8
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #6
    v.insert     v7, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #9
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #7
    v.insert     v7, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #10
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #8
    v.insert     v7, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #11
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #9
    v.insert     v7, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #12
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #10
    v.insert     v7, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #13
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #11
    v.insert     v7, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #14
    s.ashri      s5, s1, #32
    v.insert     v5, s4, #12
    v.insert     v7, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #15
    s.ashri      s4, s1, #32
    v.insert     v5, s5, #13
    v.insert     v7, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v5, s4, #14
    v.insert     v7, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v5, s3, #15
    v.insert     v7, s1, #15
    s.movz       s1, #0
    v.extract    s2, v5, #0
    v.extract    s3, v7, #0
    v.extract    s4, v7, #1
    s.shli       s5, s3, #32
    v.movi       v0, #0
    s.or         s3, s2, s5
    v.extract    s2, v5, #1
    s.shli       s5, s4, #32
    s.cmp.eq     s4, s3, s1
    v.extract    s1, v7, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v0, s4, #0
    v.extract    s4, v5, #2
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s3, s2
    v.extract    s2, v7, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v0, s1, #1
    v.extract    s1, v5, #3
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s3, s4
    v.extract    s3, v7, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #2
    v.extract    s2, v5, #4
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #3
    v.extract    s3, v5, #5
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #4
    v.extract    s1, v5, #6
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #5
    v.extract    s2, v5, #7
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #6
    v.extract    s3, v5, #8
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #7
    v.extract    s1, v5, #9
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #8
    v.extract    s2, v5, #10
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #9
    v.extract    s3, v5, #11
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #10
    v.extract    s1, v5, #12
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v7, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #11
    v.extract    s2, v5, #13
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v7, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #12
    v.extract    s3, v5, #14
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v7, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #13
    v.extract    s1, v5, #15
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #14
    s.cmp.eq     s2, s3, s1
    v.movi       v5, #0
    v.insert     v0, s2, #15
    v.movi       v7, #0
    v.sub        v10, v5, v6
    v.sub        v11, v5, v3
    p.and        p3, p2, p6
    v.cmp.ne     p2, v0, v7
    v.cmp.lt     p4, v6, v5
    v.cmp.lt     p5, v3, v5
    p.and        p6, p3, p2
    v.movi       v0, #1
    @p4 v.sel        v7, v10, v6
    @p5 v.sel        v10, v11, v3
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v13, s1
    v.shl        v15, v12, v0
    v.cmp.lt     p2, v12, v5
    v.lshr       v16, v7, v13
    v.shl        v17, v0, v13
    s.subi       s2, s1, #1
    v.and        v13, v16, v0
    s.movz       s3, #0
    v.or         v16, v15, v13
    v.cmp.geu    p3, v16, v10
    p.or         p7, p2, p3
    v.sub        v13, v16, v10
    @p7 v.sel        v15, v17, v5
    @p7 v.sel        v17, v13, v16
    v.or         v13, v11, v15
    v.mov        v12, v17
    v.mov        v11, v13
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_2
    v.sub        v0, v5, v11
    p.xor        p2, p4, p5
    v.movi       v5, #1
    @p2 v.sel        v7, v0, v11
    v.movi       v0, #0
    v.movi       v10, #66
    v.sub        v11, v7, v5
    v.cmp.ne     p2, v9, v0
    v.cmp.lt     p3, v6, v0
    @p2 v.sel        v0, v11, v7
    p.and        p2, p6, p1
    s.movz       s1, #1
    @p3 v.sel        v5, v0, v7
    s.movz       s1, #3
    s.movz       s1, #66
    v.mul        v0, v5, v3
    v.add        v3, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s39, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s40, v3]              // index is in elements (ISA sec 9.1)
    @p6 v.sel        v3, v0, v14
    vf.mul       v0, v2, v3
    @p6 v.sel        v2, v5, v4
    vf.mul       v3, v1, v2
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s41, v8], v0
__rctx_next:
    exit
