#!/usr/bin/env bash
set -euo pipefail
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$HOME/r41_chat_astage_default_20261031"
tree=$(PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm" "$HOME/flux-venv/bin/python" -c 'from archbench.provenance import software_tree; from pathlib import Path; print(software_tree(Path.cwd(),refresh=True))')
"$HOME/flux-venv/bin/python" tools/performance_harness/default_change_audit.py run --source-root "$PWD" --software-tree "$tree" --label astage-default --out "$HOME/r41_astage_113_20261031" --jobs 1
"$HOME/flux-venv/bin/python" tools/performance_harness/default_change_audit.py compare --control "$HOME/r41_pipeline_double_113/report.json" --candidate "$HOME/r41_astage_113_20261031/report.json" --out "$HOME/r41_astage_113_compare_20261031.json"
