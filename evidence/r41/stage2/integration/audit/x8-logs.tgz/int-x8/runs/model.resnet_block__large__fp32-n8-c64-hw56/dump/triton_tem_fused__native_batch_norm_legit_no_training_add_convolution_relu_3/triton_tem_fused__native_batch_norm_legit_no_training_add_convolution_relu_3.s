    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.sub        v3, v2, v1
    v.splat      v4, s2
    v.cmp.lt     p1, v1, v2
    v.add        v5, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    v.sub        v4, v2, v5
    v.cmp.lt     p2, v5, v2
    s.ld.d       s4, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    v.movi       v6, #1
    @p2 v.sel        v7, v4, v5
    s.ld.d       s5, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v4, v3, v1
    v.movi       v3, #0
    s.ld.d       s6, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v8, #0
    s.movz       s7, #31
    s.ld.d       s8, [s3, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s3, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s3, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s11, [s3, #56]                  // out_ptr1: device_ptr64 at arg_base+56
idiv_1:
    v.splat      v9, s7
    v.shl        v10, v8, v6
    v.lshr       v11, v7, v9
    v.cmp.lt     p1, v8, v2
    v.and        v12, v11, v6
    v.shl        v11, v6, v9
    v.or         v9, v10, v12
    s.subi       s3, s7, #1
    v.cmp.geu    p3, v9, v4
    p.or         p4, p1, p3
    v.sub        v10, v9, v4
    @p4 v.sel        v12, v11, v2
    @p4 v.sel        v11, v10, v9
    v.or         v9, v3, v12
    v.mov        v8, v11
    v.mov        v3, v9
    s.mov        s7, s3
    s.movz       s3, #0
    s.cmp.ge     s12, s7, s3
    br.nz        s12, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v5
    v.sub        v6, v3, v1
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p3, v1, v3
    @p2 v.sel        v7, v4, v8
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v5
    @p3 v.sel        v2, v6, v1
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v9, s3
    v.shl        v10, v6, v4
    v.lshr       v11, v8, v9
    v.cmp.lt     p2, v6, v3
    v.and        v12, v11, v4
    v.shl        v11, v4, v9
    v.or         v9, v10, v12
    s.subi       s7, s3, #1
    v.cmp.geu    p4, v9, v2
    p.or         p5, p2, p4
    v.sub        v10, v9, v2
    @p5 v.sel        v12, v11, v3
    @p5 v.sel        v11, v10, v9
    v.or         v9, v5, v12
    v.mov        v6, v11
    v.mov        v5, v9
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s12, s3, s7
    br.nz        s12, idiv_2
    p.xor        p2, p1, p3
    v.sub        v2, v3, v5
    v.movi       v3, #0
    @p2 v.sel        v4, v2, v5
    v.sub        v2, v3, v1
    v.sub        v5, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.movi       v6, #1
    @p1 v.sel        v8, v5, v4
    @p2 v.sel        v5, v2, v1
    v.movi       v2, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v9, v6
    v.lshr       v12, v8, v10
    v.cmp.lt     p2, v9, v3
    v.and        v13, v12, v6
    v.shl        v12, v6, v10
    v.or         v10, v11, v13
    s.subi       s7, s3, #1
    v.cmp.geu    p3, v10, v5
    p.or         p4, p2, p3
    v.sub        v11, v10, v5
    @p4 v.sel        v13, v12, v3
    @p4 v.sel        v12, v11, v10
    v.or         v10, v2, v13
    v.mov        v9, v12
    v.mov        v2, v10
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s12, s3, s7
    br.nz        s12, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v9
    v.sub        v3, v2, v4
    v.sub        v6, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v8, v5, v9
    v.movi       v5, #1
    @p2 v.sel        v9, v3, v4
    @p3 v.sel        v3, v6, v1
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v10, s3
    v.shl        v11, v6, v5
    v.lshr       v12, v9, v10
    v.cmp.lt     p1, v6, v2
    v.and        v13, v12, v5
    v.shl        v12, v5, v10
    v.or         v10, v11, v13
    s.subi       s7, s3, #1
    v.cmp.geu    p4, v10, v3
    p.or         p5, p1, p4
    v.sub        v11, v10, v3
    @p5 v.sel        v13, v12, v2
    @p5 v.sel        v12, v11, v10
    v.or         v10, v4, v13
    v.mov        v6, v12
    v.mov        v4, v10
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s12, s3, s7
    br.nz        s12, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s7, role_id
    s.mul        s12, s3, s1
    s.movz       s3, #6208
    p.xor        p1, p2, p3
    v.sub        v3, v2, v4
    s.rdspecial  s13, arg_base
    s.mul        s14, s7, s3
    @p1 v.sel        v2, v3, v4
    .li       s3, #200704
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s3, [s13, #64]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s12
    v.mul        v5, v2, v3
    v.add        v3, v4, v0
    s.add        s7, s3, s14                     // this context's own scratch
    s.movz       s3, #0
    v.extract    s13, v5, #0
    v.extract    s14, v5, #1
    v.extract    s15, v5, #2
    v.extract    s16, v5, #3
    v.extract    s17, v5, #4
    v.extract    s18, v5, #5
    v.extract    s19, v5, #6
    v.extract    s20, v5, #7
    v.splat      v4, s3
    v.splat      v6, s13
    s.addi       s13, s7, #0
    v.splat      v9, s14
    v.splat      v10, s15
    v.splat      v11, s16
    v.splat      v12, s17
    v.add        v13, v4, v6
    s.addi       s14, s13, #64
    v.add        v6, v4, v9
    s.addi       s15, s13, #128
    v.add        v9, v4, v10
    s.addi       s16, s13, #192
    v.add        v10, v4, v11
    s.addi       s17, s13, #256
    v.add        v11, v4, v12
    v.st.w       [s13, #0], v13
    v.splat      v12, s18
    s.addi       s18, s13, #320
    v.add        v13, v4, v12
    v.st.w       [s14, #0], v6
    v.splat      v6, s19
    s.addi       s14, s13, #384
    v.add        v12, v4, v6
    s.addi       s19, s13, #448
    v.st.w       [s15, #0], v9
    .li       s15, #200704
    v.splat      v6, s20
    v.extract    s20, v5, #8
    v.add        v9, v4, v6
    v.st.w       [s16, #0], v10
    v.extract    s16, v5, #9
    v.splat      v6, s20
    v.extract    s20, v5, #10
    v.add        v10, v4, v6
    v.st.w       [s17, #0], v11
    v.extract    s17, v5, #11
    v.splat      v6, s16
    v.extract    s16, v5, #12
    v.add        v11, v4, v6
    v.st.w       [s18, #0], v13
    v.extract    s18, v5, #13
    v.splat      v6, s20
    v.extract    s20, v5, #14
    v.add        v13, v4, v6
    s.movz       s21, #576
    v.st.w       [s14, #0], v12
    v.movi       v6, #576
    v.extract    s14, v5, #15
    v.splat      v5, s17
    v.mul        v12, v3, v6
    s.addi       s17, s13, #512
    v.add        v6, v4, v5
    v.st.w       [s19, #0], v9
    v.splat      v5, s16
    s.addi       s16, s13, #576
    s.addi       s19, s13, #640
    v.add        v9, v4, v5
    v.st.w       [s17, #0], v10
    v.splat      v5, s18
    s.addi       s17, s13, #704
    s.addi       s18, s13, #768
    v.add        v10, v4, v5
    v.st.w       [s16, #0], v11
    v.splat      v5, s20
    s.addi       s16, s13, #832
    s.addi       s20, s13, #896
    v.add        v11, v4, v5
    s.addi       s21, s13, #960
    v.st.w       [s19, #0], v13
    v.splat      v5, s14
    s.addi       s13, s7, #1024
    v.add        v13, v4, v5
    v.splat      v4, s3
    s.movz       s14, #36
    v.add        v5, v4, v12
    v.st.w       [s17, #0], v6
    s.movz       s17, #1
    v.st.w       [s18, #0], v9
    s.addi       s18, s3, #0
    v.st.w       [s16, #0], v10
    v.st.w       [s20, #0], v11
    v.st.w       [s21, #0], v13
    fence.acq_rel.device
    v.st.w       [s13, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s13, s18, s14
    br.nz        s13, endfor_6
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s19, s18, s13
    s.movz       s13, #4
    s.sub        s20, s16, s19
    s.movz       s16, #0
    s.movz       s19, #0
    s.cmp.lt     s21, s13, s16
    s.xor        s16, s18, s20
    s.sub        s22, s19, s21
    s.sub        s19, s16, s20
    s.xor        s16, s20, s22
    s.lshri      s20, s19, #2
    s.movz       s21, #0
    s.xor        s23, s20, s16
    s.movz       s24, #0
    s.sub        s25, s23, s16
    s.movz       s16, #0
    s.cmp.lt     s23, s25, s21
    s.movz       s21, #0
    s.sub        s26, s24, s23
    .li       s23, #1431655766
    s.xor        s24, s25, s26
    s.cmp.lt     s27, s18, s16
    s.sub        s16, s24, s26
    s.sub        s24, s21, s27
    s.mul        s21, s16, s23
    s.xor        s23, s18, s24
    s.movz       s27, #3
    s.sub        s28, s23, s24
    s.muli       s23, s20, #4
    s.lshri      s20, s21, #32
    s.sub        s21, s19, s23
    s.movz       s19, #0
    s.lshri      s21, s28, #2
    s.cmp.lt     s23, s27, s19
    s.muli       s19, s21, #4
    s.sub        s21, s28, s19
    s.movz       s19, #0
    s.xor        s28, s21, s24
    s.sub        s21, s19, s23
    s.sub        s19, s28, s24
    s.movz       s23, #0
    s.mul        s24, s19, s1
    s.movz       s19, #0
    s.sub        s28, s16, s20
    s.cmp.lt     s29, s13, s23
    s.lshri      s23, s28, #1
    s.sub        s28, s19, s29
    s.add        s19, s20, s23
    s.xor        s20, s13, s28
    s.lshri      s23, s19, #1
    s.xor        s19, s26, s21
    s.muli       s26, s23, #3
    s.xor        s29, s13, s22
    s.sub        s13, s20, s28
    s.movz       s13, #0
    s.movz       s20, #0
    s.cmp.lt     s28, s25, s13
    s.xor        s13, s23, s19
    s.sub        s23, s20, s28
    .li       s20, #1431655766
    s.xor        s28, s25, s23
    s.sub        s25, s13, s19
    s.sub        s13, s28, s23
    s.movz       s19, #0
    s.mul        s28, s13, s20
    s.cmp.lt     s20, s27, s19
    s.sub        s19, s29, s22
    s.sub        s19, s25, s17
    v.movi       v4, #3584
    s.lshri      s22, s28, #32
    v.splat      v5, s19
    s.sub        s19, s13, s22
    v.add        v6, v5, v8
    s.lshri      s28, s19, #1
    v.mul        v5, v6, v4
    s.add        s19, s22, s28
    v.splat      v4, s24
    s.lshri      s22, s19, #1
    v.add        v9, v0, v4
    s.muli       s19, s22, #3
    s.movz       s22, #0
    s.xor        s28, s27, s21
    s.sub        s29, s22, s20
    s.movz       s20, #64
    s.sub        s22, s13, s19
    s.xor        s13, s27, s29
    s.xor        s19, s22, s23
    s.sub        s22, s28, s21
    s.sub        s21, s19, s23
    s.addi       s19, s7, #0
    s.sub        s22, s21, s17
    v.movi       v4, #64
    v.splat      v10, s22
    v.ld.w       v11, [s19, #0]
    v.add        v12, v10, v7
    v.extract    s19, v5, #0
    v.mul        v10, v12, v4
    v.splat      v13, s19
    v.extract    s19, v10, #0
    v.splat      v14, s19
    s.addi       s19, s7, #1088
    s.sub        s22, s16, s26
    s.movz       s16, #0
    v.iota       v15                             // arange(0, VLEN)
    s.add        s22, s16, s24                   // the tile origin
    v.add        v16, v13, v14
    v.splat      v13, s22
    s.addi       s16, s7, #64
    v.add        v14, v15, v13
    v.extract    s22, v5, #1
    v.add        v13, v16, v14
    v.extract    s23, v10, #1
    v.add        v16, v11, v13
    v.splat      v11, s22
    v.st.w       [s19, #0], v16
    s.addi       s22, s19, #64
    s.sub        s26, s13, s29
    v.splat      v13, s23
    s.addi       s13, s7, #128
    v.add        v16, v11, v13
    v.extract    s23, v5, #2
    v.add        v11, v16, v14
    v.extract    s26, v10, #2
    v.splat      v13, s23
    v.ld.w       v16, [s16, #0]
    v.splat      v17, s26
    s.addi       s16, s19, #128
    v.add        v18, v13, v17
    s.addi       s23, s7, #192
    v.add        v13, v18, v14
    v.extract    s26, v5, #3
    s.addi       s27, s19, #192
    s.movz       s28, #3584
    v.extract    s28, v10, #3
    v.add        v17, v16, v11
    v.splat      v11, s26
    v.st.w       [s22, #0], v17
    v.splat      v16, s28
    s.addi       s22, s7, #256
    v.add        v17, v11, v16
    v.extract    s26, v5, #4
    v.add        v11, v17, v14
    v.extract    s28, v10, #4
    v.splat      v16, s26
    v.splat      v17, s28
    s.addi       s26, s19, #256
    v.ld.w       v18, [s13, #0]
    v.add        v19, v16, v17
    s.addi       s13, s7, #320
    v.add        v16, v19, v14
    v.extract    s28, v5, #5
    v.splat      v17, s28
    v.extract    s28, v10, #5
    v.splat      v19, s28
    s.addi       s28, s19, #320
    v.add        v20, v17, v19
    v.add        v17, v18, v13
    v.add        v13, v20, v14
    v.st.w       [s16, #0], v17
    s.addi       s16, s7, #384
    v.ld.w       v17, [s23, #0]
    v.extract    s23, v5, #6
    v.splat      v18, s23
    v.extract    s23, v10, #6
    v.splat      v19, s23
    s.addi       s23, s19, #384
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v17, v11
    v.st.w       [s27, #0], v19
    s.addi       s27, s7, #448
    v.ld.w       v11, [s22, #0]
    v.extract    s22, v5, #7
    v.splat      v17, s22
    v.extract    s22, v10, #7
    v.splat      v19, s22
    s.addi       s22, s19, #448
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s26, #0], v19
    s.addi       s26, s7, #512
    v.ld.w       v11, [s13, #0]
    v.extract    s13, v5, #8
    v.splat      v16, s13
    v.extract    s13, v10, #8
    v.splat      v19, s13
    s.addi       s13, s19, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s28, #0], v19
    s.addi       s28, s7, #576
    v.ld.w       v11, [s16, #0]
    v.extract    s16, v5, #9
    v.splat      v13, s16
    v.extract    s16, v10, #9
    v.splat      v19, s16
    s.addi       s16, s19, #576
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s23, #0], v19
    s.addi       s23, s7, #640
    v.ld.w       v11, [s27, #0]
    v.extract    s27, v5, #10
    v.splat      v18, s27
    v.extract    s27, v10, #10
    v.splat      v19, s27
    s.addi       s27, s19, #640
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v11, v17
    v.st.w       [s22, #0], v19
    s.addi       s22, s7, #704
    v.ld.w       v11, [s26, #0]
    v.extract    s26, v5, #11
    v.splat      v17, s26
    v.extract    s26, v10, #11
    v.splat      v19, s26
    s.addi       s26, s19, #704
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s13, #0], v19
    s.addi       s13, s7, #768
    v.ld.w       v11, [s28, #0]
    v.extract    s28, v5, #12
    v.splat      v16, s28
    v.extract    s28, v10, #12
    v.splat      v19, s28
    s.addi       s28, s19, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s16, #0], v19
    s.addi       s16, s7, #832
    v.ld.w       v11, [s23, #0]
    v.extract    s23, v5, #13
    v.splat      v13, s23
    v.extract    s23, v10, #13
    v.splat      v19, s23
    s.addi       s23, s19, #832
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s27, #0], v19
    s.addi       s27, s7, #896
    v.ld.w       v11, [s22, #0]
    v.extract    s22, v5, #14
    v.splat      v18, s22
    v.extract    s22, v10, #14
    v.splat      v19, s22
    s.addi       s22, s19, #896
    v.add        v20, v18, v19
    v.movi       v18, #8
    v.add        v19, v20, v14
    s.addi       s29, s19, #960
    v.add        v20, v11, v17
    v.cmp.lt     p1, v2, v18
    v.st.w       [s26, #0], v20
    s.addi       s19, s7, #960
    v.movi       v11, #1
    v.movi       v17, #0
    @p1 v.sel        v18, v11, v17
    v.ld.w       v11, [s13, #0]
    v.extract    s13, v5, #15
    v.movi       v5, #0
    v.splat      v17, s13
    v.extract    s13, v10, #15
    v.splat      v10, s13
    v.movi       v20, #1
    v.cmp.ge     p1, v6, v5
    v.add        v21, v17, v10
    v.movi       v10, #0
    v.add        v17, v11, v16
    @p1 v.sel        v11, v20, v10
    v.st.w       [s28, #0], v17
    v.movi       v10, #1
    v.movi       v16, #0
    v.cmp.lt     p1, v6, v1
    v.add        v6, v21, v14
    @p1 v.sel        v14, v10, v16
    v.movi       v10, #1
    v.cmp.ge     p1, v12, v5
    v.ld.w       v5, [s16, #0]
    v.movi       v16, #0
    v.movi       v17, #1
    @p1 v.sel        v20, v10, v16
    v.movi       v10, #0
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v12, v17, v10
    v.cmp.lt     p1, v9, v4
    v.add        v4, v5, v13
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.st.w       [s23, #0], v4
    v.extract    s16, v18, #0
    s.addi       s23, s7, #1088
    v.ld.w       v4, [s27, #0]
    v.extract    s26, v11, #0
    v.splat      v5, s16
    v.movi       v9, #0
    v.splat      v10, s26
    v.movi       v13, #0
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p3, v10, v13
    v.add        v5, v4, v19
    p.and        p4, p2, p3
    v.st.w       [s22, #0], v5
    v.extract    s16, v14, #0
    v.splat      v4, s16
    v.movi       v5, #0
    v.ld.w       v9, [s19, #0]
    v.extract    s16, v20, #0
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s16
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p3, p2
    v.add        v4, v9, v6
    v.extract    s16, v12, #0
    v.st.w       [s29, #0], v4
    fence.acq_rel.device
    v.splat      v4, s16
    v.movi       v5, #0
    v.extract    s16, v18, #1
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s19, v11, #1
    p.and        p2, p3, p1
    v.splat      v4, s16
    v.ld.w       v5, [s23, #0]
    v.movi       v6, #0
    v.splat      v9, s19
    v.movi       v10, #0
    s.addi       s16, s7, #1152
    v.extract    s19, v14, #1
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s19, v20, #1
    v.cmp.ne     p3, v4, v6
    v.splat      v4, s19
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s19, v12, #1
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s19
    a.vwrite     a1, s13, v9
    v.ld.w       v5, [s16, #0]
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p3, p2
    v.extract    s13, v18, #2
    p.and        p2, p4, p1
    v.extract    s16, v11, #2
    v.splat      v4, s13
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s16
    v.movi       v10, #0
    s.movz       s13, #1
    s.addi       s16, s7, #1216
    v.extract    s19, v14, #2
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v5, v10
    v.splat      v4, s19
    v.movi       v5, #0
    a.vwrite     a1, s13, v9
    v.ld.w       v6, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s13
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s13
    v.movi       v5, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s13, v18, #3
    p.and        p2, p3, p1
    v.extract    s16, v11, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #2
    s.addi       s16, s7, #1280
    v.extract    s19, v14, #3
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #4
    p.and        p2, p3, p1
    v.extract    s16, v11, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #3
    s.addi       s16, s7, #1344
    v.extract    s19, v14, #4
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #5
    p.and        p2, p3, p1
    v.extract    s16, v11, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #4
    s.addi       s16, s7, #1408
    v.extract    s19, v14, #5
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #6
    p.and        p2, p3, p1
    v.extract    s16, v11, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #5
    s.addi       s16, s7, #1472
    v.extract    s19, v14, #6
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #7
    p.and        p2, p3, p1
    v.extract    s16, v11, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #6
    s.addi       s16, s7, #1536
    v.extract    s19, v14, #7
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #8
    p.and        p2, p3, p1
    v.extract    s16, v11, #8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #7
    s.addi       s16, s7, #1600
    v.extract    s19, v14, #8
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #9
    p.and        p2, p3, p1
    v.extract    s16, v11, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #8
    s.addi       s16, s7, #1664
    v.extract    s19, v14, #9
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #10
    p.and        p2, p3, p1
    v.extract    s16, v11, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #9
    s.addi       s16, s7, #1728
    v.extract    s19, v14, #10
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #11
    p.and        p2, p3, p1
    v.extract    s16, v11, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #10
    s.addi       s16, s7, #1792
    v.extract    s19, v14, #11
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #12
    p.and        p2, p3, p1
    v.extract    s16, v11, #12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #11
    s.addi       s16, s7, #1856
    v.extract    s19, v14, #12
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #13
    p.and        p2, p3, p1
    v.extract    s16, v11, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #12
    s.addi       s16, s7, #1920
    v.extract    s19, v14, #13
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #14
    p.and        p2, p3, p1
    v.extract    s16, v11, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #13
    s.addi       s16, s7, #1984
    v.extract    s19, v14, #14
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v5
    v.ld.w       v5, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #15
    p.and        p2, p3, p1
    v.extract    s16, v11, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s13
    v.movi       v6, #0
    v.splat      v9, s16
    v.movi       v10, #0
    s.movz       s13, #14
    s.addi       s16, s7, #2048
    v.extract    s19, v14, #15
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s19
    v.movi       v6, #0
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s16, #0]
    p.and        p4, p2, p3
    v.extract    s13, v20, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s13, v12, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s13
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    s.movz       s13, #192
    p.and        p2, p3, p1
    s.movz       s16, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s19, s7, #1024
    s.mul        s22, s25, s13
    s.movz       s13, #0
    s.mul        s23, s21, s20
    s.add        s21, s13, s24                   // the tile origin
    s.addi       s13, s7, #2112
    s.add        s25, s21, s22                   // the tile origin
    s.addi       s21, s7, #1024
    s.add        s22, s25, s23                   // the tile origin
    a.vwrite     a1, s16, v5
    v.ld.w       v4, [s19, #0]
    v.splat      v5, s22
    s.addi       s16, s22, #1
    s.addi       s19, s13, #64
    v.splat      v6, s16
    s.addi       s16, s7, #1024
    s.addi       s23, s22, #2
    s.addi       s25, s13, #128
    v.splat      v9, s23
    s.addi       s23, s7, #1024
    v.add        v10, v4, v5
    s.addi       s26, s22, #3
    v.st.w       [s13, #0], v10
    v.splat      v4, s26
    s.addi       s26, s13, #192
    s.addi       s27, s7, #1024
    s.addi       s28, s22, #4
    s.addi       s29, s13, #256
    v.splat      v5, s28
    s.addi       s28, s7, #1024
    v.ld.w       v10, [s21, #0]
    s.addi       s21, s22, #5
    v.splat      v11, s21
    s.addi       s21, s13, #320
    v.add        v12, v10, v6
    v.st.w       [s19, #0], v12
    s.addi       s19, s7, #1024
    v.ld.w       v6, [s16, #0]
    s.addi       s16, s22, #6
    v.splat      v10, s16
    s.addi       s16, s13, #384
    v.add        v12, v6, v9
    v.st.w       [s25, #0], v12
    s.addi       s25, s7, #1024
    v.ld.w       v6, [s23, #0]
    s.addi       s23, s22, #7
    v.splat      v9, s23
    s.addi       s23, s13, #448
    v.add        v12, v6, v4
    v.st.w       [s26, #0], v12
    s.addi       s26, s7, #1024
    v.ld.w       v4, [s27, #0]
    s.addi       s27, s22, #8
    v.splat      v6, s27
    s.addi       s27, s13, #512
    v.add        v12, v4, v5
    v.st.w       [s29, #0], v12
    s.addi       s29, s7, #1024
    v.ld.w       v4, [s28, #0]
    s.addi       s28, s22, #9
    v.splat      v5, s28
    s.addi       s28, s13, #576
    v.add        v12, v4, v11
    v.st.w       [s21, #0], v12
    s.addi       s21, s7, #1024
    v.ld.w       v4, [s19, #0]
    s.addi       s19, s22, #10
    v.splat      v11, s19
    s.addi       s19, s13, #640
    v.add        v12, v4, v10
    v.st.w       [s16, #0], v12
    s.addi       s16, s7, #1024
    v.ld.w       v4, [s25, #0]
    s.addi       s25, s22, #11
    v.splat      v10, s25
    s.addi       s25, s13, #704
    v.add        v12, v4, v9
    v.st.w       [s23, #0], v12
    s.addi       s23, s7, #1024
    v.ld.w       v4, [s26, #0]
    s.addi       s26, s22, #12
    v.splat      v9, s26
    s.addi       s26, s13, #768
    v.add        v12, v4, v6
    v.st.w       [s27, #0], v12
    s.addi       s27, s7, #1024
    v.ld.w       v4, [s29, #0]
    s.addi       s29, s22, #13
    v.splat      v6, s29
    s.addi       s29, s13, #832
    v.add        v12, v4, v5
    v.st.w       [s28, #0], v12
    s.addi       s28, s7, #1024
    v.splat      v4, s20
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s22, #14
    s.addi       s30, s22, #15
    v.splat      v12, s21
    s.addi       s21, s13, #896
    v.splat      v13, s30
    s.addi       s22, s7, #1024
    s.addi       s30, s13, #960
    v.add        v14, v5, v11
    v.st.w       [s19, #0], v14
    s.addi       s13, s7, #2112
    v.splat      v5, s20
    s.movz       s19, #0
    s.add        s20, s19, s12                   // the tile origin
    v.splat      v11, s20
    s.movz       s19, #0
    v.add        v14, v15, v11
    v.ld.w       v11, [s16, #0]
    s.add        s16, s19, s24                   // the tile origin
    v.cmp.lt     p1, v14, v5
    v.splat      v5, s16
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    v.add        v5, v11, v10
    s.movz       s20, #1
    v.st.w       [s25, #0], v5
    s.addi       s24, s7, #2176
    v.ld.w       v5, [s23, #0]
    s.addi       s23, s16, #1
    v.splat      v10, s23
    v.cmp.lt     p2, v10, v4
    p.and        p4, p2, p1
    v.add        v10, v5, v9
    v.st.w       [s26, #0], v10
    s.addi       s23, s7, #2240
    s.movz       s25, #2
    v.ld.w       v5, [s27, #0]
    s.addi       s26, s16, #2
    v.splat      v9, s26
    v.add        v10, v5, v6
    v.cmp.lt     p2, v9, v4
    v.st.w       [s29, #0], v10
    p.and        p5, p2, p1
    v.ld.w       v5, [s28, #0]
    s.addi       s26, s7, #2304
    s.movz       s27, #3
    v.add        v6, v5, v12
    s.addi       s28, s16, #3
    v.st.w       [s21, #0], v6
    v.splat      v5, s28
    v.ld.w       v6, [s22, #0]
    s.movz       s21, #4
    v.add        v9, v6, v13
    s.addi       s22, s7, #2368
    v.st.w       [s30, #0], v9
    fence.acq_rel.device
    s.addi       s28, s16, #4
    v.splat      v6, s28
    v.ld.w       v9, [s13, #0]
    s.addi       s13, s7, #2432
    s.addi       s28, s16, #5
    s.movz       s29, #5
    v.splat      v10, s28
    s.movz       s28, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v9]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s19, v11
    v.ld.w       v5, [s24, #0]
    s.addi       s19, s7, #2496
    s.addi       s24, s16, #6
    v.splat      v9, s24
    s.movz       s24, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s20, v11
    v.ld.w       v5, [s23, #0]
    s.addi       s20, s7, #2560
    s.addi       s23, s16, #7
    v.splat      v6, s23
    s.movz       s23, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s25, v11
    v.ld.w       v5, [s26, #0]
    s.addi       s25, s7, #2624
    s.addi       s26, s16, #8
    v.splat      v10, s26
    s.movz       s26, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s27, v11
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s7, #2688
    s.addi       s27, s16, #9
    v.splat      v9, s27
    s.movz       s27, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s21, v11
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s7, #2752
    s.addi       s21, s16, #10
    v.splat      v6, s21
    s.movz       s21, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s29, v11
    v.ld.w       v5, [s19, #0]
    s.addi       s19, s7, #2816
    s.addi       s29, s16, #11
    v.splat      v10, s29
    s.movz       s29, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s28, v11
    v.ld.w       v5, [s20, #0]
    s.addi       s20, s7, #2880
    s.addi       s28, s16, #12
    v.splat      v9, s28
    s.movz       s28, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s24, v11
    v.ld.w       v5, [s25, #0]
    s.addi       s24, s7, #2944
    s.addi       s25, s16, #13
    v.splat      v6, s25
    s.movz       s25, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s23, v11
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s7, #3008
    s.addi       s23, s16, #14
    v.splat      v10, s23
    s.movz       s23, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s26, v11
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s7, #3072
    s.addi       s26, s16, #15
    v.movi       v9, #0
    v.splat      v11, s26
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    a.vwrite     a2, s27, v12
    v.ld.w       v5, [s19, #0]
    s.movz       s19, #0
    s.movz       s26, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s21, v6
    v.ld.w       v5, [s20, #0]
    s.movz       s20, #1
    s.movz       s21, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s29, v6
    v.ld.w       v4, [s24, #0]
    s.movz       s24, #3
    s.movz       s27, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v5
    v.ld.w       v4, [s22, #0]
    s.movz       s22, #5
    s.movz       s28, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v5
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    s.movz       s25, #8
    a.vwrite     a2, s23, v5
    a.vread      v4, a1, s19
    a.vread      v5, a2, s26
    v.extract    s19, v4, #0
    v.splat      v6, s19
    v.extract    s19, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s19
    a.vread      v6, a2, s20
    v.extract    s19, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s19
    a.vread      v6, a2, s21
    v.extract    s19, v4, #3
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s19
    a.vread      v6, a2, s24
    v.extract    s19, v4, #4
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s19
    a.vread      v6, a2, s27
    v.extract    s19, v4, #5
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s19
    a.vread      v6, a2, s22
    v.extract    s19, v4, #6
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s19
    a.vread      v6, a2, s28
    v.extract    s19, v4, #7
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s19
    a.vread      v6, a2, s13
    v.extract    s13, v4, #8
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s25
    s.movz       s13, #9
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s13
    s.movz       s13, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s13
    s.movz       s13, #1
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s16, v6
    a.vread      v4, a1, s13
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #1
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #2
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #2
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #3
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #4
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #5
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #6
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #7
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #8
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #9
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #9
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #10
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #11
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #12
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #13
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #14
    vf.fma       v10, v5, v6, v11
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s13, v6
    a.vread      v4, a1, s16
    a.vread      v5, a2, s19
    v.extract    s13, v4, #0
    v.splat      v6, s13
    v.extract    s13, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s13
    a.vread      v6, a2, s20
    v.extract    s13, v4, #2
    vf.fma       v9, v5, v6, v10
    v.splat      v5, s13
    a.vread      v6, a2, s21
    s.movz       s13, #3
    vf.fma       v10, v5, v6, v9
    v.extract    s16, v4, #3
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #4
    vf.fma       v9, v5, v6, v10
    v.extract    s16, v4, #4
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #5
    vf.fma       v10, v5, v6, v9
    v.extract    s16, v4, #5
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #6
    vf.fma       v9, v5, v6, v10
    v.extract    s16, v4, #6
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #7
    vf.fma       v10, v5, v6, v9
    v.extract    s16, v4, #7
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #8
    vf.fma       v9, v5, v6, v10
    v.extract    s16, v4, #8
    v.splat      v5, s16
    a.vread      v6, a2, s13
    s.movz       s13, #15
    vf.fma       v10, v5, v6, v9
    s.movz       s16, #9
    v.extract    s19, v4, #9
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #10
    vf.fma       v9, v5, v6, v10
    v.extract    s19, v4, #10
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #11
    vf.fma       v10, v5, v6, v9
    v.extract    s19, v4, #11
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #12
    vf.fma       v9, v5, v6, v10
    v.extract    s19, v4, #12
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #13
    vf.fma       v10, v5, v6, v9
    v.extract    s19, v4, #13
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #14
    vf.fma       v9, v5, v6, v10
    v.extract    s19, v4, #14
    v.splat      v5, s19
    a.vread      v6, a2, s16
    s.movz       s16, #15
    vf.fma       v10, v5, v6, v9
    v.extract    s19, v4, #15
    v.splat      v4, s19
    a.vread      v5, a2, s16
    s.movz       s16, #0
    vf.fma       v6, v4, v5, v10
    s.movz       s19, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s20, #0
    s.movz       s21, #1
    a.vwrite     a3, s13, v6
    a.vread      v4, a0, s16
    a.vread      v5, a3, s19
    s.movz       s13, #1
    vf.add       v6, v4, v5
    s.movz       s16, #1
    s.movz       s19, #2
    s.movz       s22, #2
    a.vwrite     a4, s20, v6
    a.vread      v4, a0, s21
    a.vread      v5, a3, s13
    s.movz       s13, #2
    vf.add       v6, v4, v5
    s.movz       s20, #3
    s.movz       s21, #3
    s.movz       s23, #3
    a.vwrite     a4, s16, v6
    a.vread      v4, a0, s19
    a.vread      v5, a3, s22
    s.movz       s16, #4
    vf.add       v6, v4, v5
    s.movz       s19, #4
    s.movz       s22, #4
    s.movz       s24, #5
    a.vwrite     a4, s13, v6
    a.vread      v4, a0, s20
    a.vread      v5, a3, s21
    s.movz       s13, #5
    vf.add       v6, v4, v5
    s.movz       s20, #5
    s.movz       s21, #6
    s.movz       s25, #6
    a.vwrite     a4, s23, v6
    a.vread      v4, a0, s16
    a.vread      v5, a3, s19
    s.movz       s16, #6
    vf.add       v6, v4, v5
    s.movz       s19, #7
    s.movz       s23, #7
    s.movz       s26, #7
    a.vwrite     a4, s22, v6
    a.vread      v4, a0, s24
    a.vread      v5, a3, s13
    s.movz       s13, #8
    vf.add       v6, v4, v5
    s.movz       s22, #8
    s.movz       s24, #8
    s.movz       s27, #9
    a.vwrite     a4, s20, v6
    a.vread      v4, a0, s21
    a.vread      v5, a3, s25
    s.movz       s20, #9
    vf.add       v6, v4, v5
    s.movz       s21, #9
    s.movz       s25, #10
    s.movz       s28, #10
    a.vwrite     a4, s16, v6
    a.vread      v4, a0, s19
    a.vread      v5, a3, s23
    s.movz       s16, #10
    vf.add       v6, v4, v5
    s.movz       s19, #11
    s.movz       s23, #11
    s.movz       s29, #11
    a.vwrite     a4, s26, v6
    a.vread      v4, a0, s13
    a.vread      v5, a3, s22
    s.movz       s13, #12
    vf.add       v6, v4, v5
    s.movz       s22, #12
    s.movz       s26, #12
    s.movz       s30, #13
    a.vwrite     a4, s24, v6
    a.vread      v4, a0, s27
    a.vread      v5, a3, s20
    s.movz       s20, #13
    vf.add       v6, v4, v5
    s.movz       s24, #13
    s.movz       s27, #14
    a.vwrite     a4, s21, v6
    a.vread      v4, a0, s25
    a.vread      v5, a3, s28
    s.movz       s21, #14
    vf.add       v6, v4, v5
    s.movz       s25, #14
    s.movz       s28, #15
    a.vwrite     a4, s16, v6
    a.vread      v4, a0, s19
    a.vread      v5, a3, s23
    s.movz       s16, #15
    vf.add       v6, v4, v5
    s.movz       s19, #15
    s.movz       s23, #0
    a.vwrite     a4, s29, v6
    a.vread      v4, a0, s13
    a.vread      v5, a3, s22
    s.movz       s13, #0
    vf.add       v6, v4, v5
    s.movz       s22, #1
    s.movz       s29, #1
    a.vwrite     a4, s26, v6
    a.vread      v4, a0, s30
    a.vread      v5, a3, s20
    s.movz       s20, #2
    vf.add       v6, v4, v5
    s.movz       s26, #2
    s.movz       s30, #3
    a.vwrite     a4, s24, v6
    a.vread      v4, a0, s27
    a.vread      v5, a3, s21
    s.movz       s21, #3
    vf.add       v6, v4, v5
    s.movz       s24, #4
    s.movz       s27, #4
    a.vwrite     a4, s25, v6
    a.vread      v4, a0, s28
    a.vread      v5, a3, s16
    s.movz       s16, #5
    vf.add       v6, v4, v5
    s.movz       s25, #5
    s.movz       s28, #6
    a.vwrite     a4, s19, v6
    a.vread      v4, a4, s23
    s.movz       s19, #6
    a.vwrite     a0, s13, v4
    a.vread      v4, a4, s22
    s.movz       s13, #7
    a.vwrite     a0, s29, v4
    a.vread      v4, a4, s20
    s.movz       s20, #7
    a.vwrite     a0, s26, v4
    a.vread      v4, a4, s30
    s.movz       s22, #8
    a.vwrite     a0, s21, v4
    a.vread      v4, a4, s24
    s.movz       s21, #8
    a.vwrite     a0, s27, v4
    a.vread      v4, a4, s16
    s.movz       s16, #9
    a.vwrite     a0, s25, v4
    a.vread      v4, a4, s28
    s.movz       s23, #9
    a.vwrite     a0, s19, v4
    a.vread      v4, a4, s13
    s.movz       s13, #10
    a.vwrite     a0, s20, v4
    a.vread      v4, a4, s22
    s.movz       s19, #10
    a.vwrite     a0, s21, v4
    a.vread      v4, a4, s16
    s.movz       s16, #11
    a.vwrite     a0, s23, v4
    a.vread      v4, a4, s13
    s.movz       s13, #11
    a.vwrite     a0, s19, v4
    a.vread      v4, a4, s16
    s.movz       s16, #12
    a.vwrite     a0, s13, v4
    s.movz       s13, #12
    a.vread      v4, a4, s16
    s.movz       s16, #13
    a.vwrite     a0, s13, v4
    s.movz       s13, #13
    a.vread      v4, a4, s16
    s.movz       s16, #14
    a.vwrite     a0, s13, v4
    s.movz       s13, #14
    a.vread      v4, a4, s16
    s.movz       s16, #15
    a.vwrite     a0, s13, v4
    s.movz       s13, #15
    a.vread      v4, a4, s16
    s.add        s16, s18, s17
    s.movz       s19, #1
    a.vwrite     a0, s13, v4
    s.mov        s18, s16
    br.nz        s19, for_5
endfor_6:
    s.muli       s1, s12, #3136                  // a runtime tile origin, x3136
    s.movz       s2, #56
    s.movz       s4, #0
    s.movz       s13, #3136
    v.extract    s14, v8, #0
    v.splat      v0, s14
    v.splat      v4, s2
    s.add        s2, s4, s1                      // the tile origin
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s13
    v.extract    s1, v7, #0
    v.splat      v9, s1
    v.mul        v10, v0, v4
    v.mul        v0, v5, v6
    v.splat      v5, s2
    v.extract    s1, v2, #0
    v.add        v6, v9, v10
    v.add        v9, v0, v5
    v.splat      v0, s1
    v.splat      v5, s15
    v.add        v10, v6, v9
    v.mul        v6, v0, v5
    s.movz       s1, #3136
    s.muli       s2, s12, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s4, s12, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s13, s12, #4                    // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s14, s12, #4                    // a runtime tile origin, x4
    v.add        v0, v10, v6
    v.movi       v6, #8
    v.splat      v10, s1
    v.movi       v11, #1
    v.movi       v12, #0
    v.movi       v13, #1
    v.movi       v14, #0
    v.movi       v15, #1
    v.movi       v16, #0
    v.movi       v17, #64
    v.cmp.lt     p1, v2, v6
    v.movi       v6, #0
    v.cmp.lt     p2, v8, v1
    v.cmp.lt     p3, v7, v1
    v.cmp.lt     p4, v0, v6
    @p1 v.sel        v1, v11, v12
    v.sub        v11, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v10, v6
    @p2 v.sel        v18, v13, v14
    @p3 v.sel        v13, v15, v16
    v.cmp.lt     p2, v3, v17
    s.add        s1, s5, s2                      // the tile origin
    s.add        s2, s6, s4                      // the tile origin
    s.add        s4, s8, s13                     // the tile origin
    s.add        s5, s9, s14                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s6, s7, #3136
    v.movi       v3, #1
    @p4 v.sel        v14, v11, v0
    @p1 v.sel        v0, v12, v10
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s8, #31
idiv_7:
    v.splat      v15, s8
    v.shl        v16, v12, v3
    v.lshr       v17, v14, v15
    v.cmp.lt     p1, v12, v6
    v.and        v19, v17, v3
    v.shl        v17, v3, v15
    v.or         v15, v16, v19
    s.subi       s9, s8, #1
    v.cmp.geu    p3, v15, v0
    p.or         p5, p1, p3
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v11, v19
    v.mov        v12, v17
    v.mov        v11, v15
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s12, s8, s9
    br.nz        s12, idiv_7
    v.extract    s8, v8, #1
    v.splat      v0, s8
    v.extract    s8, v7, #1
    v.splat      v3, s8
    v.mul        v11, v0, v4
    v.extract    s8, v2, #1
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s8
    v.extract    s8, v2, #0
    @p4 v.sel        v11, v0, v12
    v.splat      v0, s8
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s6, #0], v12
    s.addi       s8, s6, #64
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_8:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_8
    v.extract    s9, v8, #2
    v.splat      v0, s9
    v.extract    s9, v7, #2
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #2
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #1
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #128
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_9:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_9
    v.extract    s9, v8, #3
    v.splat      v0, s9
    v.extract    s9, v7, #3
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #3
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #2
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #192
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_10:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_10
    v.extract    s9, v8, #4
    v.splat      v0, s9
    v.extract    s9, v7, #4
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #4
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #3
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #256
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_11:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_11
    v.extract    s9, v8, #5
    v.splat      v0, s9
    v.extract    s9, v7, #5
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #5
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #4
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #320
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_12:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_12
    v.extract    s9, v8, #6
    v.splat      v0, s9
    v.extract    s9, v7, #6
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #6
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #5
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #384
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_13:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_13
    v.extract    s9, v8, #7
    v.splat      v0, s9
    v.extract    s9, v7, #7
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #7
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #6
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #448
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_14:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_14
    v.extract    s9, v8, #8
    v.splat      v0, s9
    v.extract    s9, v7, #8
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #8
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #7
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #512
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_15:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_15
    v.extract    s9, v8, #9
    v.splat      v0, s9
    v.extract    s9, v7, #9
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #9
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #8
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #576
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_16:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_16
    v.extract    s9, v8, #10
    v.splat      v0, s9
    v.extract    s9, v7, #10
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #10
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #9
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #640
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_17:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_17
    v.extract    s9, v8, #11
    v.splat      v0, s9
    v.extract    s9, v7, #11
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #11
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #10
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #704
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_18:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_18
    v.extract    s9, v8, #12
    v.splat      v0, s9
    v.extract    s9, v7, #12
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #12
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #11
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #768
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_19:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_19
    v.extract    s9, v8, #13
    v.splat      v0, s9
    v.extract    s9, v7, #13
    v.splat      v3, s9
    v.mul        v11, v0, v4
    v.extract    s9, v2, #13
    v.sub        v0, v6, v12
    v.add        v6, v3, v11
    v.splat      v3, s9
    v.extract    s9, v2, #12
    @p1 v.sel        v11, v0, v12
    v.splat      v0, s9
    v.add        v12, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v11, v9
    v.mul        v11, v0, v5
    v.add        v0, v12, v6
    v.movi       v6, #0
    v.add        v12, v3, v11
    v.sub        v3, v6, v0
    v.sub        v11, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v12
    s.addi       s8, s6, #832
    v.movi       v12, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v11, v10
    v.movi       v3, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_20:
    v.splat      v15, s9
    v.shl        v16, v11, v12
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v11, v6
    v.and        v19, v17, v12
    v.shl        v17, v12, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v11, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_20
    v.extract    s9, v8, #14
    v.splat      v0, s9
    v.extract    s9, v7, #14
    v.splat      v3, s9
    v.mul        v12, v0, v4
    v.extract    s9, v2, #14
    v.sub        v0, v6, v11
    v.add        v6, v3, v12
    v.splat      v3, s9
    v.extract    s9, v2, #13
    @p1 v.sel        v12, v0, v11
    v.splat      v0, s9
    v.add        v11, v6, v9
    v.mul        v6, v3, v5
    v.add        v3, v12, v9
    v.mul        v12, v0, v5
    v.add        v0, v11, v6
    v.movi       v6, #0
    v.add        v11, v3, v12
    v.sub        v3, v6, v0
    v.sub        v12, v6, v10
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v10, v6
    v.st.w       [s8, #0], v11
    s.addi       s8, s6, #896
    v.movi       v11, #1
    @p1 v.sel        v14, v3, v0
    @p3 v.sel        v0, v12, v10
    v.movi       v3, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_21:
    v.splat      v15, s9
    v.shl        v16, v12, v11
    v.lshr       v17, v14, v15
    v.cmp.lt     p3, v12, v6
    v.and        v19, v17, v11
    v.shl        v17, v11, v15
    v.or         v15, v16, v19
    s.subi       s12, s9, #1
    v.cmp.geu    p4, v15, v0
    p.or         p5, p3, p4
    v.sub        v16, v15, v0
    @p5 v.sel        v19, v17, v6
    @p5 v.sel        v17, v16, v15
    v.or         v15, v3, v19
    v.mov        v12, v17
    v.mov        v3, v15
    s.mov        s9, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s9, s12
    br.nz        s13, idiv_21
    v.extract    s9, v8, #15
    v.splat      v0, s9
    v.extract    s9, v7, #15
    v.splat      v3, s9
    v.mul        v7, v0, v4
    v.extract    s9, v2, #15
    v.sub        v0, v6, v12
    v.add        v4, v3, v7
    v.splat      v3, s9
    v.extract    s9, v2, #14
    @p1 v.sel        v6, v0, v12
    v.splat      v0, s9
    v.add        v7, v4, v9
    v.mul        v4, v3, v5
    v.add        v3, v6, v9
    v.mul        v6, v0, v5
    v.add        v0, v7, v4
    v.movi       v4, #0
    v.add        v7, v3, v6
    v.sub        v3, v4, v0
    v.sub        v6, v4, v10
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p3, v10, v4
    v.st.w       [s8, #0], v7
    s.addi       s8, s6, #960
    v.movi       v7, #1
    @p1 v.sel        v8, v3, v0
    @p3 v.sel        v0, v6, v10
    v.movi       v3, #0
    v.movi       v6, #0
    s.movz       s6, #31
idiv_22:
    v.splat      v10, s6
    v.shl        v11, v6, v7
    v.lshr       v12, v8, v10
    v.cmp.lt     p3, v6, v4
    v.and        v14, v12, v7
    v.shl        v12, v7, v10
    v.or         v10, v11, v14
    s.subi       s9, s6, #1
    v.cmp.geu    p4, v10, v0
    p.or         p5, p3, p4
    v.sub        v11, v10, v0
    @p5 v.sel        v14, v12, v4
    @p5 v.sel        v12, v11, v10
    v.or         v10, v3, v14
    v.mov        v6, v12
    v.mov        v3, v10
    s.mov        s6, s9
    s.movz       s9, #0
    s.cmp.ge     s12, s6, s9
    br.nz        s12, idiv_22
    v.sub        v0, v4, v6
    v.extract    s6, v2, #15
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s6
    v.add        v3, v2, v9
    v.mul        v2, v0, v5
    s.addi       s6, s7, #3136
    v.add        v0, v3, v2
    v.splat      v2, s3
    v.st.w       [s8, #0], v0
    fence.acq_rel.device
    s.addi       s8, s7, #4160
    s.addi       s9, s7, #3200
    s.addi       s12, s8, #64
    s.addi       s13, s7, #3264
    s.addi       s14, s8, #128
    s.addi       s15, s7, #3328
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s8, #192
    v.add        v3, v2, v0
    v.st.w       [s8, #0], v3
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #3392
    v.add        v3, v2, v0
    v.st.w       [s12, #0], v3
    s.addi       s12, s8, #256
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s7, #3456
    v.add        v3, v2, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s8, #320
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #3520
    v.add        v3, v2, v0
    v.st.w       [s6, #0], v3
    s.addi       s6, s8, #384
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #3584
    v.add        v3, v2, v0
    v.st.w       [s12, #0], v3
    s.addi       s12, s8, #448
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s7, #3648
    v.add        v3, v2, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s8, #512
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #3712
    v.add        v3, v2, v0
    v.st.w       [s6, #0], v3
    s.addi       s6, s8, #576
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #3776
    v.add        v3, v2, v0
    v.movi       v0, #0
    v.st.w       [s12, #0], v3
    s.addi       s12, s8, #640
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s7, #3840
    v.movi       v4, #0
    v.add        v5, v2, v3
    v.st.w       [s14, #0], v5
    s.addi       s14, s8, #704
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s7, #3904
    v.movi       v5, #0
    v.add        v6, v2, v3
    v.st.w       [s6, #0], v6
    s.addi       s6, s8, #768
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #3968
    v.add        v6, v2, v3
    v.st.w       [s12, #0], v6
    s.addi       s12, s8, #832
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s7, #4032
    v.add        v6, v2, v3
    v.movi       v3, #0
    v.st.w       [s14, #0], v6
    s.addi       s14, s8, #896
    s.addi       s16, s8, #960
    v.ld.w       v6, [s15, #0]
    s.addi       s8, s7, #4096
    v.movi       v7, #0
    v.add        v8, v2, v6
    v.st.w       [s6, #0], v8
    s.addi       s6, s7, #4160
    v.ld.w       v6, [s9, #0]
    v.extract    s9, v1, #0
    v.splat      v8, s9
    v.extract    s9, v18, #0
    v.splat      v9, s9
    v.extract    s9, v13, #0
    v.cmp.ne     p1, v8, v0
    v.cmp.ne     p3, v9, v4
    v.splat      v0, s9
    p.and        p4, p1, p3
    v.add        v4, v2, v6
    v.cmp.ne     p1, v0, v5
    v.st.w       [s12, #0], v4
    p.and        p3, p4, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    p.and        p1, p3, p2
    s.addi       s12, s7, #4224
    v.movi       v0, #0
    v.ld.w       v4, [s13, #0]
    v.extract    s13, v1, #1
    v.splat      v5, s13
    v.extract    s13, v18, #1
    v.splat      v6, s13
    v.extract    s13, v13, #1
    v.cmp.ne     p3, v5, v3
    v.cmp.ne     p4, v6, v7
    v.splat      v3, s13
    p.and        p5, p3, p4
    v.add        v5, v2, v4
    v.cmp.ne     p3, v3, v0
    v.st.w       [s14, #0], v5
    p.and        p4, p5, p3
    s.movz       s13, #1
    p.and        p3, p4, p2
    s.addi       s14, s7, #4288
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v1, #2
    v.splat      v3, s8
    s.movz       s8, #2
    v.add        v4, v2, v0
    v.movi       v0, #0
    v.st.w       [s16, #0], v4
    fence.acq_rel.device
    v.extract    s15, v18, #2
    v.splat      v2, s15
    v.movi       v4, #0
    v.cmp.ne     p4, v3, v0
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v13, #2
    v.splat      v3, s6
    v.movi       v5, #0
    s.addi       s6, s7, #4352
    v.extract    s15, v1, #3
    v.splat      v6, s15
    v.movi       v7, #0
    s.movz       s15, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v4
    p.and        p5, p4, p1
    v.cmp.ne     p1, v3, v5
    p.and        p4, p5, p1
    v.cmp.ne     p1, v6, v7
    p.and        p5, p4, p2
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s12, #0]
    v.extract    s9, v18, #3
    v.splat      v2, s9
    v.movi       v3, #0
    v.extract    s9, v13, #3
    v.splat      v4, s9
    v.movi       v5, #0
    s.addi       s9, s7, #4416
    v.extract    s12, v1, #4
    v.splat      v6, s12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p4, p1, p3
    v.cmp.ne     p1, v4, v5
    p.and        p3, p4, p1
    v.movi       v0, #0
    p.and        p1, p3, p2
    v.cmp.ne     p3, v6, v0
    s.movz       s12, #4
    a.vwrite     a5, s13, v7
    v.ld.w       v0, [s14, #0]
    v.extract    s13, v18, #4
    v.splat      v2, s13
    v.movi       v3, #0
    v.extract    s13, v13, #4
    v.splat      v4, s13
    v.movi       v5, #0
    s.addi       s13, s7, #4480
    v.extract    s14, v1, #5
    v.splat      v6, s14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p4, v2, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s14, #5
    a.vwrite     a5, s8, v7
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #5
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v13, #5
    v.splat      v4, s6
    v.movi       v5, #0
    s.addi       s6, s7, #4544
    v.extract    s8, v1, #6
    v.splat      v6, s8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    v.movi       v0, #0
    p.and        p1, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s8, #6
    a.vwrite     a5, s15, v7
    v.ld.w       v0, [s9, #0]
    v.extract    s9, v18, #6
    v.splat      v2, s9
    v.movi       v3, #0
    v.extract    s9, v13, #6
    v.splat      v4, s9
    v.movi       v5, #0
    s.addi       s9, s7, #4608
    v.extract    s15, v1, #7
    v.splat      v6, s15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s15, #7
    a.vwrite     a5, s12, v7
    v.ld.w       v0, [s13, #0]
    v.extract    s12, v18, #7
    v.splat      v2, s12
    v.movi       v3, #0
    v.extract    s12, v13, #7
    v.splat      v4, s12
    v.movi       v5, #0
    s.addi       s12, s7, #4672
    v.extract    s13, v1, #8
    v.splat      v6, s13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    v.movi       v0, #0
    p.and        p1, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s13, #8
    a.vwrite     a5, s14, v7
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #8
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v13, #8
    v.splat      v4, s6
    v.movi       v5, #0
    s.addi       s6, s7, #4736
    v.extract    s14, v1, #9
    v.splat      v6, s14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s14, #9
    a.vwrite     a5, s8, v7
    v.ld.w       v0, [s9, #0]
    v.extract    s8, v18, #9
    v.splat      v2, s8
    v.movi       v3, #0
    v.extract    s8, v13, #9
    v.splat      v4, s8
    v.movi       v5, #0
    s.addi       s8, s7, #4800
    v.extract    s9, v1, #10
    v.splat      v6, s9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    v.movi       v0, #0
    p.and        p1, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s9, #10
    a.vwrite     a5, s15, v7
    v.ld.w       v0, [s12, #0]
    v.extract    s12, v18, #10
    v.splat      v2, s12
    v.movi       v3, #0
    v.extract    s12, v13, #10
    v.splat      v4, s12
    v.movi       v5, #0
    s.addi       s12, s7, #4864
    v.extract    s15, v1, #11
    v.splat      v6, s15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s15, #11
    a.vwrite     a5, s13, v7
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #11
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v13, #11
    v.splat      v4, s6
    v.movi       v5, #0
    s.addi       s6, s7, #4928
    v.extract    s13, v1, #12
    v.splat      v6, s13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    v.movi       v0, #0
    p.and        p1, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s13, #12
    a.vwrite     a5, s14, v7
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v18, #12
    v.splat      v2, s8
    v.movi       v3, #0
    v.extract    s8, v13, #12
    v.splat      v4, s8
    v.movi       v5, #0
    s.addi       s8, s7, #4992
    v.extract    s14, v1, #13
    v.splat      v6, s14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s14, #13
    a.vwrite     a5, s9, v7
    v.ld.w       v0, [s12, #0]
    v.extract    s9, v18, #13
    v.splat      v2, s9
    v.movi       v3, #0
    v.extract    s9, v13, #13
    v.splat      v4, s9
    v.movi       v5, #0
    s.addi       s9, s7, #5056
    v.extract    s12, v1, #14
    v.splat      v6, s12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    v.movi       v0, #0
    p.and        p1, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s12, #14
    a.vwrite     a5, s15, v7
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #14
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v13, #14
    v.splat      v4, s6
    v.movi       v5, #0
    s.addi       s6, s7, #5120
    v.extract    s15, v1, #15
    v.splat      v6, s15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.movi       v0, #0
    p.and        p3, p4, p2
    v.cmp.ne     p4, v6, v0
    s.movz       s15, #15
    a.vwrite     a5, s13, v7
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v18, #15
    v.splat      v2, s8
    v.movi       v3, #0
    v.extract    s8, v13, #15
    v.splat      v4, s8
    v.movi       v5, #0
    s.addi       s8, s7, #3136
    v.splat      v6, s3
    s.addi       s3, s7, #5184
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v2, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v4, v5
    p.and        p4, p5, p1
    .li       s13, #925353388
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    p.and        p1, p4, p2
    v.movi       v2, #0
    a.vwrite     a5, s14, v7
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #3200
    s.addi       s13, s3, #64
    s.addi       s14, s7, #3264
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s10, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s12, v4
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s3, #128
    s.addi       s12, s7, #3328
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s10, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s10, s3, #192
    a.vwrite     a5, s15, v4
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s7, #3392
    s.addi       s15, s3, #256
    v.add        v4, v6, v3
    v.st.w       [s3, #0], v4
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #3456
    v.add        v4, v6, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s3, #320
    v.ld.w       v3, [s14, #0]
    s.addi       s14, s7, #3520
    v.add        v4, v6, v3
    v.st.w       [s6, #0], v4
    s.addi       s6, s3, #384
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s7, #3584
    v.add        v4, v6, v3
    v.st.w       [s10, #0], v4
    s.addi       s10, s3, #448
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s7, #3648
    v.add        v4, v6, v3
    v.st.w       [s15, #0], v4
    s.addi       s15, s3, #512
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #3712
    v.add        v4, v6, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s3, #576
    v.ld.w       v3, [s14, #0]
    s.addi       s14, s7, #3776
    v.add        v4, v6, v3
    v.st.w       [s6, #0], v4
    s.addi       s6, s3, #640
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s7, #3840
    v.movi       v4, #0
    v.add        v5, v6, v3
    v.st.w       [s10, #0], v5
    s.addi       s10, s3, #704
    v.movi       v3, #0
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s7, #3904
    v.add        v7, v6, v5
    v.st.w       [s15, #0], v7
    s.addi       s15, s3, #768
    v.movi       v5, #0
    v.ld.w       v7, [s9, #0]
    s.addi       s9, s7, #3968
    v.add        v8, v6, v7
    v.st.w       [s13, #0], v8
    s.addi       s13, s3, #832
    v.ld.w       v7, [s14, #0]
    s.addi       s14, s7, #4032
    v.add        v8, v6, v7
    v.st.w       [s6, #0], v8
    s.addi       s6, s3, #896
    v.movi       v7, #0
    s.addi       s16, s3, #960
    v.ld.w       v8, [s12, #0]
    s.addi       s3, s7, #4096
    v.add        v9, v6, v8
    v.movi       v8, #0
    v.st.w       [s10, #0], v9
    v.extract    s10, v1, #0
    v.splat      v9, s10
    v.extract    s10, v18, #0
    v.splat      v10, s10
    v.extract    s10, v13, #0
    v.cmp.ne     p1, v9, v7
    v.cmp.ne     p3, v10, v8
    p.and        p4, p1, p3
    v.ld.w       v7, [s8, #0]
    v.splat      v8, s10
    s.movz       s8, #0
    v.extract    s10, v1, #0
    v.splat      v9, s10
    v.extract    s10, v18, #0
    v.splat      v10, s10
    v.extract    s10, v13, #0
    v.cmp.ne     p1, v9, v4
    v.cmp.ne     p3, v10, v3
    v.add        v3, v6, v7
    v.movi       v4, #0
    v.st.w       [s15, #0], v3
    v.splat      v3, s10
    p.and        p5, p1, p3
    v.cmp.ne     p1, v8, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v3, v5
    p.and        p4, p3, p2
    p.and        p3, p5, p1
    p.and        p1, p3, p2
    v.ld.w       v3, [s9, #0]
    v.add        v4, v6, v3
    v.st.w       [s13, #0], v4
    .li       s9, #1077936128
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v4, [s14, #0]
    v.add        v5, v6, v4
    .li       s9, #3204448256
    v.splat      v4, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s6, #0], v5
    v.ld.w       v5, [s3, #0]
    v.add        v7, v6, v5
    v.st.w       [s16, #0], v7
    fence.acq_rel.device
    a.vread      v5, a0, s8
    v.extract    s3, v1, #0
    v.extract    s6, v18, #0
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s2, #0]
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s3
    v.movi       v7, #0
    p.and        p5, p3, p4
    v.extract    s3, v1, #0
    v.cmp.ne     p3, v6, v7
    v.splat      v6, s3
    p.and        p4, p5, p3
    vf.add       v7, v10, v0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s1, #0]
    v.movi       v9, #0
    p.and        p1, p4, p2
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s4, #0]
    vf.sub       v12, v5, v8
    v.extract    s3, v18, #0
    v.splat      v5, s3
    v.movi       v8, #0
    v.extract    s3, v13, #0
    v.cmp.ne     p1, v6, v9
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v6, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v6
    p.and        p3, p4, p1
    s.movz       s3, #0
    p.and        p1, p3, p2
    s.addi       s6, s7, #5184
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s5, #0]
    a.vread      v6, a5, s3
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    v.extract    s3, v1, #0
    vf.fms       v14, v7, v8, v3
    v.splat      v7, s3
    vf.mul       v8, v9, v14                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.ld.w       v9, [s6, #0]
    v.extract    s3, v18, #0
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v14, v8, v10
    v.movi       v8, #0
    vf.mul       v10, v12, v14
    v.splat      v12, s3
    v.extract    s3, v13, #0
    v.cmp.ne     p1, v7, v8
    vf.mul       v7, v10, v11
    v.extract    s6, v1, #1
    v.extract    s8, v18, #1
    v.movi       v8, #0
    vf.add       v10, v7, v5
    v.splat      v5, s6
    v.movi       v7, #0
    v.splat      v11, s8
    vf.add       v14, v10, v6
    v.movi       v6, #0
    v.extract    s6, v13, #1
    v.cmp.ne     p3, v12, v8
    v.splat      v8, s3
    v.movi       v10, #0
    v.cmp.ne     p4, v5, v7
    p.and        p5, p1, p3
    v.cmp.ne     p1, v11, v6
    p.and        p3, p4, p1
    v.cmp.ne     p1, v8, v10
    vf.max.prop  v5, v14, v2
    v.splat      v6, s6
    v.movi       v7, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v6, v7
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #1
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v9], v5
    a.vread      v5, a0, s3
    v.extract    s3, v1, #1
    v.extract    s6, v18, #1
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #1
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #1
    p.and        p1, p3, p2
    v.extract    s6, v18, #1
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #1
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #1
    v.extract    s6, v18, #1
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #1
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #1
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5248
    v.extract    s8, v1, #1
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #1
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #2
    v.extract    s6, v18, #2
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #1
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #2
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #2
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #2
    v.extract    s6, v18, #2
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #2
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #2
    p.and        p1, p3, p2
    v.extract    s6, v18, #2
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #2
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #2
    v.extract    s6, v18, #2
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #2
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #2
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5312
    v.extract    s8, v1, #2
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #2
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #3
    v.extract    s6, v18, #3
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #2
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #3
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #3
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #3
    v.extract    s6, v18, #3
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #3
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #3
    p.and        p1, p3, p2
    v.extract    s6, v18, #3
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #3
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #3
    v.extract    s6, v18, #3
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #3
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #3
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5376
    v.extract    s8, v1, #3
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #3
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #4
    v.extract    s6, v18, #4
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #3
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #4
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #4
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #4
    v.extract    s6, v18, #4
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #4
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #4
    p.and        p1, p3, p2
    v.extract    s6, v18, #4
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #4
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #4
    v.extract    s6, v18, #4
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #4
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #4
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5440
    v.extract    s8, v1, #4
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #4
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #5
    v.extract    s6, v18, #5
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #4
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #5
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #5
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #5
    v.extract    s6, v18, #5
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #5
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #5
    p.and        p1, p3, p2
    v.extract    s6, v18, #5
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #5
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #5
    v.extract    s6, v18, #5
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #5
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #5
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5504
    v.extract    s8, v1, #5
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #5
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #6
    v.extract    s6, v18, #6
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #5
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #6
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #6
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #6
    v.extract    s6, v18, #6
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #6
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #6
    p.and        p1, p3, p2
    v.extract    s6, v18, #6
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #6
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #6
    v.extract    s6, v18, #6
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #6
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #6
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5568
    v.extract    s8, v1, #6
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #6
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #7
    v.extract    s6, v18, #7
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #6
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #7
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #7
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #7
    v.extract    s6, v18, #7
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #7
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #7
    p.and        p1, p3, p2
    v.extract    s6, v18, #7
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #7
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #7
    v.extract    s6, v18, #7
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #7
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #7
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5632
    v.extract    s8, v1, #7
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #7
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #8
    v.extract    s6, v18, #8
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #7
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #8
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #8
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #8
    v.extract    s6, v18, #8
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #8
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #8
    p.and        p1, p3, p2
    v.extract    s6, v18, #8
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #8
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #8
    v.extract    s6, v18, #8
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #8
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #8
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5696
    v.extract    s8, v1, #8
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #8
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #9
    v.extract    s6, v18, #9
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #8
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #9
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #9
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #9
    v.extract    s6, v18, #9
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #9
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #9
    p.and        p1, p3, p2
    v.extract    s6, v18, #9
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #9
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #9
    v.extract    s6, v18, #9
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #9
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #9
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5760
    v.extract    s8, v1, #9
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #9
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #10
    v.extract    s6, v18, #10
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #9
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #10
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #10
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #10
    v.extract    s6, v18, #10
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #10
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #10
    p.and        p1, p3, p2
    v.extract    s6, v18, #10
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #10
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #10
    v.extract    s6, v18, #10
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #10
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #10
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5824
    v.extract    s8, v1, #10
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #10
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #11
    v.extract    s6, v18, #11
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #10
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #11
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #11
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #11
    v.extract    s6, v18, #11
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #11
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #11
    p.and        p1, p3, p2
    v.extract    s6, v18, #11
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #11
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #11
    v.extract    s6, v18, #11
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #11
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #11
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5888
    v.extract    s8, v1, #11
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #11
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #12
    v.extract    s6, v18, #12
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #11
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #12
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #12
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #12
    v.extract    s6, v18, #12
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #12
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #12
    p.and        p1, p3, p2
    v.extract    s6, v18, #12
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #12
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #12
    v.extract    s6, v18, #12
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #12
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #12
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #5952
    v.extract    s8, v1, #12
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #12
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #13
    v.extract    s6, v18, #13
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #12
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #13
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #13
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #13
    v.extract    s6, v18, #13
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #13
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #13
    p.and        p1, p3, p2
    v.extract    s6, v18, #13
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #13
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #13
    v.extract    s6, v18, #13
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #13
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #13
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #6016
    v.extract    s8, v1, #13
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #13
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #14
    v.extract    s6, v18, #14
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #13
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #14
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #14
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #14
    v.extract    s6, v18, #14
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #14
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s3, v1, #14
    p.and        p1, p3, p2
    v.extract    s6, v18, #14
    vf.add       v7, v6, v0
    v.splat      v6, s3
    v.movi       v8, #0
    v.splat      v9, s6
    v.rsqrt.approx v10, v7                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s1, #0]
    v.extract    s3, v13, #14
    v.cmp.ne     p1, v6, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.extract    s3, v1, #14
    v.extract    s6, v18, #14
    v.cmp.ne     p1, v6, v8
    v.splat      v6, s3
    v.movi       v8, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v6, v8
    p.and        p4, p3, p2
    vf.sub       v6, v5, v12
    v.splat      v5, s6
    v.movi       v8, #0
    v.extract    s3, v13, #14
    v.cmp.ne     p3, v5, v8
    v.splat      v5, s3
    v.movi       v8, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v8, v10, v10
    vf.mul       v9, v10, v4
    p.and        p3, p5, p1
    s.movz       s3, #14
    vf.fms       v11, v7, v8, v3
    p.and        p1, p3, p2
    s.addi       s6, s7, #6080
    v.extract    s8, v1, #14
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s5, #0]
    a.vread      v9, a5, s3
    v.extract    s3, v18, #14
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v11, v7, v10
    v.splat      v7, s8
    vf.mul       v10, v6, v11
    v.movi       v6, #0
    v.splat      v11, s3
    v.movi       v12, #0
    vf.mul       v14, v10, v5
    v.ld.w       v5, [s6, #0]
    v.extract    s3, v1, #15
    v.extract    s6, v18, #15
    vf.add       v10, v14, v8
    v.splat      v8, s3
    v.extract    s3, v13, #14
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0
    v.splat      v7, s6
    vf.add       v14, v10, v9
    v.movi       v9, #0
    v.extract    s6, v13, #15
    v.cmp.ne     p3, v11, v12
    v.splat      v10, s3
    v.movi       v11, #0
    v.cmp.ne     p4, v8, v6
    p.and        p5, p1, p3
    v.cmp.ne     p1, v7, v9
    p.and        p3, p4, p1
    v.cmp.ne     p1, v10, v11
    vf.max.prop  v6, v14, v2
    v.splat      v7, s6
    v.movi       v8, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v8
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s3, #15
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v5], v6
    a.vread      v5, a0, s3
    v.extract    s3, v1, #15
    v.extract    s6, v18, #15
    v.splat      v6, s3
    v.movi       v7, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s3, v13, #15
    v.cmp.ne     p1, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s2, #0]
    v.cmp.ne     p3, v8, v9
    v.splat      v7, s3
    v.movi       v8, #0
    p.and        p4, p1, p3
    v.cmp.ne     p1, v7, v8
    p.and        p3, p4, p1
    v.extract    s2, v1, #15
    p.and        p1, p3, p2
    v.extract    s3, v18, #15
    vf.add       v7, v6, v0
    v.splat      v0, s2
    v.movi       v6, #0
    v.splat      v8, s3
    v.rsqrt.approx v9, v7                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s1, #0]
    v.extract    s1, v13, #15
    v.cmp.ne     p1, v0, v6
    v.cmp.ne     p3, v8, v10
    v.splat      v0, s1
    v.movi       v6, #0
    p.and        p4, p1, p3
    v.extract    s1, v1, #15
    v.extract    s2, v18, #15
    v.cmp.ne     p1, v0, v6
    v.splat      v0, s1
    v.movi       v6, #0
    p.and        p3, p4, p1
    v.cmp.ne     p1, v0, v6
    p.and        p4, p3, p2
    vf.sub       v0, v5, v11
    v.splat      v5, s2
    v.movi       v6, #0
    v.extract    s1, v13, #15
    v.cmp.ne     p3, v5, v6
    v.splat      v5, s1
    v.movi       v6, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s4, #0]
    vf.mul       v6, v9, v9
    vf.mul       v8, v9, v4
    p.and        p3, p5, p1
    s.movz       s1, #15
    vf.fms       v4, v7, v6, v3
    p.and        p1, p3, p2
    s.addi       s2, s7, #6144
    v.extract    s3, v1, #15
    vf.mul       v1, v8, v4                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s5, #0]
    a.vread      v4, a5, s1
    v.extract    s1, v18, #15
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v9
    v.splat      v1, s3
    vf.mul       v7, v0, v6
    v.movi       v0, #0
    v.splat      v6, s1
    v.movi       v8, #0
    vf.mul       v9, v7, v5
    v.ld.w       v5, [s2, #0]
    v.extract    s1, v13, #15
    v.cmp.ne     p1, v1, v0
    vf.add       v0, v9, v3
    v.cmp.ne     p3, v6, v8
    v.splat      v1, s1
    v.movi       v3, #0
    vf.add       v6, v0, v4
    p.and        p4, p1, p3
    v.cmp.ne     p1, v1, v3
    p.and        p3, p4, p1
    vf.max.prop  v0, v6, v2
    p.and        p1, p3, p2
    @p1 v.st.scatter.w [s11, v5], v0
__rctx_next:
    exit
