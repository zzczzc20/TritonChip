    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s4, #1024
    s.movz       s5, #176
    s.mul        s6, s1, s4
    s.movz       s1, #0
    s.movz       s4, #0
    s.cmp.lt     s7, s5, s1
    .li       s1, #2147483647
    s.sub        s8, s4, s7
    .li       s4, #2147483647
    s.ld.d       s7, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.add        s9, s3, s6                      // this context's own scratch
    s.movz       s3, #2048
    s.addi       s6, s9, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s9, #2
    .li       s10, #68719476752
    .li       s11, #8589934592
    s.xor        s12, s5, s8
    s.movz       s13, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.ld.d       s15, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s16, s12, s8
    .li       s12, #1952257862
    s.movz       s16, #1
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.ld.d       s22, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.st.d       [s6, #0], s7
    s.movz       s2, #0
    s.st.d       [s6, #8], s1
    s.movz       s1, #1
    s.st.d       [s6, #16], s4
    s.rdspecial  s4, role_id
    s.st.d       [s6, #48], s3
    s.rdspecial  s3, npid.x
    s.st.d       [s6, #56], s9
    s.st.d       [s6, #88], s10
    s.st.d       [s6, #104], s11
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
__rctx_program:
    s.cmp.lt     s6, s4, s14
    s.cmp.lt     s7, s4, s18
    s.sub        s9, s13, s6
    s.sub        s6, s17, s7
    s.xor        s7, s4, s9
    s.xor        s10, s9, s8
    s.sub        s11, s7, s9
    s.xor        s7, s4, s6
    s.mul        s9, s11, s12
    s.sub        s23, s7, s6
    s.addi       s7, s21, #0
    s.addi       s24, s2, #0
    s.mov        s7, s23
    s.lshri      s25, s9, #32
    s.sub        s9, s11, s25
    s.lshri      s26, s9, #1
    s.add        s9, s25, s26
    s.lshri      s25, s9, #7
    s.xor        s9, s25, s10
    s.muli       s26, s25, #176
    s.sub        s25, s9, s10
    s.sub        s9, s16, s25
    s.min.s      s10, s9, s16
    s.sub        s9, s11, s26
    s.cmp.lt     s9, s10, s20
    s.sub        s11, s19, s9
    s.xor        s9, s10, s11
    s.sub        s26, s9, s11
    s.cmp.eq     s9, s26, s1
    br.nz        s9, sdiv_done_1
    s.movz       s9, #0
    s.movz       s11, #31
    s.mov        s7, s9
    s.addi       s9, s11, #0
sdiv_2:
    s.lshr       s11, s23, s9
    s.shli       s27, s24, #1
    s.andi       s28, s11, #1
    s.movz       s11, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s26
    s.shl        s30, s27, s9
    s.sub        s27, s11, s28
    s.subi       s11, s9, #1
    s.and        s28, s26, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s7, s31
    s.mov        s24, s27
    s.mov        s7, s28
    s.mov        s9, s11
    s.movz       s11, #0
    s.cmp.ge     s27, s9, s11
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.movz       s7, #0
    s.movz       s9, #0
    s.cmp.lt     s11, s4, s7
    .li       s7, #1952257862
    s.sub        s23, s9, s11
    s.movz       s9, #0
    s.xor        s11, s4, s23
    s.movz       s26, #0
    s.sub        s27, s11, s23
    s.movz       s11, #0
    s.mul        s28, s27, s7
    s.cmp.lt     s7, s10, s9
    s.movz       s9, #0
    s.movz       s29, #0
    s.sub        s30, s11, s7
    s.lshri      s7, s28, #32
    s.movz       s11, #0
    s.cmp.lt     s28, s5, s9
    s.xor        s9, s10, s30
    s.xor        s10, s24, s6
    s.sub        s24, s11, s28
    s.sub        s11, s27, s7
    s.sub        s28, s9, s30
    s.lshri      s9, s11, #1
    s.sub        s11, s10, s6
    s.add        s6, s7, s9
    s.movz       s7, #0
    s.lshri      s9, s6, #7
    s.movz       s6, #1
    s.muli       s10, s9, #176
    s.addi       s9, s7, #0
    s.cmp.eq     s7, s28, s6
    s.add        s6, s25, s11
    s.xor        s11, s5, s24
    s.sub        s25, s27, s10
    s.movz       s10, #0
    s.xor        s27, s25, s23
    s.sub        s25, s11, s24
    s.sub        s11, s27, s23
    s.addi       s23, s10, #0
    s.cmp.lt     s10, s11, s26
    s.sub        s24, s29, s10
    s.xor        s10, s11, s24
    s.sub        s11, s10, s24
    s.mov        s9, s11
    br.nz        s7, sdiv_done_3
    s.movz       s7, #0
    s.movz       s10, #31
    s.mov        s9, s7
    s.addi       s7, s10, #0
sdiv_4:
    s.lshr       s10, s11, s7
    s.shli       s25, s23, #1
    s.andi       s26, s10, #1
    s.movz       s10, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s28
    s.shl        s29, s25, s7
    s.sub        s25, s10, s26
    s.subi       s10, s7, #1
    s.and        s26, s28, s25
    s.and        s31, s29, s25
    s.sub        s25, s27, s26
    s.or         s26, s9, s31
    s.mov        s23, s25
    s.mov        s9, s26
    s.mov        s7, s10
    s.movz       s10, #0
    s.cmp.ge     s25, s7, s10
    br.nz        s25, sdiv_4
sdiv_done_3:
    s.xor        s7, s24, s30
    s.movz       s10, #16
    s.xor        s11, s9, s7
    .li       s9, #1952257862
    s.sub        s23, s11, s7
    s.movz       s7, #0
    s.mul        s11, s23, s10
    v.splat      v0, s6
    v.splat      v1, s7
    v.splat      v2, s23
    v.splat      v3, s7
    s.mul        s23, s11, s9
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s11
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    s.lshri      s9, s23, #32
    v.cmp.ge     p1, v2, v3
    s.sub        s23, s11, s9
    v.add        v0, v5, v4
    s.lshri      s24, s23, #1
    s.movz       s23, #64
    s.add        s25, s9, s24
    s.addi       s9, s7, #0
    s.lshri      s7, s25, #11
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.muli       s24, s7, #2816
    s.sub        s7, s11, s24
    v.splat      v0, s7
    v.add        v1, v0, v6
for_5:
    s.cmp.ge     s24, s9, s23
    br.nz        s24, endfor_6
    s.mul        s24, s9, s10
    s.muli       s25, s24, #2                    // a runtime tile origin, x2
    s.add        s26, s15, s25                   // the tile origin
    v.ld.h       v0, [s26, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s26, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s26, s25
    mb.wait      s25
    s.rdspecial  s24, arg_base
    s.ld.d       s26, [s24, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s24, role_id
    s.movz       s27, #1024
    s.mul        s28, s24, s27
    s.add        s24, s26, s28                   // this context's own scratch
    s.addi       s26, s24, #256                  // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s26, #0], v0
    s.addi       s27, s26, #32                   // row 1
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #64                   // row 2
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #96                   // row 3
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #128                  // row 4
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #160                  // row 5
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #192                  // row 6
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #224                  // row 7
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #256                  // row 8
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #288                  // row 9
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #320                  // row 10
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #352                  // row 11
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #384                  // row 12
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #416                  // row 13
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #448                  // row 14
    v.st.h       [s27, #0], v0
    s.addi       s27, s26, #480                  // row 15
    v.st.h       [s27, #0], v0
    s.addi       s27, s24, #768                  // TensorMap 1: a repacked tile
    s.movz       s24, #0
    s.st.d       [s27, #0], s26
    s.movz       s24, #16
    s.st.d       [s27, #8], s24
    s.movz       s24, #16
    s.st.d       [s27, #16], s24
    s.movz       s24, #32
    s.st.d       [s27, #48], s24
    s.movz       s24, #2
    s.st.d       [s27, #56], s24
    .li       s24, #68719476752
    s.st.d       [s27, #88], s24
    .li       s24, #8589934592
    s.st.d       [s27, #104], s24
    fence.release.device
    td.load      d1, [s27]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s24, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s26, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s27, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s27, s26
    mb.wait      s26
    mb.arm       s24, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v48, v56, s24
    mb.wait      s24
    s.add        s27, s9, s16
    s.mov        s9, s27
    s.movz       s27, #1
    br.nz        s27, for_5
endfor_6:
    s.mul        s7, s6, s10
    s.movz       s6, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    s.add        s10, s6, s11                    // the tile origin
    s.movz       s6, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s10
    a.vread      v2, a0, s9
    s.add        s9, s6, s7                      // the tile origin
    s.movz       s6, #2816
    s.muli       s10, s11, #2                    // a runtime tile origin, x2
    v.splat      v3, s9
    v.splat      v5, s16
    v.add        v6, v0, v1
    v.splat      v0, s6
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v6, v0
    s.add        s6, s22, s10                    // the tile origin
    p.and        p3, p1, p2
    s.movz       s10, #1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v0, a0, s10
    s.addi       s10, s9, #1
    s.movz       s11, #2
    v.splat      v1, s10
    vf.cvt.f32.f16 v2, v0
    s.addi       s10, s9, #2
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    v.splat      v0, s10
    s.movz       s10, #3
    s.addi       s23, s9, #3
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    @p3 v.st.h       [s6, #0], v2
    a.vread      v0, a0, s11
    v.splat      v1, s23
    s.movz       s11, #4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    v.splat      v0, s7
    v.add        v1, v0, v4
    s.addi       s7, s9, #4
    s.movz       s23, #5
    v.splat      v0, s7
    @p4 v.st.h       [s6, #0], v2
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s7, s9, #5
    s.movz       s10, #6
    v.splat      v1, s7
    s.addi       s7, s9, #6
    s.movz       s27, #7
    v.splat      v2, s7
    s.addi       s7, s9, #7
    s.movz       s28, #8
    v.splat      v3, s7
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s7, s9, #8
    s.movz       s11, #9
    v.splat      v0, s7
    s.addi       s7, s9, #9
    v.splat      v4, s7
    s.movz       s7, #10
    @p4 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s23
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s23, s9, #10
    v.splat      v1, s23
    s.movz       s23, #11
    @p3 v.st.h       [s6, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s10, s9, #11
    v.splat      v2, s10
    s.movz       s10, #12
    @p4 v.st.h       [s6, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v3
    s.addi       s27, s9, #12
    v.splat      v3, s27
    s.movz       s27, #13
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s28
    v.cmp.lt     p1, v4, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v4, v0
    s.addi       s28, s9, #13
    v.splat      v0, s28
    s.movz       s28, #14
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a0, s11
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v4
    s.addi       s11, s9, #14
    s.addi       s29, s9, #15
    v.splat      v4, s11
    s.movz       s9, #15
    v.splat      v6, s29
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s6, #0], v2
    a.vread      v1, a0, s23
    v.cmp.lt     p1, v3, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s6, #0], v2
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s27
    v.cmp.lt     p1, v4, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s6, #0], v1
    a.vread      v0, a0, s28
    v.cmp.lt     p1, v6, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s6, #0], v1
    a.vread      v0, a0, s9
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s6, #0], v1
__rctx_next:
    s.addi       s6, s4, #2                      // the next program of this context: + 2
    s.cmp.lt     s7, s6, s3
    s.mov        s4, s6
    br.nz        s7, __rctx_program
    exit
