module owner_gold(input [63:0] a, input [7:0] tv,tbyp,
input [511:0] tbase,tsize,input [47:0] tlsb,output [11:0] result);
localparam ADDR_W=64,DCO_T=8;
localparam OWNER_LEAVES=(DCO_T>1)?(1<<$clog2(DCO_T)):1;
function [11:0] owner;
        input [ADDR_W-1:0]      a;
        input [DCO_T-1:0]       tv;
        input [DCO_T*64-1:0]    tbase;
        input [DCO_T*64-1:0]    tsize;
        input [DCO_T-1:0]       tbyp;
        input [DCO_T*6-1:0]     tlsb;
        integer k;
        reg     hit, byp;
        reg [63:0] best, b, z;
        reg [3:0]  idx;
        reg [5:0]  lsb;
        begin
            hit = 1'b0; best = 64'd0; byp = 1'b0; idx = 4'd0; lsb = 6'd0;
            for (k = 0; k < DCO_T; k = k + 1) begin
                b = tbase[k*64 +: 64];
                z = tsize[k*64 +: 64];
                if (tv[k] && (a >= b) && ((z == 64'd0) || (a - b < z)) &&
                    (!hit || b > best)) begin
                    hit = 1'b1; best = b; byp = tbyp[k]; idx = k[3:0];
                    lsb = tlsb[k*6 +: 6];
                end
            end
            owner = {hit, byp, idx, lsb};
        end
    endfunction
assign result=owner(a,tv,tbase,tsize,tbyp,tlsb);
endmodule
module owner_gate(input [63:0] a, input [7:0] tv,tbyp,
input [511:0] tbase,tsize,input [47:0] tlsb,output [11:0] result);
localparam ADDR_W=64,DCO_T=8;
localparam OWNER_LEAVES=(DCO_T>1)?(1<<$clog2(DCO_T)):1;
function automatic [11:0] owner;
        input [ADDR_W-1:0]      a;
        input [DCO_T-1:0]       tv;
        input [DCO_T*64-1:0]    tbase;
        input [DCO_T*64-1:0]    tsize;
        input [DCO_T-1:0]       tbyp;
        input [DCO_T*6-1:0]     tlsb;
        integer k, leaf, left, right;
        reg [63:0] b, z;
        reg [63:0] bases [0:2*OWNER_LEAVES-2];
        reg [11:0] winners [0:2*OWNER_LEAVES-2];
        begin
            // Evaluate membership in parallel, then a balanced highest-base
            // tournament. Equal bases keep the left (lower table index), as
            // the original ascending scan's strict `b > best` did. Invalid
            // leaves, including padding, have an entirely zero result.
            for (k = 0; k < OWNER_LEAVES; k = k + 1) begin
                leaf = OWNER_LEAVES-1+k;
                bases[leaf] = 64'd0;
                winners[leaf] = 12'd0;
                if (k < DCO_T) begin
                    b = tbase[k*64 +: 64];
                    z = tsize[k*64 +: 64];
                    if (tv[k] && (a >= b) && ((z == 64'd0) || (a - b < z))) begin
                        bases[leaf] = b;
                        winners[leaf] = {1'b1, tbyp[k], k[3:0], tlsb[k*6 +: 6]};
                    end
                end
            end
            for (k = OWNER_LEAVES-2; k >= 0; k = k - 1) begin
                left = 2*k+1;
                right = 2*k+2;
                if (winners[right][11] &&
                    (!winners[left][11] || bases[right] > bases[left])) begin
                    bases[k] = bases[right];
                    winners[k] = winners[right];
                end else begin
                    bases[k] = bases[left];
                    winners[k] = winners[left];
                end
            end
            owner = winners[0];
        end
    endfunction
assign result=owner(a,tv,tbase,tsize,tbyp,tlsb);
endmodule
