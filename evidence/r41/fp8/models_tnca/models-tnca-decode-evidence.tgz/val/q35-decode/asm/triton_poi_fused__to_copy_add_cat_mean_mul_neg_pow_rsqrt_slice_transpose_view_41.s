    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s1, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v0, v2, v1
    v.movi       v4, #2176
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0
    v.movi       v1, #31
    v.sub        v4, v0, v3
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v4, #32
    v.and        v7, v6, v1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v1, v0, v7
    v.movi       v6, #0
    @p2 v.sel        v8, v1, v7
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v1, #0
    v.sub        v7, v6, v3
    v.cmp.lt     p2, v3, v6
    v.sub        v9, v1, v5
    v.cmp.lt     p3, v5, v1
    @p3 v.sel        v10, v9, v5
    v.movi       v9, #3
    v.movi       v11, #4
    v.and        v12, v10, v9
    v.movi       v9, #128
    v.sub        v10, v1, v12
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    @p2 v.sel        v13, v7, v3
    @p3 v.sel        v3, v10, v12
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v7, #256
    v.add        v10, v8, v4
    v.mul        v12, v5, v7
    v.movi       v7, #7
    v.add        v14, v10, v12
    v.lshr       v15, v13, v7
    v.sub        v7, v0, v4
    v.cmp.lt     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.sub        v5, v6, v15
    v.cmp.lt     p4, v4, v2
    @p2 v.sel        v13, v5, v15
    v.sub        v5, v2, v4
    v.sub        v2, v1, v11
    v.cmp.lt     p2, v11, v1
    v.sub        v1, v6, v9
    @p3 v.sel        v15, v7, v4
    .li       s1, #1132462080
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v15, [s3, v14]             // index is in elements (ISA sec 9.1)
    v.add        v14, v8, v12
    v.cmp.lt     p3, v9, v6
    v.rcp.approx v6, v7                          // ISA 8.8: <= 2**-22 relative
    @p4 v.sel        v12, v5, v4
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s4, v10]             // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v10, v15
    @p2 v.sel        v15, v2, v11
    .li       s1, #1077936128
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v15, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v14]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v9, v12
    .li       s1, #1065353216
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v14, #64
    vf.add       v15, v9, v12
    vf.cvt.bf16.f32 v9, v1
    v.mul        v1, v13, v14
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s4, v8]              // index is in elements (ISA sec 9.1)
    v.add        v14, v8, v1
    v.movi       v1, #1088
    v.mul        v8, v3, v1
    vf.cvt.bf16.f32 v1, v13
    v.add        v3, v14, v8
    vf.fms       v8, v7, v6, v4
    vf.add       v4, v1, v12
    vf.fms       v1, v6, v8, v6
    vf.neg       v8, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v1, v8, v6
    vf.mul       v6, v0, v1                      // a/y: faithful quotient
    vf.fms       v8, v6, v7, v0
    vf.fms       v0, v8, v1, v6
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v6
    vf.add       v1, v0, v5
    v.rsqrt.approx v0, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v0, v0
    vf.mul       v6, v0, v11
    vf.fms       v7, v1, v5, v2
    vf.mul       v1, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v0
    vf.mul       v0, v10, v2
    vf.mul       v1, v9, v2
    vf.mul       v2, v0, v15
    vf.mul       v0, v1, v4
    vf.neg       v1, v2
    vf.cvt.f32.bf16 v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s5, v3], v0
    @p1 v.st.scatter.h [s6, v3], v2
__rctx_next:
    exit
