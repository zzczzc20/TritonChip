#!/usr/bin/env python3
"""Exercise eviction selection, aliases and phase aging without a device."""
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT),str(ROOT/'python'),str(ROOT/'compiler/python'),str(ROOT/'tools/asm')]
import triton
from tnca.errors import BufferError
from tnca.triton_backend import driver

class Module:
 def __init__(self,path):self.path=path;self.code_size=64
class Session:
 def __init__(self):self.id=1;self.epoch=1;self.items=[]
 def load(self,path):
  if len(self.items)>=2:raise BufferError('compiled code overlaps the device heap')
  m=Module(path);self.items.append(m);return m
 def drain(self):pass
 def unload(self,module):self.items.remove(module)

class Tests(unittest.TestCase):
 def setUp(self):
  driver._loaded.clear();driver._loaded_by_artifact.clear();driver._cache_frequency.clear();driver.evicted=0
  self.sha=patch.object(driver,'_artifact_sha256',side_effect=lambda p: 'A' if p=='A-alias' else p);self.sha.start();self.addCleanup(self.sha.stop)
 def sequence(self,policy):
  with patch.dict(os.environ,{'TNCA_CODE_CACHE_POLICY':policy},clear=False):
   s=Session()
   for key in ('A','A','A','B','C'):driver._load(s,key)
   return {m.path for m in s.items}
 def test_frequency_changes_victim(self):
  self.assertEqual(self.sequence('lru'),{'B','C'})
  driver._loaded.clear();driver._loaded_by_artifact.clear();driver._cache_frequency.clear()
  self.assertEqual(self.sequence('lfu'),{'A','C'})
 def test_alias_eviction_is_safe(self):
  with patch.dict(os.environ,{'TNCA_CODE_CACHE_POLICY':'lfu'},clear=False):
   s=Session()
   for key in ('A','A-alias','B','B','B','C'):driver._load(s,key)
   self.assertEqual({m.path for m in s.items},{'B','C'})
   self.assertFalse(any(k[2] in ('A','A-alias') for k in driver._loaded))
 def test_aging_adapts_to_new_hot_artifact(self):
  with patch.dict(os.environ,{'TNCA_CODE_CACHE_POLICY':'lfu'},clear=False):
   s=Session()
   for _ in range(100):driver._load(s,'A')
   for _ in range(800):driver._load(s,'B')
   driver._load(s,'C')
   self.assertEqual({m.path for m in s.items},{'B','C'})
if __name__=='__main__':unittest.main()
