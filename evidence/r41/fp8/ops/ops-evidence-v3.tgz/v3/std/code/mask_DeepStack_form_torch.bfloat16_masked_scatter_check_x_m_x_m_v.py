# AOT ID: ['46_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/bp/cbpnyvg3zkryphixwyqkzfavrsvkrumorilhinou7zgqo2d6lonb.py
# Topologically Sorted Source Nodes: [getitem_1], Original ATen: [aten.index]
# Source node to ATen node mapping:
#   getitem_1 => full_1
# Graph fragment:
#   %full_1 : Tensor "i64[41][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([%add], 0), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   return %index_put
triton_poi_fused_index_0 = async_compile.triton('triton_poi_fused_index_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'out_ptr0': '*i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_index_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 0, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 656}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_0(out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 41
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.full([1], 0, tl.int64)
    tl.store(out_ptr0 + (x0), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/w2/cw2lvbgos4ci3yc2pvvi6wkh6jjhrzfvzrocrr7loqhmin76ikwi.py
# Topologically Sorted Source Nodes: [m, sum_1, mul, eq_1, _is_all_true, getitem_1], Original ATen: [aten.eq, aten.sum, aten.mul, aten._is_all_true, aten.index]
# Source node to ATen node mapping:
#   _is_all_true => any_1, logical_not, logical_not_1
#   eq_1 => eq_1
#   getitem_1 => cumsum_1, full, full_1, index_put, iota, sub_1, sum_2, view_5, where_1
#   m => eq
#   mul => mul
#   sum_1 => sum_1
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %cumsum_1 : Tensor "i64[128][1]tnca:0" = PlaceHolder[target=cumsum_1]
#   %index_put : Tensor "i64[41][1]tnca:0" = PlaceHolder[target=index_put]
#   %sum_1 : Tensor "i64[][]tnca:0" = PlaceHolder[target=sum_1]
#   %eq : Tensor "b8[1, 128][128, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg0_1, 7), kwargs = {})
#   %sum_1 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.default](args = (%eq,), kwargs = {})
#   %mul : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sum_1, 64), kwargs = {})
#   %eq_1 : Tensor "b8[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%mul, 2560), kwargs = {})
#   %logical_not : Tensor "b8[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq_1,), kwargs = {})
#   %any_1 : Tensor "b8[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dims](args = (%logical_not,), kwargs = {})
#   %logical_not_1 : Tensor "b8[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %view_5 : Tensor "b8[128][1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [-1]), kwargs = {})
#   %sum_2 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.default](args = (%view_5,), kwargs = {})
#   %full_1 : Tensor "i64[41][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([%add], 0), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %cumsum_1 : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cumsum.default](args = (%view_5, 0), kwargs = {})
#   %sub_1 : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%cumsum_1, 1), kwargs = {})
#   %full : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([128], %_local_scalar_dense_1), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where_1 : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view_5, %sub_1, %full), kwargs = {})
#   %iota : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (128,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %index_put : Tensor "i64[41][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%full_1, [%where_1], %iota), kwargs = {})
#   return %sum_1,%sum_2,%cumsum_1,%buf14,%logical_not_1
triton_red_fused__is_all_true_eq_index_mul_sum_1 = async_compile.triton('triton_red_fused__is_all_true_eq_index_mul_sum_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'out_ptr3': '*i64', 'out_ptr4': '*i1', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__is_all_true_eq_index_mul_sum_1', 'mutated_arg_names': ['out_ptr3'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 3, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1024}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__is_all_true_eq_index_mul_sum_1(in_ptr0, out_ptr1, out_ptr3, out_ptr4, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    _tmp5 = tl.full([R0_BLOCK], 0, tl.int64)
    tmp9 = tl.full([1], 0, tl.int64)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.full([1], 7, tl.int64)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2.to(tl.int64)
        tmp4 = tl.broadcast_to(tmp3, [R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask, tmp6, _tmp5)
        tmp7 = tmp3.to(tl.int64)
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10, = tl.associative_scan((tmp8,), 0, _triton_helper_fn_add0)
        tmp11 = triton_helpers.select_one((tmp10), rbase == (RBLOCK - 1), dim=-1, keep_dims=True)
        tmp12 = tmp9 + tmp11
        tmp13 = tmp9 + tmp10
        tmp14 = tl.where(roffset > 0, tmp13, tmp10)
        tmp9 = tl.where(roffset > 0, tmp12, tmp11)
        tmp15 = tl.full([1], 1, tl.int64)
        tmp16 = tmp14 - tmp15
        tmp17 = tl.full([1], 40, tl.int64)
        tmp18 = tl.where(tmp2, tmp16, tmp17)
        tmp19 = (tl.full([R0_BLOCK], 41, tl.int32)).to(tl.int32)
        tmp20 = tmp18 + tmp19
        tmp21 = tmp18 < 0
        tmp22 = tl.where(tmp21, tmp20, tmp18)
        tl.device_assert(((0 <= tmp22) & (tmp22 < 41)) | ~(r0_mask), "index out of bounds: 0 <= tmp22 < 41")
        tmp24 = (r0_0).to(tl.int64)
        tmp25 = (tmp24).to(tl.int64)
        tl.store(out_ptr3 + (tl.broadcast_to(tmp22, [R0_BLOCK])), tmp25, r0_mask)
    tmp5 = triton_helpers.promote_to_tensor(tl.sum(_tmp5, 0))
    tl.store(out_ptr1 + (tl.full([1], 0, tl.int32)), tmp5, None)
    tmp26 = tl.full([1], 64, tl.int64)
    tmp27 = tmp5 * tmp26
    tmp28 = tl.full([1], 2560, tl.int64)
    tmp29 = tmp27 == tmp28
    tmp30 = tmp29 == 0
    tmp31 = tmp30 == 0
    tl.store(out_ptr4 + (tl.full([1], 0, tl.int32)), tmp31, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/5l/c5lbdpyvggjetrd5ru6eanmystopxfxywhgv6ltqcyldui5rknm6.py
# Topologically Sorted Source Nodes: [m, getitem, expand_as, h, setitem], Original ATen: [aten.eq, aten.unsqueeze, aten.expand, aten.masked_scatter, aten.index_put]
# Source node to ATen node mapping:
#   expand_as => expand
#   getitem => unsqueeze
#   h => clone, cumsum, view
#   m => eq
#   setitem => clone_3, cumsum_2, expand_1, view_7, view_8
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %eq : Tensor "b8[1, 128][128, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg0_1, 7), kwargs = {})
#   %unsqueeze : Tensor "b8[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%eq, 2), kwargs = {})
#   %expand : Tensor "b8[1, 128, 64][128, 1, 0]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 128, 64]), kwargs = {})
#   %clone : Tensor "b8[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "b8[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [8192]), kwargs = {})
#   %cumsum : Tensor "i64[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cumsum.default](args = (%view, 0), kwargs = {})
#   %view_7 : Tensor "b8[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 128, 1]), kwargs = {})
#   %expand_1 : Tensor "b8[1, 128, 64][128, 1, 0]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.expand.default](args = (%view_7, [1, 128, 64]), kwargs = {})
#   %clone_3 : Tensor "b8[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_8 : Tensor "b8[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_3, [8192]), kwargs = {})
#   %cumsum_2 : Tensor "i64[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cumsum.default](args = (%view_8, 0), kwargs = {})
#   return %cumsum,%cumsum_2
triton_red_fused_eq_expand_index_put_masked_scatter_unsqueeze_2 = async_compile.triton('triton_red_fused_eq_expand_index_put_masked_scatter_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 8192},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_eq_expand_index_put_masked_scatter_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'r0_': 263168}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_eq_expand_index_put_masked_scatter_unsqueeze_2(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 8192
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp6 = tl.full([1], 0, tl.int64)
    tmp12 = tl.full([1], 0, tl.int64)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0 // 64), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.full([1], 7, tl.int64)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2.to(tl.int64)
        tmp4 = tmp3.to(tl.int64)
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7, = tl.associative_scan((tmp5,), 0, _triton_helper_fn_add0)
        tmp8 = triton_helpers.select_one((tmp7), rbase == (RBLOCK - 1), dim=-1, keep_dims=True)
        tmp9 = tmp6 + tmp8
        tmp10 = tmp6 + tmp7
        tmp11 = tl.where(roffset > 0, tmp10, tmp7)
        tmp6 = tl.where(roffset > 0, tmp9, tmp8)
        tmp13 = tmp12 + tmp8
        tmp14 = tmp12 + tmp7
        tmp15 = tl.where(roffset > 0, tmp14, tmp7)
        tmp12 = tl.where(roffset > 0, tmp13, tmp8)
        tl.store(out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp11, r0_mask)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp15, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/6a/c6ak37z3rqpru6g6axvy2f4ytf343ej74zimtombgnr7adpuj6ed.py
# Topologically Sorted Source Nodes: [m, h, getitem, expand_as, getitem_1, add, setitem], Original ATen: [aten.eq, aten.masked_scatter, aten.unsqueeze, aten.expand, aten.index, aten.add, aten.index_put]
# Source node to ATen node mapping:
#   add => add_4
#   expand_as => expand
#   getitem => unsqueeze
#   getitem_1 => index, slice_1, view_6
#   h => _unsafe_masked_index, clone_1, sub, view_1, view_2, view_3, view_4, where
#   m => eq
#   setitem => _unsafe_masked_index_1, clone_4, expand_1, sub_3, view_10, view_11, view_7, view_9, where_2
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %cumsum_2 : Tensor "i64[8192][1]tnca:0" = PlaceHolder[target=cumsum_2]
#   %buf14 : Tensor "i64[41][1]tnca:0" = PlaceHolder[target=buf14]
#   %cumsum : Tensor "i64[8192][1]tnca:0" = PlaceHolder[target=cumsum]
#   %arg2_1 : Tensor "bf16[40, 64][64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg1_1 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg3_1 : Tensor "bf16[40, 64][64, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %eq : Tensor "b8[1, 128][128, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg0_1, 7), kwargs = {})
#   %view_3 : Tensor "bf16[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg2_1, [2560]), kwargs = {})
#   %unsqueeze : Tensor "b8[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%eq, 2), kwargs = {})
#   %expand : Tensor "b8[1, 128, 64][128, 1, 0]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 128, 64]), kwargs = {})
#   %clone_1 : Tensor "b8[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "b8[8192][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [8192]), kwargs = {})
#   %sub : Tensor "i64[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%cumsum, 1), kwargs = {})
#   %_unsafe_masked_index : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten._unsafe_masked_index.default](args = (%view_3, %view_2, [%sub], 0), kwargs = {})
#   %view_1 : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg1_1, [8192]), kwargs = {})
#   %where : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view_2, %_unsafe_masked_index, %view_1), kwargs = {})
#   %view_4 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%where, [1, 128, 64]), kwargs = {})
#   %view_6 : Tensor "bf16[128, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [128, 64]), kwargs = {})
#   %slice_1 : Tensor "i64[40][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%index_put, 0, 0, %_local_scalar_dense_1), kwargs = {})
#   %index : Tensor "bf16[40, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%view_6, [%slice_1]), kwargs = {})
#   %add_4 : Tensor "bf16[40, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%index, %arg3_1), kwargs = {})
#   %view_11 : Tensor "bf16[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [2560]), kwargs = {})
#   %view_7 : Tensor "b8[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 128, 1]), kwargs = {})
#   %expand_1 : Tensor "b8[1, 128, 64][128, 1, 0]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.expand.default](args = (%view_7, [1, 128, 64]), kwargs = {})
#   %clone_4 : Tensor "b8[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "b8[8192][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [8192]), kwargs = {})
#   %sub_3 : Tensor "i64[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%cumsum_2, 1), kwargs = {})
#   %_unsafe_masked_index_1 : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten._unsafe_masked_index.default](args = (%view_11, %view_10, [%sub_3], 0), kwargs = {})
#   %view_9 : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [8192]), kwargs = {})
#   %where_2 : Tensor "bf16[8192][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view_10, %_unsafe_masked_index_1, %view_9), kwargs = {})
#   return %where_2
triton_poi_fused_add_eq_expand_index_index_put_masked_scatter_unsqueeze_3 = async_compile.triton('triton_poi_fused_add_eq_expand_index_index_put_masked_scatter_unsqueeze_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'in_ptr3': '*i64', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'in_ptr6': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_eq_expand_index_index_put_masked_scatter_unsqueeze_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 181248}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_eq_expand_index_index_put_masked_scatter_unsqueeze_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 // 64), None, eviction_policy='evict_last')
    tmp29 = tl.load(in_ptr5 + (x0), None).to(tl.float32)
    tmp1 = tl.full([1], 7, tl.int64)
    tmp2 = tmp0 == tmp1
    tmp3 = tl.load(in_ptr1 + (x0), tmp2, other=0.0)
    tmp4 = tl.full([1], 1, tl.int64)
    tmp5 = tmp3 - tmp4
    tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(((tmp5 // 64) % 40), [XBLOCK])), tmp2, eviction_policy='evict_last', other=0.0)
    tmp7 = (tl.full([XBLOCK], 128, tl.int32)).to(tl.int32)
    tmp8 = tmp6 + tmp7
    tmp9 = tmp6 < 0
    tmp10 = tl.where(tmp9, tmp8, tmp6)
    tl.device_assert(((0 <= tl.broadcast_to(tmp10, [XBLOCK])) & (tl.broadcast_to(tmp10, [XBLOCK]) < 128)) | ~(tmp2), "index out of bounds: 0 <= tl.broadcast_to(tmp10, [XBLOCK]) < 128")
    tmp12 = tl.load(in_ptr0 + (tl.broadcast_to((((64*tmp10 + ((tmp5 % 64))) // 64) % 128), [XBLOCK])), tmp2, eviction_policy='evict_last', other=0.0)
    tmp13 = tl.full([1], 7, tl.int64)
    tmp14 = tmp12 == tmp13
    tmp15 = tmp14 & tmp2
    tmp16 = tl.load(in_ptr3 + (tl.broadcast_to(64*tmp10 + ((tmp5 % 64)), [XBLOCK])), tmp15, eviction_policy='evict_last', other=0.0)
    tmp17 = tl.full([1], 1, tl.int64)
    tmp18 = tmp16 - tmp17
    tmp19 = tl.load(in_ptr4 + (tl.broadcast_to(tmp18, [XBLOCK])), tmp15, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp20 = tl.load(in_ptr5 + (tl.broadcast_to(64*tmp10 + ((tmp5 % 64)), [XBLOCK])), tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp21 = tl.where(tmp14, tmp19, tmp20)
    tmp22 = tl.load(in_ptr6 + (tl.broadcast_to((tmp5 % 2560), [XBLOCK])), tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp23 = tmp21 + tmp22
    tmp24 = tl.full(tmp23.shape, 0, tmp23.dtype)
    tmp25 = tl.where(tmp2, tmp23, tmp24)
    tmp26 = tl.load(in_ptr3 + (x0), tmp2, other=0.0)
    tmp27 = tmp26 - tmp4
    tmp28 = tl.load(in_ptr4 + (tl.broadcast_to(tmp27, [XBLOCK])), tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp30 = tl.where(tmp2, tmp28, tmp29)
    tmp31 = tl.where(tmp2, tmp25, tmp30)
    tl.store(out_ptr0 + (x0), tmp31, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        buf13 = empty_strided((41, ), (1, ), device='tnca', dtype=torch.int64)
        # Topologically Sorted Source Nodes: [getitem_1], Original ATen: [aten.index]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_0.run(buf13, 41, stream=raw_stream0)
        assert_size_stride(arg0_1, (1, 128), (128, 1), 'input')
        buf7 = empty_strided((), (), device='tnca', dtype=torch.int64)
        buf1 = empty_strided((), (), device='tnca', dtype=torch.bool)
        # Topologically Sorted Source Nodes: [m, sum_1, mul, eq_1, _is_all_true, getitem_1], Original ATen: [aten.eq, aten.sum, aten.mul, aten._is_all_true, aten.index]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__is_all_true_eq_index_mul_sum_1.run(arg0_1, buf7, buf13, buf1, 1, 128, stream=raw_stream0)
        u0 = 1 if buf1.item() else 0
        buf2 = None
        del buf1
        if not (u0 >= 1):
            raise RuntimeError('u0 >= 1')
        buf3 = None
        if not (u0 <= 1):
            raise RuntimeError('u0 <= 1')
        buf4 = None
        if not (u0 == 1):
            raise RuntimeError('Eq(u0, 1)')
        buf5 = None
        buf6 = empty_strided((8192, ), (1, ), device='tnca', dtype=torch.int64)
        buf15 = empty_strided((8192, ), (1, ), device='tnca', dtype=torch.int64)
        # Topologically Sorted Source Nodes: [m, getitem, expand_as, h, setitem], Original ATen: [aten.eq, aten.unsqueeze, aten.expand, aten.masked_scatter, aten.index_put]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_eq_expand_index_put_masked_scatter_unsqueeze_2.run(arg0_1, buf6, buf15, 1, 8192, stream=raw_stream0)
        u1 = buf7.item()
        buf8 = None
        del buf7
        if not (u1 >= 40):
            raise RuntimeError('u1 >= 40')
        buf9 = None
        if not (u1 <= 40):
            raise RuntimeError('u1 <= 40')
        buf10 = None
        if not (u1 == 40):
            raise RuntimeError('Eq(u1, 40)')
        buf11 = None
        assert_size_stride_grouped((arg2_1, arg1_1, arg3_1), ((40, 64), (1, 128, 64), (40, 64)), ((64, 1), (8192, 64, 1), (64, 1)), 'input')
        buf16 = empty_strided((8192, ), (1, ), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [m, h, getitem, expand_as, getitem_1, add, setitem], Original ATen: [aten.eq, aten.masked_scatter, aten.unsqueeze, aten.expand, aten.index, aten.add, aten.index_put]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_eq_expand_index_index_put_masked_scatter_unsqueeze_3.run(arg0_1, buf15, buf13, buf6, arg2_1, arg1_1, arg3_1, buf16, 8192, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        del arg3_1
        return (reinterpret_tensor(buf16, (1, 128, 64), (8192, 64, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 128), (128, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((1, 128, 64), (8192, 64, 1), device='tnca:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((40, 64), (64, 1), device='tnca:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((40, 64), (64, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
