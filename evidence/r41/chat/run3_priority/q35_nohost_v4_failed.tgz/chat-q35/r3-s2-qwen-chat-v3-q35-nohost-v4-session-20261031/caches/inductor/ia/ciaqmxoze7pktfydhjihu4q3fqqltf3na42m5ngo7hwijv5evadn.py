
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2560*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 248320), "index out of bounds: 0 <= tmp12 < 248320")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 2560*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 2560.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 1e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tl.full([1], 1.0, tl.float32)
        tmp27 = tmp25 + tmp26
        tmp28 = tmp23 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
