    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.cmp.lt     p3, v4, v1
    @p3 v.sel        v9, v3, v4
    @p1 v.sel        v3, v5, v8
    v.movi       v4, #63
    v.movi       v5, #31
    v.sub        v8, v6, v3
    v.cmp.lt     p1, v3, v6
    v.and        v10, v9, v4
    @p1 v.sel        v4, v8, v3
    s.rdspecial  s2, arg_base
    v.movi       v3, #64
    v.and        v8, v4, v5
    v.sub        v4, v1, v10
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v5, v6, v8
    @p3 v.sel        v9, v4, v10
    v.movi       v4, #32
    @p1 v.sel        v10, v5, v8
    v.movi       v5, #2048
    v.sub        v8, v1, v3
    v.cmp.lt     p1, v3, v1
    v.sub        v1, v2, v3
    v.cmp.lt     p3, v3, v2
    v.sub        v2, v6, v4
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p1 v.sel        v11, v8, v3
    v.movi       v8, #11
    v.cmp.lt     p1, v4, v6
    s.movz       s1, #32768
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v11, v7, v8
    v.sub        v7, v0, v5
    v.mul        v8, v10, v6
    v.sub        v6, v0, v11
    @p3 v.sel        v10, v1, v3
    s.add        s1, s4, s2                      // &out_ptr0[...]
    @p2 v.sel        v1, v6, v11
    v.cmp.lt     p2, v5, v0
    @p1 v.sel        v0, v2, v4
    v.mul        v0, v1, v3
    @p2 v.sel        v1, v7, v5
    v.add        v1, v9, v0
    v.add        v0, v1, v8
    v.ld.gather.w v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
