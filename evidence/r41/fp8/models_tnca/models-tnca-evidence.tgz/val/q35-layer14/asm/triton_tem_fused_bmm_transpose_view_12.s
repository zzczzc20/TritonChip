    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #4
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #2
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #4
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s6, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s6, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #2
    s.movz       s15, #0
    s.muli       s16, s3, #4
    s.sub        s3, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.xor        s15, s12, s3
    s.sub        s12, s14, s16
    s.movz       s14, #0
    s.xor        s16, s12, s13
    s.xor        s12, s6, s8
    s.sub        s6, s16, s13
    s.sub        s13, s14, s9
    s.cmp.lt     s9, s6, s5
    s.sub        s5, s15, s3
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.xor        s9, s6, s14
    s.movz       s6, #1
    s.sub        s15, s12, s8
    s.xor        s8, s1, s13
    s.sub        s1, s9, s14
    s.movz       s9, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s5, s6
    s.add        s6, s10, s15
    s.sub        s10, s8, s13
    s.addi       s8, s9, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s12, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s10, s8, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s5
    s.shl        s16, s10, s4
    s.sub        s10, s9, s13
    s.subi       s9, s4, #1
    s.and        s13, s5, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s12, s17
    s.mov        s8, s10
    s.mov        s12, s13
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s4, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s3
    s.movz       s3, #16
    s.xor        s4, s12, s1
    s.rdspecial  s5, pid.z
    s.sub        s8, s4, s1
    s.rdspecial  s1, npid.y
    s.mul        s4, s6, s3
    s.mul        s9, s8, s3
    s.mul        s10, s5, s1
    s.rdspecial  s1, pid.y
    s.movz       s5, #63
    s.andi       s12, s4, #63
    s.andi       s13, s9, #63
    s.add        s14, s1, s10
    s.movz       s1, #8192
    s.min.s      s10, s14, s5
    s.muli       s5, s12, #128                   // a runtime tile origin, x128
    s.mul        s15, s10, s1
    s.rdspecial  s1, role_id
    s.movz       s10, #6144
    s.movz       s16, #0
    s.rdspecial  s17, arg_base
    s.mul        s18, s1, s10
    s.add        s1, s16, s5                     // the tile origin
    s.ld.d       s5, [s17, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s10, s1, s15                    // the tile origin
    s.movz       s1, #0
    s.add        s16, s5, s18                    // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s5, s16, #0
    v.splat      v1, s10
    v.splat      v2, s6
    v.splat      v3, s1
    s.addi       s6, s10, #128
    v.splat      v4, s8
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v0, v1
    s.addi       s8, s5, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s6
    v.splat      v2, s4
    v.add        v3, v0, v1
    v.cmp.ge     p1, v4, v5
    s.addi       s6, s10, #256
    v.splat      v1, s9
    v.splat      v4, s6
    s.addi       s6, s5, #128
    v.add        v5, v0, v4
    v.add        v4, v2, v6
    s.addi       s17, s10, #384
    v.splat      v2, s12
    s.addi       s12, s5, #192
    v.add        v4, v1, v6
    v.splat      v1, s17
    v.iota       v4                              // arange(0, VLEN)
    s.addi       s17, s10, #512
    v.add        v6, v0, v1
    s.addi       s18, s5, #256
    v.add        v1, v2, v4
    v.splat      v1, s17
    v.splat      v2, s13
    v.add        v4, v0, v1
    s.movz       s17, #128
    s.addi       s19, s1, #0
    v.st.w       [s5, #0], v7
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s1, s5, #320
    v.add        v7, v2, v1
    s.addi       s20, s10, #640
    v.splat      v1, s20
    s.addi       s20, s10, #768
    v.add        v2, v0, v1
    v.splat      v1, s20
    s.addi       s20, s10, #896
    v.add        v7, v0, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s10, #1024
    v.splat      v1, s20
    s.addi       s20, s10, #1152
    v.add        v3, v0, v1
    v.st.w       [s6, #0], v5
    s.addi       s6, s10, #1280
    v.splat      v1, s8
    s.addi       s8, s10, #1408
    v.add        v5, v0, v1
    v.st.w       [s12, #0], v6
    s.addi       s12, s10, #1536
    v.splat      v1, s20
    s.addi       s20, s10, #1664
    v.add        v6, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s10, #1792
    s.addi       s21, s10, #1920
    v.splat      v1, s6
    s.addi       s6, s5, #384
    v.add        v4, v0, v1
    v.st.w       [s1, #0], v2
    v.splat      v1, s8
    s.addi       s1, s16, #1024
    s.addi       s8, s5, #448
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v7
    s.muli       s6, s13, #128                   // a runtime tile origin, x128
    s.movz       s10, #0
    v.iota       v1                              // arange(0, VLEN)
    s.add        s13, s10, s6                    // the tile origin
    s.addi       s6, s5, #512
    s.add        s10, s13, s15                   // the tile origin
    s.addi       s13, s5, #576
    v.st.w       [s8, #0], v3
    s.movz       s8, #128
    v.splat      v3, s12
    s.addi       s12, s5, #640
    v.add        v7, v0, v3
    v.st.w       [s6, #0], v5
    v.splat      v3, s8
    s.addi       s6, s10, #1
    v.mul        v5, v1, v3
    v.splat      v1, s20
    s.addi       s8, s5, #704
    s.addi       s15, s5, #768
    v.add        v3, v0, v1
    v.st.w       [s13, #0], v6
    s.addi       s13, s10, #2
    v.splat      v1, s18
    s.addi       s18, s5, #832
    v.add        v6, v0, v1
    v.st.w       [s12, #0], v4
    s.addi       s12, s10, #3
    v.splat      v1, s21
    s.addi       s20, s5, #896
    s.addi       s21, s5, #960
    v.add        v4, v0, v1
    v.st.w       [s8, #0], v2
    s.addi       s5, s10, #4
    v.splat      v1, s10
    v.add        v2, v5, v1
    v.st.w       [s15, #0], v7
    s.addi       s8, s10, #5
    v.splat      v1, s6
    s.addi       s6, s1, #64
    v.add        v7, v5, v1
    v.st.w       [s18, #0], v3
    s.addi       s15, s10, #6
    v.splat      v1, s13
    s.addi       s13, s1, #128
    v.add        v3, v5, v1
    v.st.w       [s20, #0], v6
    s.addi       s18, s10, #7
    v.splat      v1, s12
    s.addi       s12, s1, #192
    v.add        v6, v5, v1
    v.st.w       [s21, #0], v4
    v.splat      v1, s5
    s.addi       s5, s1, #256
    v.add        v4, v5, v1
    s.addi       s20, s1, #320
    fence.acq_rel.device
    v.st.w       [s1, #0], v2
    v.splat      v1, s8
    s.addi       s8, s10, #8
    v.add        v2, v5, v1
    v.st.w       [s6, #0], v7
    s.addi       s6, s10, #9
    v.splat      v1, s15
    s.addi       s15, s10, #10
    v.add        v7, v5, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s10, #11
    v.splat      v1, s18
    s.addi       s18, s10, #12
    v.add        v3, v5, v1
    v.st.w       [s12, #0], v6
    s.addi       s12, s10, #13
    v.splat      v1, s8
    s.addi       s8, s10, #14
    v.add        v6, v5, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s10, #15
    v.splat      v1, s6
    s.addi       s6, s1, #384
    s.addi       s10, s1, #448
    v.add        v4, v5, v1
    v.st.w       [s20, #0], v2
    v.splat      v1, s15
    s.addi       s15, s1, #512
    s.addi       s20, s1, #576
    v.add        v2, v5, v1
    v.st.w       [s6, #0], v7
    v.splat      v1, s13
    s.addi       s6, s1, #640
    s.addi       s13, s1, #704
    v.add        v7, v5, v1
    v.st.w       [s10, #0], v3
    v.splat      v1, s18
    s.addi       s10, s1, #768
    v.add        v3, v5, v1
    s.addi       s18, s1, #832
    v.st.w       [s15, #0], v6
    v.splat      v1, s12
    s.addi       s12, s1, #896
    v.add        v6, v5, v1
    s.addi       s15, s1, #960
    v.st.w       [s20, #0], v4
    v.splat      v1, s8
    v.add        v4, v5, v1
    v.st.w       [s6, #0], v2
    v.splat      v1, s5
    v.add        v2, v5, v1
    v.st.w       [s13, #0], v7
    v.st.w       [s10, #0], v3
    v.st.w       [s18, #0], v6
    v.st.w       [s12, #0], v4
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s19, s17
    br.nz        s1, endfor_6
    s.addi       s1, s16, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #64
    s.movz       s6, #1
    s.addi       s8, s16, #128
    s.movz       s10, #2
    s.addi       s12, s16, #192
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s5, v2
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.addi       s5, s16, #256
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #4
    s.addi       s8, s16, #320
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s10, #5
    s.addi       s12, s16, #384
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #6
    s.addi       s5, s16, #448
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #7
    s.addi       s8, s16, #512
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s10, #8
    s.addi       s12, s16, #576
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #9
    s.addi       s5, s16, #640
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #10
    s.addi       s8, s16, #704
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s10, #11
    s.addi       s12, s16, #768
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #12
    s.addi       s5, s16, #832
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #13
    s.addi       s8, s16, #896
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s10, #14
    s.addi       s12, s16, #960
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #15
    s.addi       s5, s16, #1024
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.addi       s8, s16, #1088
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s10, #1
    s.addi       s12, s16, #1152
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s13, #2
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.addi       s1, s16, #1216
    s.movz       s5, #3
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v2
    v.ld.w       v1, [s8, #0]
    s.addi       s6, s16, #1280
    s.movz       s8, #4
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v2
    v.ld.w       v1, [s12, #0]
    s.addi       s10, s16, #1344
    s.movz       s12, #5
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #1408
    s.movz       s13, #6
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s5, v2
    v.ld.w       v1, [s6, #0]
    s.addi       s5, s16, #1472
    s.movz       s6, #7
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v2
    v.ld.w       v1, [s10, #0]
    s.addi       s8, s16, #1536
    s.movz       s10, #8
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #1600
    s.movz       s12, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #1664
    s.movz       s13, #10
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v3
    v.ld.w       v1, [s8, #0]
    s.addi       s6, s16, #1728
    s.movz       s8, #11
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #1792
    s.movz       s10, #12
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #1856
    s.movz       s12, #13
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #1920
    s.movz       s13, #14
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #1984
    s.movz       s8, #15
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v3
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    s.movz       s10, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    s.movz       s12, #2
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.movz       s13, #4
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s15, #5
    a.vwrite     a2, s8, v3
    a.vread      v1, a1, s5
    a.vread      v3, a2, s10
    v.extract    s5, v1, #0
    v.splat      v4, s5
    v.extract    s5, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s5
    a.vread      v4, a2, s6
    v.extract    s5, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s5
    a.vread      v4, a2, s12
    v.extract    s5, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    v.extract    s1, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s13
    v.extract    s1, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s1
    a.vread      v4, a2, s15
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s1
    a.vread      v3, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s1
    a.vread      v3, a2, s10
    s.movz       s1, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #3
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #4
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #5
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #6
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #7
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #8
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #10
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #11
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #12
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #13
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #14
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v2, a2, s5
    s.addi       s5, s16, #0
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s3
    s.addi       s6, s16, #2048
    s.addi       s8, s16, #64
    a.vwrite     a3, s1, v3
    v.ld.w       v2, [s5, #0]
    s.addi       s1, s6, #64
    s.addi       s5, s16, #128
    s.addi       s10, s6, #128
    s.addi       s12, s16, #192
    s.addi       s13, s6, #192
    s.addi       s15, s16, #256
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s6, #256
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s16, #320
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #320
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s16, #384
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s6, #384
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #448
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s6, #448
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s16, #512
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s6, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s16, #576
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s6, #576
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s16, #640
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s6, #640
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #704
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s6, #704
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s16, #768
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #768
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s16, #832
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s6, #832
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #896
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s6, #896
    s.addi       s18, s6, #960
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s6, s16, #960
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s16, #1024
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s16, #3072
    v.ld.w       v2, [s10, #0]
    s.addi       s8, s16, #1088
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s10, s5, #64
    v.ld.w       v2, [s13, #0]
    s.addi       s12, s16, #1152
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s13, s5, #128
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s16, #1216
    v.add        v3, v2, v1
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.addi       s15, s5, #192
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s16, #1280
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s5, #256
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s16, #1344
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s5, #320
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #1408
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s5, #384
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #1472
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s5, #448
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s16, #1536
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s5, #512
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s16, #1600
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s5, #576
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    s.addi       s6, s16, #1664
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s5, #640
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s16, #1728
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s5, #704
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s16, #1792
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s5, #768
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #1856
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s5, #832
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #1920
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s5, #896
    s.addi       s18, s5, #960
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s5, s16, #1984
    v.ld.w       v2, [s10, #0]
    s.addi       s8, s16, #2048
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s10, s16, #4096
    v.ld.w       v2, [s13, #0]
    s.addi       s12, s16, #2112
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    s.addi       s6, s10, #64
    v.ld.w       v2, [s15, #0]
    s.addi       s13, s16, #2176
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s10, #128
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s16, #2240
    v.add        v3, v2, v1
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.addi       s15, s10, #192
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s16, #2304
    v.st.w       [s10, #0], v1
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #256
    v.st.w       [s6, #0], v1
    s.addi       s6, s16, #2368
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #320
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #2432
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #384
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #2496
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #448
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #2560
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #512
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #2624
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s10, #576
    v.st.w       [s5, #0], v1
    s.addi       s5, s16, #2688
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #640
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #2752
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #704
    v.st.w       [s6, #0], v1
    s.addi       s6, s16, #2816
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #768
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #2880
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #832
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #2944
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #896
    s.addi       s18, s10, #960
    v.st.w       [s12, #0], v1
    s.addi       s10, s16, #3008
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #3072
    v.st.w       [s13, #0], v1
    s.addi       s12, s16, #5120
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s16, #3136
    v.st.w       [s5, #0], v1
    s.addi       s5, s12, #64
    v.ld.w       v1, [s15, #0]
    s.addi       s13, s16, #3200
    v.st.w       [s8, #0], v1
    s.addi       s8, s12, #128
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #3264
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    s.addi       s15, s12, #192
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #3328
    v.st.w       [s12, #0], v1
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s12, #256
    v.st.w       [s5, #0], v1
    s.addi       s5, s16, #3392
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s12, #320
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #3456
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s12, #384
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #3520
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s12, #448
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #3584
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #512
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #3648
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s12, #576
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #3712
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #640
    v.st.w       [s6, #0], v1
    s.addi       s6, s16, #3776
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s12, #704
    v.st.w       [s5, #0], v1
    s.addi       s5, s16, #3840
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s12, #768
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #3904
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s12, #832
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #3968
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s12, #896
    s.addi       s18, s12, #960
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #4032
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    v.st.w       [s13, #0], v1
    s.movz       s12, #0
    v.ld.w       v1, [s8, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.st.w       [s10, #0], v1
    s.movz       s10, #1
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #1
    v.st.w       [s6, #0], v1
    s.movz       s6, #1
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #2
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s5
    a.vread      v2, a3, s12
    s.movz       s5, #2
    vf.add       v3, v1, v2
    s.movz       s12, #2
    s.movz       s15, #3
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s10
    a.vread      v2, a3, s13
    s.movz       s8, #3
    vf.add       v3, v1, v2
    s.movz       s10, #3
    s.movz       s13, #4
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s1
    a.vread      v2, a3, s5
    s.movz       s1, #4
    vf.add       v3, v1, v2
    s.movz       s5, #4
    s.movz       s6, #5
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s8
    s.movz       s8, #5
    vf.add       v3, v1, v2
    s.movz       s12, #5
    s.movz       s15, #6
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s1
    s.movz       s1, #6
    vf.add       v3, v1, v2
    s.movz       s10, #6
    s.movz       s13, #7
    a.vwrite     a4, s5, v3
    a.vread      v1, a0, s6
    a.vread      v2, a3, s8
    s.movz       s5, #7
    vf.add       v3, v1, v2
    s.movz       s6, #7
    s.movz       s8, #8
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s1
    s.movz       s1, #8
    vf.add       v3, v1, v2
    s.movz       s12, #8
    s.movz       s15, #9
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s5
    s.movz       s5, #9
    vf.add       v3, v1, v2
    s.movz       s10, #9
    s.movz       s13, #10
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s1
    s.movz       s1, #10
    vf.add       v3, v1, v2
    s.movz       s6, #10
    s.movz       s8, #11
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s5
    s.movz       s5, #11
    vf.add       v3, v1, v2
    s.movz       s12, #11
    s.movz       s15, #12
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s1
    s.movz       s1, #12
    vf.add       v3, v1, v2
    s.movz       s10, #12
    s.movz       s13, #13
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s5
    s.movz       s5, #13
    vf.add       v3, v1, v2
    s.movz       s6, #13
    s.movz       s8, #14
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s1
    s.movz       s1, #14
    vf.add       v3, v1, v2
    s.movz       s12, #14
    s.movz       s15, #15
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s5
    s.movz       s5, #15
    vf.add       v3, v1, v2
    s.movz       s10, #15
    s.addi       s13, s16, #4096
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s1
    s.addi       s1, s16, #0
    vf.add       v3, v1, v2
    s.addi       s6, s16, #4160
    s.addi       s8, s16, #64
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s5
    s.addi       s5, s16, #4224
    vf.add       v3, v1, v2
    s.addi       s12, s16, #128
    s.addi       s15, s16, #4288
    a.vwrite     a4, s10, v3
    v.ld.w       v1, [s13, #0]
    s.addi       s10, s16, #192
    s.addi       s13, s16, #4352
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #256
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #4416
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #4480
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #4544
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #448
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #4608
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #512
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #4672
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #4736
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #4800
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #704
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #4864
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #4928
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #4992
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #896
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #5056
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #960
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #5120
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #1024
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #5184
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #1088
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #5248
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #1152
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #5312
    v.st.w       [s10, #0], v1
    fence.acq_rel.device
    s.addi       s10, s16, #1216
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #5376
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #1280
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #5440
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #1344
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #5504
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #1408
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #5568
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #1472
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #5632
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #1536
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #5696
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #1600
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #5760
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #1664
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #5824
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #1728
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #5888
    v.st.w       [s1, #0], v1
    s.addi       s1, s16, #1792
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #5952
    v.st.w       [s8, #0], v1
    s.addi       s8, s16, #1856
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #6016
    v.st.w       [s12, #0], v1
    s.addi       s12, s16, #1920
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #6080
    s.addi       s18, s16, #1984
    v.st.w       [s10, #0], v1
    s.movz       s10, #0
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #0
    v.st.w       [s1, #0], v1
    s.movz       s1, #1
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    v.st.w       [s8, #0], v1
    s.movz       s8, #2
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #2
    v.st.w       [s12, #0], v1
    s.movz       s12, #3
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #3
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s10
    s.movz       s10, #4
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s1
    s.movz       s1, #4
    a.vwrite     a0, s6, v1
    a.vread      v1, a4, s8
    s.movz       s6, #5
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s12
    s.movz       s5, #5
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s10
    s.movz       s8, #6
    a.vwrite     a0, s1, v1
    a.vread      v1, a4, s6
    s.movz       s1, #6
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s8
    s.movz       s5, #7
    a.vwrite     a0, s1, v1
    s.movz       s1, #7
    a.vread      v1, a4, s5
    s.movz       s5, #8
    a.vwrite     a0, s1, v1
    s.movz       s1, #8
    a.vread      v1, a4, s5
    s.movz       s5, #9
    a.vwrite     a0, s1, v1
    s.movz       s1, #9
    a.vread      v1, a4, s5
    s.movz       s5, #10
    a.vwrite     a0, s1, v1
    s.movz       s1, #10
    a.vread      v1, a4, s5
    s.movz       s5, #11
    a.vwrite     a0, s1, v1
    s.movz       s1, #11
    a.vread      v1, a4, s5
    s.movz       s5, #12
    a.vwrite     a0, s1, v1
    s.movz       s1, #12
    a.vread      v1, a4, s5
    s.movz       s5, #13
    a.vwrite     a0, s1, v1
    s.movz       s1, #13
    a.vread      v1, a4, s5
    s.movz       s5, #14
    a.vwrite     a0, s1, v1
    s.movz       s1, #14
    a.vread      v1, a4, s5
    s.movz       s5, #15
    a.vwrite     a0, s1, v1
    s.movz       s1, #15
    a.vread      v1, a4, s5
    s.add        s5, s19, s3
    s.movz       s6, #1
    a.vwrite     a0, s1, v1
    s.mov        s19, s5
    br.nz        s6, for_5
endfor_6:
    s.movz       s1, #4096
    s.movz       s2, #0
    s.mul        s3, s14, s1
    s.muli       s1, s9, #4                      // a runtime tile origin, x4
    s.movz       s5, #0
    s.add        s6, s2, s9                      // the tile origin
    s.movz       s2, #64
    s.muli       s8, s4, #256                    // a runtime tile origin, x256
    s.add        s9, s5, s4                      // the tile origin
    v.splat      v1, s6
    s.muli       s4, s3, #4                      // a runtime tile origin, x4
    v.splat      v2, s9
    v.splat      v3, s2
    v.add        v4, v0, v1
    v.splat      v0, s2
    s.addi       s3, s9, #1
    s.add        s5, s7, s1                      // the tile origin
    v.splat      v1, s14
    v.splat      v5, s2
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s3
    s.addi       s1, s9, #2
    s.add        s2, s5, s8                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s1
    s.addi       s1, s9, #3
    s.add        s5, s2, s4                      // the tile origin
    a.vread      v1, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #1
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s9, #4
    @p5 v.st.w       [s5, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s2
    s.addi       s2, s5, #256                    // row 1
    p.and        p5, p3, p1
    s.movz       s3, #2
    p.and        p3, p4, p2
    v.splat      v1, s1
    s.addi       s1, s9, #5
    s.addi       s4, s5, #512                    // row 2
    @p5 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #3
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s9, #6
    s.addi       s3, s5, #768                    // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s4, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s2
    s.movz       s2, #4
    p.and        p5, p3, p2
    v.splat      v1, s1
    s.addi       s1, s9, #7
    s.addi       s4, s5, #1024                   // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    @p4 v.st.w       [s3, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s2
    p.and        p5, p4, p2
    v.splat      v2, s1
    s.addi       s1, s9, #8
    s.addi       s2, s5, #1280                   // row 5
    p.and        p4, p5, p1
    s.movz       s3, #6
    v.splat      v4, s1
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s9, #9
    s.addi       s4, s5, #1536                   // row 6
    p.and        p3, p5, p1
    s.movz       s6, #7
    v.splat      v1, s1
    s.addi       s1, s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    s.addi       s2, s5, #1792                   // row 7
    p.and        p4, p5, p1
    s.movz       s3, #8
    v.splat      v2, s1
    s.addi       s1, s9, #11
    s.addi       s7, s5, #2048                   // row 8
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.movz       s4, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s9, #12
    s.addi       s6, s5, #2304                   // row 9
    s.movz       s8, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s9, #13
    s.addi       s2, s5, #2560                   // row 10
    s.movz       s3, #11
    v.splat      v5, s1
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p2
    s.addi       s1, s9, #14
    p.and        p3, p5, p1
    s.addi       s4, s5, #2816                   // row 11
    s.movz       s7, #12
    v.splat      v2, s1
    s.addi       s1, s5, #3072                   // row 12
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s8
    p.and        p5, p4, p2
    s.addi       s6, s9, #15
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v4, s6
    s.addi       s6, s5, #3328                   // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    s.addi       s2, s5, #3584                   // row 14
    p.and        p3, p5, p1
    s.movz       s3, #15
    s.addi       s10, s5, #3840                  // row 15
    @p4 v.st.w       [s4, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s7
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s8
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s3
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
