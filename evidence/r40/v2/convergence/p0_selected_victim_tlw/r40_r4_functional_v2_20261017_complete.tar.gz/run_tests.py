from pathlib import Path
import subprocess,json,itertools
r=Path.cwd();out=r/'functional';out.mkdir(exist_ok=False);records=[]
def step(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=900);s=p.stdout+p.stderr;(out/(name+'.log')).write_text(s)
 if p.returncode!=expected:raise RuntimeError((name,p.returncode,s[-3500:]))
 return s
def test(name,top,sources,params=(),opts=()):
 binary=str(out/(name+'.vvp'));args=['iverilog','-g2012','-I','rtl/common','-s',top,*['-P'+top+'.'+p for p in params],'-o',binary,*sources];step(name+'_build',args);s=step(name,['vvp',binary,*opts]);assert 'PASS' in s.splitlines() or 'TMU REGISTERED RANGES PASS' in s,s;assert 'FATAL' not in s and '\nFAIL' not in s,s;records.append(dict(name=name,scope='functional-only',stdout=s));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',name,flush=True);return args
for wp,pipe,ports in itertools.product([0,1],[0,1,2],[3,4]):
 test(f'tmu_write{wp}_tlw{pipe}_ports{ports}','tb_tmu_registered_ranges',['rtl/nuca/tnca_tmu.v','tb/nuca/tb_tmu_pipeline_quiet.v'],[f'WRITE_PIPE={wp}',f'PIPE={pipe}',f'PORTS={ports}'])
for ports in [3,4]:
 test(f'replicas_write1_ports{ports}','tb_tmu_registered_ranges',['rtl/nuca/tnca_tmu.v','rtl/nuca/tnca_replicated_tmu.v','tb/nuca/tb_tmu_replicated.v'],[f'PORTS={ports}'])
for amo,ranges,policy in [(0,0,0),(0,1,74),(1,0,0),(1,1,0),(1,1,2),(1,1,74)]:
 for seed in [1,7]:
  test(f'data_amo{amo}_range{ranges}_policy{policy}_seed{seed}','tb_nuca_slice',['rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_slice.v'],['SETS=32','SET_W=5','WAYS=8','WAY_W=3','REGISTER_VICTIM_OWNER=1','REGISTER_VICTIM_SELECT=1','SYNC_TAG_BANK=1','BALANCED_VICTIM=1',f'DCO_REGISTERED_RANGES={ranges}',f'POLICY={policy}',f'AMO_TRAFFIC={amo}','DRAM_LAT=400'],['+nreq=20000',f'+seed={seed}','+min_wb=1','+min_block=1'])
for latency,stall,full in itertools.product([1,8],[0,1],[0,1]):
 test(f'maintenance_lat{latency}_stall{stall}_full{full}','tb_nuca_maintenance',['rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_maintenance.v'],[f'LATENCY={latency}',f'STALL={stall}',f'FULL_TAG={full}'])
print('R4_FUNCTIONAL_BATCH_DONE',flush=True)
