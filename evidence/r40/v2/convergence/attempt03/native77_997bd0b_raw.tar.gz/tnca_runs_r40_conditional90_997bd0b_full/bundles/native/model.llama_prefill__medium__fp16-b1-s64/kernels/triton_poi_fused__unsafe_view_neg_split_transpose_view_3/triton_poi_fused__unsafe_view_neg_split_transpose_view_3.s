    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.cmp.lt     p3, v4, v1
    @p2 v.sel        v3, v6, v4
    v.sub        v6, v2, v8
    v.movi       v7, #15
    v.movi       v9, #63
    @p1 v.sel        v10, v6, v8
    v.and        v6, v3, v7
    s.rdspecial  s1, arg_base
    v.sub        v3, v1, v4
    v.sub        v7, v5, v10
    v.cmp.lt     p1, v10, v5
    v.sub        v8, v0, v6
    @p1 v.sel        v11, v7, v10
    v.movi       v7, #16
    @p2 v.sel        v12, v8, v6
    v.and        v6, v11, v9
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p3 v.sel        v8, v3, v4
    v.sub        v3, v5, v6
    v.movi       v9, #6144
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v11, v3, v6
    v.cmp.lt     p1, v4, v9
    v.movi       v3, #64
    v.movi       v4, #1024
    v.sub        v6, v0, v7
    v.sub        v0, v2, v7
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p4, v7, v2
    v.movi       v2, #10
    @p2 v.sel        v9, v6, v7
    v.movi       v6, #32
    v.lshr       v9, v8, v2
    v.add        v2, v12, v7
    v.mul        v8, v10, v6
    v.cmp.lt     p2, v3, v5
    v.sub        v10, v5, v3
    v.add        v5, v12, v8
    v.sub        v8, v1, v9
    @p4 v.sel        v12, v0, v7
    v.movi       v0, #192
    @p3 v.sel        v7, v8, v9
    v.sub        v8, v1, v4
    v.mul        v9, v11, v0
    v.mul        v0, v7, v6
    v.cmp.lt     p3, v4, v1
    @p2 v.sel        v1, v10, v3
    v.add        v1, v2, v0
    @p3 v.sel        v0, v8, v4
    v.add        v0, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v1
    vf.neg       v1, v0
    vf.cvt.f32.f16 v0, v1
    @p1 v.st.scatter.h [s3, v5], v0
__rctx_next:
    exit
