.li s1, #0x30000
td.load d0, [s1]
w.def w0, #0, #1
mb.arm s3, b0, #0, #1
.li s10, #0
t.ld.async.h w0, d0, s10, s3
v.movi v0, #7
mb.wait s3
exit
