    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #128
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #8589934592
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #128
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s21, #8
    s.ld.d       s22, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.st.d       [s7, #0], s12
    s.movz       s2, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s12, s21, s1
    s.st.d       [s7, #48], s5
    s.cmp.lt     s1, s4, s2
    s.movz       s2, #0
    s.sub        s5, s2, s12
    s.movz       s2, #1
    s.st.d       [s7, #56], s8
    s.sub        s8, s6, s1
    s.movz       s1, #0
    s.xor        s6, s4, s8
    s.st.d       [s7, #88], s9
    s.sub        s9, s6, s8
    s.movz       s6, #0
    s.st.d       [s7, #104], s10
    s.lshri      s10, s9, #3
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s8, s5
    s.movz       s8, #0
    s.ld.d       s12, [s11, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s11, s4, s6
    s.add        s6, s12, s15                    // this context's own scratch
    s.xor        s12, s10, s7
    s.muli       s15, s10, #8
    s.sub        s10, s12, s7
    s.movz       s7, #0
    s.addi       s12, s6, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.sub        s6, s7, s11
    s.sub        s7, s2, s10
    s.st.d       [s12, #0], s18
    s.min.s      s11, s7, s2
    s.movz       s7, #0
    s.cmp.lt     s18, s11, s1
    s.sub        s1, s9, s15
    s.sub        s1, s8, s18
    s.movz       s8, #1
    s.xor        s9, s4, s6
    s.xor        s15, s21, s5
    s.sub        s18, s9, s6
    s.sub        s9, s15, s5
    s.movz       s5, #0
    s.st.d       [s12, #8], s14
    s.xor        s9, s11, s1
    s.sub        s14, s9, s1
    s.st.d       [s12, #16], s3
    s.addi       s1, s7, #0
    s.addi       s3, s5, #0
    s.st.d       [s12, #48], s13
    s.cmp.eq     s5, s14, s8
    s.st.d       [s12, #56], s16
    s.st.d       [s12, #88], s17
    s.st.d       [s12, #104], s19
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s18
    br.nz        s5, sdiv_done_1
    s.movz       s5, #0
    s.movz       s7, #31
    s.mov        s1, s5
    s.addi       s5, s7, #0
sdiv_2:
    s.lshr       s7, s18, s5
    s.shli       s8, s3, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s12, s14
    s.shl        s13, s8, s5
    s.sub        s8, s7, s9
    s.subi       s7, s5, #1
    s.and        s9, s14, s8
    s.and        s15, s13, s8
    s.sub        s8, s12, s9
    s.or         s9, s1, s15
    s.mov        s3, s8
    s.mov        s1, s9
    s.mov        s5, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s5, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s7, s4, s1
    s.movz       s1, #0
    s.sub        s8, s5, s7
    s.movz       s5, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.cmp.lt     s7, s11, s1
    s.lshri      s1, s9, #3
    s.movz       s12, #0
    s.muli       s13, s1, #8
    s.sub        s1, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s21, s12
    s.xor        s12, s11, s1
    s.sub        s11, s9, s13
    s.movz       s9, #0
    s.xor        s13, s11, s8
    s.xor        s11, s3, s6
    s.sub        s3, s13, s8
    s.sub        s8, s9, s7
    s.cmp.lt     s7, s3, s5
    s.sub        s5, s12, s1
    s.sub        s9, s4, s7
    s.movz       s4, #0
    s.xor        s7, s3, s9
    s.movz       s3, #1
    s.sub        s12, s11, s6
    s.xor        s6, s21, s8
    s.sub        s11, s7, s9
    s.movz       s7, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s3
    s.add        s3, s10, s12
    s.sub        s10, s6, s8
    s.addi       s6, s7, #0
    s.mov        s13, s11
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s13, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s11, s4
    s.shli       s8, s6, #1
    s.andi       s10, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s10
    s.movz       s8, #1
    s.cmp.geu    s10, s12, s5
    s.shl        s14, s8, s4
    s.sub        s8, s7, s10
    s.subi       s7, s4, #1
    s.and        s10, s5, s8
    s.and        s15, s14, s8
    s.sub        s8, s12, s10
    s.or         s10, s13, s15
    s.mov        s6, s8
    s.mov        s13, s10
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s4, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s4, s9, s1
    s.movz       s1, #16
    s.xor        s5, s13, s4
    s.mul        s6, s3, s1
    s.sub        s7, s5, s4
    s.movz       s4, #0
    s.mul        s5, s7, s1
    v.splat      v0, s3
    s.andi       s3, s6, #15
    v.splat      v1, s4
    v.splat      v2, s7
    s.andi       s7, s5, #127
    v.splat      v3, s4
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s5
    v.splat      v1, s3
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s7
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #4
    s.addi       s9, s4, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s9, s8
    br.nz        s4, endfor_6
    s.mul        s4, s9, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s4, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s4
    mb.wait      s4
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.muli       s2, s5, #2                      // a runtime tile origin, x2
    s.add        s3, s20, s2                     // the tile origin
    s.muli       s2, s6, #256                    // a runtime tile origin, x256
    s.add        s7, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    s.movz       s3, #0
    s.add        s8, s3, s6                      // the tile origin
    v.splat      v0, s8
    v.splat      v1, s1
    v.cmp.lt     p1, v0, v1
    s.movz       s1, #0
    s.add        s3, s1, s5                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s3
    v.add        v3, v0, v2
    s.movz       s1, #128
    v.splat      v0, s1
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s1, #1
    s.addi       s2, s7, #256                    // row 1
    s.addi       s3, s8, #1
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #2
    s.addi       s2, s7, #512                    // row 2
    s.addi       s3, s8, #2
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #3
    s.addi       s2, s7, #768                    // row 3
    s.addi       s3, s8, #3
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #4
    s.addi       s2, s7, #1024                   // row 4
    s.addi       s3, s8, #4
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #5
    s.addi       s2, s7, #1280                   // row 5
    s.addi       s3, s8, #5
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #6
    s.addi       s2, s7, #1536                   // row 6
    s.addi       s3, s8, #6
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #7
    s.addi       s2, s7, #1792                   // row 7
    s.addi       s3, s8, #7
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #8
    s.addi       s2, s7, #2048                   // row 8
    s.addi       s3, s8, #8
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #9
    s.addi       s2, s7, #2304                   // row 9
    s.addi       s3, s8, #9
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #10
    s.addi       s2, s7, #2560                   // row 10
    s.addi       s3, s8, #10
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #11
    s.addi       s2, s7, #2816                   // row 11
    s.addi       s3, s8, #11
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #12
    s.addi       s2, s7, #3072                   // row 12
    s.addi       s3, s8, #12
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #13
    s.addi       s2, s7, #3328                   // row 13
    s.addi       s3, s8, #13
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #14
    s.addi       s2, s7, #3584                   // row 14
    s.addi       s3, s8, #14
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #15
    s.addi       s2, s7, #3840                   // row 15
    s.addi       s3, s8, #15
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s5, #2                      // a runtime tile origin, x2
    s.add        s2, s22, s1                     // the tile origin
    s.muli       s1, s6, #256                    // a runtime tile origin, x256
    s.add        s3, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a1, s1
    s.movz       s1, #0
    a.vread      v3, a1, s1
    vf.neg       v4, v3
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v4, v3
    vf.fms       v6, v4, v3, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v6, v5
    vf.fma       v6, v4, v7, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v7, v6, v4
    vf.add       v4, v7, v0
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v4, v6, v7
    vf.fms       v4, v6, v8, v6
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.mul       v6, v2, v4                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v2
    vf.cvt.f32.f16 v2, v4
    v.splat      v4, s8
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s3, #0], v2
    s.movz       s1, #1
    a.vread      v2, a1, s1
    s.movz       s1, #1
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #256                    // row 1
    s.addi       s2, s8, #1
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #2
    a.vread      v2, a1, s1
    s.movz       s1, #2
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #512                    // row 2
    s.addi       s2, s8, #2
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #3
    a.vread      v2, a1, s1
    s.movz       s1, #3
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #768                    // row 3
    s.addi       s2, s8, #3
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #4
    a.vread      v2, a1, s1
    s.movz       s1, #4
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #1024                   // row 4
    s.addi       s2, s8, #4
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #5
    a.vread      v2, a1, s1
    s.movz       s1, #5
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #1280                   // row 5
    s.addi       s2, s8, #5
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #6
    a.vread      v2, a1, s1
    s.movz       s1, #6
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #1536                   // row 6
    s.addi       s2, s8, #6
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #7
    a.vread      v2, a1, s1
    s.movz       s1, #7
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #1792                   // row 7
    s.addi       s2, s8, #7
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #8
    a.vread      v2, a1, s1
    s.movz       s1, #8
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #2048                   // row 8
    s.addi       s2, s8, #8
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #9
    a.vread      v2, a1, s1
    s.movz       s1, #9
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #2304                   // row 9
    s.addi       s2, s8, #9
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #10
    a.vread      v2, a1, s1
    s.movz       s1, #10
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #2560                   // row 10
    s.addi       s2, s8, #10
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #11
    a.vread      v2, a1, s1
    s.movz       s1, #11
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #2816                   // row 11
    s.addi       s2, s8, #11
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #12
    a.vread      v2, a1, s1
    s.movz       s1, #12
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #3072                   // row 12
    s.addi       s2, s8, #12
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #13
    a.vread      v2, a1, s1
    s.movz       s1, #13
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #3328                   // row 13
    s.addi       s2, s8, #13
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #14
    a.vread      v2, a1, s1
    s.movz       s1, #14
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s3, #3584                   // row 14
    s.addi       s2, s8, #14
    v.splat      v4, s2
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #15
    a.vread      v2, a1, s1
    s.movz       s1, #15
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v5, v3, v4, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    vf.add       v3, v4, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v0, v7
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v2, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v3, v2
    vf.cvt.f16.f32 v2, v3
    vf.mul       v3, v0, v2
    vf.cvt.f32.f16 v0, v3
    s.addi       s1, s3, #3840                   // row 15
    s.addi       s2, s8, #15
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
