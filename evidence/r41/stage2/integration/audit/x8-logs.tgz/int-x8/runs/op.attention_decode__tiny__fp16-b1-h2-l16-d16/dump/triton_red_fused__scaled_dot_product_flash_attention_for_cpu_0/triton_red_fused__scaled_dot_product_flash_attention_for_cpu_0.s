    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #4
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v4, v3, v0
    v.movi       v0, #16
    v.lshr       v3, v4, v2
    s.rdspecial  s1, arg_base
    v.sub        v2, v1, v3
    s.shli       s2, s4, #4                      // x16 as a shift
    @p1 v.sel        v4, v2, v3
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.mul        v2, v4, v0
    v.iota       v3                              // arange(0, VLEN)
    v.extract    s5, v2, #0
    v.splat      v2, s5
    s.shli       s5, s2, #1                      // element offset -> bytes (x2)
    s.ld.d       s6, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v4, #16
    v.add        v5, v3, v2
    s.add        s7, s3, s5                      // &in_ptr1[...]
    v.cmp.lt     p1, v3, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s6, v5]               // index is in elements (ISA sec 9.1)
    .li       s3, #1056964608
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0
    v.movi       v6, #0
    s.shli       s3, s4, #2                      // element offset -> bytes (x4)
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s7, #0]
    vf.cvt.f16.f32 v9, v2
    v.cmp.lt     p2, v0, v1
    v.sub        v2, v1, v0
    v.cmpi.lt    p3, v7, #1
    vf.mul       v1, v9, v4
    vf.cvt.f16.f32 v7, v8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.splat      v8, s2
    @p2 v.sel        v9, v2, v0
    vf.mul       v0, v7, v4
    s.add        s1, s4, s3                      // &out_ptr0[...]
    v.add        v2, v3, v8
    vf.mul       v2, v1, v0
    vf.add       v0, v2, v5
    @p1 v.sel        v1, v0, v5
    vf.reduce.add.b v0, v1
    vf.add       v1, v0, v6
    @p3 v.st.w       [s1, #0], v1
__rctx_next:
    exit
