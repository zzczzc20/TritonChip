    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #5
    v.movi       v2, #0
    v.movi       v3, #10240
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v7, v0
    v.cmp.lt     p1, v7, v2
    v.lshr       v10, v3, v8
    v.shl        v11, v0, v8
    s.subi       s1, s4, #1
    v.and        v8, v10, v0
    s.movz       s6, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v8, v10, v4
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v7, v11
    v.mov        v5, v8
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s6
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v6
    v.sub        v5, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p4, v1, v0
    @p2 v.sel        v8, v3, v7
    @p1 v.sel        v3, v4, v6
    @p4 v.sel        v4, v5, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v9, v5, v2
    v.cmp.lt     p2, v5, v0
    v.lshr       v10, v3, v7
    v.shl        v11, v2, v7
    s.subi       s4, s1, #1
    v.and        v7, v10, v2
    s.movz       s6, #0
    v.or         v10, v9, v7
    v.cmp.geu    p5, v10, v4
    p.or         p6, p2, p5
    v.sub        v7, v10, v4
    @p6 v.sel        v9, v11, v0
    @p6 v.sel        v11, v7, v10
    v.or         v7, v1, v9
    v.mov        v5, v11
    v.mov        v1, v7
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s6
    br.nz        s4, idiv_2
    v.sub        v2, v0, v1
    p.xor        p2, p1, p4
    v.movi       v0, #0
    @p2 v.sel        v3, v2, v1
    v.movi       v1, #255
    v.movi       v2, #256
    v.sub        v4, v0, v3
    v.cmp.lt     p1, v3, v0
    v.movi       v5, #1280
    @p1 v.sel        v7, v4, v3
    v.movi       v3, #0
    v.sub        v4, v0, v2
    v.and        v9, v7, v1
    v.sub        v1, v3, v6
    v.sub        v7, v3, v5
    v.sub        v10, v0, v9
    v.cmp.lt     p2, v2, v0
    v.cmp.lt     p4, v6, v3
    v.movi       v0, #1
    @p2 v.sel        v0, v4, v2
    v.cmp.lt     p2, v5, v3
    @p1 v.sel        v0, v10, v9
    v.movi       v4, #1
    @p4 v.sel        v9, v1, v6
    @p2 v.sel        v1, v7, v5
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v10, s1
    v.shl        v11, v7, v4
    v.cmp.lt     p1, v7, v3
    v.lshr       v12, v9, v10
    v.shl        v13, v4, v10
    s.subi       s4, s1, #1
    v.and        v10, v12, v4
    s.movz       s6, #0
    v.or         v12, v11, v10
    v.cmp.geu    p5, v12, v1
    p.or         p6, p1, p5
    v.sub        v10, v12, v1
    @p6 v.sel        v11, v13, v3
    @p6 v.sel        v13, v10, v12
    v.or         v10, v6, v11
    v.mov        v7, v13
    v.mov        v6, v10
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s6
    br.nz        s4, idiv_3
    v.sub        v1, v3, v6
    p.xor        p1, p4, p2
    v.movi       v3, #0
    @p1 v.sel        v4, v1, v6
    v.movi       v1, #2
    v.mul        v6, v8, v2
    v.sub        v2, v3, v4
    v.cmp.lt     p1, v4, v3
    v.add        v7, v0, v6
    @p1 v.sel        v0, v2, v4
    .li       s1, #1048576000
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v4, #4
    v.lshr       v6, v0, v1
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.sub        v0, v3, v4
    v.sub        v1, v3, v6
    s.add        s2, s5, s1                      // &out_ptr0[...]
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v3, v1, v6
    s.movz       s1, #256
    v.movi       v1, #1
    v.mul        v1, v3, v5
    @p2 v.sel        v3, v0, v4
    s.movz       s1, #1280
    v.add        v0, v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v1
    vf.mul       v1, v0, v2
    @p3 v.st.w       [s2, #0], v1
__rctx_next:
    exit
