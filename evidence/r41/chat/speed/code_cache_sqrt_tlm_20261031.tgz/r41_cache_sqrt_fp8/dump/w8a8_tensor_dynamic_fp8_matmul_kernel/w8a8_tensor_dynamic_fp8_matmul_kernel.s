    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #128
    s.movz       s6, #15
    s.cmp.lt     s7, s5, s4
    s.rdspecial  s8, pid.x
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #16
    s.xor        s11, s5, s9
    s.cmp.lt     s12, s10, s4
    s.add        s13, s3, s2
    s.ld.sw      s14, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s4, s12
    s.sub        s12, s4, s15
    s.xor        s15, s10, s16
    s.xor        s17, s13, s12
    s.xor        s13, s12, s9
    s.sub        s18, s17, s12
    s.sub        s12, s15, s16
    s.lshri      s12, s18, #7
    s.sub        s15, s11, s9
    s.xor        s9, s12, s13
    s.add        s11, s14, s6
    s.sub        s6, s9, s13
    s.cmp.lt     s9, s11, s4
    s.muli       s13, s12, #128
    s.sub        s12, s4, s9
    s.ld.d       s9, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.mul        s15, s8, s6
    s.xor        s8, s11, s12
    s.xor        s11, s12, s16
    s.sub        s16, s8, s12
    s.sub        s8, s18, s13
    s.lshri      s8, s16, #4
    s.muli       s12, s8, #16
    s.xor        s13, s8, s11
    s.ld.d       s8, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.add        s17, s15, s7
    s.sub        s7, s16, s12
    s.sub        s7, s13, s11
    s.ld.d       s11, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.movz       s12, #8
    s.ld.d       s13, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.mul        s15, s6, s12
    s.ld.d       s6, [s1, #32]                   // Bs: device_ptr64 at arg_base+32
    s.cmp.lt     s16, s15, s4
    s.cmp.lt     s18, s17, s4
    s.sub        s19, s4, s18
    s.ld.sw      s18, [s1, #56]                  // K: i32 at arg_base+56
    s.sub        s20, s4, s16
    s.ld.sw      s16, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.xor        s21, s17, s19
    s.ld.sw      s22, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.sub        s23, s21, s19
    s.ld.sw      s21, [s1, #80]                  // stride_cm: i32 at arg_base+80
    s.xor        s1, s15, s20
    s.movz       s24, #1
    s.sub        s25, s1, s20
    s.addi       s1, s4, #0
    s.cmp.eq     s26, s25, s24
    s.addi       s27, s4, #0
    s.mov        s1, s23
    br.nz        s26, sdiv_done_1
    s.movz       s4, #0
    s.movz       s26, #31
    s.mov        s1, s4
    s.addi       s4, s26, #0
sdiv_2:
    s.lshr       s26, s23, s4
    s.shli       s28, s27, #1
    s.andi       s29, s26, #1
    s.movz       s26, #0
    s.or         s30, s28, s29
    s.shl        s28, s24, s4
    s.cmp.geu    s29, s30, s25
    s.subi       s31, s4, #1
    s.sub        s32, s26, s29
    s.and        s29, s25, s32
    s.and        s33, s28, s32
    s.sub        s28, s30, s29
    s.or         s29, s1, s33
    s.mov        s27, s28
    s.mov        s1, s29
    s.mov        s4, s31
    s.cmp.ge     s28, s4, s26
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s4, s19, s20
    s.movz       s19, #0
    s.xor        s20, s1, s4
    s.cmp.lt     s1, s15, s19
    s.sub        s23, s20, s4
    s.cmp.lt     s4, s17, s19
    s.sub        s20, s19, s1
    s.mul        s1, s23, s12
    s.sub        s23, s19, s4
    s.xor        s4, s15, s20
    s.xor        s15, s17, s23
    s.sub        s17, s4, s20
    s.sub        s4, s7, s1
    s.sub        s7, s15, s23
    s.addi       s15, s19, #0
    s.cmp.eq     s20, s17, s24
    s.min.s      s24, s4, s12
    s.addi       s4, s19, #0
    s.mov        s15, s7
    br.nz        s20, sdiv_done_3
    s.movz       s12, #0
    s.movz       s20, #31
    s.mov        s15, s12
    s.addi       s12, s20, #0
sdiv_4:
    s.lshr       s20, s7, s12
    s.shli       s25, s4, #1
    s.andi       s26, s20, #1
    s.movz       s20, #1
    s.or         s27, s25, s26
    s.shl        s25, s20, s12
    s.cmp.geu    s20, s27, s17
    s.subi       s26, s12, #1
    s.sub        s28, s19, s20
    s.and        s20, s17, s28
    s.and        s29, s25, s28
    s.sub        s25, s27, s20
    s.or         s20, s15, s29
    s.mov        s4, s25
    s.mov        s15, s20
    s.mov        s12, s26
    s.cmp.ge     s20, s12, s19
    br.nz        s20, sdiv_4
sdiv_done_3:
    s.xor        s7, s4, s23
    s.cmp.lt     s4, s24, s19
    s.sub        s12, s7, s23
    s.sub        s7, s19, s4
    s.cmp.lt     s4, s12, s19
    s.xor        s15, s24, s7
    s.sub        s17, s19, s4
    s.sub        s4, s15, s7
    s.xor        s7, s12, s17
    s.movz       s15, #1
    s.sub        s20, s7, s17
    s.addi       s7, s19, #0
    s.cmp.eq     s23, s4, s15
    s.addi       s25, s19, #0
    s.mov        s7, s20
    br.nz        s23, sdiv_done_5
    s.movz       s19, #0
    s.movz       s23, #31
    s.mov        s7, s19
    s.addi       s19, s23, #0
sdiv_6:
    s.lshr       s23, s20, s19
    s.shli       s26, s25, #1
    s.andi       s27, s23, #1
    s.movz       s23, #0
    s.or         s28, s26, s27
    s.shl        s26, s15, s19
    s.cmp.geu    s27, s28, s4
    s.subi       s29, s19, #1
    s.sub        s30, s23, s27
    s.and        s27, s4, s30
    s.and        s31, s26, s30
    s.sub        s26, s28, s27
    s.or         s27, s7, s31
    s.mov        s25, s26
    s.mov        s7, s27
    s.mov        s19, s29
    s.cmp.ge     s26, s19, s23
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.xor        s7, s25, s17
    s.cmp.lt     s19, s24, s4
    s.cmp.lt     s20, s12, s4
    s.sub        s23, s4, s19
    s.sub        s19, s4, s20
    s.xor        s20, s24, s23
    s.xor        s24, s12, s19
    s.sub        s12, s20, s23
    s.sub        s20, s7, s17
    s.sub        s7, s24, s19
    s.addi       s17, s4, #0
    s.cmp.eq     s24, s12, s15
    s.add        s15, s1, s20
    s.addi       s1, s4, #0
    s.mov        s17, s7
    br.nz        s24, sdiv_done_7
    s.movz       s20, #0
    s.movz       s24, #31
    s.mov        s17, s20
    s.addi       s20, s24, #0
sdiv_8:
    s.lshr       s24, s7, s20
    s.shli       s25, s1, #1
    s.andi       s26, s24, #1
    s.movz       s24, #1
    s.or         s27, s25, s26
    s.shl        s25, s24, s20
    s.cmp.geu    s24, s27, s12
    s.subi       s26, s20, #1
    s.sub        s28, s4, s24
    s.and        s24, s12, s28
    s.and        s29, s25, s28
    s.sub        s25, s27, s24
    s.or         s24, s17, s29
    s.mov        s1, s25
    s.mov        s17, s24
    s.mov        s20, s26
    s.cmp.ge     s24, s20, s4
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s1, s15, s10
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s14
    v.movi       v2, #0
    s.xor        s4, s19, s23
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s7, s17, s4
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s12, s7, s4
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v5, s4
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s7, s4, #1
    v.and        v5, v8, v3
    s.movz       s15, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s15
    br.nz        s7, idiv_9
    s.mul        s4, s12, s5
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v3, #32
    v.movi       v5, #48
    v.splat      v6, s4
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.movi       v9, #80
    v.movi       v10, #96
    v.iota       v11                             // arange(0, VLEN)
    v.movi       v12, #112
    v.add        v13, v6, v0
    v.splat      v14, s3
    v.movi       v15, #0
    v.sub        v16, v2, v4
    v.add        v2, v0, v1
    v.add        v1, v0, v3
    v.add        v3, v0, v5
    v.add        v0, v7, v8
    v.add        v5, v7, v9
    v.add        v8, v7, v10
    v.add        v7, v11, v12
    v.sub        v9, v15, v13
    v.sub        v10, v15, v14
    v.cmp.lt     p1, v13, v15
    v.cmp.lt     p3, v14, v15
    @p2 v.sel        v11, v16, v4
    v.add        v4, v6, v2
    v.add        v2, v6, v1
    v.add        v1, v6, v3
    v.add        v3, v6, v0
    v.add        v0, v6, v5
    v.add        v5, v6, v8
    v.add        v8, v6, v7
    v.movi       v6, #1
    @p1 v.sel        v7, v9, v13
    @p3 v.sel        v9, v10, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s7, #31
idiv_10:
    v.splat      v13, s7
    v.shl        v16, v12, v6
    v.cmp.lt     p2, v12, v15
    v.lshr       v17, v7, v13
    v.shl        v18, v6, v13
    s.subi       s12, s7, #1
    v.and        v13, v17, v6
    s.movz       s15, #0
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v9
    p.or         p4, p2, p3
    v.sub        v13, v17, v9
    @p4 v.sel        v16, v18, v15
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_10
    v.movi       v6, #0
    v.sub        v7, v15, v12
    v.movi       v9, #1
    v.sub        v10, v6, v4
    v.sub        v13, v6, v14
    v.cmp.lt     p2, v4, v6
    v.cmp.lt     p3, v14, v6
    @p1 v.sel        v15, v7, v12
    @p2 v.sel        v7, v10, v4
    @p3 v.sel        v4, v13, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v13, s7
    v.shl        v16, v12, v9
    v.cmp.lt     p1, v12, v6
    v.lshr       v17, v7, v13
    v.shl        v18, v9, v13
    s.subi       s12, s7, #1
    v.and        v13, v17, v9
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v13, v17, v4
    @p4 v.sel        v16, v18, v6
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v12
    v.movi       v6, #1
    v.sub        v9, v4, v2
    v.sub        v10, v4, v14
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p3, v14, v4
    @p2 v.sel        v13, v7, v12
    @p1 v.sel        v7, v9, v2
    @p3 v.sel        v2, v10, v14
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_12:
    v.splat      v12, s7
    v.shl        v16, v10, v6
    v.cmp.lt     p2, v10, v4
    v.lshr       v17, v7, v12
    v.shl        v18, v6, v12
    s.subi       s12, s7, #1
    v.and        v12, v17, v6
    s.movz       s15, #0
    v.or         v17, v16, v12
    v.cmp.geu    p3, v17, v2
    p.or         p4, p2, p3
    v.sub        v12, v17, v2
    @p4 v.sel        v16, v18, v4
    @p4 v.sel        v18, v12, v17
    v.or         v12, v9, v16
    v.mov        v10, v18
    v.mov        v9, v12
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_12
    v.movi       v2, #0
    v.sub        v6, v4, v10
    v.movi       v4, #1
    v.sub        v7, v2, v1
    v.sub        v9, v2, v14
    v.cmp.lt     p2, v1, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v12, v6, v10
    @p2 v.sel        v6, v7, v1
    @p3 v.sel        v1, v9, v14
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v10, s7
    v.shl        v16, v9, v4
    v.cmp.lt     p1, v9, v2
    v.lshr       v17, v6, v10
    v.shl        v18, v4, v10
    s.subi       s12, s7, #1
    v.and        v10, v17, v4
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v10, v17, v1
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v10, v17
    v.or         v10, v7, v16
    v.mov        v9, v18
    v.mov        v7, v10
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_13
    v.movi       v1, #0
    v.sub        v4, v2, v9
    v.movi       v2, #1
    v.sub        v6, v1, v3
    v.sub        v7, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v10, v4, v9
    @p1 v.sel        v4, v6, v3
    @p3 v.sel        v3, v7, v14
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_14:
    v.splat      v9, s7
    v.shl        v16, v7, v2
    v.cmp.lt     p2, v7, v1
    v.lshr       v17, v4, v9
    v.shl        v18, v2, v9
    s.subi       s12, s7, #1
    v.and        v9, v17, v2
    s.movz       s15, #0
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v9, v17, v3
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v9, v17
    v.or         v9, v6, v16
    v.mov        v7, v18
    v.mov        v6, v9
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_14
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.movi       v1, #1
    v.sub        v4, v2, v0
    v.sub        v6, v2, v14
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v9, v3, v7
    @p2 v.sel        v3, v4, v0
    @p3 v.sel        v0, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v7, s7
    v.shl        v16, v6, v1
    v.cmp.lt     p1, v6, v2
    v.lshr       v17, v3, v7
    v.shl        v18, v1, v7
    s.subi       s12, s7, #1
    v.and        v7, v17, v1
    v.or         v17, v16, v7
    v.cmp.geu    p3, v17, v0
    p.or         p4, p1, p3
    v.sub        v7, v17, v0
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v7, v17
    v.or         v7, v4, v16
    v.mov        v6, v18
    v.mov        v4, v7
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_15
    v.movi       v0, #0
    v.sub        v1, v2, v6
    v.movi       v2, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v14
    v.cmp.lt     p1, v5, v0
    v.cmp.lt     p3, v14, v0
    @p2 v.sel        v7, v1, v6
    @p1 v.sel        v1, v3, v5
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s7, #31
idiv_16:
    v.splat      v6, s7
    v.shl        v16, v5, v2
    v.cmp.lt     p2, v5, v0
    v.lshr       v17, v1, v6
    v.shl        v18, v2, v6
    s.subi       s12, s7, #1
    v.and        v6, v17, v2
    s.movz       s15, #0
    v.or         v17, v16, v6
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v6, v17, v3
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v6, v17
    v.or         v6, v4, v16
    v.mov        v5, v18
    v.mov        v4, v6
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_16
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v8
    v.sub        v4, v1, v14
    v.cmp.lt     p2, v8, v1
    v.cmp.lt     p3, v14, v1
    @p1 v.sel        v6, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v8, s7
    v.shl        v14, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v16, v2, v8
    v.shl        v17, v0, v8
    s.subi       s12, s7, #1
    v.and        v8, v16, v0
    v.or         v16, v14, v8
    v.cmp.geu    p3, v16, v3
    p.or         p4, p1, p3
    v.sub        v8, v16, v3
    @p4 v.sel        v14, v17, v1
    @p4 v.sel        v17, v8, v16
    v.or         v8, v4, v14
    v.mov        v5, v17
    v.mov        v4, v8
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_17
    s.add        s7, s18, s2
    s.cmp.lt     s2, s5, s15
    s.cmp.lt     s12, s7, s15
    s.sub        s17, s15, s2
    s.sub        s2, s15, s12
    v.sub        v0, v1, v5
    s.xor        s12, s7, s2
    s.xor        s7, s2, s17
    s.sub        s15, s12, s2
    s.xor        s2, s5, s17
    s.lshri      s12, s15, #7
    s.movz       s19, #0
    s.muli       s20, s12, #128
    s.xor        s23, s12, s7
    @p2 v.sel        v1, v0, v5
    s.movz       s12, #32
    s.movz       s24, #48
    s.movz       s25, #64
    s.movz       s26, #80
    s.movz       s27, #96
    s.movz       s28, #112
    v.ld.gather.w v0, [s13, v11]                 // index is in elements (ISA sec 9.1)
    s.sub        s13, s2, s17
    s.sub        s2, s15, s20
    s.sub        s2, s23, s7
    s.movz       s7, #1
    s.addi       s13, s19, #0
    s.addi       s15, s19, #0
    s.addi       s17, s19, #0
    s.ld.w       s20, [s6, #0]                   // one element, not a vector
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s6, s13, s2
    br.nz        s6, endfor_19
    v.extract    s6, v15, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s6
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s23, arg_base
    s.mul        s29, s13, s5
    v.extract    s30, v13, #0
    v.add        v4, v3, v2
    s.ld.d       s31, [s23, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s23, #0
    v.sub        v3, v15, v4
    s.sub        s32, s18, s29
    v.splat      v4, s30
    v.reduce.or  s29, v3
    v.splat      v3, s22
    v.add        v5, v4, v2
    v.splat      v4, s22
    s.add        s33, s19, s32
    s.cmp.eq     s34, s29, s23
    s.cmp.ge     s29, s6, s23
    s.cmp.ge     s35, s33, s23
    s.and        s36, s34, s29
    v.mul        v8, v15, v3
    v.sub        v14, v13, v5
    v.mul        v5, v13, v3
    v.mul        v16, v12, v3
    v.reduce.or  s29, v14
    v.mul        v14, v10, v3
    v.mul        v17, v9, v3
    v.mul        v3, v7, v4
    v.mul        v18, v6, v4
    v.mul        v19, v1, v4
    v.extract    s34, v12, #0
    v.movi       v4, #0
    v.splat      v20, s34
    s.cmp.eq     s37, s29, s23
    s.cmp.ge     s29, s30, s23
    v.add        v21, v20, v2
    s.addi       s38, s31, #0
    s.addi       s39, s31, #64
    v.sub        v20, v12, v21
    s.addi       s40, s31, #128
    s.addi       s41, s31, #192
    s.addi       s42, s31, #256
    s.and        s43, s36, s35
    s.and        s36, s37, s29
    s.addi       s29, s31, #320
    v.st.w       [s38, #0], v8
    s.addi       s37, s31, #384
    v.movi       v8, #0
    s.and        s38, s36, s35
    v.st.w       [s39, #0], v5
    s.addi       s36, s31, #448
    v.st.w       [s40, #0], v16
    v.reduce.or  s39, v20
    s.cmp.eq     s40, s39, s23
    v.st.w       [s41, #0], v14
    v.extract    s39, v10, #0
    v.splat      v5, s39
    v.st.w       [s42, #0], v17
    v.add        v14, v5, v2
    s.cmp.ge     s41, s34, s23
    v.sub        v5, v10, v14
    s.and        s42, s40, s41
    s.and        s40, s42, s35
    v.st.w       [s29, #0], v3
    v.reduce.or  s29, v5
    s.cmp.eq     s41, s29, s23
    v.st.w       [s37, #0], v18
    s.cmp.ge     s29, s39, s23
    s.and        s37, s41, s29
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    v.extract    s29, v9, #0
    v.extract    s36, v7, #0
    v.splat      v3, s29
    v.splat      v5, s36
    v.insert     v4, s43, #0
    v.add        v14, v3, v2
    v.add        v3, v5, v2
    v.insert     v8, s6, #0
    v.extract    s6, v6, #0
    v.sub        v5, v9, v14
    v.insert     v4, s38, #1
    v.splat      v14, s6
    v.reduce.or  s38, v5
    v.sub        v5, v7, v3
    v.insert     v8, s30, #1
    v.extract    s30, v1, #0
    v.add        v3, v14, v2
    v.insert     v4, s40, #2
    v.splat      v14, s30
    s.cmp.eq     s40, s38, s23
    s.cmp.ge     s38, s29, s23
    s.and        s23, s37, s35
    v.reduce.or  s37, v5
    s.movz       s41, #0
    v.sub        v5, v6, v3
    s.and        s42, s40, s38
    v.insert     v8, s34, #2
    v.add        v3, v14, v2
    v.insert     v4, s23, #3
    s.cmp.eq     s23, s37, s41
    s.cmp.ge     s34, s36, s41
    s.and        s37, s42, s35
    v.reduce.or  s38, v5
    v.sub        v2, v1, v3
    s.and        s40, s23, s34
    v.insert     v8, s39, #3
    v.insert     v4, s37, #4
    s.cmp.eq     s23, s38, s41
    s.cmp.ge     s34, s6, s41
    s.and        s37, s40, s35
    v.reduce.or  s38, v2
    s.and        s39, s23, s34
    v.insert     v8, s29, #4
    v.insert     v4, s37, #5
    s.cmp.eq     s23, s38, s41
    s.cmp.ge     s29, s30, s41
    s.and        s34, s39, s35
    s.and        s37, s23, s29
    v.insert     v8, s36, #5
    v.insert     v4, s34, #6
    s.and        s23, s37, s35
    v.insert     v8, s6, #6
    v.insert     v4, s23, #7
    s.add        s6, s8, s17
    s.addi       s23, s31, #512                  // TensorMap 0: W's rows for a transposed FP8 B
    .li       s29, #2147483647
    s.movz       s34, #1
    .li       s35, #137438953488
    .li       s36, #7705171329024
    s.addi       s37, s31, #768
    s.addi       s38, s31, #1792                 // TensorMap 1: the gathered fallback B tile
    s.movz       s39, #32
    s.movz       s40, #16
    .li       s41, #68719476768
    s.addi       s42, s31, #1280
    v.insert     v8, s30, #7
    s.addi       s30, s31, #2048                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s23, #0], s6
    v.extract    s6, v4, #0
    s.st.d       [s23, #8], s29
    s.movz       s29, #0
    s.st.d       [s23, #16], s33
    s.st.d       [s23, #48], s22
    s.st.d       [s23, #56], s34
    s.st.d       [s23, #88], s35
    s.st.d       [s23, #104], s36
    fence.release.device
    td.load      d0, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s38, #0], s37
    s.st.d       [s38, #8], s39
    s.st.d       [s38, #16], s40
    s.st.d       [s38, #48], s40
    s.st.d       [s38, #56], s34
    s.st.d       [s38, #88], s41
    s.st.d       [s38, #104], s36
    fence.release.device
    td.load      d1, [s38]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s30, #0], s42
    s.st.d       [s30, #8], s39
    s.st.d       [s30, #16], s40
    s.st.d       [s30, #48], s40
    s.st.d       [s30, #56], s34
    s.st.d       [s30, #88], s41
    s.st.d       [s30, #104], s36
    fence.release.device
    td.load      d2, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s6, x8dot_done_20
    s.addi       s23, s31, #0
    s.addi       s30, s29, #0
    v.ld.w       v2, [s23, #0]
    s.add        s23, s8, s17
x8dot_row_21:
    s.addi       s34, s33, #0
    v.movi       v3, #0
    s.sub        s35, s34, s30
    s.add        s34, s23, s30
    v.splat      v5, s35
    s.shli       s35, s30, #4
    s.addi       s36, s30, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s34, v2]              // index is in elements (ISA sec 9.1)
    s.add        s34, s37, s35
    v.st.b       [s34, #0], v3
    fence.acq_rel.device
    s.mov        s30, s36
    s.cmp.lt     s34, s30, s39
    br.nz        s34, x8dot_row_21
x8dot_done_20:
    v.splat      v2, s6
    v.movi       v3, #0
    mb.arm       s6, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    v.extract    s23, v8, #0
    v.extract    s30, v4, #1
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s6             // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s6           // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s30, x8dot_done_22
    s.movz       s23, #0
    s.addi       s29, s31, #64
    s.addi       s34, s23, #0
    v.ld.w       v2, [s29, #0]
    s.add        s23, s8, s17
    s.addi       s29, s31, #1280
x8dot_row_23:
    s.addi       s35, s33, #0
    v.movi       v3, #0
    s.sub        s36, s35, s34
    s.add        s35, s23, s34
    v.splat      v5, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s35, v2]              // index is in elements (ISA sec 9.1)
    s.add        s35, s29, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v3
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_23
x8dot_done_22:
    v.splat      v2, s16
    s.movz       s23, #0
    v.splat      v3, s30
    v.mul        v5, v11, v2
    s.add        s29, s23, s32                   // the tile origin
    v.movi       v2, #0
    v.extract    s30, v5, #0
    v.iota       v14                             // arange(0, VLEN)
    s.add        s34, s30, s15
    v.splat      v16, s29
    mb.arm       s29, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v8, #1
    s.add        s35, s9, s34
    v.cmp.ne     p1, v3, v2
    v.cmp.eq     p2, v3, v2
    v.cmp.lt     p3, v14, v16
    s.mov        s36, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s29          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s23, v5, #1
    s.addi       s30, s31, #2304                 // 512 bytes of repack scratch
    s.add        s34, s23, s15
    s.addi       s23, s30, #0
    s.add        s35, s9, s34
    v.extract    s34, v5, #2
    s.addi       s36, s30, #32
    s.add        s37, s34, s15
    v.extract    s34, v5, #3
    s.add        s38, s9, s37
    s.add        s37, s34, s15
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #64
    s.add        s34, s9, s37
    v.extract    s37, v5, #4
    s.addi       s39, s30, #96
    s.add        s40, s37, s15
    s.add        s37, s9, s40
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #5
    s.add        s40, s35, s15
    s.add        s35, s9, s40
    v.st.b       [s36, #0], v2
    s.addi       s36, s30, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s38, v5, #6
    s.add        s40, s38, s15
    s.add        s38, s9, s40
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #160
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s34, #0]
    v.extract    s34, v5, #7
    s.add        s40, s34, s15
    s.add        s34, s9, s40
    v.st.b       [s39, #0], v2
    s.addi       s39, s30, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    v.extract    s37, v5, #8
    s.add        s40, s37, s15
    s.add        s37, s9, s40
    v.st.b       [s36, #0], v2
    s.addi       s36, s30, #224
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #9
    s.add        s40, s35, s15
    s.add        s35, s9, s40
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s38, v5, #10
    s.add        s40, s38, s15
    s.add        s38, s9, s40
    v.st.b       [s39, #0], v2
    s.addi       s39, s30, #288
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s34, #0]
    v.extract    s34, v5, #11
    s.add        s40, s34, s15
    s.add        s34, s9, s40
    v.st.b       [s36, #0], v2
    s.addi       s36, s30, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    v.extract    s37, v5, #12
    s.add        s40, s37, s15
    s.add        s37, s9, s40
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #352
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #13
    s.add        s40, s35, s15
    s.add        s35, s9, s40
    v.st.b       [s39, #0], v2
    s.addi       s39, s30, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s38, v5, #14
    s.add        s40, s38, s15
    s.add        s38, s9, s40
    v.st.b       [s36, #0], v2
    s.addi       s36, s30, #416
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s34, #0]
    v.extract    s34, v5, #15
    s.add        s40, s34, s15
    s.add        s34, s9, s40
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    s.movz       s37, #0
    v.st.b       [s39, #0], v2
    s.add        s39, s37, s10                   // the tile origin
    s.add        s40, s37, s32                   // the tile origin
    v.splat      v2, s39
    v.extract    s37, v5, #0
    v.splat      v3, s40
    s.add        s39, s37, s15
    v.add        v16, v14, v2
    s.addi       s37, s39, #16
    s.addi       s39, s30, #480
    s.add        s40, s9, s37
    v.cmp.lt     p1, v16, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #1
    s.add        s37, s35, s15
    s.addi       s35, s37, #16
    s.add        s37, s9, s35
    v.st.b       [s36, #0], v2
    s.addi       s35, s30, #16
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s36, v5, #2
    s.add        s38, s36, s15
    s.addi       s36, s38, #16
    s.add        s38, s9, s36
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #48
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s34, #0]
    v.extract    s34, v5, #3
    s.add        s36, s34, s15
    s.addi       s34, s36, #16
    s.add        s36, s9, s34
    v.st.b       [s39, #0], v2
    s.addi       s34, s30, #80
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s40, #0]
    v.extract    s39, v5, #4
    s.add        s40, s39, s15
    s.addi       s39, s40, #16
    s.add        s40, s9, s39
    v.st.b       [s35, #0], v2
    s.addi       s35, s30, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    v.extract    s37, v5, #5
    s.add        s39, s37, s15
    s.addi       s37, s39, #16
    s.add        s39, s9, s37
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #144
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    v.extract    s37, v5, #6
    s.add        s38, s37, s15
    s.addi       s37, s38, #16
    s.add        s38, s9, s37
    v.st.b       [s34, #0], v2
    s.addi       s34, s30, #176
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s36, #0]
    v.extract    s36, v5, #7
    s.add        s37, s36, s15
    s.addi       s36, s37, #16
    s.add        s37, s9, s36
    v.st.b       [s35, #0], v2
    s.addi       s35, s30, #208
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s40, #0]
    v.extract    s36, v5, #8
    s.add        s40, s36, s15
    s.addi       s36, s40, #16
    s.add        s40, s9, s36
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #240
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    v.extract    s36, v5, #9
    s.add        s39, s36, s15
    s.addi       s36, s39, #16
    s.add        s39, s9, s36
    v.st.b       [s34, #0], v2
    s.addi       s34, s30, #272
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    v.extract    s36, v5, #10
    s.add        s38, s36, s15
    s.addi       s36, s38, #16
    s.add        s38, s9, s36
    v.st.b       [s35, #0], v2
    s.addi       s35, s30, #304
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    v.extract    s36, v5, #11
    s.add        s37, s36, s15
    s.addi       s36, s37, #16
    s.add        s37, s9, s36
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #336
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s40, #0]
    v.extract    s36, v5, #12
    s.add        s40, s36, s15
    s.addi       s36, s40, #16
    s.add        s40, s9, s36
    v.st.b       [s34, #0], v2
    s.addi       s34, s30, #368
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    v.extract    s36, v5, #13
    s.add        s39, s36, s15
    s.addi       s36, s39, #16
    s.add        s39, s9, s36
    v.st.b       [s35, #0], v2
    s.addi       s35, s30, #400
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    v.extract    s36, v5, #14
    s.add        s38, s36, s15
    s.addi       s36, s38, #16
    s.add        s38, s9, s36
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #432
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    v.extract    s36, v5, #15
    s.add        s37, s36, s15
    s.addi       s36, s37, #16
    s.add        s37, s9, s36
    v.st.b       [s34, #0], v2
    s.addi       s34, s30, #464
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s40, #0]
    s.addi       s36, s30, #496
    v.st.b       [s35, #0], v2
    s.addi       s35, s30, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    s.addi       s39, s30, #128
    v.st.b       [s23, #0], v2
    s.addi       s23, s30, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    s.addi       s38, s30, #256
    v.st.b       [s34, #0], v2
    s.addi       s34, s30, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    s.addi       s37, s30, #384
    v.st.b       [s36, #0], v2
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s36, s30, #448
    v.ld.w       v2, [s30, #0]
    v.extract    s30, v4, #2
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s35, #0]
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s39, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s23, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s38, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s34, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s37, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s36, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s6
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s23
    mb.wait      s23
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s30, x8dot_done_24
    s.movz       s34, #0
    s.addi       s35, s31, #128
    s.addi       s36, s34, #0
    v.ld.w       v2, [s35, #0]
    s.add        s34, s8, s17
    s.addi       s35, s31, #768
x8dot_row_25:
    s.addi       s37, s33, #0
    v.movi       v3, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v16, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s37, v2]              // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v3
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_25
x8dot_done_24:
    v.splat      v2, s30
    v.movi       v3, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v8, #2
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s35
    mb.wait      s35
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_26
    s.addi       s37, s31, #192
    s.addi       s38, s34, #0
    v.ld.w       v2, [s37, #0]
    s.add        s37, s8, s17
    s.addi       s39, s31, #1280
x8dot_row_27:
    s.addi       s40, s33, #0
    v.movi       v3, #0
    s.sub        s41, s40, s38
    s.add        s40, s37, s38
    v.splat      v16, s41
    s.shli       s41, s38, #4
    s.addi       s42, s38, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s40, v2]              // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v3
    fence.acq_rel.device
    s.mov        s38, s42
    s.cmp.lt     s40, s38, s41
    br.nz        s40, x8dot_row_27
x8dot_done_26:
    v.splat      v2, s36
    v.movi       v3, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v8, #3
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_28
    s.addi       s39, s31, #256
    s.addi       s40, s34, #0
    v.ld.w       v2, [s39, #0]
    s.add        s34, s8, s17
    s.addi       s39, s31, #768
x8dot_row_29:
    s.addi       s41, s33, #0
    v.movi       v3, #0
    s.sub        s42, s41, s40
    s.add        s41, s34, s40
    v.splat      v16, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s41, v2]              // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v3
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_29
x8dot_done_28:
    v.splat      v2, s38
    v.movi       v3, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v8, #4
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_30
    s.addi       s41, s31, #320
    s.addi       s42, s38, #0
    v.ld.w       v2, [s41, #0]
    s.add        s41, s8, s17
    s.addi       s43, s31, #1280
x8dot_row_31:
    s.addi       s44, s33, #0
    v.movi       v3, #0
    s.sub        s45, s44, s42
    s.add        s44, s41, s42
    v.splat      v16, s45
    s.shli       s45, s42, #4
    s.addi       s46, s42, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s44, v2]              // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v3
    fence.acq_rel.device
    s.mov        s42, s46
    s.cmp.lt     s44, s42, s45
    br.nz        s44, x8dot_row_31
x8dot_done_30:
    v.splat      v2, s40
    v.movi       v3, #0
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v8, #5
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s41
    mb.wait      s41
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s42, x8dot_done_32
    s.addi       s43, s31, #384
    s.addi       s44, s38, #0
    v.ld.w       v2, [s43, #0]
    s.add        s38, s8, s17
    s.addi       s43, s31, #768
x8dot_row_33:
    s.addi       s45, s33, #0
    v.movi       v3, #0
    s.sub        s46, s45, s44
    s.add        s45, s38, s44
    v.splat      v16, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s45, v2]              // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v3
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_33
x8dot_done_32:
    v.splat      v2, s42
    v.movi       v3, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v8, #6
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_34
    s.addi       s45, s31, #448
    s.addi       s46, s42, #0
    v.ld.w       v2, [s45, #0]
    s.add        s45, s8, s17
    s.addi       s47, s31, #1280
x8dot_row_35:
    s.addi       s48, s33, #0
    v.movi       v3, #0
    s.sub        s49, s48, s46
    s.add        s48, s45, s46
    v.splat      v16, s49
    s.shli       s49, s46, #4
    s.addi       s50, s46, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s48, v2]              // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v3
    fence.acq_rel.device
    s.mov        s46, s50
    s.cmp.lt     s48, s46, s49
    br.nz        s48, x8dot_row_35
x8dot_done_34:
    v.splat      v2, s44
    v.movi       v3, #0
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s45, v8, #7
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s45
    mb.wait      s45
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s46, x8dot_done_36
    s.addi       s47, s31, #0
    s.add        s48, s8, s17
    s.addi       s49, s42, #0
    v.ld.w       v2, [s47, #0]
    s.addi       s42, s48, #32
    s.addi       s47, s31, #768
x8dot_row_37:
    s.addi       s48, s33, #-32
    v.movi       v3, #0
    s.sub        s50, s48, s49
    s.add        s48, s42, s49
    v.splat      v16, s50
    s.shli       s50, s49, #4
    s.addi       s51, s49, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s48, v2]              // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v3
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s48, s49, s50
    br.nz        s48, x8dot_row_37
x8dot_done_36:
    v.splat      v2, s46
    v.movi       v3, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v8, #0
    s.movz       s48, #32
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_38
    s.addi       s50, s31, #64
    s.add        s51, s8, s17
    s.addi       s52, s46, #0
    v.ld.w       v2, [s50, #0]
    s.addi       s50, s51, #32
    s.addi       s51, s31, #1280
x8dot_row_39:
    s.addi       s53, s33, #-32
    v.movi       v3, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v16, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s53, v2]              // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    v.st.b       [s53, #0], v3
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s48
    br.nz        s53, x8dot_row_39
x8dot_done_38:
    s.add        s50, s46, s12                   // the tile origin
    v.extract    s51, v5, #0
    v.splat      v2, s50
    s.add        s50, s51, s15
    s.add        s51, s46, s32                   // the tile origin
    v.splat      v3, s49
    v.movi       v16, #0
    s.addi       s49, s50, #32
    v.add        v17, v14, v2
    v.splat      v2, s51
    mb.arm       s50, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s51, v8, #1
    s.add        s52, s9, s49
    v.cmp.ne     p1, v3, v16
    v.cmp.eq     p2, v3, v16
    v.cmp.lt     p3, v17, v2
    s.mov        s53, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s50          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s52, #0]
    v.extract    s46, v5, #1
    s.addi       s48, s31, #2816                 // 512 bytes of repack scratch
    s.add        s49, s46, s15
    s.addi       s46, s48, #0
    s.addi       s51, s49, #32
    v.extract    s49, v5, #2
    s.add        s52, s9, s51
    s.add        s51, s49, s15
    s.addi       s49, s48, #32
    s.addi       s53, s51, #32
    v.extract    s51, v5, #3
    v.st.b       [s46, #0], v2
    s.add        s46, s9, s53
    s.add        s53, s51, s15
    s.addi       s51, s48, #64
    s.addi       s54, s53, #32
    v.extract    s53, v5, #4
    s.add        s55, s9, s54
    s.add        s54, s53, s15
    s.addi       s53, s48, #96
    s.addi       s56, s54, #32
    s.add        s54, s9, s56
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s52, #0]
    v.extract    s52, v5, #5
    s.add        s56, s52, s15
    s.addi       s52, s56, #32
    s.add        s56, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s46, #0]
    v.extract    s46, v5, #6
    s.add        s52, s46, s15
    s.addi       s46, s52, #32
    s.add        s52, s9, s46
    v.st.b       [s51, #0], v2
    s.addi       s46, s48, #160
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    v.extract    s51, v5, #7
    s.add        s55, s51, s15
    s.addi       s51, s55, #32
    s.add        s55, s9, s51
    v.st.b       [s53, #0], v2
    s.addi       s51, s48, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s54, #0]
    v.extract    s53, v5, #8
    s.add        s54, s53, s15
    s.addi       s53, s54, #32
    s.add        s54, s9, s53
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #224
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s56, #0]
    v.extract    s53, v5, #9
    s.add        s56, s53, s15
    s.addi       s53, s56, #32
    s.add        s56, s9, s53
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s52, #0]
    v.extract    s52, v5, #10
    s.add        s53, s52, s15
    s.addi       s52, s53, #32
    s.add        s53, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #288
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    v.extract    s52, v5, #11
    s.add        s55, s52, s15
    s.addi       s52, s55, #32
    s.add        s55, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s54, #0]
    v.extract    s52, v5, #12
    s.add        s54, s52, s15
    s.addi       s52, s54, #32
    s.add        s54, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #352
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s56, #0]
    v.extract    s52, v5, #13
    s.add        s56, s52, s15
    s.addi       s52, s56, #32
    s.add        s56, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s53, #0]
    v.extract    s52, v5, #14
    s.add        s53, s52, s15
    s.addi       s52, s53, #32
    s.add        s53, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #416
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    v.extract    s52, v5, #15
    s.add        s55, s52, s15
    s.addi       s52, s55, #32
    s.add        s55, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s54, #0]
    s.movz       s52, #0
    v.st.b       [s51, #0], v2
    s.add        s51, s52, s24                   // the tile origin
    s.add        s54, s52, s32                   // the tile origin
    v.splat      v2, s51
    v.extract    s51, v5, #0
    v.splat      v3, s54
    s.add        s52, s51, s15
    v.add        v16, v14, v2
    s.addi       s51, s52, #48
    s.addi       s52, s48, #480
    s.add        s54, s9, s51
    v.cmp.lt     p1, v16, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s56, #0]
    v.extract    s51, v5, #1
    s.add        s56, s51, s15
    s.addi       s51, s56, #48
    s.add        s56, s9, s51
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #16
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s53, #0]
    v.extract    s51, v5, #2
    s.add        s53, s51, s15
    s.addi       s51, s53, #48
    s.add        s53, s9, s51
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #48
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    v.extract    s51, v5, #3
    s.add        s55, s51, s15
    s.addi       s51, s55, #48
    s.add        s55, s9, s51
    v.st.b       [s52, #0], v2
    s.addi       s51, s48, #80
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s54, #0]
    v.extract    s52, v5, #4
    s.add        s54, s52, s15
    s.addi       s52, s54, #48
    s.add        s54, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s56, #0]
    v.extract    s52, v5, #5
    s.add        s56, s52, s15
    s.addi       s52, s56, #48
    s.add        s56, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #144
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s53, #0]
    v.extract    s52, v5, #6
    s.add        s53, s52, s15
    s.addi       s52, s53, #48
    s.add        s53, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #176
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s55, #0]
    v.extract    s52, v5, #7
    s.add        s55, s52, s15
    s.addi       s52, s55, #48
    s.add        s55, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #208
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s54, #0]
    v.extract    s52, v5, #8
    s.add        s54, s52, s15
    s.addi       s52, s54, #48
    s.add        s54, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #240
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s56, #0]
    v.extract    s52, v5, #9
    s.add        s56, s52, s15
    s.addi       s52, s56, #48
    s.add        s56, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #272
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s53, #0]
    v.extract    s52, v5, #10
    s.add        s53, s52, s15
    s.addi       s52, s53, #48
    s.add        s53, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #304
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s55, #0]
    v.extract    s52, v5, #11
    s.add        s55, s52, s15
    s.addi       s52, s55, #48
    s.add        s55, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #336
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s54, #0]
    v.extract    s52, v5, #12
    s.add        s54, s52, s15
    s.addi       s52, s54, #48
    s.add        s54, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #368
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s56, #0]
    v.extract    s52, v5, #13
    s.add        s56, s52, s15
    s.addi       s52, s56, #48
    s.add        s56, s9, s52
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #400
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s53, #0]
    v.extract    s52, v5, #14
    s.add        s53, s52, s15
    s.addi       s52, s53, #48
    s.add        s53, s9, s52
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #432
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s55, #0]
    v.extract    s52, v5, #15
    s.add        s55, s52, s15
    s.addi       s52, s55, #48
    s.add        s55, s9, s52
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #464
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s54, #0]
    s.addi       s52, s48, #496
    v.st.b       [s49, #0], v2
    s.addi       s49, s48, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s56, #0]
    s.addi       s54, s48, #128
    v.st.b       [s46, #0], v2
    s.addi       s46, s48, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s53, #0]
    s.addi       s53, s48, #256
    v.st.b       [s51, #0], v2
    s.addi       s51, s48, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s55, #0]
    s.addi       s55, s48, #384
    v.st.b       [s52, #0], v2
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s52, s48, #448
    v.ld.w       v2, [s48, #0]
    v.extract    s48, v4, #2
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s49, #0]
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s54, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s46, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s53, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s51, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s55, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s52, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s42
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s48, x8dot_done_40
    s.movz       s49, #0
    s.addi       s51, s31, #128
    s.add        s52, s8, s17
    s.addi       s53, s49, #0
    v.ld.w       v2, [s51, #0]
    s.addi       s49, s52, #32
    s.addi       s51, s31, #768
x8dot_row_41:
    s.addi       s52, s33, #-32
    v.movi       v3, #0
    s.sub        s54, s52, s53
    s.add        s52, s49, s53
    v.splat      v16, s54
    s.shli       s54, s53, #4
    s.addi       s55, s53, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s52, v2]              // index is in elements (ISA sec 9.1)
    s.add        s52, s51, s54
    s.movz       s54, #32
    v.st.b       [s52, #0], v3
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s52, s53, s54
    br.nz        s52, x8dot_row_41
x8dot_done_40:
    v.splat      v2, s48
    v.movi       v3, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s51, v8, #2
    s.movz       s52, #32
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s51
    mb.wait      s51
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_42
    s.addi       s54, s31, #192
    s.add        s55, s8, s17
    s.addi       s56, s49, #0
    v.ld.w       v2, [s54, #0]
    s.addi       s54, s55, #32
    s.addi       s55, s31, #1280
x8dot_row_43:
    s.addi       s57, s33, #-32
    v.movi       v3, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v16, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s57, v2]              // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    v.st.b       [s57, #0], v3
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s52
    br.nz        s57, x8dot_row_43
x8dot_done_42:
    v.splat      v2, s53
    v.movi       v3, #0
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v8, #3
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s54, x8dot_done_44
    s.addi       s55, s31, #256
    s.add        s56, s8, s17
    s.addi       s57, s49, #0
    v.ld.w       v2, [s55, #0]
    s.addi       s49, s56, #32
    s.addi       s55, s31, #768
x8dot_row_45:
    s.addi       s56, s33, #-32
    v.movi       v3, #0
    s.sub        s58, s56, s57
    s.add        s56, s49, s57
    v.splat      v16, s58
    s.shli       s58, s57, #4
    s.addi       s59, s57, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s56, v2]              // index is in elements (ISA sec 9.1)
    s.add        s56, s55, s58
    s.movz       s58, #32
    v.st.b       [s56, #0], v3
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s56, s57, s58
    br.nz        s56, x8dot_row_45
x8dot_done_44:
    v.splat      v2, s54
    v.movi       v3, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v8, #4
    s.movz       s56, #32
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s55, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s55
    mb.wait      s55
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_46
    s.addi       s58, s31, #320
    s.add        s59, s8, s17
    s.addi       s60, s54, #0
    v.ld.w       v2, [s58, #0]
    s.addi       s58, s59, #32
    s.addi       s59, s31, #1280
x8dot_row_47:
    s.addi       s6, s33, #-32
    v.movi       v3, #0
    s.sub        s23, s6, s60
    s.add        s6, s58, s60
    v.splat      v16, s23
    s.shli       s23, s60, #4
    s.addi       s29, s60, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s6, v2]               // index is in elements (ISA sec 9.1)
    s.add        s6, s59, s23
    v.st.b       [s6, #0], v3
    fence.acq_rel.device
    s.mov        s60, s29
    s.cmp.lt     s6, s60, s56
    br.nz        s6, x8dot_row_47
x8dot_done_46:
    v.splat      v2, s57
    v.movi       v3, #0
    mb.arm       s6, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    v.extract    s23, v8, #5
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s29, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s29, s6             // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s6           // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s29, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s23
    mb.wait      s23
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s29, x8dot_done_48
    s.addi       s30, s31, #384
    s.add        s34, s8, s17
    s.addi       s35, s54, #0
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s34, #32
    s.addi       s34, s31, #768
x8dot_row_49:
    s.addi       s36, s33, #-32
    v.movi       v3, #0
    s.sub        s37, s36, s35
    s.add        s36, s30, s35
    v.splat      v16, s37
    s.shli       s37, s35, #4
    s.addi       s38, s35, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s36, v2]              // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v3
    fence.acq_rel.device
    s.mov        s35, s38
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_49
x8dot_done_48:
    v.splat      v2, s29
    v.movi       v3, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s34, v8, #6
    s.movz       s35, #32
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s6
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_50
    s.addi       s37, s31, #448
    s.add        s38, s8, s17
    s.addi       s39, s30, #0
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s38, #32
    s.addi       s38, s31, #1280
x8dot_row_51:
    s.addi       s40, s33, #-32
    v.movi       v3, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v16, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s40, v2]              // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    v.st.b       [s40, #0], v3
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s35
    br.nz        s40, x8dot_row_51
x8dot_done_50:
    v.splat      v2, s36
    v.movi       v3, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v8, #7
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s38, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_52
    s.addi       s38, s31, #0
    s.add        s39, s8, s17
    s.addi       s40, s30, #0
    v.ld.w       v2, [s38, #0]
    s.addi       s30, s39, #64
    s.addi       s38, s31, #768
x8dot_row_53:
    s.addi       s39, s33, #-64
    v.movi       v3, #0
    s.sub        s41, s39, s40
    s.add        s39, s30, s40
    v.splat      v16, s41
    s.shli       s41, s40, #4
    s.addi       s42, s40, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s39, v2]              // index is in elements (ISA sec 9.1)
    s.add        s39, s38, s41
    s.movz       s41, #32
    v.st.b       [s39, #0], v3
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s39, s40, s41
    br.nz        s39, x8dot_row_53
x8dot_done_52:
    v.splat      v2, s37
    v.movi       v3, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v8, #0
    s.movz       s39, #64
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_54
    s.addi       s41, s31, #64
    s.add        s42, s8, s17
    s.addi       s43, s37, #0
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s42, #64
    s.addi       s42, s31, #1280
x8dot_row_55:
    s.addi       s44, s33, #-64
    v.movi       v3, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v16, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s44, v2]              // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v3
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_55
x8dot_done_54:
    s.add        s41, s37, s25                   // the tile origin
    v.extract    s42, v5, #0
    v.splat      v2, s41
    s.add        s41, s42, s15
    s.add        s42, s37, s32                   // the tile origin
    v.splat      v3, s40
    v.movi       v16, #0
    s.addi       s40, s41, #64
    v.add        v17, v14, v2
    v.splat      v2, s42
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v8, #1
    s.add        s43, s9, s40
    v.cmp.ne     p1, v3, v16
    v.cmp.eq     p2, v3, v16
    v.cmp.lt     p3, v17, v2
    s.mov        s44, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s44, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s41          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s43, #0]
    v.extract    s37, v5, #1
    s.addi       s39, s31, #3328                 // 512 bytes of repack scratch
    s.add        s40, s37, s15
    s.addi       s37, s39, #0
    s.addi       s42, s40, #64
    v.extract    s40, v5, #2
    s.add        s43, s9, s42
    s.add        s42, s40, s15
    s.addi       s40, s39, #32
    s.addi       s44, s42, #64
    v.extract    s42, v5, #3
    v.st.b       [s37, #0], v2
    s.add        s37, s9, s44
    s.add        s44, s42, s15
    s.addi       s42, s39, #64
    s.addi       s45, s44, #64
    v.extract    s44, v5, #4
    s.add        s46, s9, s45
    s.add        s45, s44, s15
    s.addi       s44, s39, #96
    s.addi       s47, s45, #64
    s.add        s45, s9, s47
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s43, #0]
    v.extract    s43, v5, #5
    s.add        s47, s43, s15
    s.addi       s43, s47, #64
    s.add        s47, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    v.extract    s37, v5, #6
    s.add        s43, s37, s15
    s.addi       s37, s43, #64
    s.add        s43, s9, s37
    v.st.b       [s42, #0], v2
    s.addi       s37, s39, #160
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s46, #0]
    v.extract    s42, v5, #7
    s.add        s46, s42, s15
    s.addi       s42, s46, #64
    s.add        s46, s9, s42
    v.st.b       [s44, #0], v2
    s.addi       s42, s39, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s45, #0]
    v.extract    s44, v5, #8
    s.add        s45, s44, s15
    s.addi       s44, s45, #64
    s.add        s45, s9, s44
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #224
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s47, #0]
    v.extract    s44, v5, #9
    s.add        s47, s44, s15
    s.addi       s44, s47, #64
    s.add        s47, s9, s44
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s43, #0]
    v.extract    s43, v5, #10
    s.add        s44, s43, s15
    s.addi       s43, s44, #64
    s.add        s44, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #288
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s46, #0]
    v.extract    s43, v5, #11
    s.add        s46, s43, s15
    s.addi       s43, s46, #64
    s.add        s46, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s45, #0]
    v.extract    s43, v5, #12
    s.add        s45, s43, s15
    s.addi       s43, s45, #64
    s.add        s45, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #352
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s47, #0]
    v.extract    s43, v5, #13
    s.add        s47, s43, s15
    s.addi       s43, s47, #64
    s.add        s47, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s44, #0]
    v.extract    s43, v5, #14
    s.add        s44, s43, s15
    s.addi       s43, s44, #64
    s.add        s44, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #416
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s46, #0]
    v.extract    s43, v5, #15
    s.add        s46, s43, s15
    s.addi       s43, s46, #64
    s.add        s46, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s45, #0]
    s.movz       s43, #0
    v.st.b       [s42, #0], v2
    s.add        s42, s43, s26                   // the tile origin
    s.add        s45, s43, s32                   // the tile origin
    v.splat      v2, s42
    v.extract    s42, v5, #0
    v.splat      v3, s45
    s.add        s43, s42, s15
    v.add        v16, v14, v2
    s.addi       s42, s43, #80
    s.addi       s43, s39, #480
    s.add        s45, s9, s42
    v.cmp.lt     p1, v16, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s47, #0]
    v.extract    s42, v5, #1
    s.add        s47, s42, s15
    s.addi       s42, s47, #80
    s.add        s47, s9, s42
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #16
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s44, #0]
    v.extract    s42, v5, #2
    s.add        s44, s42, s15
    s.addi       s42, s44, #80
    s.add        s44, s9, s42
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #48
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s46, #0]
    v.extract    s42, v5, #3
    s.add        s46, s42, s15
    s.addi       s42, s46, #80
    s.add        s46, s9, s42
    v.st.b       [s43, #0], v2
    s.addi       s42, s39, #80
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s45, #0]
    v.extract    s43, v5, #4
    s.add        s45, s43, s15
    s.addi       s43, s45, #80
    s.add        s45, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s47, #0]
    v.extract    s43, v5, #5
    s.add        s47, s43, s15
    s.addi       s43, s47, #80
    s.add        s47, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #144
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s44, #0]
    v.extract    s43, v5, #6
    s.add        s44, s43, s15
    s.addi       s43, s44, #80
    s.add        s44, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #176
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s46, #0]
    v.extract    s43, v5, #7
    s.add        s46, s43, s15
    s.addi       s43, s46, #80
    s.add        s46, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #208
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s45, #0]
    v.extract    s43, v5, #8
    s.add        s45, s43, s15
    s.addi       s43, s45, #80
    s.add        s45, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #240
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s47, #0]
    v.extract    s43, v5, #9
    s.add        s47, s43, s15
    s.addi       s43, s47, #80
    s.add        s47, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #272
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s44, #0]
    v.extract    s43, v5, #10
    s.add        s44, s43, s15
    s.addi       s43, s44, #80
    s.add        s44, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #304
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s46, #0]
    v.extract    s43, v5, #11
    s.add        s46, s43, s15
    s.addi       s43, s46, #80
    s.add        s46, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #336
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s45, #0]
    v.extract    s43, v5, #12
    s.add        s45, s43, s15
    s.addi       s43, s45, #80
    s.add        s45, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #368
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s47, #0]
    v.extract    s43, v5, #13
    s.add        s47, s43, s15
    s.addi       s43, s47, #80
    s.add        s47, s9, s43
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #400
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s44, #0]
    v.extract    s43, v5, #14
    s.add        s44, s43, s15
    s.addi       s43, s44, #80
    s.add        s44, s9, s43
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #432
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s46, #0]
    v.extract    s43, v5, #15
    s.add        s46, s43, s15
    s.addi       s43, s46, #80
    s.add        s46, s9, s43
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #464
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s45, #0]
    s.addi       s43, s39, #496
    v.st.b       [s40, #0], v2
    s.addi       s40, s39, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s47, #0]
    s.addi       s45, s39, #128
    v.st.b       [s37, #0], v2
    s.addi       s37, s39, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s44, #0]
    s.addi       s44, s39, #256
    v.st.b       [s42, #0], v2
    s.addi       s42, s39, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s46, #0]
    s.addi       s46, s39, #384
    v.st.b       [s43, #0], v2
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s43, s39, #448
    v.ld.w       v2, [s39, #0]
    v.extract    s39, v4, #2
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s40, #0]
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s45, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s37, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s44, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s42, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s46, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s43, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s30
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s39, x8dot_done_56
    s.movz       s40, #0
    s.addi       s42, s31, #128
    s.add        s43, s8, s17
    s.addi       s44, s40, #0
    v.ld.w       v2, [s42, #0]
    s.addi       s40, s43, #64
    s.addi       s42, s31, #768
x8dot_row_57:
    s.addi       s43, s33, #-64
    v.movi       v3, #0
    s.sub        s45, s43, s44
    s.add        s43, s40, s44
    v.splat      v16, s45
    s.shli       s45, s44, #4
    s.addi       s46, s44, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s43, v2]              // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s45
    s.movz       s45, #32
    v.st.b       [s43, #0], v3
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s43, s44, s45
    br.nz        s43, x8dot_row_57
x8dot_done_56:
    v.splat      v2, s39
    v.movi       v3, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s42, v8, #2
    s.movz       s43, #64
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_58
    s.addi       s45, s31, #192
    s.add        s46, s8, s17
    s.addi       s47, s40, #0
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s46, #64
    s.addi       s46, s31, #1280
x8dot_row_59:
    s.addi       s48, s33, #-64
    v.movi       v3, #0
    s.sub        s50, s48, s47
    s.add        s48, s45, s47
    v.splat      v16, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s48, v2]              // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v3
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_59
x8dot_done_58:
    v.splat      v2, s44
    v.movi       v3, #0
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s45, v8, #3
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s43
    mb.wait      s43
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_60
    s.addi       s46, s31, #256
    s.add        s47, s8, s17
    s.addi       s48, s40, #0
    v.ld.w       v2, [s46, #0]
    s.addi       s40, s47, #64
    s.addi       s46, s31, #768
x8dot_row_61:
    s.addi       s47, s33, #-64
    v.movi       v3, #0
    s.sub        s50, s47, s48
    s.add        s47, s40, s48
    v.splat      v16, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s47, v2]              // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s50
    s.movz       s50, #32
    v.st.b       [s47, #0], v3
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s47, s48, s50
    br.nz        s47, x8dot_row_61
x8dot_done_60:
    v.splat      v2, s45
    v.movi       v3, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v8, #4
    s.movz       s47, #64
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s48, x8dot_done_62
    s.addi       s50, s31, #320
    s.add        s51, s8, s17
    s.addi       s52, s45, #0
    v.ld.w       v2, [s50, #0]
    s.addi       s50, s51, #64
    s.addi       s51, s31, #1280
x8dot_row_63:
    s.addi       s53, s33, #-64
    v.movi       v3, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v16, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s53, v2]              // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v3
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_63
x8dot_done_62:
    v.splat      v2, s48
    v.movi       v3, #0
    mb.arm       s48, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v8, #5
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s51, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s47
    mb.wait      s47
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s50, x8dot_done_64
    s.addi       s51, s31, #384
    s.add        s52, s8, s17
    s.addi       s53, s45, #0
    v.ld.w       v2, [s51, #0]
    s.addi       s45, s52, #64
    s.addi       s51, s31, #768
x8dot_row_65:
    s.addi       s52, s33, #-64
    v.movi       v3, #0
    s.sub        s54, s52, s53
    s.add        s52, s45, s53
    v.splat      v16, s54
    s.shli       s54, s53, #4
    s.addi       s55, s53, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s52, v2]              // index is in elements (ISA sec 9.1)
    s.add        s52, s51, s54
    s.movz       s54, #32
    v.st.b       [s52, #0], v3
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s52, s53, s54
    br.nz        s52, x8dot_row_65
x8dot_done_64:
    v.splat      v2, s50
    v.movi       v3, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v8, #6
    s.movz       s52, #64
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s51
    mb.wait      s51
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_66
    s.addi       s54, s31, #448
    s.add        s55, s8, s17
    s.addi       s56, s50, #0
    v.ld.w       v2, [s54, #0]
    s.addi       s54, s55, #64
    s.addi       s55, s31, #1280
x8dot_row_67:
    s.addi       s57, s33, #-64
    v.movi       v3, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v16, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s57, v2]              // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v3
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_67
x8dot_done_66:
    v.splat      v2, s53
    v.movi       v3, #0
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v8, #7
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s54, x8dot_done_68
    s.addi       s55, s31, #0
    s.add        s56, s8, s17
    s.addi       s57, s50, #0
    v.ld.w       v2, [s55, #0]
    s.addi       s50, s56, #96
    s.addi       s55, s31, #768
x8dot_row_69:
    s.addi       s56, s33, #-96
    v.movi       v3, #0
    s.sub        s58, s56, s57
    s.add        s56, s50, s57
    v.splat      v16, s58
    s.shli       s58, s57, #4
    s.addi       s59, s57, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s56, v2]              // index is in elements (ISA sec 9.1)
    s.add        s56, s55, s58
    s.movz       s58, #32
    v.st.b       [s56, #0], v3
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s56, s57, s58
    br.nz        s56, x8dot_row_69
x8dot_done_68:
    v.splat      v2, s54
    v.movi       v3, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v8, #0
    s.movz       s56, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s55, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s55
    mb.wait      s55
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_70
    s.addi       s58, s31, #64
    s.add        s59, s8, s17
    s.addi       s60, s54, #0
    v.ld.w       v2, [s58, #0]
    s.addi       s58, s59, #96
    s.addi       s59, s31, #1280
x8dot_row_71:
    s.addi       s6, s33, #-96
    v.movi       v3, #0
    s.sub        s23, s6, s60
    s.add        s6, s58, s60
    v.splat      v16, s23
    s.shli       s23, s60, #4
    s.addi       s29, s60, #1
    v.cmp.gt     p1, v16, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s6, v2]               // index is in elements (ISA sec 9.1)
    s.add        s6, s59, s23
    s.movz       s23, #32
    v.st.b       [s6, #0], v3
    fence.acq_rel.device
    s.mov        s60, s29
    s.cmp.lt     s6, s60, s23
    br.nz        s6, x8dot_row_71
x8dot_done_70:
    s.add        s6, s54, s27                    // the tile origin
    v.extract    s23, v5, #0
    v.splat      v2, s6
    s.add        s6, s23, s15
    s.add        s23, s54, s32                   // the tile origin
    v.splat      v3, s57
    v.movi       v16, #0
    s.addi       s29, s6, #96
    v.add        v17, v14, v2
    v.splat      v2, s23
    mb.arm       s6, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    v.extract    s23, v8, #1
    s.add        s30, s9, s29
    v.cmp.ne     p1, v3, v16
    v.cmp.eq     p2, v3, v16
    v.cmp.lt     p3, v17, v2
    s.mov        s34, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s34, s6             // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s6           // predicated off still completes once (ISA sec 9A.3)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s30, #0]
    v.extract    s23, v5, #1
    s.addi       s29, s31, #3840                 // 512 bytes of repack scratch
    s.add        s30, s23, s15
    s.addi       s23, s29, #0
    s.addi       s34, s30, #96
    v.extract    s30, v5, #2
    s.add        s35, s9, s34
    s.add        s34, s30, s15
    s.addi       s30, s29, #32
    s.addi       s36, s34, #96
    v.extract    s34, v5, #3
    v.st.b       [s23, #0], v2
    s.add        s23, s9, s36
    s.add        s36, s34, s15
    s.addi       s34, s29, #64
    s.addi       s37, s36, #96
    v.extract    s36, v5, #4
    s.add        s38, s9, s37
    s.add        s37, s36, s15
    s.addi       s36, s29, #96
    s.addi       s39, s37, #96
    s.add        s37, s9, s39
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #5
    s.add        s39, s35, s15
    s.addi       s35, s39, #96
    s.add        s39, s9, s35
    v.st.b       [s30, #0], v2
    s.addi       s30, s29, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s23, #0]
    v.extract    s23, v5, #6
    s.add        s35, s23, s15
    s.addi       s23, s35, #96
    s.add        s35, s9, s23
    v.st.b       [s34, #0], v2
    s.addi       s23, s29, #160
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s34, v5, #7
    s.add        s38, s34, s15
    s.addi       s34, s38, #96
    s.add        s38, s9, s34
    v.st.b       [s36, #0], v2
    s.addi       s34, s29, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    v.extract    s36, v5, #8
    s.add        s37, s36, s15
    s.addi       s36, s37, #96
    s.add        s37, s9, s36
    v.st.b       [s30, #0], v2
    s.addi       s30, s29, #224
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s39, #0]
    v.extract    s36, v5, #9
    s.add        s39, s36, s15
    s.addi       s36, s39, #96
    s.add        s39, s9, s36
    v.st.b       [s23, #0], v2
    s.addi       s23, s29, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s35, #0]
    v.extract    s35, v5, #10
    s.add        s36, s35, s15
    s.addi       s35, s36, #96
    s.add        s36, s9, s35
    v.st.b       [s34, #0], v2
    s.addi       s34, s29, #288
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s35, v5, #11
    s.add        s38, s35, s15
    s.addi       s35, s38, #96
    s.add        s38, s9, s35
    v.st.b       [s30, #0], v2
    s.addi       s30, s29, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    v.extract    s35, v5, #12
    s.add        s37, s35, s15
    s.addi       s35, s37, #96
    s.add        s37, s9, s35
    v.st.b       [s23, #0], v2
    s.addi       s23, s29, #352
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s39, #0]
    v.extract    s35, v5, #13
    s.add        s39, s35, s15
    s.addi       s35, s39, #96
    s.add        s39, s9, s35
    v.st.b       [s34, #0], v2
    s.addi       s34, s29, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s36, #0]
    v.extract    s35, v5, #14
    s.add        s36, s35, s15
    s.addi       s35, s36, #96
    s.add        s36, s9, s35
    v.st.b       [s30, #0], v2
    s.addi       s30, s29, #416
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    v.extract    s35, v5, #15
    s.add        s38, s35, s15
    s.addi       s35, s38, #96
    s.add        s38, s9, s35
    v.st.b       [s23, #0], v2
    s.addi       s23, s29, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s37, #0]
    s.movz       s35, #0
    s.add        s37, s35, s32                   // the tile origin
    s.add        s32, s35, s28                   // the tile origin
    v.splat      v3, s37
    v.extract    s35, v5, #0
    v.splat      v16, s32
    s.add        s32, s35, s15
    s.addi       s35, s29, #480
    s.addi       s37, s32, #112
    v.add        v17, v14, v16
    v.st.b       [s34, #0], v2
    s.add        s32, s9, s37
    v.cmp.lt     p1, v17, v3
    v.extract    s34, v5, #1
    s.add        s37, s34, s15
    s.addi       s34, s37, #112
    s.add        s37, s9, s34
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s39, #0]
    s.addi       s34, s29, #16
    v.st.b       [s30, #0], v2
    v.extract    s30, v5, #2
    s.add        s39, s30, s15
    s.addi       s30, s39, #112
    s.add        s39, s9, s30
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s36, #0]
    s.addi       s30, s29, #48
    v.st.b       [s23, #0], v2
    v.extract    s23, v5, #3
    s.add        s36, s23, s15
    s.addi       s23, s36, #112
    s.add        s36, s9, s23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s38, #0]
    s.addi       s23, s29, #80
    v.st.b       [s35, #0], v2
    v.extract    s35, v5, #4
    s.add        s38, s35, s15
    s.addi       s35, s38, #112
    s.add        s38, s9, s35
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s32, #0]
    s.addi       s32, s29, #112
    v.st.b       [s34, #0], v2
    v.extract    s34, v5, #5
    s.add        s35, s34, s15
    s.addi       s34, s35, #112
    s.add        s35, s9, s34
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    s.addi       s34, s29, #144
    v.st.b       [s30, #0], v2
    v.extract    s30, v5, #6
    s.add        s37, s30, s15
    s.addi       s30, s37, #112
    s.add        s37, s9, s30
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    s.addi       s30, s29, #176
    v.st.b       [s23, #0], v2
    v.extract    s23, v5, #7
    s.add        s39, s23, s15
    s.addi       s23, s39, #112
    s.add        s39, s9, s23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s36, #0]
    s.addi       s23, s29, #208
    v.st.b       [s32, #0], v2
    v.extract    s32, v5, #8
    s.add        s36, s32, s15
    s.addi       s32, s36, #112
    s.add        s36, s9, s32
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    s.addi       s32, s29, #240
    v.st.b       [s34, #0], v2
    v.extract    s34, v5, #9
    s.add        s38, s34, s15
    s.addi       s34, s38, #112
    s.add        s38, s9, s34
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s35, #0]
    s.addi       s34, s29, #272
    v.st.b       [s30, #0], v2
    v.extract    s30, v5, #10
    s.add        s35, s30, s15
    s.addi       s30, s35, #112
    s.add        s35, s9, s30
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    s.addi       s30, s29, #304
    v.st.b       [s23, #0], v2
    v.extract    s23, v5, #11
    s.add        s37, s23, s15
    s.addi       s23, s37, #112
    s.add        s37, s9, s23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    s.addi       s23, s29, #336
    v.st.b       [s32, #0], v2
    v.extract    s32, v5, #12
    s.add        s39, s32, s15
    s.addi       s32, s39, #112
    s.add        s39, s9, s32
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s36, #0]
    s.addi       s32, s29, #368
    v.st.b       [s34, #0], v2
    v.extract    s34, v5, #13
    s.add        s36, s34, s15
    s.addi       s34, s36, #112
    s.add        s36, s9, s34
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    s.addi       s34, s29, #400
    v.st.b       [s30, #0], v2
    v.extract    s30, v5, #14
    s.add        s38, s30, s15
    s.addi       s30, s38, #112
    s.add        s38, s9, s30
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s35, #0]
    s.addi       s30, s29, #432
    v.st.b       [s23, #0], v2
    v.extract    s23, v5, #15
    s.add        s35, s23, s15
    s.addi       s23, s35, #112
    s.add        s35, s9, s23
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s37, #0]
    s.addi       s23, s29, #464
    v.st.b       [s32, #0], v2
    s.addi       s32, s29, #496
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s39, #0]
    s.addi       s37, s29, #64
    v.st.b       [s34, #0], v2
    s.addi       s34, s29, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s36, #0]
    s.addi       s36, s29, #192
    v.st.b       [s30, #0], v2
    s.addi       s30, s29, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s38, #0]
    s.addi       s38, s29, #320
    v.st.b       [s23, #0], v2
    s.addi       s23, s29, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s35, #0]
    s.addi       s35, s29, #448
    v.st.b       [s32, #0], v2
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.extract    s32, v4, #2
    v.ld.w       v2, [s29, #0]
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s37, #0]
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s34, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s36, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s30, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s38, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s23, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s35, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s50
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s23
    mb.wait      s23
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s32, x8dot_done_72
    s.movz       s29, #0
    s.addi       s30, s31, #128
    s.add        s34, s8, s17
    s.addi       s35, s29, #0
    v.ld.w       v2, [s30, #0]
    s.addi       s29, s34, #96
    s.addi       s30, s31, #768
x8dot_row_73:
    s.addi       s34, s33, #-96
    v.movi       v3, #0
    s.sub        s36, s34, s35
    s.add        s34, s29, s35
    v.splat      v5, s36
    s.shli       s36, s35, #4
    s.addi       s37, s35, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s34, v2]              // index is in elements (ISA sec 9.1)
    s.add        s34, s30, s36
    s.movz       s36, #32
    v.st.b       [s34, #0], v3
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s34, s35, s36
    br.nz        s34, x8dot_row_73
x8dot_done_72:
    v.splat      v2, s32
    v.movi       v3, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s32, v8, #2
    s.movz       s34, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s6
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_74
    s.addi       s36, s31, #192
    s.add        s37, s8, s17
    s.addi       s38, s30, #0
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s37, #96
    s.addi       s37, s31, #1280
x8dot_row_75:
    s.addi       s39, s33, #-96
    v.movi       v3, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v5, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s39, v2]              // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v3
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_75
x8dot_done_74:
    v.splat      v2, s35
    v.movi       v3, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s36, v8, #3
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_76
    s.addi       s37, s31, #256
    s.add        s38, s8, s17
    s.addi       s39, s30, #0
    v.ld.w       v2, [s37, #0]
    s.addi       s30, s38, #96
    s.addi       s37, s31, #768
x8dot_row_77:
    s.addi       s38, s33, #-96
    v.movi       v3, #0
    s.sub        s40, s38, s39
    s.add        s38, s30, s39
    v.splat      v5, s40
    s.shli       s40, s39, #4
    s.addi       s41, s39, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s38, v2]              // index is in elements (ISA sec 9.1)
    s.add        s38, s37, s40
    s.movz       s40, #32
    v.st.b       [s38, #0], v3
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s38, s39, s40
    br.nz        s38, x8dot_row_77
x8dot_done_76:
    v.splat      v2, s36
    v.movi       v3, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v8, #4
    s.movz       s38, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_78
    s.addi       s40, s31, #320
    s.add        s41, s8, s17
    s.addi       s42, s36, #0
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s41, #96
    s.addi       s41, s31, #1280
x8dot_row_79:
    s.addi       s43, s33, #-96
    v.movi       v3, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v5, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s43, v2]              // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v3
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_79
x8dot_done_78:
    v.splat      v2, s39
    v.movi       v3, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v8, #5
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_80
    s.addi       s41, s31, #384
    s.add        s42, s8, s17
    s.addi       s43, s36, #0
    v.ld.w       v2, [s41, #0]
    s.addi       s36, s42, #96
    s.addi       s41, s31, #768
x8dot_row_81:
    s.addi       s42, s33, #-96
    v.movi       v3, #0
    s.sub        s44, s42, s43
    s.add        s42, s36, s43
    v.splat      v5, s44
    s.shli       s44, s43, #4
    s.addi       s45, s43, #1
    v.cmp.gt     p1, v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s42, v2]              // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.movz       s44, #32
    v.st.b       [s42, #0], v3
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s42, s43, s44
    br.nz        s42, x8dot_row_81
x8dot_done_80:
    v.splat      v2, s40
    v.movi       v3, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v8, #6
    s.movz       s42, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_82
    s.addi       s44, s31, #448
    s.add        s45, s8, s17
    s.addi       s46, s40, #0
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s45, #96
    s.addi       s45, s31, #1280
x8dot_row_83:
    s.addi       s47, s33, #-96
    v.movi       v3, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v4, s48
    s.shli       s48, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v4, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s47, v2]              // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v3
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s48
    br.nz        s47, x8dot_row_83
x8dot_done_82:
    v.splat      v2, s43
    v.movi       v3, #0
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s43, v8, #7
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v2, v3
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s44, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s43, s31, #4352
    s.movz       s44, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s42
    mb.wait      s42
    mb.wait      s33
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s46, s43, #64
    s.movz       s47, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    a.vread      v2, a8, s40
    s.addi       s40, s43, #128
    s.movz       s48, #3
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s44, s43, #192
    s.movz       s49, #4
    s.addi       s51, s43, #256
    s.movz       s52, #5
    s.addi       s53, s43, #320
    s.movz       s54, #6
    s.addi       s55, s43, #384
    s.movz       s56, #7
    s.addi       s57, s43, #448
    s.movz       s58, #8
    s.addi       s59, s43, #512
    s.movz       s60, #9
    s.addi       s6, s43, #576
    s.movz       s23, #10
    v.st.w       [s46, #0], v2
    a.vread      v2, a8, s47
    s.addi       s29, s43, #640
    s.movz       s30, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s48
    s.addi       s32, s43, #704
    s.movz       s33, #12
    v.st.w       [s44, #0], v2
    a.vread      v2, a8, s49
    s.addi       s34, s43, #768
    s.movz       s35, #13
    v.st.w       [s51, #0], v2
    a.vread      v2, a8, s52
    s.addi       s36, s43, #832
    s.movz       s37, #14
    v.st.w       [s53, #0], v2
    a.vread      v2, a8, s54
    s.addi       s38, s43, #896
    s.movz       s39, #15
    s.addi       s40, s43, #960
    v.st.w       [s55, #0], v2
    a.vread      v2, a8, s56
    s.movz       s41, #0
    s.addi       s42, s31, #5376
    v.st.w       [s57, #0], v2
    a.vread      v2, a8, s58
    s.movz       s43, #1
    s.addi       s44, s42, #64
    v.st.w       [s59, #0], v2
    a.vread      v2, a8, s60
    s.movz       s45, #2
    s.addi       s46, s42, #128
    v.st.w       [s6, #0], v2
    a.vread      v2, a8, s23
    s.movz       s6, #3
    s.addi       s23, s42, #192
    v.st.w       [s29, #0], v2
    a.vread      v2, a8, s30
    s.movz       s29, #4
    s.addi       s30, s42, #256
    v.st.w       [s32, #0], v2
    a.vread      v2, a8, s33
    s.movz       s32, #5
    s.addi       s33, s42, #320
    v.st.w       [s34, #0], v2
    a.vread      v2, a8, s35
    s.movz       s34, #6
    s.addi       s35, s42, #384
    v.st.w       [s36, #0], v2
    a.vread      v2, a8, s37
    s.movz       s36, #7
    s.addi       s37, s42, #448
    v.st.w       [s38, #0], v2
    a.vread      v2, a8, s39
    s.movz       s38, #8
    s.addi       s39, s42, #512
    v.st.w       [s40, #0], v2
    fence.acq_rel.device
    a.vread      v2, a9, s41
    s.movz       s40, #9
    s.addi       s41, s42, #576
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.movz       s43, #10
    v.st.w       [s44, #0], v2
    a.vread      v2, a9, s45
    s.addi       s44, s42, #640
    s.movz       s45, #11
    v.st.w       [s46, #0], v2
    a.vread      v2, a9, s6
    s.addi       s6, s42, #704
    s.movz       s46, #12
    v.st.w       [s23, #0], v2
    a.vread      v2, a9, s29
    s.addi       s23, s42, #768
    s.movz       s29, #13
    v.st.w       [s30, #0], v2
    a.vread      v2, a9, s32
    s.addi       s30, s42, #832
    s.movz       s32, #14
    v.st.w       [s33, #0], v2
    a.vread      v2, a9, s34
    s.addi       s33, s42, #896
    s.movz       s34, #15
    s.addi       s47, s42, #960
    v.st.w       [s35, #0], v2
    a.vread      v2, a9, s36
    s.movz       s35, #0
    s.addi       s36, s31, #6400
    v.st.w       [s37, #0], v2
    a.vread      v2, a9, s38
    s.movz       s37, #1
    s.addi       s38, s36, #64
    v.st.w       [s39, #0], v2
    a.vread      v2, a9, s40
    s.movz       s39, #2
    s.addi       s40, s36, #128
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s43
    s.movz       s41, #3
    s.addi       s42, s36, #192
    v.st.w       [s44, #0], v2
    a.vread      v2, a9, s45
    s.movz       s43, #4
    s.addi       s44, s36, #256
    v.st.w       [s6, #0], v2
    a.vread      v2, a9, s46
    s.movz       s6, #5
    s.addi       s45, s36, #320
    v.st.w       [s23, #0], v2
    a.vread      v2, a9, s29
    s.movz       s23, #6
    s.addi       s29, s36, #384
    v.st.w       [s30, #0], v2
    a.vread      v2, a9, s32
    s.movz       s30, #7
    s.addi       s32, s36, #448
    v.st.w       [s33, #0], v2
    a.vread      v2, a9, s34
    s.movz       s33, #8
    s.addi       s34, s36, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a10, s35
    s.movz       s35, #9
    s.addi       s46, s36, #576
    v.st.w       [s36, #0], v2
    a.vread      v2, a10, s37
    s.movz       s37, #10
    v.st.w       [s38, #0], v2
    a.vread      v2, a10, s39
    s.addi       s38, s36, #640
    s.movz       s39, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s41
    s.addi       s40, s36, #704
    s.movz       s41, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s43
    s.addi       s42, s36, #768
    s.movz       s43, #13
    v.st.w       [s44, #0], v2
    a.vread      v2, a10, s6
    s.addi       s6, s36, #832
    s.movz       s44, #14
    v.st.w       [s45, #0], v2
    a.vread      v2, a10, s23
    s.addi       s23, s36, #896
    s.movz       s45, #15
    s.addi       s47, s36, #960
    v.st.w       [s29, #0], v2
    a.vread      v2, a10, s30
    s.movz       s29, #0
    s.addi       s30, s31, #7424
    v.st.w       [s32, #0], v2
    a.vread      v2, a10, s33
    s.movz       s32, #1
    s.addi       s33, s30, #64
    v.st.w       [s34, #0], v2
    a.vread      v2, a10, s35
    s.movz       s34, #2
    s.addi       s35, s30, #128
    v.st.w       [s46, #0], v2
    a.vread      v2, a10, s37
    s.movz       s36, #3
    s.addi       s37, s30, #192
    v.st.w       [s38, #0], v2
    a.vread      v2, a10, s39
    s.movz       s38, #4
    s.addi       s39, s30, #256
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s41
    s.movz       s40, #5
    s.addi       s41, s30, #320
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s43
    s.movz       s42, #6
    s.addi       s43, s30, #384
    v.st.w       [s6, #0], v2
    a.vread      v2, a10, s44
    s.movz       s6, #7
    s.addi       s44, s30, #448
    v.st.w       [s23, #0], v2
    a.vread      v2, a10, s45
    s.movz       s23, #8
    s.addi       s45, s30, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a11, s29
    s.movz       s29, #9
    s.addi       s46, s30, #576
    v.st.w       [s30, #0], v2
    a.vread      v2, a11, s32
    s.movz       s32, #10
    v.st.w       [s33, #0], v2
    a.vread      v2, a11, s34
    s.addi       s33, s30, #640
    s.movz       s34, #11
    v.st.w       [s35, #0], v2
    a.vread      v2, a11, s36
    s.addi       s35, s30, #704
    s.movz       s36, #12
    v.st.w       [s37, #0], v2
    a.vread      v2, a11, s38
    s.addi       s37, s30, #768
    s.movz       s38, #13
    v.st.w       [s39, #0], v2
    a.vread      v2, a11, s40
    s.addi       s39, s30, #832
    s.movz       s40, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s42
    s.addi       s41, s30, #896
    s.movz       s42, #15
    s.addi       s47, s30, #960
    v.st.w       [s43, #0], v2
    a.vread      v2, a11, s6
    s.movz       s6, #0
    s.addi       s30, s31, #8448
    v.st.w       [s44, #0], v2
    a.vread      v2, a11, s23
    s.movz       s23, #1
    s.addi       s43, s30, #64
    v.st.w       [s45, #0], v2
    a.vread      v2, a11, s29
    s.movz       s29, #2
    s.addi       s44, s30, #128
    v.st.w       [s46, #0], v2
    a.vread      v2, a11, s32
    s.movz       s32, #3
    s.addi       s45, s30, #192
    v.st.w       [s33, #0], v2
    a.vread      v2, a11, s34
    s.movz       s33, #4
    s.addi       s34, s30, #256
    v.st.w       [s35, #0], v2
    a.vread      v2, a11, s36
    s.movz       s35, #5
    s.addi       s36, s30, #320
    v.st.w       [s37, #0], v2
    a.vread      v2, a11, s38
    s.movz       s37, #6
    s.addi       s38, s30, #384
    v.st.w       [s39, #0], v2
    a.vread      v2, a11, s40
    s.movz       s39, #7
    s.addi       s40, s30, #448
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s42
    s.movz       s41, #8
    s.addi       s42, s30, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a12, s6
    s.movz       s6, #9
    s.addi       s46, s30, #576
    v.st.w       [s30, #0], v2
    a.vread      v2, a12, s23
    s.movz       s23, #10
    v.st.w       [s43, #0], v2
    a.vread      v2, a12, s29
    s.addi       s29, s30, #640
    s.movz       s43, #11
    v.st.w       [s44, #0], v2
    a.vread      v2, a12, s32
    s.addi       s32, s30, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v2
    a.vread      v2, a12, s33
    s.addi       s33, s30, #768
    s.movz       s45, #13
    v.st.w       [s34, #0], v2
    a.vread      v2, a12, s35
    s.addi       s34, s30, #832
    s.movz       s35, #14
    v.st.w       [s36, #0], v2
    a.vread      v2, a12, s37
    s.addi       s36, s30, #896
    s.movz       s37, #15
    s.addi       s47, s30, #960
    v.st.w       [s38, #0], v2
    a.vread      v2, a12, s39
    s.movz       s30, #0
    s.addi       s38, s31, #9472
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s41
    s.movz       s39, #1
    s.addi       s40, s38, #64
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s6
    s.movz       s6, #2
    s.addi       s41, s38, #128
    v.st.w       [s46, #0], v2
    a.vread      v2, a12, s23
    s.movz       s23, #3
    s.addi       s42, s38, #192
    v.st.w       [s29, #0], v2
    a.vread      v2, a12, s43
    s.movz       s29, #4
    s.addi       s43, s38, #256
    v.st.w       [s32, #0], v2
    a.vread      v2, a12, s44
    s.movz       s32, #5
    s.addi       s44, s38, #320
    v.st.w       [s33, #0], v2
    a.vread      v2, a12, s45
    s.movz       s33, #6
    s.addi       s45, s38, #384
    v.st.w       [s34, #0], v2
    a.vread      v2, a12, s35
    s.movz       s34, #7
    s.addi       s35, s38, #448
    v.st.w       [s36, #0], v2
    a.vread      v2, a12, s37
    s.movz       s36, #8
    s.addi       s37, s38, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a13, s30
    s.movz       s30, #9
    s.addi       s46, s38, #576
    v.st.w       [s38, #0], v2
    a.vread      v2, a13, s39
    s.movz       s39, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s6
    s.addi       s6, s38, #640
    s.movz       s40, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s23
    s.addi       s23, s38, #704
    s.movz       s41, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s29
    s.addi       s29, s38, #768
    s.movz       s42, #13
    v.st.w       [s43, #0], v2
    a.vread      v2, a13, s32
    s.addi       s32, s38, #832
    s.movz       s43, #14
    v.st.w       [s44, #0], v2
    a.vread      v2, a13, s33
    s.addi       s33, s38, #896
    s.movz       s44, #15
    s.addi       s47, s38, #960
    v.st.w       [s45, #0], v2
    a.vread      v2, a13, s34
    s.movz       s34, #0
    s.addi       s38, s31, #10496
    v.st.w       [s35, #0], v2
    a.vread      v2, a13, s36
    s.movz       s35, #1
    s.addi       s36, s38, #64
    v.st.w       [s37, #0], v2
    a.vread      v2, a13, s30
    s.movz       s30, #2
    s.addi       s37, s38, #128
    v.st.w       [s46, #0], v2
    a.vread      v2, a13, s39
    s.movz       s39, #3
    s.addi       s45, s38, #192
    v.st.w       [s6, #0], v2
    a.vread      v2, a13, s40
    s.movz       s6, #4
    s.addi       s40, s38, #256
    v.st.w       [s23, #0], v2
    a.vread      v2, a13, s41
    s.movz       s23, #5
    s.addi       s41, s38, #320
    v.st.w       [s29, #0], v2
    a.vread      v2, a13, s42
    s.movz       s29, #6
    s.addi       s42, s38, #384
    v.st.w       [s32, #0], v2
    a.vread      v2, a13, s43
    s.movz       s32, #7
    s.addi       s43, s38, #448
    v.st.w       [s33, #0], v2
    a.vread      v2, a13, s44
    s.movz       s33, #8
    s.addi       s44, s38, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a14, s34
    s.movz       s34, #9
    s.addi       s46, s38, #576
    v.st.w       [s38, #0], v2
    a.vread      v2, a14, s35
    s.movz       s35, #10
    v.st.w       [s36, #0], v2
    a.vread      v2, a14, s30
    s.addi       s30, s38, #640
    s.movz       s36, #11
    v.st.w       [s37, #0], v2
    a.vread      v2, a14, s39
    s.addi       s37, s38, #704
    s.movz       s39, #12
    v.st.w       [s45, #0], v2
    a.vread      v2, a14, s6
    s.addi       s6, s38, #768
    s.movz       s45, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s23
    s.addi       s23, s38, #832
    s.movz       s40, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s29
    s.addi       s29, s38, #896
    s.movz       s41, #15
    s.addi       s47, s38, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s32
    s.movz       s32, #0
    s.addi       s38, s31, #11520
    v.st.w       [s43, #0], v2
    a.vread      v2, a14, s33
    s.movz       s33, #1
    s.addi       s42, s38, #64
    v.st.w       [s44, #0], v2
    a.vread      v2, a14, s34
    s.movz       s34, #2
    s.addi       s43, s38, #128
    v.st.w       [s46, #0], v2
    a.vread      v2, a14, s35
    s.movz       s35, #3
    s.addi       s44, s38, #192
    v.st.w       [s30, #0], v2
    a.vread      v2, a14, s36
    s.movz       s30, #4
    s.addi       s36, s38, #256
    v.st.w       [s37, #0], v2
    a.vread      v2, a14, s39
    s.movz       s37, #5
    s.addi       s39, s38, #320
    v.st.w       [s6, #0], v2
    a.vread      v2, a14, s45
    s.movz       s6, #6
    s.addi       s45, s38, #384
    v.st.w       [s23, #0], v2
    a.vread      v2, a14, s40
    s.movz       s23, #7
    s.addi       s40, s38, #448
    v.st.w       [s29, #0], v2
    a.vread      v2, a14, s41
    s.movz       s29, #8
    s.addi       s41, s38, #512
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a15, s32
    s.movz       s32, #9
    s.addi       s46, s38, #576
    v.st.w       [s38, #0], v2
    a.vread      v2, a15, s33
    s.movz       s33, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s34
    s.addi       s34, s38, #640
    s.movz       s42, #11
    v.st.w       [s43, #0], v2
    a.vread      v2, a15, s35
    s.addi       s35, s38, #704
    s.movz       s43, #12
    v.st.w       [s44, #0], v2
    a.vread      v2, a15, s30
    s.addi       s30, s38, #768
    s.movz       s44, #13
    v.st.w       [s36, #0], v2
    a.vread      v2, a15, s37
    s.addi       s36, s38, #832
    s.movz       s37, #14
    v.st.w       [s39, #0], v2
    a.vread      v2, a15, s6
    s.addi       s6, s38, #896
    s.movz       s39, #15
    s.addi       s47, s38, #960
    v.st.w       [s45, #0], v2
    a.vread      v2, a15, s23
    s.movz       s23, #0
    s.addi       s38, s31, #4352
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s29
    s.addi       s29, s31, #12544
    s.movz       s40, #1
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s32
    s.addi       s32, s31, #4416
    s.addi       s41, s29, #64
    v.st.w       [s46, #0], v2
    a.vread      v2, a15, s33
    s.movz       s33, #2
    s.addi       s45, s31, #4480
    v.st.w       [s34, #0], v2
    a.vread      v2, a15, s42
    s.addi       s34, s29, #128
    s.movz       s42, #3
    v.st.w       [s35, #0], v2
    a.vread      v2, a15, s43
    s.addi       s35, s31, #4544
    s.addi       s43, s29, #192
    v.st.w       [s30, #0], v2
    a.vread      v2, a15, s44
    s.movz       s30, #4
    s.addi       s44, s31, #4608
    v.st.w       [s36, #0], v2
    a.vread      v2, a15, s37
    s.addi       s36, s29, #256
    s.movz       s37, #5
    v.st.w       [s6, #0], v2
    a.vread      v2, a15, s39
    s.addi       s6, s31, #4672
    s.addi       s39, s29, #320
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a0, s23
    s.movz       s23, #6
    s.addi       s46, s31, #4736
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s29, #384
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a0, s40
    s.movz       s40, #7
    v.ld.w       v3, [s32, #0]
    s.addi       s32, s31, #4800
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a0, s33
    s.addi       s33, s29, #448
    s.movz       s41, #8
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s31, #4864
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a0, s42
    s.addi       s34, s29, #512
    s.movz       s42, #9
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s31, #4928
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s30
    s.addi       s30, s29, #576
    s.movz       s43, #10
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s31, #4992
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    a.vread      v2, a0, s37
    s.addi       s36, s29, #640
    s.movz       s37, #11
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s31, #5056
    vf.add       v4, v2, v3
    v.st.w       [s39, #0], v4
    a.vread      v2, a0, s23
    s.addi       s23, s29, #704
    s.movz       s39, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #5120
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a0, s40
    s.addi       s38, s29, #768
    s.movz       s40, #13
    v.ld.w       v3, [s32, #0]
    s.addi       s32, s31, #5184
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a0, s41
    s.addi       s33, s29, #832
    s.movz       s41, #14
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s31, #5248
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a0, s42
    s.addi       s34, s29, #896
    s.movz       s42, #15
    s.addi       s47, s29, #960
    v.ld.w       v3, [s35, #0]
    s.addi       s29, s31, #5312
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a0, s43
    s.movz       s30, #0
    s.addi       s35, s31, #5376
    v.ld.w       v3, [s44, #0]
    s.addi       s43, s31, #13568
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    a.vread      v2, a0, s37
    s.movz       s36, #1
    s.addi       s37, s31, #5440
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s43, #64
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a0, s39
    s.movz       s23, #2
    s.addi       s39, s31, #5504
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s43, #128
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a0, s40
    s.movz       s38, #3
    s.addi       s40, s31, #5568
    v.ld.w       v3, [s32, #0]
    s.addi       s32, s43, #192
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a0, s41
    s.movz       s33, #4
    s.addi       s41, s31, #5632
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s43, #256
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a0, s42
    s.movz       s34, #5
    s.addi       s42, s31, #5696
    v.ld.w       v3, [s29, #0]
    s.addi       s29, s43, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a1, s30
    s.movz       s30, #6
    s.addi       s46, s31, #5760
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s43, #384
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a1, s36
    s.movz       s36, #7
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s31, #5824
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a1, s23
    s.addi       s6, s43, #448
    s.movz       s23, #8
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #5888
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a1, s38
    s.addi       s38, s43, #512
    s.movz       s44, #9
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #5952
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a1, s33
    s.addi       s32, s43, #576
    s.movz       s33, #10
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s31, #6016
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a1, s34
    s.addi       s34, s43, #640
    s.movz       s45, #11
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s31, #6080
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a1, s30
    s.addi       s29, s43, #704
    s.movz       s30, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #6144
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a1, s36
    s.addi       s35, s43, #768
    s.movz       s36, #13
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s31, #6208
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a1, s23
    s.addi       s6, s43, #832
    s.movz       s23, #14
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #6272
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a1, s44
    s.addi       s38, s43, #896
    s.movz       s44, #15
    s.addi       s47, s43, #960
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #6336
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a1, s33
    s.movz       s32, #0
    s.addi       s33, s31, #6400
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s31, #14592
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a1, s45
    s.movz       s34, #1
    s.addi       s43, s31, #6464
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s41, #64
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a1, s30
    s.movz       s29, #2
    s.addi       s30, s31, #6528
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s41, #128
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a1, s36
    s.movz       s35, #3
    s.addi       s36, s31, #6592
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s41, #192
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a1, s23
    s.movz       s6, #4
    s.addi       s23, s31, #6656
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s41, #256
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a1, s44
    s.movz       s38, #5
    s.addi       s44, s31, #6720
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s41, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a2, s32
    s.movz       s32, #6
    s.addi       s46, s31, #6784
    v.ld.w       v3, [s33, #0]
    s.addi       s33, s41, #384
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s34
    s.movz       s34, #7
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s31, #6848
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a2, s29
    s.addi       s29, s41, #448
    s.movz       s42, #8
    v.ld.w       v3, [s30, #0]
    s.addi       s30, s31, #6912
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a2, s35
    s.addi       s35, s41, #512
    s.movz       s45, #9
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #6976
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a2, s6
    s.addi       s6, s41, #576
    s.movz       s37, #10
    v.ld.w       v3, [s23, #0]
    s.addi       s23, s31, #7040
    vf.add       v4, v2, v3
    v.st.w       [s39, #0], v4
    a.vread      v2, a2, s38
    s.addi       s38, s41, #640
    s.movz       s39, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s31, #7104
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s32
    s.addi       s32, s41, #704
    s.movz       s40, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #7168
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a2, s34
    s.addi       s33, s41, #768
    s.movz       s34, #13
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s31, #7232
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a2, s42
    s.addi       s29, s41, #832
    s.movz       s42, #14
    v.ld.w       v3, [s30, #0]
    s.addi       s30, s31, #7296
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a2, s45
    s.addi       s35, s41, #896
    s.movz       s45, #15
    s.addi       s47, s41, #960
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #7360
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a2, s37
    s.movz       s6, #0
    s.addi       s37, s31, #7424
    v.ld.w       v3, [s23, #0]
    s.addi       s23, s31, #15616
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a2, s39
    s.movz       s38, #1
    s.addi       s39, s31, #7488
    v.ld.w       v3, [s44, #0]
    s.addi       s41, s23, #64
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a2, s40
    s.movz       s32, #2
    s.addi       s40, s31, #7552
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s23, #128
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a2, s34
    s.movz       s33, #3
    s.addi       s34, s31, #7616
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #192
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a2, s42
    s.movz       s29, #4
    s.addi       s42, s31, #7680
    v.ld.w       v3, [s30, #0]
    s.addi       s30, s23, #256
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a2, s45
    s.movz       s35, #5
    s.addi       s45, s31, #7744
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s23, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a3, s6
    s.movz       s6, #6
    s.addi       s46, s31, #7808
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s23, #384
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a3, s38
    s.movz       s38, #7
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #7872
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s32
    s.addi       s32, s23, #448
    s.movz       s41, #8
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #7936
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a3, s33
    s.addi       s33, s23, #512
    s.movz       s44, #9
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #8000
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a3, s29
    s.addi       s29, s23, #576
    s.movz       s43, #10
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s31, #8064
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a3, s35
    s.addi       s30, s23, #640
    s.movz       s35, #11
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s31, #8128
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    a.vread      v2, a3, s6
    s.addi       s6, s23, #704
    s.movz       s36, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #8192
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a3, s38
    s.addi       s37, s23, #768
    s.movz       s38, #13
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #8256
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a3, s41
    s.addi       s32, s23, #832
    s.movz       s41, #14
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #8320
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a3, s44
    s.addi       s33, s23, #896
    s.movz       s44, #15
    s.addi       s47, s23, #960
    v.ld.w       v3, [s34, #0]
    s.addi       s23, s31, #8384
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a3, s43
    s.movz       s29, #0
    s.addi       s34, s31, #8448
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s31, #16640
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a3, s35
    s.movz       s30, #1
    s.addi       s35, s31, #8512
    v.ld.w       v3, [s45, #0]
    s.addi       s43, s42, #64
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a3, s36
    s.movz       s6, #2
    s.addi       s36, s31, #8576
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s42, #128
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a3, s38
    s.movz       s37, #3
    s.addi       s38, s31, #8640
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s42, #192
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a3, s41
    s.movz       s32, #4
    s.addi       s41, s31, #8704
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s42, #256
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a3, s44
    s.movz       s33, #5
    s.addi       s44, s31, #8768
    v.ld.w       v3, [s23, #0]
    s.addi       s23, s42, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a4, s29
    s.movz       s29, #6
    s.addi       s46, s31, #8832
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s42, #384
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a4, s30
    s.movz       s30, #7
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s31, #8896
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a4, s6
    s.addi       s6, s42, #448
    s.movz       s43, #8
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #8960
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a4, s37
    s.addi       s37, s42, #512
    s.movz       s45, #9
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s31, #9024
    vf.add       v4, v2, v3
    v.st.w       [s39, #0], v4
    a.vread      v2, a4, s32
    s.addi       s32, s42, #576
    s.movz       s39, #10
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s31, #9088
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s33
    s.addi       s33, s42, #640
    s.movz       s40, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s31, #9152
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a4, s29
    s.addi       s23, s42, #704
    s.movz       s29, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #9216
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a4, s30
    s.addi       s30, s42, #768
    s.movz       s34, #13
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s31, #9280
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a4, s43
    s.addi       s6, s42, #832
    s.movz       s43, #14
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #9344
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a4, s45
    s.addi       s37, s42, #896
    s.movz       s45, #15
    s.addi       s47, s42, #960
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s31, #9408
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a4, s39
    s.movz       s32, #0
    s.addi       s39, s31, #9472
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s31, #17664
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a4, s40
    s.movz       s33, #1
    s.addi       s40, s31, #9536
    v.ld.w       v3, [s44, #0]
    s.addi       s42, s41, #64
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a4, s29
    s.movz       s23, #2
    s.addi       s29, s31, #9600
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s41, #128
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a4, s34
    s.movz       s30, #3
    s.addi       s34, s31, #9664
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s41, #192
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a4, s43
    s.movz       s6, #4
    s.addi       s43, s31, #9728
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s41, #256
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a4, s45
    s.movz       s37, #5
    s.addi       s45, s31, #9792
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s41, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a5, s32
    s.movz       s32, #6
    s.addi       s46, s31, #9856
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s41, #384
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s33
    s.movz       s33, #7
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #9920
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a5, s23
    s.addi       s23, s41, #448
    s.movz       s42, #8
    v.ld.w       v3, [s29, #0]
    s.addi       s29, s31, #9984
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a5, s30
    s.addi       s30, s41, #512
    s.movz       s44, #9
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #10048
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a5, s6
    s.addi       s6, s41, #576
    s.movz       s35, #10
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s31, #10112
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    a.vread      v2, a5, s37
    s.addi       s36, s41, #640
    s.movz       s37, #11
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s31, #10176
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a5, s32
    s.addi       s32, s41, #704
    s.movz       s38, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #10240
    vf.add       v4, v2, v3
    v.st.w       [s39, #0], v4
    a.vread      v2, a5, s33
    s.addi       s33, s41, #768
    s.movz       s39, #13
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s31, #10304
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a5, s42
    s.addi       s23, s41, #832
    s.movz       s42, #14
    v.ld.w       v3, [s29, #0]
    s.addi       s29, s31, #10368
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a5, s44
    s.addi       s30, s41, #896
    s.movz       s44, #15
    s.addi       s47, s41, #960
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #10432
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a5, s35
    s.movz       s6, #0
    s.addi       s35, s31, #10496
    v.ld.w       v3, [s43, #0]
    s.addi       s41, s31, #18688
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    a.vread      v2, a5, s37
    s.movz       s36, #1
    s.addi       s37, s31, #10560
    v.ld.w       v3, [s45, #0]
    s.addi       s43, s41, #64
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a5, s38
    s.movz       s32, #2
    s.addi       s38, s31, #10624
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s41, #128
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a5, s39
    s.movz       s33, #3
    s.addi       s39, s31, #10688
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s41, #192
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a5, s42
    s.movz       s23, #4
    s.addi       s42, s31, #10752
    v.ld.w       v3, [s29, #0]
    s.addi       s29, s41, #256
    vf.add       v4, v2, v3
    v.st.w       [s30, #0], v4
    a.vread      v2, a5, s44
    s.movz       s30, #5
    s.addi       s44, s31, #10816
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s41, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a6, s6
    s.movz       s6, #6
    s.addi       s46, s31, #10880
    v.ld.w       v3, [s35, #0]
    s.addi       s35, s41, #384
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s36
    s.movz       s36, #7
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s31, #10944
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a6, s32
    s.addi       s32, s41, #448
    s.movz       s43, #8
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s31, #11008
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a6, s33
    s.addi       s33, s41, #512
    s.movz       s45, #9
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #11072
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s23
    s.addi       s23, s41, #576
    s.movz       s40, #10
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s31, #11136
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a6, s30
    s.addi       s29, s41, #640
    s.movz       s30, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s31, #11200
    vf.add       v4, v2, v3
    v.st.w       [s34, #0], v4
    a.vread      v2, a6, s6
    s.addi       s6, s41, #704
    s.movz       s34, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #11264
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a6, s36
    s.addi       s35, s41, #768
    s.movz       s36, #13
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s31, #11328
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a6, s43
    s.addi       s32, s41, #832
    s.movz       s43, #14
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s31, #11392
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a6, s45
    s.addi       s33, s41, #896
    s.movz       s45, #15
    s.addi       s47, s41, #960
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s31, #11456
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a6, s40
    s.movz       s23, #0
    s.addi       s40, s31, #11520
    v.ld.w       v3, [s42, #0]
    s.addi       s41, s31, #19712
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a6, s30
    s.movz       s29, #1
    s.addi       s30, s31, #11584
    v.ld.w       v3, [s44, #0]
    s.addi       s42, s41, #64
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a6, s34
    s.movz       s6, #2
    s.addi       s34, s31, #11648
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s41, #128
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a6, s36
    s.movz       s35, #3
    s.addi       s36, s31, #11712
    v.ld.w       v3, [s37, #0]
    s.addi       s37, s41, #192
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a6, s43
    s.movz       s32, #4
    s.addi       s43, s31, #11776
    v.ld.w       v3, [s38, #0]
    s.addi       s38, s41, #256
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a6, s45
    s.movz       s33, #5
    s.addi       s45, s31, #11840
    v.ld.w       v3, [s39, #0]
    s.addi       s39, s41, #320
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a7, s23
    s.movz       s23, #6
    s.addi       s46, s31, #11904
    v.ld.w       v3, [s40, #0]
    s.addi       s40, s41, #384
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s29
    s.movz       s29, #7
    v.ld.w       v3, [s30, #0]
    s.addi       s30, s31, #11968
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a7, s6
    s.addi       s6, s41, #448
    s.movz       s42, #8
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #12032
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a7, s35
    s.addi       s35, s41, #512
    s.movz       s44, #9
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #12096
    vf.add       v4, v2, v3
    v.st.w       [s37, #0], v4
    a.vread      v2, a7, s32
    s.addi       s32, s41, #576
    s.movz       s37, #10
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s31, #12160
    vf.add       v4, v2, v3
    v.st.w       [s38, #0], v4
    a.vread      v2, a7, s33
    s.addi       s33, s41, #640
    s.movz       s38, #11
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s31, #12224
    vf.add       v4, v2, v3
    v.st.w       [s39, #0], v4
    a.vread      v2, a7, s23
    s.addi       s23, s41, #704
    s.movz       s39, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s31, #12288
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s29
    s.addi       s29, s41, #768
    s.movz       s40, #13
    v.ld.w       v3, [s30, #0]
    s.addi       s30, s31, #12352
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a7, s42
    s.addi       s6, s41, #832
    s.movz       s42, #14
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #12416
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a7, s44
    s.addi       s35, s41, #896
    s.movz       s44, #15
    s.addi       s47, s41, #960
    v.ld.w       v3, [s36, #0]
    s.addi       s36, s31, #12480
    vf.add       v4, v2, v3
    v.st.w       [s32, #0], v4
    a.vread      v2, a7, s37
    s.addi       s32, s15, #128
    s.addi       s37, s17, #128
    s.addi       s41, s32, #0
    s.addi       s32, s37, #0
    v.ld.w       v3, [s43, #0]
    s.addi       s37, s31, #12544
    vf.add       v4, v2, v3
    v.st.w       [s33, #0], v4
    a.vread      v2, a7, s38
    s.movz       s33, #0
    s.addi       s38, s31, #12608
    v.ld.w       v3, [s45, #0]
    s.movz       s43, #1
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    a.vread      v2, a7, s39
    s.addi       s23, s31, #12672
    s.movz       s39, #2
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s31, #12736
    vf.add       v4, v2, v3
    v.st.w       [s29, #0], v4
    a.vread      v2, a7, s40
    s.movz       s29, #3
    s.addi       s40, s31, #12800
    v.ld.w       v3, [s30, #0]
    s.movz       s30, #4
    vf.add       v4, v2, v3
    v.st.w       [s6, #0], v4
    a.vread      v2, a7, s42
    s.addi       s6, s31, #12864
    s.movz       s42, #5
    v.ld.w       v3, [s34, #0]
    s.addi       s34, s31, #12928
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    a.vread      v2, a7, s44
    s.movz       s35, #6
    s.addi       s44, s31, #12992
    v.ld.w       v3, [s36, #0]
    s.movz       s36, #7
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    s.mov        s15, s41
    s.mov        s17, s32
    s.addi       s32, s31, #13056
    s.movz       s41, #8
    s.addi       s46, s31, #13120
    s.movz       s47, #9
    s.addi       s48, s31, #13184
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #10
    a.vwrite     a0, s33, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #13248
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s23, #0]
    s.movz       s23, #11
    a.vwrite     a0, s39, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s31, #13312
    a.vwrite     a0, s29, v2
    v.ld.w       v2, [s40, #0]
    s.movz       s40, #12
    a.vwrite     a0, s30, v2
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s31, #13376
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #13
    a.vwrite     a0, s35, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #13440
    a.vwrite     a0, s36, v2
    v.ld.w       v2, [s32, #0]
    s.movz       s32, #14
    a.vwrite     a0, s41, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s31, #13504
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s48, #0]
    s.movz       s48, #15
    a.vwrite     a0, s37, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #13568
    a.vwrite     a0, s23, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s31, #13632
    a.vwrite     a0, s40, v2
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s31, #13696
    a.vwrite     a0, s34, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #13760
    a.vwrite     a0, s32, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s31, #13824
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #13888
    a.vwrite     a1, s33, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s33, s31, #13952
    s.addi       s45, s31, #14016
    a.vwrite     a1, s43, v2
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s31, #14080
    s.addi       s43, s31, #14144
    a.vwrite     a1, s39, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s39, s31, #14208
    s.addi       s44, s31, #14272
    a.vwrite     a1, s29, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s29, s31, #14336
    s.addi       s46, s31, #14400
    a.vwrite     a1, s30, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s30, s31, #14464
    s.addi       s38, s31, #14528
    a.vwrite     a1, s42, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #14592
    s.movz       s42, #0
    a.vwrite     a1, s35, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s35, s31, #14656
    s.movz       s45, #1
    a.vwrite     a1, s36, v2
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s31, #14720
    s.movz       s36, #2
    a.vwrite     a1, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s41, s31, #14784
    s.movz       s43, #3
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #14848
    s.movz       s47, #4
    a.vwrite     a1, s37, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s37, s31, #14912
    s.movz       s44, #5
    a.vwrite     a1, s23, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s23, s31, #14976
    s.movz       s29, #6
    a.vwrite     a1, s40, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s40, s31, #15040
    s.movz       s46, #7
    a.vwrite     a1, s34, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #15104
    s.movz       s34, #8
    a.vwrite     a1, s32, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s32, s31, #15168
    s.movz       s38, #9
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #15232
    s.movz       s48, #10
    a.vwrite     a2, s42, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #15296
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s6, #0]
    s.movz       s6, #11
    a.vwrite     a2, s36, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #15360
    a.vwrite     a2, s43, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #12
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #15424
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s23, #0]
    s.movz       s23, #13
    a.vwrite     a2, s29, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #15488
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s30, #0]
    s.movz       s30, #14
    a.vwrite     a2, s34, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #15552
    a.vwrite     a2, s38, v2
    v.ld.w       v2, [s33, #0]
    s.movz       s33, #15
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #15616
    a.vwrite     a2, s6, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #15680
    a.vwrite     a2, s39, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #15744
    a.vwrite     a2, s23, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #15808
    a.vwrite     a2, s30, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #15872
    a.vwrite     a2, s33, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #15936
    a.vwrite     a3, s42, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #16000
    s.addi       s42, s31, #16064
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #16128
    s.addi       s45, s31, #16192
    a.vwrite     a3, s36, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s36, s31, #16256
    s.addi       s40, s31, #16320
    a.vwrite     a3, s43, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #16384
    s.addi       s43, s31, #16448
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #16512
    s.addi       s47, s31, #16576
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #16640
    s.movz       s44, #0
    a.vwrite     a3, s29, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s29, s31, #16704
    s.movz       s42, #1
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #16768
    s.movz       s46, #2
    a.vwrite     a3, s34, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s34, s31, #16832
    s.movz       s45, #3
    a.vwrite     a3, s38, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #16896
    s.movz       s38, #4
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #16960
    s.movz       s48, #5
    a.vwrite     a3, s6, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s6, s31, #17024
    s.movz       s32, #6
    a.vwrite     a3, s39, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s39, s31, #17088
    s.movz       s43, #7
    a.vwrite     a3, s23, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s23, s31, #17152
    s.movz       s35, #8
    a.vwrite     a3, s30, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s30, s31, #17216
    s.movz       s47, #9
    a.vwrite     a3, s33, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s33, s31, #17280
    s.movz       s41, #10
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #17344
    a.vwrite     a4, s42, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #11
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s31, #17408
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s36, #0]
    s.movz       s36, #12
    a.vwrite     a4, s38, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #17472
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s6, #0]
    s.movz       s6, #13
    a.vwrite     a4, s32, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #17536
    a.vwrite     a4, s43, v2
    v.ld.w       v2, [s23, #0]
    s.movz       s23, #14
    a.vwrite     a4, s35, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #17600
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s33, #0]
    s.movz       s33, #15
    a.vwrite     a4, s41, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #17664
    a.vwrite     a4, s37, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s31, #17728
    a.vwrite     a4, s36, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #17792
    a.vwrite     a4, s6, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #17856
    a.vwrite     a4, s23, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #17920
    a.vwrite     a4, s33, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #17984
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s31, #18048
    s.addi       s44, s31, #18112
    a.vwrite     a5, s42, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #18176
    s.addi       s42, s31, #18240
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #18304
    s.addi       s46, s31, #18368
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #18432
    s.addi       s45, s31, #18496
    a.vwrite     a5, s38, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #18560
    s.addi       s38, s31, #18624
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s31, #18688
    s.movz       s48, #0
    a.vwrite     a5, s32, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s32, s31, #18752
    s.movz       s44, #1
    a.vwrite     a5, s43, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #18816
    s.movz       s43, #2
    a.vwrite     a5, s35, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s35, s31, #18880
    s.movz       s42, #3
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #18944
    s.movz       s47, #4
    a.vwrite     a5, s41, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s41, s31, #19008
    s.movz       s46, #5
    a.vwrite     a5, s37, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #19072
    s.movz       s37, #6
    a.vwrite     a5, s36, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s36, s31, #19136
    s.movz       s45, #7
    a.vwrite     a5, s6, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s6, s31, #19200
    s.movz       s29, #8
    a.vwrite     a5, s23, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s23, s31, #19264
    s.movz       s38, #9
    a.vwrite     a5, s33, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s33, s31, #19328
    s.movz       s34, #10
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #19392
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s40, #0]
    s.movz       s40, #11
    a.vwrite     a6, s43, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #19456
    a.vwrite     a6, s42, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #12
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #19520
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s30, #0]
    s.movz       s30, #13
    a.vwrite     a6, s37, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #19584
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s6, #0]
    s.movz       s6, #14
    a.vwrite     a6, s29, v2
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s31, #19648
    a.vwrite     a6, s38, v2
    v.ld.w       v2, [s33, #0]
    s.movz       s33, #15
    a.vwrite     a6, s34, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #19712
    a.vwrite     a6, s40, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #19776
    a.vwrite     a6, s39, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #19840
    a.vwrite     a6, s30, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #19904
    a.vwrite     a6, s6, v2
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s31, #19968
    a.vwrite     a6, s33, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #20032
    s.add        s49, s13, s7
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #20096
    s.addi       s48, s31, #20160
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #20224
    s.addi       s44, s31, #20288
    a.vwrite     a7, s43, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #20352
    s.addi       s43, s31, #20416
    a.vwrite     a7, s42, v2
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s31, #20480
    s.addi       s42, s31, #20544
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s31, #20608
    s.addi       s47, s31, #20672
    s.movz       s31, #1
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s35, #0]
    a.vwrite     a7, s37, v2
    v.ld.w       v2, [s48, #0]
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s41, #0]
    a.vwrite     a7, s29, v2
    v.ld.w       v2, [s44, #0]
    a.vwrite     a7, s38, v2
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s34, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s40, v2
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s39, v2
    v.ld.w       v2, [s42, #0]
    a.vwrite     a7, s30, v2
    v.ld.w       v2, [s32, #0]
    a.vwrite     a7, s6, v2
    v.ld.w       v2, [s47, #0]
    a.vwrite     a7, s33, v2
    s.mov        s13, s49
    br.nz        s31, for_18
endfor_19:
    s.movz       s2, #0
    v.extract    s5, v0, #0
    a.vread      v1, a0, s2
    v.splat      v2, s5
    s.mul        s5, s1, s21
    v.splat      v3, s20
    vf.mul       v4, v1, v2
    s.add        s6, s2, s4                      // the tile origin
    s.muli       s7, s4, #2
    s.muli       s8, s5, #2
    v.iota       v1                              // arange(0, VLEN)
    vf.mul       v2, v4, v3
    v.splat      v4, s6
    s.add        s5, s2, s1                      // the tile origin
    s.add        s1, s2, s14                     // the tile origin
    s.add        s6, s2, s3                      // the tile origin
    v.splat      v5, s5
    v.splat      v6, s1
    v.add        v7, v1, v4
    v.splat      v4, s6
    vf.cvt.f32.bf16 v8, v2
    s.add        s1, s8, s7
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s2, s11, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s6, v0, #1
    @p3 v.st.h       [s2, #0], v8
    a.vread      v2, a0, s1
    v.splat      v4, s6
    s.muli       s1, s21, #2
    s.addi       s2, s5, #1
    vf.mul       v5, v2, v4
    v.splat      v2, s2
    s.addi       s2, s4, #16
    s.muli       s6, s1, #1
    v.cmp.lt     p1, v2, v6
    vf.mul       v2, v5, v3
    p.and        p3, p1, p2
    s.addi       s9, s4, #32
    s.add        s10, s6, s8
    s.addi       s6, s4, #48
    vf.cvt.f32.bf16 v4, v2
    s.add        s12, s10, s7
    s.movz       s10, #2
    s.add        s13, s11, s12
    s.addi       s12, s4, #64
    @p3 v.st.h       [s13, #0], v4
    a.vread      v2, a0, s10
    s.addi       s10, s4, #80
    v.extract    s13, v0, #2
    s.addi       s14, s4, #96
    v.splat      v4, s13
    s.addi       s13, s4, #112
    s.muli       s4, s1, #2
    vf.mul       v5, v2, v4
    s.addi       s15, s5, #2
    s.movz       s16, #3
    v.splat      v2, s15
    s.add        s15, s4, s8
    vf.mul       v4, v5, v3
    s.add        s4, s15, s7
    v.cmp.lt     p1, v2, v6
    s.add        s15, s11, s4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    v.extract    s4, v0, #3
    s.muli       s17, s1, #3
    v.splat      v4, s4
    s.addi       s4, s5, #3
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a0, s16
    s.add        s15, s17, s8
    v.splat      v5, s4
    vf.mul       v7, v2, v4
    s.add        s4, s15, s7
    v.cmp.lt     p1, v5, v6
    s.add        s15, s11, s4
    p.and        p3, p1, p2
    vf.mul       v2, v7, v3
    s.movz       s4, #4
    v.extract    s16, v0, #4
    s.muli       s17, s1, #4
    v.splat      v4, s16
    vf.cvt.f32.bf16 v5, v2
    s.addi       s16, s5, #4
    s.movz       s18, #5
    s.add        s19, s17, s8
    v.splat      v2, s16
    @p3 v.st.h       [s15, #0], v5
    a.vread      v5, a0, s4
    s.add        s4, s19, s7
    v.cmp.lt     p1, v2, v6
    vf.mul       v2, v5, v4
    s.add        s15, s11, s4
    p.and        p3, p1, p2
    v.extract    s4, v0, #5
    s.muli       s16, s1, #5
    vf.mul       v4, v2, v3
    v.splat      v2, s4
    s.addi       s4, s5, #5
    s.movz       s17, #6
    s.add        s19, s16, s8
    vf.cvt.f32.bf16 v5, v4
    v.splat      v4, s4
    s.add        s4, s19, s7
    v.extract    s16, v0, #6
    v.cmp.lt     p1, v4, v6
    @p3 v.st.h       [s15, #0], v5
    a.vread      v4, a0, s18
    s.add        s15, s11, s4
    p.and        p3, p1, p2
    vf.mul       v5, v4, v2
    v.splat      v2, s16
    s.muli       s4, s1, #6
    s.addi       s16, s5, #6
    s.movz       s18, #7
    vf.mul       v4, v5, v3
    v.splat      v5, s16
    s.add        s16, s4, s8
    v.extract    s4, v0, #7
    s.add        s19, s16, s7
    vf.cvt.f32.bf16 v7, v4
    v.cmp.lt     p1, v5, v6
    s.add        s16, s11, s19
    p.and        p4, p1, p2
    v.splat      v4, s4
    @p3 v.st.h       [s15, #0], v7
    a.vread      v5, a0, s17
    s.muli       s4, s1, #7
    s.addi       s15, s5, #7
    vf.mul       v7, v5, v2
    v.splat      v2, s15
    s.movz       s15, #8
    s.add        s17, s4, s8
    v.cmp.lt     p1, v2, v6
    vf.mul       v2, v7, v3
    s.add        s4, s17, s7
    p.and        p3, p1, p2
    s.add        s17, s11, s4
    v.extract    s4, v0, #8
    vf.cvt.f32.bf16 v5, v2
    v.splat      v2, s4
    s.muli       s4, s1, #8
    s.addi       s19, s5, #8
    s.movz       s20, #9
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a0, s18
    s.add        s16, s4, s8
    v.splat      v7, s19
    vf.mul       v8, v5, v4
    s.add        s4, s16, s7
    v.cmp.lt     p1, v7, v6
    s.add        s16, s11, s4
    p.and        p4, p1, p2
    vf.mul       v4, v8, v3
    v.extract    s4, v0, #9
    s.muli       s18, s1, #9
    v.splat      v5, s4
    s.addi       s4, s5, #9
    vf.cvt.f32.bf16 v7, v4
    v.splat      v4, s4
    s.add        s4, s18, s8
    s.movz       s18, #10
    s.add        s19, s4, s7
    @p3 v.st.h       [s17, #0], v7
    a.vread      v7, a0, s15
    v.cmp.lt     p1, v4, v6
    s.add        s4, s11, s19
    vf.mul       v4, v7, v2
    p.and        p3, p1, p2
    v.extract    s15, v0, #10
    s.muli       s17, s1, #10
    v.splat      v2, s15
    vf.mul       v7, v4, v3
    s.addi       s15, s5, #10
    s.movz       s19, #11
    s.add        s21, s17, s8
    v.splat      v4, s15
    vf.cvt.f32.bf16 v8, v7
    s.add        s15, s21, s7
    v.extract    s17, v0, #11
    s.add        s21, s11, s15
    v.splat      v7, s17
    @p4 v.st.h       [s16, #0], v8
    a.vread      v8, a0, s20
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v8, v5
    s.muli       s15, s1, #11
    s.addi       s16, s5, #11
    s.movz       s17, #12
    v.splat      v5, s16
    vf.mul       v8, v4, v3
    s.add        s16, s15, s8
    v.extract    s15, v0, #12
    s.add        s20, s16, s7
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v8
    s.add        s15, s11, s20
    s.muli       s16, s1, #12
    s.addi       s20, s5, #12
    @p3 v.st.h       [s4, #0], v9
    a.vread      v8, a0, s18
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v8, v2
    s.add        s4, s16, s8
    v.splat      v2, s20
    s.add        s16, s4, s7
    s.movz       s4, #13
    vf.mul       v8, v5, v3
    s.add        s18, s11, s16
    v.extract    s16, v0, #13
    v.splat      v5, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s1, #13
    s.addi       s20, s5, #13
    v.splat      v8, s20
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a0, s19
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v7
    s.add        s19, s16, s8
    s.movz       s16, #14
    s.add        s20, s19, s7
    v.extract    s19, v0, #14
    vf.mul       v7, v2, v3
    s.add        s21, s11, s20
    v.splat      v2, s19
    vf.cvt.f32.bf16 v9, v7
    s.muli       s19, s1, #14
    s.addi       s20, s5, #14
    v.splat      v7, s20
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a0, s17
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v4
    s.add        s15, s19, s8
    s.movz       s17, #15
    s.add        s19, s15, s7
    v.extract    s15, v0, #15
    vf.mul       v4, v8, v3
    s.add        s20, s11, s19
    v.splat      v8, s15
    vf.cvt.f32.bf16 v9, v4
    s.muli       s15, s1, #15
    s.addi       s19, s5, #15
    v.splat      v4, s19
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a0, s4
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v5
    s.add        s4, s15, s8
    s.movz       s15, #0
    s.add        s18, s4, s7
    v.extract    s4, v0, #0
    vf.mul       v5, v7, v3
    s.add        s7, s11, s18
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v5
    s.add        s4, s15, s2                     // the tile origin
    s.muli       s18, s2, #2
    v.splat      v5, s4
    v.splat      v10, s5
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a0, s16
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v2
    s.add        s2, s15, s3                     // the tile origin
    v.add        v2, v1, v5
    v.splat      v5, s2
    s.add        s2, s8, s18
    vf.mul       v9, v4, v3
    v.cmp.lt     p1, v10, v6
    s.add        s4, s11, s2
    s.movz       s2, #1
    vf.cvt.f32.bf16 v4, v9
    v.extract    s16, v0, #1
    s.muli       s19, s1, #1
    v.splat      v9, s16
    @p4 v.st.h       [s20, #0], v4
    a.vread      v4, a0, s17
    v.cmp.lt     p2, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v8
    s.addi       s16, s5, #1
    s.add        s17, s19, s8
    v.splat      v4, s16
    s.add        s16, s17, s18
    vf.mul       v5, v2, v3
    s.add        s17, s11, s16
    s.movz       s16, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s19, v0, #2
    s.muli       s20, s1, #2
    v.splat      v5, s19
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a1, s15
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v7
    s.addi       s7, s5, #2
    s.add        s15, s20, s8
    v.splat      v2, s7
    s.add        s7, s15, s18
    vf.mul       v7, v4, v3
    s.add        s15, s11, s7
    s.movz       s7, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s19, v0, #3
    s.muli       s20, s1, #3
    v.splat      v7, s19
    s.addi       s19, s5, #3
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a1, s2
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s2, s20, s8
    v.splat      v4, s19
    s.add        s4, s2, s18
    s.movz       s2, #4
    vf.mul       v8, v2, v3
    s.add        s19, s11, s4
    v.extract    s4, v0, #4
    v.splat      v2, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #4
    s.addi       s20, s5, #4
    v.splat      v8, s20
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s16, s4, s8
    s.movz       s4, #5
    s.add        s17, s16, s18
    v.extract    s16, v0, #5
    vf.mul       v5, v4, v3
    s.add        s20, s11, s17
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v5
    s.muli       s16, s1, #5
    s.addi       s17, s5, #5
    v.splat      v5, s17
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a1, s7
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s7, s16, s8
    s.movz       s15, #6
    s.add        s16, s7, s18
    v.extract    s7, v0, #6
    vf.mul       v7, v8, v3
    s.add        s17, s11, s16
    v.splat      v8, s7
    vf.cvt.f32.bf16 v9, v7
    s.muli       s7, s1, #6
    s.addi       s16, s5, #6
    v.splat      v7, s16
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s2, s7, s8
    s.movz       s7, #7
    s.add        s16, s2, s18
    v.extract    s2, v0, #7
    vf.mul       v2, v5, v3
    s.add        s19, s11, s16
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v2
    s.muli       s2, s1, #7
    s.addi       s16, s5, #7
    v.splat      v2, s16
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s4, s2, s8
    s.movz       s2, #8
    s.add        s16, s4, s18
    v.extract    s4, v0, #8
    vf.mul       v4, v7, v3
    s.add        s20, s11, s16
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #8
    s.addi       s16, s5, #8
    v.splat      v4, s16
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s15, s4, s8
    s.movz       s4, #9
    s.add        s16, s15, s18
    v.extract    s15, v0, #9
    vf.mul       v8, v2, v3
    s.add        s17, s11, s16
    v.splat      v2, s15
    vf.cvt.f32.bf16 v9, v8
    s.muli       s15, s1, #9
    s.addi       s16, s5, #9
    v.splat      v8, s16
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a1, s7
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s7, s15, s8
    s.movz       s15, #10
    s.add        s16, s7, s18
    v.extract    s7, v0, #10
    vf.mul       v5, v4, v3
    s.add        s19, s11, s16
    v.splat      v4, s7
    vf.cvt.f32.bf16 v9, v5
    s.muli       s7, s1, #10
    s.addi       s16, s5, #10
    v.splat      v5, s16
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s2, s7, s8
    s.movz       s7, #11
    s.add        s16, s2, s18
    v.extract    s2, v0, #11
    vf.mul       v7, v8, v3
    s.add        s20, s11, s16
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #11
    s.addi       s16, s5, #11
    v.splat      v7, s16
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s4, s2, s8
    s.movz       s2, #12
    s.add        s16, s4, s18
    v.extract    s4, v0, #12
    vf.mul       v2, v5, v3
    s.add        s17, s11, s16
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v2
    s.muli       s4, s1, #12
    s.addi       s16, s5, #12
    v.splat      v2, s16
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s15, s4, s8
    s.movz       s4, #13
    s.add        s16, s15, s18
    v.extract    s15, v0, #13
    vf.mul       v4, v7, v3
    s.add        s19, s11, s16
    v.splat      v7, s15
    vf.cvt.f32.bf16 v9, v4
    s.muli       s15, s1, #13
    s.addi       s16, s5, #13
    v.splat      v4, s16
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s7
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s7, s15, s8
    s.movz       s15, #14
    s.add        s16, s7, s18
    v.extract    s7, v0, #14
    vf.mul       v8, v2, v3
    s.add        s20, s11, s16
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #14
    s.addi       s16, s5, #14
    v.splat      v8, s16
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s7, s8
    s.movz       s7, #15
    s.add        s16, s2, s18
    v.extract    s2, v0, #15
    vf.mul       v5, v4, v3
    s.add        s17, s11, s16
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #15
    s.addi       s16, s5, #15
    v.splat      v5, s16
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s4, s2, s8
    s.movz       s2, #0
    s.add        s16, s4, s18
    v.extract    s4, v0, #0
    vf.mul       v7, v8, v3
    s.add        s18, s11, s16
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v7
    s.add        s4, s2, s9                      // the tile origin
    s.muli       s16, s9, #2
    v.splat      v7, s4
    v.splat      v10, s5
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s4, s2, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v7, s4
    s.add        s4, s8, s16
    vf.mul       v9, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s9, s11, s4
    s.movz       s4, #1
    vf.cvt.f32.bf16 v5, v9
    v.extract    s15, v0, #1
    s.muli       s19, s1, #1
    v.splat      v9, s15
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a1, s7
    v.cmp.lt     p2, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s7, s5, #1
    s.add        s15, s19, s8
    v.splat      v4, s7
    s.add        s7, s15, s16
    vf.mul       v5, v2, v3
    s.add        s15, s11, s7
    s.movz       s7, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s17, v0, #2
    s.muli       s19, s1, #2
    v.splat      v5, s17
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v8
    s.addi       s2, s5, #2
    s.add        s17, s19, s8
    v.splat      v2, s2
    s.add        s2, s17, s16
    vf.mul       v7, v4, v3
    s.add        s17, s11, s2
    s.movz       s2, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s18, v0, #3
    s.muli       s19, s1, #3
    v.splat      v7, s18
    s.addi       s18, s5, #3
    @p4 v.st.h       [s9, #0], v4
    a.vread      v4, a2, s4
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s4, s19, s8
    v.splat      v4, s18
    s.add        s9, s4, s16
    s.movz       s4, #4
    vf.mul       v8, v2, v3
    s.add        s18, s11, s9
    v.extract    s9, v0, #4
    v.splat      v2, s9
    vf.cvt.f32.bf16 v9, v8
    s.muli       s9, s1, #4
    s.addi       s19, s5, #4
    v.splat      v8, s19
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a2, s7
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s7, s9, s8
    s.movz       s9, #5
    s.add        s15, s7, s16
    v.extract    s7, v0, #5
    vf.mul       v5, v4, v3
    s.add        s19, s11, s15
    v.splat      v4, s7
    vf.cvt.f32.bf16 v9, v5
    s.muli       s7, s1, #5
    s.addi       s15, s5, #5
    v.splat      v5, s15
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s2, s7, s8
    s.movz       s7, #6
    s.add        s15, s2, s16
    v.extract    s2, v0, #6
    vf.mul       v7, v8, v3
    s.add        s17, s11, s15
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #6
    s.addi       s15, s5, #6
    v.splat      v7, s15
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s4, s2, s8
    s.movz       s2, #7
    s.add        s15, s4, s16
    v.extract    s4, v0, #7
    vf.mul       v2, v5, v3
    s.add        s18, s11, s15
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v2
    s.muli       s4, s1, #7
    s.addi       s15, s5, #7
    v.splat      v2, s15
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s9
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s9, s4, s8
    s.movz       s4, #8
    s.add        s15, s9, s16
    v.extract    s9, v0, #8
    vf.mul       v4, v7, v3
    s.add        s19, s11, s15
    v.splat      v7, s9
    vf.cvt.f32.bf16 v9, v4
    s.muli       s9, s1, #8
    s.addi       s15, s5, #8
    v.splat      v4, s15
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a2, s7
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s7, s9, s8
    s.movz       s9, #9
    s.add        s15, s7, s16
    v.extract    s7, v0, #9
    vf.mul       v8, v2, v3
    s.add        s17, s11, s15
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #9
    s.addi       s15, s5, #9
    v.splat      v8, s15
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s7, s8
    s.movz       s7, #10
    s.add        s15, s2, s16
    v.extract    s2, v0, #10
    vf.mul       v5, v4, v3
    s.add        s18, s11, s15
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #10
    s.addi       s15, s5, #10
    v.splat      v5, s15
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s4, s2, s8
    s.movz       s2, #11
    s.add        s15, s4, s16
    v.extract    s4, v0, #11
    vf.mul       v7, v8, v3
    s.add        s19, s11, s15
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #11
    s.addi       s15, s5, #11
    v.splat      v7, s15
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a2, s9
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s9, s4, s8
    s.movz       s4, #12
    s.add        s15, s9, s16
    v.extract    s9, v0, #12
    vf.mul       v2, v5, v3
    s.add        s17, s11, s15
    v.splat      v5, s9
    vf.cvt.f32.bf16 v9, v2
    s.muli       s9, s1, #12
    s.addi       s15, s5, #12
    v.splat      v2, s15
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s7
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s7, s9, s8
    s.movz       s9, #13
    s.add        s15, s7, s16
    v.extract    s7, v0, #13
    vf.mul       v4, v7, v3
    s.add        s18, s11, s15
    v.splat      v7, s7
    vf.cvt.f32.bf16 v9, v4
    s.muli       s7, s1, #13
    s.addi       s15, s5, #13
    v.splat      v4, s15
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s2, s7, s8
    s.movz       s7, #14
    s.add        s15, s2, s16
    v.extract    s2, v0, #14
    vf.mul       v8, v2, v3
    s.add        s19, s11, s15
    v.splat      v2, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #14
    s.addi       s15, s5, #14
    v.splat      v8, s15
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s8
    s.movz       s2, #15
    s.add        s15, s4, s16
    v.extract    s4, v0, #15
    vf.mul       v5, v4, v3
    s.add        s17, s11, s15
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #15
    s.addi       s15, s5, #15
    v.splat      v5, s15
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s9
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s9, s4, s8
    s.movz       s4, #0
    s.add        s15, s9, s16
    v.extract    s9, v0, #0
    vf.mul       v7, v8, v3
    s.add        s16, s11, s15
    v.splat      v8, s9
    vf.cvt.f32.bf16 v9, v7
    s.add        s9, s4, s6                      // the tile origin
    s.muli       s15, s6, #2
    v.splat      v7, s9
    v.splat      v10, s5
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s7
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s6, s4, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v7, s6
    s.add        s6, s8, s15
    vf.mul       v9, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s7, s11, s6
    s.movz       s6, #1
    vf.cvt.f32.bf16 v5, v9
    v.extract    s9, v0, #1
    s.muli       s18, s1, #1
    v.splat      v9, s9
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p2, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s2, s5, #1
    s.add        s9, s18, s8
    v.splat      v4, s2
    s.add        s2, s9, s15
    vf.mul       v5, v2, v3
    s.add        s9, s11, s2
    s.movz       s2, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s17, v0, #2
    s.muli       s18, s1, #2
    v.splat      v5, s17
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v8
    s.addi       s4, s5, #2
    s.add        s16, s18, s8
    v.splat      v2, s4
    s.add        s4, s16, s15
    vf.mul       v7, v4, v3
    s.add        s16, s11, s4
    s.movz       s4, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s17, v0, #3
    s.muli       s18, s1, #3
    v.splat      v7, s17
    s.addi       s17, s5, #3
    @p4 v.st.h       [s7, #0], v4
    a.vread      v4, a3, s6
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s6, s18, s8
    v.splat      v4, s17
    s.add        s7, s6, s15
    s.movz       s6, #4
    vf.mul       v8, v2, v3
    s.add        s17, s11, s7
    v.extract    s7, v0, #4
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #4
    s.addi       s18, s5, #4
    v.splat      v8, s18
    @p3 v.st.h       [s9, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s7, s8
    s.movz       s7, #5
    s.add        s9, s2, s15
    v.extract    s2, v0, #5
    vf.mul       v5, v4, v3
    s.add        s18, s11, s9
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #5
    s.addi       s9, s5, #5
    v.splat      v5, s9
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s4, s2, s8
    s.movz       s2, #6
    s.add        s9, s4, s15
    v.extract    s4, v0, #6
    vf.mul       v7, v8, v3
    s.add        s16, s11, s9
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #6
    s.addi       s9, s5, #6
    v.splat      v7, s9
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s6, s4, s8
    s.movz       s4, #7
    s.add        s9, s6, s15
    v.extract    s6, v0, #7
    vf.mul       v2, v5, v3
    s.add        s17, s11, s9
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v2
    s.muli       s6, s1, #7
    s.addi       s9, s5, #7
    v.splat      v2, s9
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s7
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s7, s6, s8
    s.movz       s6, #8
    s.add        s9, s7, s15
    v.extract    s7, v0, #8
    vf.mul       v4, v7, v3
    s.add        s18, s11, s9
    v.splat      v7, s7
    vf.cvt.f32.bf16 v9, v4
    s.muli       s7, s1, #8
    s.addi       s9, s5, #8
    v.splat      v4, s9
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s2, s7, s8
    s.movz       s7, #9
    s.add        s9, s2, s15
    v.extract    s2, v0, #9
    vf.mul       v8, v2, v3
    s.add        s16, s11, s9
    v.splat      v2, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #9
    s.addi       s9, s5, #9
    v.splat      v8, s9
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s8
    s.movz       s2, #10
    s.add        s9, s4, s15
    v.extract    s4, v0, #10
    vf.mul       v5, v4, v3
    s.add        s17, s11, s9
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #10
    s.addi       s9, s5, #10
    v.splat      v5, s9
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s6, s4, s8
    s.movz       s4, #11
    s.add        s9, s6, s15
    v.extract    s6, v0, #11
    vf.mul       v7, v8, v3
    s.add        s18, s11, s9
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v7
    s.muli       s6, s1, #11
    s.addi       s9, s5, #11
    v.splat      v7, s9
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a3, s7
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s7, s6, s8
    s.movz       s6, #12
    s.add        s9, s7, s15
    v.extract    s7, v0, #12
    vf.mul       v2, v5, v3
    s.add        s16, s11, s9
    v.splat      v5, s7
    vf.cvt.f32.bf16 v9, v2
    s.muli       s7, s1, #12
    s.addi       s9, s5, #12
    v.splat      v2, s9
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s2, s7, s8
    s.movz       s7, #13
    s.add        s9, s2, s15
    v.extract    s2, v0, #13
    vf.mul       v4, v7, v3
    s.add        s17, s11, s9
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #13
    s.addi       s9, s5, #13
    v.splat      v4, s9
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s4, s2, s8
    s.movz       s2, #14
    s.add        s9, s4, s15
    v.extract    s4, v0, #14
    vf.mul       v8, v2, v3
    s.add        s18, s11, s9
    v.splat      v2, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #14
    s.addi       s9, s5, #14
    v.splat      v8, s9
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s6, s4, s8
    s.movz       s4, #15
    s.add        s9, s6, s15
    v.extract    s6, v0, #15
    vf.mul       v5, v4, v3
    s.add        s16, s11, s9
    v.splat      v4, s6
    vf.cvt.f32.bf16 v9, v5
    s.muli       s6, s1, #15
    s.addi       s9, s5, #15
    v.splat      v5, s9
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s7
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s7, s6, s8
    s.movz       s6, #0
    s.add        s9, s7, s15
    v.extract    s7, v0, #0
    vf.mul       v7, v8, v3
    s.add        s15, s11, s9
    v.splat      v8, s7
    vf.cvt.f32.bf16 v9, v7
    s.add        s7, s6, s12                     // the tile origin
    s.muli       s9, s12, #2
    v.splat      v7, s7
    v.splat      v10, s5
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s2, s6, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v7, s2
    s.add        s2, s8, s9
    vf.mul       v9, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s7, s11, s2
    s.movz       s2, #1
    vf.cvt.f32.bf16 v5, v9
    v.extract    s12, v0, #1
    s.muli       s17, s1, #1
    v.splat      v9, s12
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a3, s4
    v.cmp.lt     p2, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s4, s5, #1
    s.add        s12, s17, s8
    v.splat      v4, s4
    s.add        s4, s12, s9
    vf.mul       v5, v2, v3
    s.add        s12, s11, s4
    s.movz       s4, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s16, v0, #2
    s.muli       s17, s1, #2
    v.splat      v5, s16
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a4, s6
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v8
    s.addi       s6, s5, #2
    s.add        s15, s17, s8
    v.splat      v2, s6
    s.add        s6, s15, s9
    vf.mul       v7, v4, v3
    s.add        s15, s11, s6
    s.movz       s6, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s16, v0, #3
    s.muli       s17, s1, #3
    v.splat      v7, s16
    s.addi       s16, s5, #3
    @p4 v.st.h       [s7, #0], v4
    a.vread      v4, a4, s2
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s2, s17, s8
    v.splat      v4, s16
    s.add        s7, s2, s9
    s.movz       s2, #4
    vf.mul       v8, v2, v3
    s.add        s16, s11, s7
    v.extract    s7, v0, #4
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #4
    s.addi       s17, s5, #4
    v.splat      v8, s17
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s7, s8
    s.movz       s7, #5
    s.add        s12, s4, s9
    v.extract    s4, v0, #5
    vf.mul       v5, v4, v3
    s.add        s17, s11, s12
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #5
    s.addi       s12, s5, #5
    v.splat      v5, s12
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s6, s4, s8
    s.movz       s4, #6
    s.add        s12, s6, s9
    v.extract    s6, v0, #6
    vf.mul       v7, v8, v3
    s.add        s15, s11, s12
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v7
    s.muli       s6, s1, #6
    s.addi       s12, s5, #6
    v.splat      v7, s12
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s2, s6, s8
    s.movz       s6, #7
    s.add        s12, s2, s9
    v.extract    s2, v0, #7
    vf.mul       v2, v5, v3
    s.add        s16, s11, s12
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v2
    s.muli       s2, s1, #7
    s.addi       s12, s5, #7
    v.splat      v2, s12
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s7
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s7, s2, s8
    s.movz       s2, #8
    s.add        s12, s7, s9
    v.extract    s7, v0, #8
    vf.mul       v4, v7, v3
    s.add        s17, s11, s12
    v.splat      v7, s7
    vf.cvt.f32.bf16 v9, v4
    s.muli       s7, s1, #8
    s.addi       s12, s5, #8
    v.splat      v4, s12
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s4, s7, s8
    s.movz       s7, #9
    s.add        s12, s4, s9
    v.extract    s4, v0, #9
    vf.mul       v8, v2, v3
    s.add        s15, s11, s12
    v.splat      v2, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #9
    s.addi       s12, s5, #9
    v.splat      v8, s12
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s6, s4, s8
    s.movz       s4, #10
    s.add        s12, s6, s9
    v.extract    s6, v0, #10
    vf.mul       v5, v4, v3
    s.add        s16, s11, s12
    v.splat      v4, s6
    vf.cvt.f32.bf16 v9, v5
    s.muli       s6, s1, #10
    s.addi       s12, s5, #10
    v.splat      v5, s12
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s2, s6, s8
    s.movz       s6, #11
    s.add        s12, s2, s9
    v.extract    s2, v0, #11
    vf.mul       v7, v8, v3
    s.add        s17, s11, s12
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #11
    s.addi       s12, s5, #11
    v.splat      v7, s12
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a4, s7
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s7, s2, s8
    s.movz       s2, #12
    s.add        s12, s7, s9
    v.extract    s7, v0, #12
    vf.mul       v2, v5, v3
    s.add        s15, s11, s12
    v.splat      v5, s7
    vf.cvt.f32.bf16 v9, v2
    s.muli       s7, s1, #12
    s.addi       s12, s5, #12
    v.splat      v2, s12
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s4, s7, s8
    s.movz       s7, #13
    s.add        s12, s4, s9
    v.extract    s4, v0, #13
    vf.mul       v4, v7, v3
    s.add        s16, s11, s12
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #13
    s.addi       s12, s5, #13
    v.splat      v4, s12
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s6, s4, s8
    s.movz       s4, #14
    s.add        s12, s6, s9
    v.extract    s6, v0, #14
    vf.mul       v8, v2, v3
    s.add        s17, s11, s12
    v.splat      v2, s6
    vf.cvt.f32.bf16 v9, v8
    s.muli       s6, s1, #14
    s.addi       s12, s5, #14
    v.splat      v8, s12
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s6, s8
    s.movz       s6, #15
    s.add        s12, s2, s9
    v.extract    s2, v0, #15
    vf.mul       v5, v4, v3
    s.add        s15, s11, s12
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #15
    s.addi       s12, s5, #15
    v.splat      v5, s12
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s7
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s7, s2, s8
    s.movz       s2, #0
    s.add        s12, s7, s9
    v.extract    s7, v0, #0
    vf.mul       v7, v8, v3
    s.add        s9, s11, s12
    v.splat      v8, s7
    vf.cvt.f32.bf16 v9, v7
    s.add        s7, s2, s10                     // the tile origin
    s.muli       s12, s10, #2
    v.splat      v7, s7
    v.splat      v10, s5
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s4, s2, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v7, s4
    s.add        s4, s8, s12
    vf.mul       v9, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s7, s11, s4
    s.movz       s4, #1
    vf.cvt.f32.bf16 v5, v9
    v.extract    s10, v0, #1
    s.muli       s16, s1, #1
    v.splat      v9, s10
    @p4 v.st.h       [s15, #0], v5
    a.vread      v5, a4, s6
    v.cmp.lt     p2, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s6, s5, #1
    s.add        s10, s16, s8
    v.splat      v4, s6
    s.add        s6, s10, s12
    vf.mul       v5, v2, v3
    s.add        s10, s11, s6
    s.movz       s6, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s15, v0, #2
    s.muli       s16, s1, #2
    v.splat      v5, s15
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v8
    s.addi       s2, s5, #2
    s.add        s9, s16, s8
    v.splat      v2, s2
    s.add        s2, s9, s12
    vf.mul       v7, v4, v3
    s.add        s9, s11, s2
    s.movz       s2, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s15, v0, #3
    s.muli       s16, s1, #3
    v.splat      v7, s15
    s.addi       s15, s5, #3
    @p4 v.st.h       [s7, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s4, s16, s8
    v.splat      v4, s15
    s.add        s7, s4, s12
    s.movz       s4, #4
    vf.mul       v8, v2, v3
    s.add        s15, s11, s7
    v.extract    s7, v0, #4
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #4
    s.addi       s16, s5, #4
    v.splat      v8, s16
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s6, s7, s8
    s.movz       s7, #5
    s.add        s10, s6, s12
    v.extract    s6, v0, #5
    vf.mul       v5, v4, v3
    s.add        s16, s11, s10
    v.splat      v4, s6
    vf.cvt.f32.bf16 v9, v5
    s.muli       s6, s1, #5
    s.addi       s10, s5, #5
    v.splat      v5, s10
    @p4 v.st.h       [s9, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s2, s6, s8
    s.movz       s6, #6
    s.add        s9, s2, s12
    v.extract    s2, v0, #6
    vf.mul       v7, v8, v3
    s.add        s10, s11, s9
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #6
    s.addi       s9, s5, #6
    v.splat      v7, s9
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s4, s2, s8
    s.movz       s2, #7
    s.add        s9, s4, s12
    v.extract    s4, v0, #7
    vf.mul       v2, v5, v3
    s.add        s15, s11, s9
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v2
    s.muli       s4, s1, #7
    s.addi       s9, s5, #7
    v.splat      v2, s9
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s7
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s7, s4, s8
    s.movz       s4, #8
    s.add        s9, s7, s12
    v.extract    s7, v0, #8
    vf.mul       v4, v7, v3
    s.add        s16, s11, s9
    v.splat      v7, s7
    vf.cvt.f32.bf16 v9, v4
    s.muli       s7, s1, #8
    s.addi       s9, s5, #8
    v.splat      v4, s9
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s6, s7, s8
    s.movz       s7, #9
    s.add        s9, s6, s12
    v.extract    s6, v0, #9
    vf.mul       v8, v2, v3
    s.add        s10, s11, s9
    v.splat      v2, s6
    vf.cvt.f32.bf16 v9, v8
    s.muli       s6, s1, #9
    s.addi       s9, s5, #9
    v.splat      v8, s9
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s6, s8
    s.movz       s6, #10
    s.add        s9, s2, s12
    v.extract    s2, v0, #10
    vf.mul       v5, v4, v3
    s.add        s15, s11, s9
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #10
    s.addi       s9, s5, #10
    v.splat      v5, s9
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s4, s2, s8
    s.movz       s2, #11
    s.add        s9, s4, s12
    v.extract    s4, v0, #11
    vf.mul       v7, v8, v3
    s.add        s16, s11, s9
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #11
    s.addi       s9, s5, #11
    v.splat      v7, s9
    @p4 v.st.h       [s10, #0], v9
    a.vread      v9, a5, s7
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s7, s4, s8
    s.movz       s4, #12
    s.add        s9, s7, s12
    v.extract    s7, v0, #12
    vf.mul       v2, v5, v3
    s.add        s10, s11, s9
    v.splat      v5, s7
    vf.cvt.f32.bf16 v9, v2
    s.muli       s7, s1, #12
    s.addi       s9, s5, #12
    v.splat      v2, s9
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s6, s7, s8
    s.movz       s7, #13
    s.add        s9, s6, s12
    v.extract    s6, v0, #13
    vf.mul       v4, v7, v3
    s.add        s15, s11, s9
    v.splat      v7, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s9, s5, #13
    v.splat      v4, s9
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s2, s6, s8
    s.movz       s6, #14
    s.add        s9, s2, s12
    v.extract    s2, v0, #14
    vf.mul       v8, v2, v3
    s.add        s16, s11, s9
    v.splat      v2, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #14
    s.addi       s9, s5, #14
    v.splat      v8, s9
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s8
    s.movz       s2, #15
    s.add        s9, s4, s12
    v.extract    s4, v0, #15
    vf.mul       v5, v4, v3
    s.add        s10, s11, s9
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #15
    s.addi       s9, s5, #15
    v.splat      v5, s9
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a5, s7
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s7, s4, s8
    s.movz       s4, #0
    s.add        s9, s7, s12
    v.extract    s7, v0, #0
    vf.mul       v7, v8, v3
    s.add        s12, s11, s9
    v.splat      v8, s7
    vf.cvt.f32.bf16 v9, v7
    s.add        s7, s4, s14                     // the tile origin
    s.muli       s9, s14, #2
    v.splat      v7, s7
    v.splat      v10, s5
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s6, s4, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v7, s6
    s.add        s6, s8, s9
    vf.mul       v9, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s7, s11, s6
    s.movz       s6, #1
    vf.cvt.f32.bf16 v5, v9
    v.extract    s14, v0, #1
    s.muli       s15, s1, #1
    v.splat      v9, s14
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a5, s2
    v.cmp.lt     p2, v2, v7
    p.and        p4, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s2, s5, #1
    s.add        s10, s15, s8
    v.splat      v4, s2
    s.add        s2, s10, s9
    vf.mul       v5, v2, v3
    s.add        s10, s11, s2
    s.movz       s2, #2
    vf.cvt.f32.bf16 v2, v5
    v.extract    s14, v0, #2
    s.muli       s15, s1, #2
    v.splat      v5, s14
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v2, v8
    s.addi       s4, s5, #2
    s.add        s12, s15, s8
    v.splat      v2, s4
    s.add        s4, s12, s9
    vf.mul       v7, v4, v3
    s.add        s12, s11, s4
    s.movz       s4, #3
    vf.cvt.f32.bf16 v4, v7
    v.extract    s14, v0, #3
    s.muli       s15, s1, #3
    v.splat      v7, s14
    s.addi       s14, s5, #3
    @p4 v.st.h       [s7, #0], v4
    a.vread      v4, a6, s6
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v4, v9
    s.add        s6, s15, s8
    v.splat      v4, s14
    s.add        s7, s6, s9
    s.movz       s6, #4
    vf.mul       v8, v2, v3
    s.add        s14, s11, s7
    v.extract    s7, v0, #4
    v.splat      v2, s7
    vf.cvt.f32.bf16 v9, v8
    s.muli       s7, s1, #4
    s.addi       s15, s5, #4
    v.splat      v8, s15
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s7, s8
    s.movz       s7, #5
    s.add        s10, s2, s9
    v.extract    s2, v0, #5
    vf.mul       v5, v4, v3
    s.add        s15, s11, s10
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #5
    s.addi       s10, s5, #5
    v.splat      v5, s10
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s4, s2, s8
    s.movz       s2, #6
    s.add        s10, s4, s9
    v.extract    s4, v0, #6
    vf.mul       v7, v8, v3
    s.add        s12, s11, s10
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #6
    s.addi       s10, s5, #6
    v.splat      v7, s10
    @p3 v.st.h       [s14, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s6, s4, s8
    s.movz       s4, #7
    s.add        s10, s6, s9
    v.extract    s6, v0, #7
    vf.mul       v2, v5, v3
    s.add        s14, s11, s10
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v2
    s.muli       s6, s1, #7
    s.addi       s10, s5, #7
    v.splat      v2, s10
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a6, s7
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s7, s6, s8
    s.movz       s6, #8
    s.add        s10, s7, s9
    v.extract    s7, v0, #8
    vf.mul       v4, v7, v3
    s.add        s15, s11, s10
    v.splat      v7, s7
    vf.cvt.f32.bf16 v9, v4
    s.muli       s7, s1, #8
    s.addi       s10, s5, #8
    v.splat      v4, s10
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v9, v8
    s.add        s2, s7, s8
    s.movz       s7, #9
    s.add        s10, s2, s9
    v.extract    s2, v0, #9
    vf.mul       v8, v2, v3
    s.add        s12, s11, s10
    v.splat      v2, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #9
    s.addi       s10, s5, #9
    v.splat      v8, s10
    @p4 v.st.h       [s14, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s8
    s.movz       s2, #10
    s.add        s10, s4, s9
    v.extract    s4, v0, #10
    vf.mul       v5, v4, v3
    s.add        s14, s11, s10
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #10
    s.addi       s10, s5, #10
    v.splat      v5, s10
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v7
    s.add        s6, s4, s8
    s.movz       s4, #11
    s.add        s10, s6, s9
    v.extract    s6, v0, #11
    vf.mul       v7, v8, v3
    s.add        s15, s11, s10
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v7
    s.muli       s6, s1, #11
    s.addi       s10, s5, #11
    v.splat      v7, s10
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s7
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v2
    s.add        s7, s6, s8
    s.movz       s6, #12
    s.add        s10, s7, s9
    v.extract    s7, v0, #12
    vf.mul       v2, v5, v3
    s.add        s12, s11, s10
    v.splat      v5, s7
    vf.cvt.f32.bf16 v9, v2
    s.muli       s7, s1, #12
    s.addi       s10, s5, #12
    v.splat      v2, s10
    @p3 v.st.h       [s14, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s2, s7, s8
    s.movz       s7, #13
    s.add        s10, s2, s9
    v.extract    s2, v0, #13
    vf.mul       v4, v7, v3
    s.add        s14, s11, s10
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #13
    s.addi       s10, s5, #13
    v.splat      v4, s10
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v9, v8
    s.add        s4, s2, s8
    s.movz       s2, #14
    s.add        s10, s4, s9
    v.extract    s4, v0, #14
    vf.mul       v8, v2, v3
    s.add        s15, s11, s10
    v.splat      v2, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #14
    s.addi       s10, s5, #14
    v.splat      v8, s10
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s6, s4, s8
    s.movz       s4, #15
    s.add        s10, s6, s9
    v.extract    s6, v0, #15
    vf.mul       v5, v4, v3
    s.add        s12, s11, s10
    v.splat      v4, s6
    vf.cvt.f32.bf16 v9, v5
    s.muli       s6, s1, #15
    s.addi       s10, s5, #15
    v.splat      v5, s10
    @p4 v.st.h       [s14, #0], v9
    a.vread      v9, a6, s7
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v7
    s.add        s7, s6, s8
    s.movz       s6, #0
    s.add        s10, s7, s9
    v.extract    s7, v0, #0
    vf.mul       v7, v8, v3
    s.add        s9, s11, s10
    v.splat      v8, s7
    vf.cvt.f32.bf16 v9, v7
    s.add        s7, s6, s13                     // the tile origin
    s.muli       s10, s13, #2
    v.splat      v7, s7
    v.splat      v10, s5
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v2
    s.add        s2, s6, s3                      // the tile origin
    v.add        v2, v1, v7
    v.splat      v1, s2
    s.add        s2, s8, s10
    vf.mul       v7, v5, v3
    v.cmp.lt     p1, v10, v6
    s.add        s3, s11, s2
    s.movz       s2, #1
    vf.cvt.f32.bf16 v5, v7
    v.extract    s7, v0, #1
    s.muli       s13, s1, #1
    v.splat      v7, s7
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    vf.mul       v1, v5, v4
    s.addi       s4, s5, #1
    s.add        s7, s13, s8
    v.splat      v2, s4
    s.add        s4, s7, s10
    vf.mul       v4, v1, v3
    s.add        s7, s11, s4
    s.movz       s4, #2
    vf.cvt.f32.bf16 v1, v4
    v.extract    s12, v0, #2
    s.muli       s13, s1, #2
    v.splat      v4, s12
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v1, v8
    s.addi       s6, s5, #2
    s.add        s9, s13, s8
    v.splat      v1, s6
    s.add        s6, s9, s10
    vf.mul       v5, v2, v3
    s.add        s9, s11, s6
    s.movz       s6, #3
    vf.cvt.f32.bf16 v2, v5
    v.extract    s12, v0, #3
    s.muli       s13, s1, #3
    v.splat      v5, s12
    s.addi       s12, s5, #3
    @p4 v.st.h       [s3, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v6
    p.and        p4, p1, p2
    vf.mul       v1, v2, v7
    s.add        s2, s13, s8
    v.splat      v2, s12
    s.add        s3, s2, s10
    s.movz       s2, #4
    vf.mul       v7, v1, v3
    s.add        s12, s11, s3
    v.extract    s3, v0, #4
    v.splat      v1, s3
    vf.cvt.f32.bf16 v8, v7
    s.muli       s3, s1, #4
    s.addi       s13, s5, #4
    v.splat      v7, s13
    @p3 v.st.h       [s7, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v8, v4
    s.add        s4, s3, s8
    s.movz       s3, #5
    s.add        s7, s4, s10
    v.extract    s4, v0, #5
    vf.mul       v4, v2, v3
    s.add        s13, s11, s7
    v.splat      v2, s4
    vf.cvt.f32.bf16 v8, v4
    s.muli       s4, s1, #5
    s.addi       s7, s5, #5
    v.splat      v4, s7
    @p4 v.st.h       [s9, #0], v8
    a.vread      v8, a7, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v8, v5
    s.add        s6, s4, s8
    s.movz       s4, #6
    s.add        s7, s6, s10
    v.extract    s6, v0, #6
    vf.mul       v5, v7, v3
    s.add        s9, s11, s7
    v.splat      v7, s6
    vf.cvt.f32.bf16 v8, v5
    s.muli       s6, s1, #6
    s.addi       s7, s5, #6
    v.splat      v5, s7
    @p3 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v1
    s.add        s2, s6, s8
    s.movz       s6, #7
    s.add        s7, s2, s10
    v.extract    s2, v0, #7
    vf.mul       v1, v4, v3
    s.add        s12, s11, s7
    v.splat      v4, s2
    vf.cvt.f32.bf16 v8, v1
    s.muli       s2, s1, #7
    s.addi       s7, s5, #7
    v.splat      v1, s7
    @p4 v.st.h       [s13, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v8, v2
    s.add        s3, s2, s8
    s.movz       s2, #8
    s.add        s7, s3, s10
    v.extract    s3, v0, #8
    vf.mul       v2, v5, v3
    s.add        s13, s11, s7
    v.splat      v5, s3
    vf.cvt.f32.bf16 v8, v2
    s.muli       s3, s1, #8
    s.addi       s7, s5, #8
    v.splat      v2, s7
    @p3 v.st.h       [s9, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v1, v6
    p.and        p3, p1, p2
    vf.mul       v1, v8, v7
    s.add        s4, s3, s8
    s.movz       s3, #9
    s.add        s7, s4, s10
    v.extract    s4, v0, #9
    vf.mul       v7, v1, v3
    s.add        s9, s11, s7
    v.splat      v1, s4
    vf.cvt.f32.bf16 v8, v7
    s.muli       s4, s1, #9
    s.addi       s7, s5, #9
    v.splat      v7, s7
    @p4 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s6
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v8, v4
    s.add        s6, s4, s8
    s.movz       s4, #10
    s.add        s7, s6, s10
    v.extract    s6, v0, #10
    vf.mul       v4, v2, v3
    s.add        s12, s11, s7
    v.splat      v2, s6
    vf.cvt.f32.bf16 v8, v4
    s.muli       s6, s1, #10
    s.addi       s7, s5, #10
    v.splat      v4, s7
    @p3 v.st.h       [s13, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    s.add        s2, s6, s8
    s.movz       s6, #11
    s.add        s7, s2, s10
    v.extract    s2, v0, #11
    vf.mul       v5, v7, v3
    s.add        s13, s11, s7
    v.splat      v7, s2
    vf.cvt.f32.bf16 v8, v5
    s.muli       s2, s1, #11
    s.addi       s7, s5, #11
    v.splat      v5, s7
    @p4 v.st.h       [s9, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v8, v1
    s.add        s3, s2, s8
    s.movz       s2, #12
    s.add        s7, s3, s10
    v.extract    s3, v0, #12
    vf.mul       v1, v4, v3
    s.add        s9, s11, s7
    v.splat      v4, s3
    vf.cvt.f32.bf16 v8, v1
    s.muli       s3, s1, #12
    s.addi       s7, s5, #12
    v.splat      v1, s7
    @p3 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v8, v2
    s.add        s4, s3, s8
    s.movz       s3, #13
    s.add        s7, s4, s10
    v.extract    s4, v0, #13
    vf.mul       v2, v5, v3
    s.add        s12, s11, s7
    v.splat      v5, s4
    vf.cvt.f32.bf16 v8, v2
    s.muli       s4, s1, #13
    s.addi       s7, s5, #13
    v.splat      v2, s7
    @p4 v.st.h       [s13, #0], v8
    a.vread      v8, a7, s6
    v.cmp.lt     p1, v1, v6
    p.and        p4, p1, p2
    vf.mul       v1, v8, v7
    s.add        s6, s4, s8
    s.movz       s4, #14
    s.add        s7, s6, s10
    v.extract    s6, v0, #14
    vf.mul       v7, v1, v3
    s.add        s13, s11, s7
    v.splat      v1, s6
    vf.cvt.f32.bf16 v8, v7
    s.muli       s6, s1, #14
    s.addi       s7, s5, #14
    v.splat      v7, s7
    @p3 v.st.h       [s9, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v8, v4
    s.add        s2, s6, s8
    s.movz       s6, #15
    s.add        s7, s2, s10
    v.extract    s2, v0, #15
    vf.mul       v0, v2, v3
    s.add        s9, s11, s7
    v.splat      v2, s2
    vf.cvt.f32.bf16 v4, v0
    s.muli       s2, s1, #15
    s.addi       s1, s5, #15
    v.splat      v0, s1
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a7, s3
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v4, v5
    s.add        s1, s2, s8
    s.add        s2, s1, s10
    vf.mul       v4, v7, v3
    s.add        s1, s11, s2
    vf.cvt.f32.bf16 v5, v4
    @p3 v.st.h       [s13, #0], v5
    a.vread      v4, a7, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v1
    vf.mul       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a7, s6
    vf.mul       v1, v0, v2
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s1, #0], v1
    exit
    exit
